Feature: Iteration 5 MRs

  Scenario: MR18 Deleting an order should make it inaccessible
    Given a seed input that retrieves an order by a valid order ID within the supported range documented by the API, producing a seed output with that order's details for MR18.
    When a follow-up input is created by deleting the order with the same valid order ID and then attempting to retrieve the order again, yielding a follow-up output for MR18.
    Then the follow-up output should indicate that the order is not found (for example, via an appropriate error status or message), differing from the seed output which contained the order's details for MR18.

  Scenario: MR20 Retrieving an order by ID should return consistent details
    Given a seed input that retrieves an order by a valid order ID within the supported range documented by the API, producing a seed output with that order's details for MR20.
    When a follow-up input is created by retrieving the same order by the same valid ID again without modifying or deleting it in between, yielding a follow-up output for MR20.
    Then the follow-up output should be identical to the seed output for MR20, as the order details should remain consistent for repeated retrievals of the same unchanged order.
