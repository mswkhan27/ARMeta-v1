from behave import given, when, then
import os
import json
import requests
import time

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that retrieves an order by a valid order ID within the supported range documented by the API, producing a seed output with that order's details for MR18.")
def _mr_MR18_seed_input(context):
    # Create an order to ensure we have a valid order ID
    order_data = {
        "petId": 198772,
        "quantity": 1,
        "status": "placed",
        "complete": True
    }
    response = requests.post(
        f"{BASE_URL}/store/order",
        json=order_data,
        timeout=10
    )
    context.seed_request = response

    # Safely parse JSON (avoid ValueError)
    try:
        context.seed_response = response.json()
    except ValueError:
        context.seed_response = {}

    assert response.status_code == 200, f"Failed to create order: {context.seed_response}"
    assert isinstance(context.seed_response, dict), f"Unexpected response type: {type(context.seed_response)}"
    assert 'id' in context.seed_response, f"Response does not contain 'id': {context.seed_response}"


@when("a follow-up input is created by deleting the order with the same valid order ID and then attempting to retrieve the order again, yielding a follow-up output for MR18.")
def _mr_MR18_followup_input(context):
    # Safely retrieve order ID
    seed_response = getattr(context, "seed_response", None)
    assert isinstance(seed_response, dict), f"seed_response is not a dict: {type(seed_response)}"
    order_id = seed_response.get('id')
    assert order_id is not None, f"No 'id' found in seed_response: {seed_response}"

    # Ensure order_id is an integer within supported range (< 1000)
    try:
        order_id_int = int(order_id)
    except (TypeError, ValueError):
        raise AssertionError(f"Order id is not convertible to int: {order_id}")

    assert order_id_int < 1000, f"Order id {order_id_int} is out of supported delete range (< 1000)"

    # Delete the order
    delete_response = requests.delete(
        f"{BASE_URL}/store/order/{order_id_int}",
        timeout=10
    )
    context.delete_request = delete_response

    # 200 is the documented success response; if API returns another code, surface it clearly
    assert delete_response.status_code == 200, (
        f"Failed to delete order {order_id_int}: "
        f"status={delete_response.status_code}, body={delete_response.text}"
    )

    # Attempt to retrieve the deleted order
    followup_request = requests.get(
        f"{BASE_URL}/store/order/{order_id_int}",
        timeout=10
    )
    context.followup_request = followup_request

    # Safely parse JSON (avoid ValueError)
    try:
        context.followup_response = followup_request.json()
    except ValueError:
        context.followup_response = {}


@then("the follow-up output should indicate that the order is not found (for example, via an appropriate error status or message), differing from the seed output which contained the order's details for MR18.")
def _mr_MR18_followup_output(context):
    followup_request = getattr(context, "followup_request", None)
    followup_response = getattr(context, "followup_response", {})

    assert followup_request is not None, "followup_request is not set in context"
    status_code = followup_request.status_code

    # According to the spec, 404 is the canonical 'Order not found' response.
    # Some implementations may respond with 404 and possibly a body or no body.
    assert status_code == 404, (
        f"Expected 404 Not Found after deleting order, "
        f"got {status_code} with body: {followup_request.text}"
    )

    # Ensure the seed output had order details and differs from follow-up output
    seed_response = getattr(context, "seed_response", None)
    assert isinstance(seed_response, dict), f"seed_response is not a dict: {type(seed_response)}"

    # Seed response should have had an id and possibly other details
    assert 'id' in seed_response, f"Seed response does not contain 'id': {seed_response}"

    # Follow-up response should not be identical to seed response
    if isinstance(followup_response, dict):
        assert followup_response != seed_response, (
            f"Follow-up response should differ from seed response after deletion. "
            f"Seed: {seed_response}, Follow-up: {followup_response}"
        )

# ----




@given("a seed input that retrieves an order by a valid order ID within the supported range documented by the API, producing a seed output with that order's details for MR20.")
def _mr_MR20_seed_input(context):
    # Create a new order to ensure we have a valid order ID
    order_data = {
        "petId": 198772,
        "quantity": 1,
        "status": "placed",
        "complete": True
    }

    try:
        response = requests.post(f"{BASE_URL}/store/order", json=order_data, timeout=10)
    except requests.RequestException as e:
        assert False, f"HTTP error while creating order: {e}"

    # Safely handle non-JSON or empty responses
    try:
        response_json = response.json()
    except ValueError:
        response_json = None

    assert response.status_code == 200, f"Failed to create order, status={response.status_code}, body={response.text}"

    # Ensure the response JSON is a dict and contains an 'id'
    assert isinstance(response_json, dict), f"Unexpected response format when creating order: {response_json}"
    assert 'id' in response_json, f"Order creation response missing 'id': {response_json}"

    context.seed_create_response = response
    context.seed_response = response_json
    context.seed_order_id = response_json['id']


@when("a follow-up input is created by retrieving the same order by the same valid ID again without modifying or deleting it in between, yielding a follow-up output for MR20.")
def _mr_MR20_followup_input(context):
    # Safely obtain the order id from context
    order_id = getattr(context, "seed_order_id", None)
    assert order_id is not None, "seed_order_id not set in context"

    try:
        response = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    except requests.RequestException as e:
        assert False, f"HTTP error while retrieving order: {e}"

    try:
        response_json = response.json()
    except ValueError:
        response_json = None

    assert response.status_code == 200, f"Failed to retrieve order, status={response.status_code}, body={response.text}"
    assert isinstance(response_json, dict), f"Unexpected response format when retrieving order: {response_json}"

    context.followup_request = response
    context.followup_response = response_json


@then("the follow-up output should be identical to the seed output for MR20, as the order details should remain consistent for repeated retrievals of the same unchanged order.")
def _mr_MR20_assertion(context):
    seed_response = getattr(context, "seed_response", None)
    followup_response = getattr(context, "followup_response", None)

    assert isinstance(seed_response, dict), f"seed_response is not a dict: {seed_response}"
    assert isinstance(followup_response, dict), f"followup_response is not a dict: {followup_response}"

    # Compare JSON structures by value
    assert followup_response == seed_response, (
        f"Follow-up output does not match seed output.\n"
        f"Seed: {json.dumps(seed_response, sort_keys=True)}\n"
        f"Follow-up: {json.dumps(followup_response, sort_keys=True)}"
    )
