
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new available pet should increase the count of available pets
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of available pets for MR1.
    When a follow-up input is created by adding a new pet whose status is set to 'available', yielding a follow-up output for MR1.
    Then the follow-up output should have a count of available pets that is exactly one more than the seed output for MR1.

  Scenario: MR2 Updating a pet's status should change the results of the status filter
    Given a seed input that retrieves the list of pets filtered by status 'pending', producing a seed output with a list of pending pets for MR2.
    When a follow-up input is created by updating an existing pet's status from 'available' to 'pending', and then retrieving the list of pets filtered by status 'pending' again, yielding a follow-up output for MR2.
    Then the follow-up output should include the updated pet in the list of pending pets and should have a count of pending pets that is exactly one more than the seed output for MR2.

  Scenario: MR3 Deleting a pet should decrease the count of pets for its status
    Given a seed input that retrieves the list of pets filtered by a specific status (for example, 'available'), producing a seed output with a count of pets for that status for MR3.
    When a follow-up input is created by deleting an existing pet that has that same status, and then retrieving again the list of pets filtered by that status, yielding a follow-up output for MR3.
    Then the follow-up output should have a count of pets for that status that is exactly one less than the seed output for MR3.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR4 Uploading an image for a pet should not change the pet's other attributes
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR4.
    When a follow-up input is created by first uploading an image for the same pet ID and then retrieving the pet again, yielding a follow-up output with the updated pet details for MR4.
    Then the follow-up output should have the same pet details as the seed output for MR4, since uploading an image does not modify the stored pet attributes.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR5 Deleting a user should make the user inaccessible
    Given a seed input that retrieves a user by a valid username, producing a seed output with that user's details for MR5.
    When a follow-up input is created by deleting the user with the same username, and then attempting to retrieve the user again, yielding a follow-up output for MR5.
    Then the follow-up output should indicate that the user is not found (for example, via an appropriate error response), differing from the seed output which contained the user's details for MR5.

  Scenario: MR7 Logging in multiple times with the same credentials should behave consistently
    Given a seed input that attempts to log in with valid credentials, producing a seed output that is a successful login response body and associated headers for MR7.
    When a follow-up input is created by logging in again with the same valid credentials, yielding a follow-up output for MR7.
    Then the follow-up output should again be a successful login response of the same type (for example, a non-empty string body and relevant headers), consistent with the seed output pattern for MR7, even if the exact body value may be the same or different.

  Scenario: MR8 Retrieving inventory should reflect current stock levels by status
    Given a seed input that retrieves the pet inventory grouped by status, producing a seed output that maps each status to a quantity for MR8.
    When a follow-up input is created by adding a new pet with a specific valid status, and then retrieving the inventory again, yielding a follow-up output for MR8.
    Then the follow-up output should show a quantity for the specific status that is at least one greater than (or, if the status key was previously absent, at least 1 instead of absent in) the corresponding value in the seed output for MR8, assuming no concurrent deletions or updates reduce that status count.

  Scenario: MR9 Finding pets by tags should return pets with those tags
    Given a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR9.
    When a follow-up input is created by adding a new pet that includes the same tag value in its tag list, and then retrieving pets filtered by that tag value again, yielding a follow-up output for MR9.
    Then the follow-up output should include the newly added pet among the returned pets with that tag, making it a superset of or equal to the seed output list for MR9, assuming no concurrent deletions of pets with that tag.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR12 Updating a user's details should reflect in subsequent retrievals
    Given a seed input that retrieves a user by user name, producing a seed output with the user's details for MR12.
    When a follow-up input is created by updating the user's details and then retrieving the same user again, yielding a follow-up output for MR12.
    Then the follow-up output should show the updated values for the fields provided in the update request for MR12.

  Scenario: MR14 Logging out should not affect the user's stored data
    Given a seed input that retrieves a user by user name, producing a seed output with the user's details for MR14.
    When a follow-up input is created by logging the user out and then retrieving the same user again, yielding a follow-up output for MR14.
    Then the follow-up output should be identical to the seed output for MR14, as logging out does not change stored user data.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR15 Updating a pet should correctly modify the specified fields
    Given a seed input that retrieves a pet by ID, producing a seed output with that pet's current details for MR15.
    When a follow-up input is created by updating the pet's name via a request that only changes the name, and then retrieving the pet again, yielding a follow-up output for MR15.
    Then the follow-up output should have the updated name while all other pet fields remain identical to the seed output for MR15.

  Scenario: MR16 Retrieving inventory should reflect changes in pet stock levels
    Given a seed input that retrieves the pet inventory grouped by status, producing a seed output that maps each status to a quantity for MR16.
    When a follow-up input is created by deleting an existing pet that currently has a specific status, and then retrieving the inventory again, yielding a follow-up output for MR16.
    Then the follow-up output should show, for that specific status, a quantity that is exactly one less than the corresponding value in the seed output for MR16, assuming at least one pet with that status existed initially.


# --- From iteration_5\features\mrs_iteration_5.feature ---

Feature: Iteration 5 MRs

  Scenario: MR18 Deleting an order should make it inaccessible
    Given a seed input that retrieves an order by a valid order ID within the supported range documented by the API, producing a seed output with that order's details for MR18.
    When a follow-up input is created by deleting the order with the same valid order ID and then attempting to retrieve the order again, yielding a follow-up output for MR18.
    Then the follow-up output should indicate that the order is not found (for example, via an appropriate error status or message), differing from the seed output which contained the order's details for MR18.

  Scenario: MR20 Retrieving an order by ID should return consistent details
    Given a seed input that retrieves an order by a valid order ID within the supported range documented by the API, producing a seed output with that order's details for MR20.
    When a follow-up input is created by retrieving the same order by the same valid ID again without modifying or deleting it in between, yielding a follow-up output for MR20.
    Then the follow-up output should be identical to the seed output for MR20, as the order details should remain consistent for repeated retrievals of the same unchanged order.


# --- From iteration_6\features\mrs_iteration_6.feature ---

Feature: Iteration 6 MRs

  Scenario: MR22 Adding a new pet should make it retrievable by ID
    Given a seed input that retrieves a pet by a specific ID, producing a seed output indicating whether the pet exists for MR22.
    When a follow-up input is created by adding a new pet whose data includes that specific ID using the operation that creates a new pet in the store, and then retrieving the pet by the same ID again, yielding a follow-up output for MR22.
    Then the follow-up output should indicate the presence of the newly added pet, differing from the seed output if the pet did not exist before for MR22.

  Scenario: MR24 Adding a pet with a unique ID should not affect existing pets with the same status
    Given a seed input that retrieves the list of pets filtered by a specific status value, producing a seed output with the current list of pets for that status for MR24.
    When a follow-up input is created by adding a new pet with a unique ID and the same status value using the operation that creates a new pet in the store, and then retrieving the list of pets for that same status value again, yielding a follow-up output for MR24.
    Then the follow-up output should be a superset of the seed output for that status value, containing all the pets from the seed output plus the newly added pet for MR24.

  Scenario: MR25 Creating users with a list should allow retrieval of each user by username
    Given a seed input that retrieves a user by username, producing a seed output indicating whether the user exists for MR25.
    When a follow-up input is created by adding a list of users using the operation that creates users from a list, and then retrieving each user by their username from the list using the operation that gets user details by username, yielding a follow-up output for MR25.
    Then the follow-up output should indicate the presence of each newly added user, differing from the seed output if the users did not exist before for MR25.


# --- From iteration_7\features\mrs_iteration_7.feature ---

Feature: Iteration 7 MRs

  Scenario: MR26 Adding a new pet with a previously unused ID should make it retrievable by that ID
    Given a seed input that attempts to retrieve a pet by a specific valid ID, producing a seed output that may indicate that no pet is currently associated with that ID for MR26.
    When a follow-up input is created by adding a new pet whose ID is set to that same valid ID using the operation that creates a new pet in the store, and then retrieving the pet by that ID again, yielding a follow-up output for MR26.
    Then the follow-up output should indicate the presence of a pet with that ID, differing from the seed output if the pet did not exist before for MR26.

  Scenario: MR27 Updating a pet's name while keeping all other fields the same should only change the name field
    Given a seed input that retrieves a pet by a valid ID, producing a seed output with that pet's current details for MR27.
    When a follow-up input is created by sending an update request for the same pet ID in which only the name field is changed and all other pet fields are provided with the same values as in the seed output, and then retrieving the pet again by that ID, yielding a follow-up output for MR27.
    Then the follow-up output should have the updated name while all other pet fields remain identical to the corresponding fields in the seed output for MR27.

  Scenario: MR28 Adding a pet with a specific status should increase the number of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a valid status value (available, pending, or sold), producing a seed output with a count of pets for that status for MR28.
    When a follow-up input is created by adding a new pet whose status is set to that same status value, and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR28.
    Then the follow-up output should have a count of pets for that status that is exactly one more than the seed output for MR28, assuming no other changes occurred to pets with that status in between.

  Scenario: MR29 Deleting a pet should make it inaccessible by ID
    Given a seed input that retrieves a pet by a valid ID for which a pet currently exists, producing a seed output with that pet's details for MR29.
    When a follow-up input is created by deleting the pet with that same valid ID and then attempting to retrieve the pet again by that ID, yielding a follow-up output for MR29.
    Then the follow-up output should indicate that the pet is not found for that ID, differing from the seed output which contained the pet's details for MR29.

  Scenario: MR30 Adding a pet with a specific tag should make it retrievable when filtering by that tag
    Given a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR30.
    When a follow-up input is created by adding a new pet that includes that same tag value in its tag list, and then retrieving pets filtered by that tag value again, yielding a follow-up output for MR30.
    Then the follow-up output should include the newly added pet among the returned pets with that tag, making the follow-up list a superset of or equal to the seed output list for MR30.


# --- From iteration_8\features\mrs_iteration_8.feature ---

Feature: Iteration 8 MRs

  Scenario: MR31 Adding a new pet with a chosen ID should make it retrievable by that ID
    Given a seed input that attempts to retrieve a pet by a specific valid numeric ID, producing a seed output that may indicate that no pet is currently associated with that ID for MR31.
    When a follow-up input is created by adding a new pet whose representation includes that same valid ID, and then retrieving the pet by that ID again, yielding a follow-up output for MR31.
    Then the follow-up output should indicate the presence of a pet resource associated with that ID, differing from the seed output if the pet did not exist before for MR31.

  Scenario: MR32 Adding a pet with a specific status should increase the number of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a valid status value (available, pending, or sold), producing a seed output with a count of pets for that status for MR32.
    When a follow-up input is created by adding a new pet whose status property is set to that same status value, and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR32.
    Then the follow-up output should have a count of pets for that status that is at least one more than the seed output for MR32, assuming no other changes occurred to pets with that status in between and that the added pet was not already present with that status.

  Scenario: MR33 Adding a pet with a specific tag should make it retrievable when filtering by that tag
    Given a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR33.
    When a follow-up input is created by adding a new pet whose tag list includes that same tag value, and then retrieving pets filtered by that tag value again, yielding a follow-up output for MR33.
    Then the follow-up output should include the newly added pet among the returned pets with that tag, making the follow-up list a superset of or equal to the seed output list for MR33.


# --- From iteration_9\features\mrs_iteration_9.feature ---

Feature: Iteration 9 MRs

  Scenario: MR34 Adding a new pet with a specific ID should make it retrievable by that ID
    Given a seed input that attempts to retrieve a pet by a specific valid integer ID, producing a seed output that may indicate that no pet is currently associated with that ID for MR34.
    When a follow-up input is created by adding a new pet whose ID field is set to that same valid integer ID using the operation that creates a new pet in the store, and then retrieving the pet by that ID again, yielding a follow-up output for MR34.
    Then the follow-up output should indicate the presence of a pet with that ID, differing from the seed output if the pet did not exist before for MR34.

  Scenario: MR35 Adding a pet with a specific status should increase the number of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a valid status value (available, pending, or sold), producing a seed output with a count of pets for that status for MR35.
    When a follow-up input is created by adding a new pet whose status field is set to that same valid status value, and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR35.
    Then the follow-up output should have a count of pets for that status that is exactly one more than the seed output for MR35, assuming no other changes occurred to pets with that status in between.

  Scenario: MR36 Adding a pet with a specific tag should make it retrievable when filtering by that tag
    Given a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR36.
    When a follow-up input is created by adding a new pet that includes that same tag value (as one of its tag names) in its tag list, and then retrieving pets filtered by that tag value again, yielding a follow-up output for MR36.
    Then the follow-up output should include the newly added pet among the returned pets with that tag, making the follow-up list a superset of or equal to the seed output list for MR36.

  Scenario: MR37 Adding a new pet should make it retrievable by ID
    Given a seed input that retrieves a pet by a specific integer ID, producing a seed output indicating whether the pet exists for MR37.
    When a follow-up input is created by adding a new pet whose data includes that specific integer ID using the operation that creates a new pet in the store, and then retrieving the pet by the same ID again, yielding a follow-up output for MR37.
    Then the follow-up output should indicate the presence of the newly added pet with that ID, differing from the seed output if the pet did not exist before for MR37.

  Scenario: MR38 Adding a pet with a unique ID should not affect existing pets with the same status
    Given a seed input that retrieves the list of pets filtered by a specific valid status value (available, pending, or sold), producing a seed output with the current list of pets for that status for MR38.
    When a follow-up input is created by adding a new pet with a previously unused (unique) integer ID and the same status value using the operation that creates a new pet in the store, and then retrieving the list of pets for that same status value again, yielding a follow-up output for MR38.
    Then the follow-up output should contain all the pets from the seed output for that status value, plus the newly added pet, so that the follow-up list is a superset of the seed output for MR38.

