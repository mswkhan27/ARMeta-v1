Feature: Iteration 9 MRs

  Scenario: MR34 Adding a new pet with a specific ID should make it retrievable by that ID
    Given a seed input that attempts to retrieve a pet by a specific valid integer ID, producing a seed output that may indicate that no pet is currently associated with that ID for MR34.
    When a follow-up input is created by adding a new pet whose ID field is set to that same valid integer ID using the operation that creates a new pet in the store, and then retrieving the pet by that ID again, yielding a follow-up output for MR34.
    Then the follow-up output should indicate the presence of a pet with that ID, differing from the seed output if the pet did not exist before for MR34.

  Scenario: MR35 Adding a pet with a specific status should increase the number of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a valid status value (available, pending, or sold), producing a seed output with a count of pets for that status for MR35.
    When a follow-up input is created by adding a new pet whose status field is set to that same valid status value, and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR35.
    Then the follow-up output should have a count of pets for that status that is exactly one more than the seed output for MR35, assuming no other changes occurred to pets with that status in between.

  Scenario: MR36 Adding a pet with a specific tag should make it retrievable when filtering by that tag
    Given a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR36.
    When a follow-up input is created by adding a new pet that includes that same tag value (as one of its tag names) in its tag list, and then retrieving pets filtered by that tag value again, yielding a follow-up output for MR36.
    Then the follow-up output should include the newly added pet among the returned pets with that tag, making the follow-up list a superset of or equal to the seed output list for MR36.

  Scenario: MR37 Adding a new pet should make it retrievable by ID
    Given a seed input that retrieves a pet by a specific integer ID, producing a seed output indicating whether the pet exists for MR37.
    When a follow-up input is created by adding a new pet whose data includes that specific integer ID using the operation that creates a new pet in the store, and then retrieving the pet by the same ID again, yielding a follow-up output for MR37.
    Then the follow-up output should indicate the presence of the newly added pet with that ID, differing from the seed output if the pet did not exist before for MR37.

  Scenario: MR38 Adding a pet with a unique ID should not affect existing pets with the same status
    Given a seed input that retrieves the list of pets filtered by a specific valid status value (available, pending, or sold), producing a seed output with the current list of pets for that status for MR38.
    When a follow-up input is created by adding a new pet with a previously unused (unique) integer ID and the same status value using the operation that creates a new pet in the store, and then retrieving the list of pets for that same status value again, yielding a follow-up output for MR38.
    Then the follow-up output should contain all the pets from the seed output for that status value, plus the newly added pet, so that the follow-up list is a superset of the seed output for MR38.
