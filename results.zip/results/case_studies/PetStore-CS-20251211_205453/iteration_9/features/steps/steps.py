from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that attempts to retrieve a pet by a specific valid integer ID, producing a seed output that may indicate that no pet is currently associated with that ID for MR34.')
def _mr_MR34_seed_input(context):
    pet_id = 1  # Example valid integer ID within int64 range
    context.pet_id = pet_id

    url = f"{BASE_URL}/pet/{pet_id}"
    response = requests.get(url, timeout=10)

    context.seed_status_code = response.status_code
    try:
        context.seed_response = response.json()
    except ValueError:
        context.seed_response = response.text

    if response.status_code == 404:
        context.misc = "No pet found with this ID."
    elif response.status_code not in (200, 404, 400):
        raise AssertionError(
            f"Unexpected response: {response.status_code} - {context.seed_response}"
        )


@when('a follow-up input is created by adding a new pet whose ID field is set to that same valid integer ID using the operation that creates a new pet in the store, and then retrieving the pet by that ID again, yielding a follow-up output for MR34.')
def _mr_MR34_followup_input(context):
    pet_id = getattr(context, "pet_id", 1)

    new_pet = {
        "id": pet_id,
        "name": "Buddy",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }

    create_url = f"{BASE_URL}/pet"
    create_response = requests.post(create_url, json=new_pet, timeout=10)

    context.create_status_code = create_response.status_code
    try:
        context.create_response = create_response.json()
    except ValueError:
        context.create_response = create_response.text

    if create_response.status_code != 200:
        raise AssertionError(
            f"Failed to add pet: {create_response.status_code} - {context.create_response}"
        )

    retrieve_url = f"{BASE_URL}/pet/{pet_id}"
    followup_response = requests.get(retrieve_url, timeout=10)

    context.followup_status_code = followup_response.status_code
    try:
        context.followup_response = followup_response.json()
    except ValueError:
        context.followup_response = followup_response.text

    if followup_response.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve pet: {followup_response.status_code} - {context.followup_response}"
        )


@then('the follow-up output should indicate the presence of a pet with that ID, differing from the seed output if the pet did not exist before for MR34.')
def _mr_MR34_followup_output(context):
    assert context.followup_status_code == 200, "Follow-up response should be successful."

    followup_pet = context.followup_response
    if not isinstance(followup_pet, dict):
        raise AssertionError(f"Follow-up response is not a JSON object: {followup_pet}")

    expected_id = getattr(context, "pet_id", 1)

    if "id" not in followup_pet:
        raise AssertionError(f"'id' field missing in follow-up pet: {followup_pet}")
    if "name" not in followup_pet:
        raise AssertionError(f"'name' field missing in follow-up pet: {followup_pet}")

    assert followup_pet["id"] == expected_id, "The pet ID should match the one used for creation."
    assert followup_pet["name"] == "Buddy", "The pet name should be 'Buddy'."

    # Only compare responses if the seed retrieval was successful or 404
    if hasattr(context, "seed_response"):
        # Guard against non-dict seed responses
        if isinstance(context.seed_response, dict):
            # If the pet didn't exist before (404), the bodies should differ.
            if context.seed_status_code == 404:
                assert context.seed_response != followup_pet, (
                    "The follow-up output should differ from the seed output when the pet did not exist before."
                )

# ----




@given('a seed input that retrieves the list of pets filtered by a valid status value (available, pending, or sold), producing a seed output with a count of pets for that status for MR35.')
def _mr_MR35_seed_input(context):
    status = 'available'  # Using 'available' as a valid status from enum
    context.seed_request = {'status': status}

    response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params=context.seed_request,
        timeout=10
    )
    # Raise for non-2xx HTTP errors; let Behave fail the step if this happens
    response.raise_for_status()

    # Ensure JSON decoding succeeds and is a list
    data = response.json()
    if not isinstance(data, list):
        raise TypeError(f"Expected list from /pet/findByStatus, got {type(data).__name__}")

    context.seed_response = data
    context.seed_count = len(context.seed_response)


@when('a follow-up input is created by adding a new pet whose status field is set to that same valid status value, and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR35.')
def _mr_MR35_followup_input(context):
    # Build a minimal valid Pet according to the schema: name and photoUrls are required
    status = context.seed_request.get('status')
    if status not in ('available', 'pending', 'sold'):
        raise ValueError(f"Invalid status in context.seed_request: {status!r}")

    new_pet = {
        "name": "New Pet MR35",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": status
    }

    add_response = requests.post(
        f"{BASE_URL}/pet",
        json=new_pet,
        timeout=10
    )
    add_response.raise_for_status()

    followup_response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params=context.seed_request,
        timeout=10
    )
    followup_response.raise_for_status()

    data = followup_response.json()
    if not isinstance(data, list):
        raise TypeError(f"Expected list from /pet/findByStatus, got {type(data).__name__}")

    context.followup_response = data
    context.followup_count = len(context.followup_response)


@then('the follow-up output should have a count of pets for that status that is exactly one more than the seed output for MR35, assuming no other changes occurred to pets with that status in between.')
def _mr_MR35_followup_assertion(context):
    if not isinstance(context.seed_count, int):
        raise TypeError(f"seed_count should be int, got {type(context.seed_count).__name__}")
    if not isinstance(context.followup_count, int):
        raise TypeError(f"followup_count should be int, got {type(context.followup_count).__name__}")

    expected_count = context.seed_count + 1
    actual_count = context.followup_count

    assert actual_count == expected_count, (
        f"Expected follow-up count to be {expected_count}, but got {actual_count}."
    )

# ----

import time



@given('a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR36.')
def _mr_MR36_seed_input(context):
    tag_value = "dog"  # Example tag value

    context.tag_value = tag_value
    context.seed_request = {'tags': [tag_value]}

    response = requests.get(
        f"{BASE_URL}/pet/findByTags",
        params=context.seed_request,
        timeout=10
    )
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Seed response is not valid JSON: {e}") from e

    if not isinstance(data, list):
        raise AssertionError(f"Seed response JSON is not a list, got: {type(data).__name__}")

    context.seed_response = data


@when('a follow-up input is created by adding a new pet that includes that same tag value (as one of its tag names) in its tag list, and then retrieving pets filtered by that tag value again, yielding a follow-up output for MR36.')
def _mr_MR36_followup_input(context):
    tag_value = getattr(context, "tag_value", "dog")

    new_pet = {
        "name": "Buddy",
        "photoUrls": ["http://example.com/photo.jpg"],
        "tags": [{"id": 1, "name": tag_value}],
        "status": "available"
    }

    add_response = requests.post(
        f"{BASE_URL}/pet",
        json=new_pet,
        timeout=10
    )
    add_response.raise_for_status()

    # Store the created pet (best-effort) to use its id in assertions
    created_pet = None
    try:
        created_pet = add_response.json()
        if isinstance(created_pet, dict):
            context.new_pet_id = created_pet.get("id")
    except ValueError:
        created_pet = None
    context.new_pet_body = created_pet if isinstance(created_pet, dict) else new_pet

    context.followup_request = {'tags': [tag_value]}
    followup_response = requests.get(
        f"{BASE_URL}/pet/findByTags",
        params=context.followup_request,
        timeout=10
    )
    followup_response.raise_for_status()

    try:
        data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response is not valid JSON: {e}") from e

    if not isinstance(data, list):
        raise AssertionError(f"Follow-up response JSON is not a list, got: {type(data).__name__}")

    context.followup_response = data


@then('the follow-up output should include the newly added pet among the returned pets with that tag, making the follow-up list a superset of or equal to the seed output list for MR36.')
def _mr_MR36_followup_output(context):
    if not isinstance(getattr(context, "seed_response", None), list):
        raise AssertionError("Seed response is not a list")
    if not isinstance(getattr(context, "followup_response", None), list):
        raise AssertionError("Follow-up response is not a list")

    new_pet_name = context.new_pet_body.get("name") if isinstance(getattr(context, "new_pet_body", None), dict) else "Buddy"
    new_pet_id = getattr(context, "new_pet_id", None)

    # Check if the new pet is in the follow-up response (prefer id if available, fall back to name)
    def is_new_pet(pet):
        if not isinstance(pet, dict):
            return False
        if new_pet_id is not None and isinstance(pet.get("id"), type(new_pet_id)):
            if pet.get("id") == new_pet_id:
                return True
        return pet.get("name") == new_pet_name

    new_pet_found = any(is_new_pet(pet) for pet in context.followup_response)
    if not new_pet_found:
        raise AssertionError("Newly added pet is not found in the follow-up output")

    # MR requirement: follow-up list is a superset of or equal to the seed list (by id if available, otherwise by (name, status))
    def pet_key(pet):
        if not isinstance(pet, dict):
            return None
        if "id" in pet:
            return ("id", pet.get("id"))
        return ("name_status", pet.get("name"), pet.get("status"))

    followup_keys = {pet_key(p) for p in context.followup_response if pet_key(p) is not None}

    for seed_pet in context.seed_response:
        key = pet_key(seed_pet)
        if key is None:
            continue
        if key not in followup_keys:
            seed_name = seed_pet.get("name") if isinstance(seed_pet, dict) else "<unknown>"
            raise AssertionError(f"Seed pet {seed_name} is not found in the follow-up output")

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


@given(
    "a seed input that retrieves a pet by a specific integer ID, producing a seed output indicating whether the pet exists for MR37."
)
def _mr_MR37_seed_input(context):
    # Use a fixed integer ID as per MR, cast to int explicitly to avoid type issues
    pet_id = int(1)

    url = f"{BASE_URL}/pet/{pet_id}"
    try:
        response = requests.get(url, timeout=10)
    except requests.RequestException as exc:
        raise AssertionError(f"Request to {url} failed: {exc}") from exc

    context.seed_status_code = response.status_code
    context.seed_raw_response = response

    if response.status_code == 200:
        # Ensure JSON decoding is safe
        try:
            context.seed_response = response.json()
        except (ValueError, TypeError) as exc:
            raise AssertionError(f"Failed to decode JSON from seed response: {exc}") from exc
    elif response.status_code == 404:
        context.seed_response = None
    else:
        raise AssertionError(
            f"Unexpected seed response: {response.status_code} - {response.text}"
        )


@when(
    "a follow-up input is created by adding a new pet whose data includes that specific integer ID using the operation that creates a new pet in the store, and then retrieving the pet by the same ID again, yielding a follow-up output for MR37."
)
def _mr_MR37_followup_input(context):
    # Reuse the same ID that was used in the seed step
    pet_id = int(1)

    new_pet_data = {
        "id": pet_id,
        "name": "Buddy",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }

    add_url = f"{BASE_URL}/pet"
    try:
        add_response = requests.post(add_url, json=new_pet_data, timeout=10)
    except requests.RequestException as exc:
        raise AssertionError(f"Request to {add_url} failed: {exc}") from exc

    context.followup_add_status_code = add_response.status_code
    context.followup_add_raw_response = add_response

    if add_response.status_code != 200:
        raise AssertionError(
            f"Failed to add pet: {add_response.status_code} - {add_response.text}"
        )

    get_url = f"{BASE_URL}/pet/{pet_id}"
    try:
        get_response = requests.get(get_url, timeout=10)
    except requests.RequestException as exc:
        raise AssertionError(f"Request to {get_url} failed: {exc}") from exc

    context.followup_get_status_code = get_response.status_code
    context.followup_get_raw_response = get_response

    if get_response.status_code == 200:
        try:
            context.followup_response = get_response.json()
        except (ValueError, TypeError) as exc:
            raise AssertionError(f"Failed to decode JSON from follow-up response: {exc}") from exc
    else:
        raise AssertionError(
            f"Unexpected response when retrieving pet: {get_response.status_code} - {get_response.text}"
        )


@then(
    "the follow-up output should indicate the presence of the newly added pet with that ID, differing from the seed output if the pet did not exist before for MR37."
)
def _mr_MR37_followup_output(context):
    # Ensure followup_response is a dict before indexing
    if not isinstance(context.followup_response, dict):
        raise AssertionError(
            f"Expected follow-up response to be a dict, got {type(context.followup_response)}"
        )

    expected_id = int(1)

    if context.seed_response is not None:
        if not isinstance(context.seed_response, dict):
            raise AssertionError(
                f"Expected seed response to be a dict or None, got {type(context.seed_response)}"
            )
        assert "id" in context.seed_response, "Seed response is missing 'id' field"
        assert "id" in context.followup_response, "Follow-up response is missing 'id' field"
        assert (
            context.followup_response["id"] == context.seed_response["id"]
        ), "The pet ID should match the seed output."
    else:
        assert "id" in context.followup_response, "Follow-up response is missing 'id' field"
        assert (
            context.followup_response["id"] == expected_id
        ), f"The newly added pet ID should be {expected_id}."

    # Validate the name field safely
    name = context.followup_response.get("name")
    assert name == "Buddy", f"The pet name should be 'Buddy', got {name!r}."

# ----

from typing import Any, Dict, List



def _safe_get_pet_id(pet: Dict[str, Any]) -> Any:
    """
    Safely extract the pet ID, or return None if not present or of unexpected type.
    """
    if not isinstance(pet, dict):
        return None
    pet_id = pet.get('id')
    # The schema says integer, but we avoid coercion to prevent ValueError/TypeError
    return pet_id


def _safe_parse_json(response: requests.Response) -> Any:
    """
    Safely parse JSON from a response, returning None on failure instead of raising.
    """
    try:
        return response.json()
    except ValueError:
        # Invalid JSON
        return None


@given('a seed input that retrieves the list of pets filtered by a specific valid status value (available, pending, or sold), producing a seed output with the current list of pets for that status for MR38.')
def _mr_MR38_seed_input(context):
    status = 'available'  # Using 'available' as a valid status from the enum
    context.seed_status = status
    context.seed_request = {'status': status}

    response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params=context.seed_request,
        timeout=10
    )
    response.raise_for_status()

    data = _safe_parse_json(response)
    if not isinstance(data, list):
        raise AssertionError("Expected list response for /pet/findByStatus")

    # Ensure elements are dicts to avoid TypeError when accessing keys later
    context.seed_response: List[Dict[str, Any]] = [
        pet for pet in data if isinstance(pet, dict)
    ]


@when('a follow-up input is created by adding a new pet with a previously unused (unique) integer ID and the same status value using the operation that creates a new pet in the store, and then retrieving the list of pets for that same status value again, yielding a follow-up output for MR38.')
def _mr_MR38_followup_input(context):
    status = getattr(context, "seed_status", "available")

    # Create a new pet with a unique ID; keep it simple and within int64 range
    new_pet_id = 99999
    context.new_pet_id = new_pet_id

    new_pet: Dict[str, Any] = {
        "id": new_pet_id,
        "name": "New Pet MR38",
        "status": status,
        "photoUrls": ["http://example.com/photo_mr38.jpg"]
    }

    context.followup_request = new_pet

    add_response = requests.post(
        f"{BASE_URL}/pet",
        json=context.followup_request,
        timeout=10
    )
    add_response.raise_for_status()

    # Retrieve the list of pets again for the same status
    followup_response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params={'status': status},
        timeout=10
    )
    followup_response.raise_for_status()

    data = _safe_parse_json(followup_response)
    if not isinstance(data, list):
        raise AssertionError("Expected list response for follow-up /pet/findByStatus")

    context.followup_response: List[Dict[str, Any]] = [
        pet for pet in data if isinstance(pet, dict)
    ]


@then('the follow-up output should contain all the pets from the seed output for that status value, plus the newly added pet, so that the follow-up list is a superset of the seed output for MR38.')
def _mr_MR38_followup_output(context):
    seed_pets = getattr(context, "seed_response", [])
    followup_pets = getattr(context, "followup_response", [])
    new_pet_id = getattr(context, "new_pet_id", None)

    if not isinstance(seed_pets, list) or not isinstance(followup_pets, list):
        raise AssertionError("Seed or follow-up response is not a list")

    # Build ID sets safely, ignoring entries without valid IDs
    seed_ids = {
        pet_id
        for pet_id in (_safe_get_pet_id(p) for p in seed_pets)
        if pet_id is not None
    }
    followup_ids = {
        pet_id
        for pet_id in (_safe_get_pet_id(p) for p in followup_pets)
        if pet_id is not None
    }

    # Assert that the follow-up output contains all seed output pets
    if not seed_ids.issubset(followup_ids):
        missing = seed_ids - followup_ids
        raise AssertionError(
            f"Follow-up output does not contain all seed output pets. Missing IDs: {missing}"
        )

    # Assert that the new pet is included in the follow-up output
    if new_pet_id is None or new_pet_id not in followup_ids:
        raise AssertionError(
            f"Newly added pet with ID {new_pet_id!r} is not in the follow-up output."
        )
