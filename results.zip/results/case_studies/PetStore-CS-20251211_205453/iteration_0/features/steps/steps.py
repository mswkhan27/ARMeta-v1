from behave import given, when, then
import os
import json
import requests
import time

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of available pets for MR1.")
def _mr_MR1_seed_input(context):
    url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}

    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()

        try:
            seed_response = response.json()
        except ValueError as exc:
            raise AssertionError(f"Seed response is not valid JSON: {exc}") from exc

        if not isinstance(seed_response, list):
            raise AssertionError(f"Expected seed response to be a list, got {type(seed_response).__name__}")

        context.seed_response = seed_response
        context.seed_request = params
        context.available_count = len(seed_response)
        context.added_pet_id = None
    except requests.RequestException as exc:
        raise AssertionError(f"HTTP error in GIVEN step for MR1: {exc}") from exc


@when("a follow-up input is created by adding a new pet whose status is set to 'available', yielding a follow-up output for MR1.")
def _mr_MR1_followup_input(context):
    url = f"{BASE_URL}/pet"
    new_pet = {
        "name": "New Available Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    try:
        response = requests.post(url, json=new_pet, timeout=10)
        response.raise_for_status()

        try:
            followup_response = response.json()
        except ValueError as exc:
            raise AssertionError(f"Follow-up create-pet response is not valid JSON: {exc}") from exc

        if not isinstance(followup_response, dict):
            raise AssertionError(f"Expected follow-up response to be an object, got {type(followup_response).__name__}")

        context.followup_response = followup_response
        pet_id = followup_response.get("id")
        if pet_id is not None:
            context.added_pet_id = pet_id
    except requests.RequestException as exc:
        raise AssertionError(f"HTTP error in WHEN step for MR1: {exc}") from exc


@then("the follow-up output should have a count of available pets that is exactly one more than the seed output for MR1.")
def _mr_MR1_followup_output(context):
    url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}

    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()

        try:
            followup_list = response.json()
        except ValueError as exc:
            raise AssertionError(f"Follow-up list response is not valid JSON: {exc}") from exc

        if not isinstance(followup_list, list):
            raise AssertionError(f"Expected follow-up response to be a list, got {type(followup_list).__name__}")

        followup_count = len(followup_list)
        expected_count = getattr(context, "available_count", None)
        if not isinstance(expected_count, int):
            raise AssertionError(f"Context available_count is not an int: {expected_count!r}")

        assert followup_count == expected_count + 1, (
            f"Expected {expected_count + 1} available pets, but got {followup_count}."
        )
    except requests.RequestException as exc:
        raise AssertionError(f"HTTP error in THEN step for MR1: {exc}") from exc

# ----

from typing import Any, Dict, List

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


def _safe_get_json(response: requests.Response) -> Any:
    try:
        return response.json()
    except ValueError:
        raise AssertionError("Response did not contain valid JSON")


def _ensure_list(obj: Any) -> List[Dict[str, Any]]:
    if obj is None:
        return []
    if isinstance(obj, list):
        return obj
    raise AssertionError(f"Expected a list of pets but got: {type(obj).__name__}")


@given(
    "a seed input that retrieves the list of pets filtered by status 'pending', producing a seed output with a list of pending pets for MR2."
)
def step_mr_MR2_seed_input(context) -> None:
    # Retrieve the list of pets with status 'pending'
    url = f"{BASE_URL}/pet/findByStatus"
    try:
        response = requests.get(url, params={"status": "pending"}, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Request failed in GIVEN step for MR2: {e}") from e

    data = _safe_get_json(response)
    context.seed_response = _ensure_list(data)
    context.seed_request = {"status": "pending"}


@when(
    "a follow-up input is created by updating an existing pet's status from 'available' to 'pending', and then retrieving the list of pets filtered by status 'pending' again, yielding a follow-up output for MR2."
)
def step_mr_MR2_followup_input(context) -> None:
    # Create a new pet with status 'available'
    new_pet: Dict[str, Any] = {
        "name": "TestPet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }
    create_url = f"{BASE_URL}/pet"
    try:
        add_response = requests.post(create_url, json=new_pet, timeout=10)
        add_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Request failed while adding pet in WHEN step for MR2: {e}") from e

    added_pet = _safe_get_json(add_response)
    if not isinstance(added_pet, dict):
        raise AssertionError(f"Expected created pet as JSON object but got: {type(added_pet).__name__}")

    new_pet_id = added_pet.get("id")
    if not isinstance(new_pet_id, int):
        raise AssertionError("Created pet does not contain a valid integer 'id'")

    # Prepare full pet payload for update: keep existing fields but change status
    updated_pet_payload = dict(added_pet)
    updated_pet_payload["status"] = "pending"

    # Update the pet's status to 'pending' using PUT /pet
    update_url = f"{BASE_URL}/pet"
    try:
        update_response = requests.put(update_url, json=updated_pet_payload, timeout=10)
        update_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Request failed while updating pet in WHEN step for MR2: {e}") from e

    # Retrieve the list of pets with status 'pending' again
    find_url = f"{BASE_URL}/pet/findByStatus"
    try:
        followup_response = requests.get(find_url, params={"status": "pending"}, timeout=10)
        followup_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Request failed while retrieving pending pets in WHEN step for MR2: {e}") from e

    followup_data = _safe_get_json(followup_response)
    context.followup_response = _ensure_list(followup_data)
    context.followup_request = {"status": "pending"}
    context.updated_pet_id = new_pet_id
    context.updated_pet_name = added_pet.get("name")


@then(
    "the follow-up output should include the updated pet in the list of pending pets and should have a count of pending pets that is exactly one more than the seed output for MR2."
)
def step_mr_MR2_followup_output(context) -> None:
    seed_list = _ensure_list(getattr(context, "seed_response", []))
    followup_list = _ensure_list(getattr(context, "followup_response", []))

    updated_pet_id = getattr(context, "updated_pet_id", None)
    if not isinstance(updated_pet_id, int):
        raise AssertionError("Context does not contain a valid 'updated_pet_id'")

    # Check that the follow-up output includes the updated pet
    updated_pet_in_followup = any(
        isinstance(pet, dict)
        and pet.get("id") == updated_pet_id
        and pet.get("status") == "pending"
        for pet in followup_list
    )
    if not updated_pet_in_followup:
        raise AssertionError("The updated pet is not included in the follow-up output as pending.")

    # Check that the count of pending pets is one more than the seed output
    if len(followup_list) != len(seed_list) + 1:
        raise AssertionError(
            f"The count of pending pets is not as expected: "
            f"seed={len(seed_list)}, follow-up={len(followup_list)}, expected follow-up={len(seed_list) + 1}"
        )

# ----




@given("a seed input that retrieves the list of pets filtered by a specific status (for example, 'available'), producing a seed output with a count of pets for that status for MR3.")
def _mr_MR3_seed_input(context):
    status = "available"
    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByStatus",
            params={"status": status},
            timeout=10,
        )
        response.raise_for_status()
        data = response.json()

        if not isinstance(data, list):
            raise AssertionError(f"Expected a list of pets, got: {type(data).__name__}")

        context.seed_response = data
        context.seed_request = {"status": status}
        context.seed_count = len(data)
        context.seed_status = status
    except (requests.RequestException, ValueError, TypeError) as e:
        print(f"Error in GIVEN step for MR3: {e}")
        raise


@when("a follow-up input is created by deleting an existing pet that has that same status, and then retrieving again the list of pets filtered by that status, yielding a follow-up output for MR3.")
def _mr_MR3_followup_input(context):
    try:
        seed_pets = getattr(context, "seed_response", None)
        seed_status = getattr(context, "seed_status", "available")

        if not seed_pets:
            raise AssertionError("No pets available to delete in seed_response.")

        pet_to_delete = None
        for pet in seed_pets:
            if isinstance(pet, dict) and pet.get("status") == seed_status and "id" in pet:
                pet_to_delete = pet
                break

        if pet_to_delete is None:
            raise AssertionError(
                f"No pet with status '{seed_status}' and an 'id' field found in seed_response."
            )

        pet_id = pet_to_delete.get("id")
        if not isinstance(pet_id, int):
            raise AssertionError(f"Pet id must be an integer, got: {repr(pet_id)}")

        delete_response = requests.delete(
            f"{BASE_URL}/pet/{pet_id}",
            timeout=10,
        )
        delete_response.raise_for_status()

        followup_response = requests.get(
            f"{BASE_URL}/pet/findByStatus",
            params={"status": seed_status},
            timeout=10,
        )
        followup_response.raise_for_status()
        followup_data = followup_response.json()

        if not isinstance(followup_data, list):
            raise AssertionError(f"Expected a list of pets in follow-up, got: {type(followup_data).__name__}")

        context.followup_response = followup_data
        context.followup_count = len(followup_data)
    except (requests.RequestException, ValueError, TypeError, AssertionError) as e:
        print(f"Error in WHEN step for MR3: {e}")
        raise


@then("the follow-up output should have a count of pets for that status that is exactly one less than the seed output for MR3.")
def _mr_MR3_followup_output(context):
    try:
        seed_count = getattr(context, "seed_count", None)
        followup_count = getattr(context, "followup_count", None)

        if not isinstance(seed_count, int):
            raise AssertionError(f"seed_count must be an integer, got: {repr(seed_count)}")
        if not isinstance(followup_count, int):
            raise AssertionError(f"followup_count must be an integer, got: {repr(followup_count)}")

        expected = seed_count - 1
        assert followup_count == expected, (
            f"Expected follow-up count to be {expected}, but got {followup_count}."
        )
    except AssertionError as e:
        print(f"Error in THEN step for MR3: {e}")
        raise
