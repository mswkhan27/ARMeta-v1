Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new available pet should increase the count of available pets
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of available pets for MR1.
    When a follow-up input is created by adding a new pet whose status is set to 'available', yielding a follow-up output for MR1.
    Then the follow-up output should have a count of available pets that is exactly one more than the seed output for MR1.

  Scenario: MR2 Updating a pet's status should change the results of the status filter
    Given a seed input that retrieves the list of pets filtered by status 'pending', producing a seed output with a list of pending pets for MR2.
    When a follow-up input is created by updating an existing pet's status from 'available' to 'pending', and then retrieving the list of pets filtered by status 'pending' again, yielding a follow-up output for MR2.
    Then the follow-up output should include the updated pet in the list of pending pets and should have a count of pending pets that is exactly one more than the seed output for MR2.

  Scenario: MR3 Deleting a pet should decrease the count of pets for its status
    Given a seed input that retrieves the list of pets filtered by a specific status (for example, 'available'), producing a seed output with a count of pets for that status for MR3.
    When a follow-up input is created by deleting an existing pet that has that same status, and then retrieving again the list of pets filtered by that status, yielding a follow-up output for MR3.
    Then the follow-up output should have a count of pets for that status that is exactly one less than the seed output for MR3.
