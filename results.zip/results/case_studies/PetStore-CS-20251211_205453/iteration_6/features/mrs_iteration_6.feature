Feature: Iteration 6 MRs

  Scenario: MR22 Adding a new pet should make it retrievable by ID
    Given a seed input that retrieves a pet by a specific ID, producing a seed output indicating whether the pet exists for MR22.
    When a follow-up input is created by adding a new pet whose data includes that specific ID using the operation that creates a new pet in the store, and then retrieving the pet by the same ID again, yielding a follow-up output for MR22.
    Then the follow-up output should indicate the presence of the newly added pet, differing from the seed output if the pet did not exist before for MR22.

  Scenario: MR24 Adding a pet with a unique ID should not affect existing pets with the same status
    Given a seed input that retrieves the list of pets filtered by a specific status value, producing a seed output with the current list of pets for that status for MR24.
    When a follow-up input is created by adding a new pet with a unique ID and the same status value using the operation that creates a new pet in the store, and then retrieving the list of pets for that same status value again, yielding a follow-up output for MR24.
    Then the follow-up output should be a superset of the seed output for that status value, containing all the pets from the seed output plus the newly added pet for MR24.

  Scenario: MR25 Creating users with a list should allow retrieval of each user by username
    Given a seed input that retrieves a user by username, producing a seed output indicating whether the user exists for MR25.
    When a follow-up input is created by adding a list of users using the operation that creates users from a list, and then retrieving each user by their username from the list using the operation that gets user details by username, yielding a follow-up output for MR25.
    Then the follow-up output should indicate the presence of each newly added user, differing from the seed output if the users did not exist before for MR25.
