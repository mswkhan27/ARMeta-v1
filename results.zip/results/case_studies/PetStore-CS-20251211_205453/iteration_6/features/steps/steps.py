from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that retrieves a pet by a specific ID, producing a seed output indicating whether the pet exists for MR22.')
def _mr_MR22_seed_input(context):
    pet_id = 1  # Using a fixed ID for reproducibility
    context.pet_id = pet_id
    seed_url = f"{BASE_URL}/pet/{pet_id}"

    context.seed_request = {
        "method": "GET",
        "url": seed_url,
        "path": f"/pet/{pet_id}",
    }

    try:
        response = requests.get(seed_url, timeout=10)
        context.seed_status_code = response.status_code
        try:
            context.seed_response_json = response.json()
        except ValueError:
            context.seed_response_json = None
        context.seed_response_text = response.text
    except requests.RequestException as e:
        context.seed_status_code = None
        context.seed_response_json = None
        context.seed_response_text = str(e)


@when('a follow-up input is created by adding a new pet whose data includes that specific ID using the operation that creates a new pet in the store, and then retrieving the pet by the same ID again, yielding a follow-up output for MR22.')
def _mr_MR22_followup_input(context):
    pet_id = getattr(context, "pet_id", 1)
    followup_post_url = f"{BASE_URL}/pet"
    followup_get_url = f"{BASE_URL}/pet/{pet_id}"

    new_pet_data = {
        "id": int(pet_id),
        "name": "Buddy",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    context.followup_request = {
        "post": {
            "method": "POST",
            "url": followup_post_url,
            "path": "/pet",
            "body": new_pet_data,
        },
        "get": {
            "method": "GET",
            "url": followup_get_url,
            "path": f"/pet/{pet_id}",
        },
    }

    try:
        post_response = requests.post(
            followup_post_url,
            json=new_pet_data,
            timeout=10,
            headers={"Content-Type": "application/json"},
        )
        context.followup_post_status_code = post_response.status_code
        try:
            context.followup_post_json = post_response.json()
        except ValueError:
            context.followup_post_json = None

        get_response = requests.get(followup_get_url, timeout=10)
        context.followup_get_status_code = get_response.status_code
        try:
            context.followup_response_json = get_response.json()
        except ValueError:
            context.followup_response_json = None
        context.followup_response_text = get_response.text
    except requests.RequestException as e:
        context.followup_post_status_code = None
        context.followup_post_json = None
        context.followup_get_status_code = None
        context.followup_response_json = None
        context.followup_response_text = str(e)


@then('the follow-up output should indicate the presence of the newly added pet, differing from the seed output if the pet did not exist before for MR22.')
def _mr_MR22_followup_output(context):
    assert context.followup_get_status_code == 200, (
        f"Expected status 200 when retrieving pet after creation, got "
        f"{context.followup_get_status_code}, body: {context.followup_response_text}"
    )

    assert isinstance(context.followup_response_json, dict), (
        f"Expected JSON object in follow-up response, got: {context.followup_response_text}"
    )

    pet_id = getattr(context, "pet_id", 1)
    followup_id = context.followup_response_json.get("id", None)
    assert followup_id is not None, "Follow-up response does not contain 'id'"
    assert str(followup_id) == str(pet_id), (
        f"The pet ID in follow-up response ({followup_id}) does not match the expected ID ({pet_id})"
    )

    assert context.followup_response_json.get("name") == "Buddy", (
        "The name of the pet in follow-up response does not match the expected name 'Buddy'"
    )

    if context.seed_status_code != 200 or not isinstance(context.seed_response_json, dict):
        return

    seed_id = context.seed_response_json.get("id", None)
    seed_name = context.seed_response_json.get("name", None)

    if seed_id is None and seed_name is None:
        return

    assert context.followup_response_json != context.seed_response_json, (
        "Follow-up response should differ from seed response if the pet did not exist before"
    )

# ----

import time
from typing import Any, Dict, List



def _safe_get_json(response: requests.Response) -> Any:
    """
    Safely parse JSON from a response, avoiding ValueError from invalid JSON.
    Returns None if parsing fails.
    """
    try:
        return response.json()
    except ValueError:
        return None


def _ensure_list(value: Any) -> List[Dict[str, Any]]:
    """
    Ensure the returned value is a list of dicts.
    Returns an empty list if value is None or not a list.
    """
    if isinstance(value, list):
        # Keep only dictionary elements to avoid TypeError during membership tests
        return [item for item in value if isinstance(item, dict)]
    return []


@given('a seed input that retrieves the list of pets filtered by a specific status value, producing a seed output with the current list of pets for that status for MR24.')
def step_mr_MR24_seed_input(context):
    status = 'available'  # Using a valid enum value from OpenAPI: available | pending | sold
    context.status = status  # Store for reuse in WHEN

    context.seed_request = f"{BASE_URL}/pet/findByStatus"
    try:
        response = requests.get(
            context.seed_request,
            params={'status': status},
            timeout=10
        )
        response.raise_for_status()
    except requests.RequestException as e:
        # Fail fast with clear message, avoid untyped exceptions later
        raise AssertionError(f"HTTP error in Given step for MR24: {e}") from e

    raw_json = _safe_get_json(response)
    context.seed_response = _ensure_list(raw_json)


@when('a follow-up input is created by adding a new pet with a unique ID and the same status value using the operation that creates a new pet in the store, and then retrieving the list of pets for that same status value again, yielding a follow-up output for MR24.')
def step_mr_MR24_followup_input(context):
    # Ensure status from Given; default to 'available' if missing
    status = getattr(context, 'status', 'available')

    # Construct a new pet according to components.schemas.Pet (id is optional)
    new_pet = {
        "name": "UniquePet-MR24",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": status
    }

    add_pet_url = f"{BASE_URL}/pet"
    try:
        add_pet_response = requests.post(add_pet_url, json=new_pet, timeout=10)
        add_pet_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error while adding pet in When step for MR24: {e}") from e

    added_pet_json = _safe_get_json(add_pet_response)
    # Store the added pet as a dict (or empty dict if response not usable)
    context.added_pet = added_pet_json if isinstance(added_pet_json, dict) else {}

    # Now retrieve the list of pets again using the same filtering operation
    context.followup_request = f"{BASE_URL}/pet/findByStatus"
    try:
        followup_response = requests.get(
            context.followup_request,
            params={'status': status},
            timeout=10
        )
        followup_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error while fetching follow-up list in When step for MR24: {e}") from e

    raw_followup_json = _safe_get_json(followup_response)
    context.followup_response = _ensure_list(raw_followup_json)


@then('the follow-up output should be a superset of the seed output for that status value, containing all the pets from the seed output plus the newly added pet for MR24.')
def step_mr_MR24_followup_output(context):
    seed_list = _ensure_list(getattr(context, 'seed_response', []))
    followup_list = _ensure_list(getattr(context, 'followup_response', []))
    added_pet = getattr(context, 'added_pet', {})

    # Basic type safety checks
    assert isinstance(seed_list, list), "Seed response is not a list after normalization"
    assert isinstance(followup_list, list), "Follow-up response is not a list after normalization"

    # Build a lookup set for follow-up pets based on (id, name, status) to avoid
    # direct dict membership checks that can be fragile across responses
    def key_for_pet(p: Dict[str, Any]) -> tuple:
        return (
            p.get('id'),
            p.get('name'),
            p.get('status')
        )

    followup_keys = {key_for_pet(pet) for pet in followup_list if isinstance(pet, dict)}

    # All seed pets should appear in followup (superset check)
    missing_seed_pets = []
    for pet in seed_list:
        if not isinstance(pet, dict):
            continue
        if key_for_pet(pet) not in followup_keys:
            missing_seed_pets.append(pet)

    assert not missing_seed_pets, (
        f"Some seed pets are missing in follow-up response (count={len(missing_seed_pets)})."
    )

    # Check that the newly added pet is present in the followup list.
    # Prefer id if present, otherwise fall back to name/status.
    added_key = key_for_pet(added_pet) if isinstance(added_pet, dict) else None

    new_pet_found = False
    if added_key is not None and any(added_key):
        new_pet_found = added_key in followup_keys
    else:
        # Fallback: use name only, but still avoid KeyError/TypeError
        added_name = added_pet.get('name') if isinstance(added_pet, dict) else None
        if added_name:
            new_pet_found = any(
                isinstance(pet, dict) and pet.get('name') == added_name
                for pet in followup_list
            )

    assert new_pet_found, "Newly added pet not found in follow-up response for MR24."

# ----




@given('a seed input that retrieves a user by username, producing a seed output indicating whether the user exists for MR25.')
def _mr_MR25_seed_input(context):
    # Choose a seed username; we first try to retrieve, then create if missing, then retrieve again.
    seed_username = "testuser_mr25"
    context.seed_username = seed_username

    # Retrieve user by username (may or may not exist yet)
    seed_get_resp = requests.get(
        f"{BASE_URL}/user/{seed_username}",
        timeout=10
    )
    context.seed_status_code = seed_get_resp.status_code
    try:
        context.seed_body = seed_get_resp.json()
    except ValueError:
        context.seed_body = None

    # If user does not exist (e.g., 404), create it using POST /user
    if seed_get_resp.status_code == 404:
        user_data = {
            "id": 1000001,
            "username": seed_username,
            "firstName": "Seed",
            "lastName": "User",
            "email": "seeduser_mr25@example.com",
            "password": "password",
            "phone": "1234567890",
            "userStatus": 1
        }
        create_resp = requests.post(
            f"{BASE_URL}/user",
            json=user_data,
            timeout=10
        )
        context.seed_create_status_code = create_resp.status_code
        try:
            context.seed_create_body = create_resp.json()
        except ValueError:
            context.seed_create_body = None

        # Retrieve again after creation to have a defined "exists" seed output
        seed_get_resp_after = requests.get(
            f"{BASE_URL}/user/{seed_username}",
            timeout=10
        )
        context.seed_status_code = seed_get_resp_after.status_code
        try:
            context.seed_body = seed_get_resp_after.json()
        except ValueError:
            context.seed_body = None


@when('a follow-up input is created by adding a list of users using the operation that creates users from a list, and then retrieving each user by their username from the list using the operation that gets user details by username, yielding a follow-up output for MR25.')
def _mr_MR25_followup_input(context):
    # Prepare a list of new users to be created via POST /user/createWithList
    users_list = [
        {
            "id": 1000002,
            "username": "mr25_user1",
            "firstName": "First1",
            "lastName": "Last1",
            "email": "mr25_user1@example.com",
            "password": "password1",
            "phone": "1234567891",
            "userStatus": 1
        },
        {
            "id": 1000003,
            "username": "mr25_user2",
            "firstName": "First2",
            "lastName": "Last2",
            "email": "mr25_user2@example.com",
            "password": "password2",
            "phone": "1234567892",
            "userStatus": 1
        }
    ]
    context.followup_users_list = users_list

    # Use the operation that "Creates list of users with given input array."
    create_list_resp = requests.post(
        f"{BASE_URL}/user/createWithList",
        json=users_list,
        timeout=10
    )
    context.followup_create_status_code = create_list_resp.status_code
    try:
        context.followup_create_body = create_list_resp.json()
    except ValueError:
        context.followup_create_body = None

    # Retrieve each newly added user by username using GET /user/\{username\}
    followup_responses = []
    for user in users_list:
        username = user.get("username")
        if not isinstance(username, str):
            continue
        resp = requests.get(
            f"{BASE_URL}/user/{username}",
            timeout=10
        )
        entry = {
            "username": username,
            "status_code": resp.status_code
        }
        try:
            entry["body"] = resp.json()
        except ValueError:
            entry["body"] = None
        followup_responses.append(entry)

    context.followup_responses = followup_responses


@then('the follow-up output should indicate the presence of each newly added user, differing from the seed output if the users did not exist before for MR25.')
def _mr_MR25_followup_output(context):
    # Verify each newly created user is present (status code 200 and username matches)
    created_usernames = {u.get("username") for u in context.followup_users_list if isinstance(u.get("username"), str)}
    retrieved_usernames = set()

    for item in getattr(context, "followup_responses", []):
        if not isinstance(item, dict):
            continue
        status = item.get("status_code")
        body = item.get("body")
        username = item.get("username")

        assert status == 200, f"Expected 200 when retrieving user '{username}', got {status}"
        if isinstance(body, dict):
            body_username = body.get("username")
            if isinstance(body_username, str):
                retrieved_usernames.add(body_username)

    missing = created_usernames - retrieved_usernames
    assert not missing, f"Newly added users not found in follow-up output: {', '.join(sorted(missing))}"
