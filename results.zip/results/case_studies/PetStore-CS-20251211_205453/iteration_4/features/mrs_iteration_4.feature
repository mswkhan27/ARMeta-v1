Feature: Iteration 4 MRs

  Scenario: MR15 Updating a pet should correctly modify the specified fields
    Given a seed input that retrieves a pet by ID, producing a seed output with that pet's current details for MR15.
    When a follow-up input is created by updating the pet's name via a request that only changes the name, and then retrieving the pet again, yielding a follow-up output for MR15.
    Then the follow-up output should have the updated name while all other pet fields remain identical to the seed output for MR15.

  Scenario: MR16 Retrieving inventory should reflect changes in pet stock levels
    Given a seed input that retrieves the pet inventory grouped by status, producing a seed output that maps each status to a quantity for MR16.
    When a follow-up input is created by deleting an existing pet that currently has a specific status, and then retrieving the inventory again, yielding a follow-up output for MR16.
    Then the follow-up output should show, for that specific status, a quantity that is exactly one less than the corresponding value in the seed output for MR16, assuming at least one pet with that status existed initially.
