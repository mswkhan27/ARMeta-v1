from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that retrieves a pet by ID, producing a seed output with that pet's current details for MR15.")
def _mr_MR15_seed_input(context):
    try:
        pet_data = {
            "name": "doggie",
            "photoUrls": ["url1", "url2"],
            "status": "available"
        }
        response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        response.raise_for_status()

        seed_response = response.json()
        if not isinstance(seed_response, dict):
            raise ValueError("Seed response is not a JSON object")

        pet_id = seed_response.get("id")
        if pet_id is None:
            raise ValueError("Seed response does not contain 'id' field")

        # Retrieve pet by ID to align with the MR wording
        get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        get_response.raise_for_status()
        pet_details = get_response.json()
        if not isinstance(pet_details, dict):
            raise ValueError("Retrieved pet details are not a JSON object")

        context.seed_request = pet_data
        context.seed_response = pet_details
        context.pet_id = pet_id
    except Exception as e:
        print(f"Error in Given step for MR15: {e}")
        raise


@when("a follow-up input is created by updating the pet's name via a request that only changes the name, and then retrieving the pet again, yielding a follow-up output for MR15.")
def _mr_MR15_followup_input(context):
    try:
        if not hasattr(context, "seed_response"):
            raise AttributeError("seed_response not found in context")
        if not hasattr(context, "pet_id"):
            raise AttributeError("pet_id not found in context")

        seed = context.seed_response
        pet_id = context.pet_id

        updated_pet_data = {
            "id": seed.get("id"),
            "name": "doggie_updated",
            "photoUrls": seed.get("photoUrls") or [],
            "status": seed.get("status")
        }

        if updated_pet_data["id"] is None:
            raise ValueError("Seed response 'id' is missing or null")

        update_response = requests.put(f"{BASE_URL}/pet", json=updated_pet_data, timeout=10)
        update_response.raise_for_status()

        followup_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        followup_response.raise_for_status()

        followup_data = followup_response.json()
        if not isinstance(followup_data, dict):
            raise ValueError("Follow-up response is not a JSON object")

        context.followup_response = followup_data
    except Exception as e:
        print(f"Error in When step for MR15: {e}")
        raise


@then("the follow-up output should have the updated name while all other pet fields remain identical to the seed output for MR15.")
def _mr_MR15_followup_output(context):
    try:
        if not hasattr(context, "seed_response"):
            raise AttributeError("seed_response not found in context")
        if not hasattr(context, "followup_response"):
            raise AttributeError("followup_response not found in context")

        seed = context.seed_response
        followup = context.followup_response

        for key in ("id", "name", "photoUrls", "status"):
            if key not in seed:
                raise KeyError(f"Key '{key}' missing from seed_response")
            if key not in followup:
                raise KeyError(f"Key '{key}' missing from followup_response")

        assert followup["name"] == "doggie_updated", "The pet name was not updated correctly."
        assert followup["id"] == seed["id"], "The pet ID should remain the same."
        assert followup["photoUrls"] == seed["photoUrls"], "The photoUrls should remain unchanged."
        assert followup["status"] == seed["status"], "The status should remain unchanged."

        # Ensure no unintended extra-field changes for common fields
        comparable_seed = {k: v for k, v in seed.items() if k not in ("name",)}
        comparable_followup = {k: v for k, v in followup.items() if k not in ("name",)}
        assert comparable_followup == comparable_seed, "Fields other than 'name' changed unexpectedly."
    except AssertionError as e:
        print(f"Assertion error in Then step for MR15: {e}")
        raise
    except Exception as e:
        print(f"Error in Then step for MR15: {e}")
        raise

# ----




@given('a seed input that retrieves the pet inventory grouped by status, producing a seed output that maps each status to a quantity for MR16.')
def _mr_MR16_seed_input(context):
    try:
        response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
        assert response.status_code == 200, (
            f"Failed to retrieve inventory: {response.status_code} {response.text}"
        )

        data = response.json()
        if not isinstance(data, dict):
            raise AssertionError(f"Inventory response is not an object/map: {data!r}")

        # Ensure all values are integers (or can be treated as such safely)
        safe_inventory = {}
        for k, v in data.items():
            try:
                safe_inventory[str(k)] = int(v)
            except (TypeError, ValueError):
                raise AssertionError(
                    f"Inventory value for status '{k}' is not an integer-compatible value: {v!r}"
                )

        if not safe_inventory:
            raise AssertionError("Inventory is empty; cannot apply MR16.")

        context.seed_request = response
        context.seed_response = safe_inventory

    except Exception as e:
        print(f"Error in Given step for MR16: {e}")
        raise


@when('a follow-up input is created by deleting an existing pet that currently has a specific status, and then retrieving the inventory again, yielding a follow-up output for MR16.')
def _mr_MR16_followup_input(context):
    try:
        if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
            raise AssertionError("Seed inventory not available or invalid in context.")

        # Select a status that has at least one pet in the inventory
        status_to_delete = None
        for status, qty in context.seed_response.items():
            if isinstance(qty, int) and qty > 0:
                status_to_delete = status
                break

        if status_to_delete is None:
            raise AssertionError(
                "No status with quantity > 0 found in inventory; cannot apply MR16."
            )

        # Retrieve pets for that status using /pet/findByStatus (summary: Finds Pets by status.)
        pets_response = requests.get(
            f"{BASE_URL}/pet/findByStatus",
            params={"status": status_to_delete},
            timeout=10,
        )
        assert pets_response.status_code == 200, (
            f"Failed to retrieve pets with status {status_to_delete}: "
            f"{pets_response.status_code} {pets_response.text}"
        )

        pets = pets_response.json()
        if not isinstance(pets, list):
            raise AssertionError(f"Pets response is not a list: {pets!r}")

        if not pets:
            raise AssertionError(
                f"No pets found with status '{status_to_delete}' despite inventory indicating at least one."
            )

        first_pet = pets[0]
        if not isinstance(first_pet, dict):
            raise AssertionError(f"Pet item is not an object: {first_pet!r}")

        pet_id = first_pet.get("id")
        if pet_id is None:
            raise AssertionError(f"Pet object has no 'id' field: {first_pet!r}")

        try:
            pet_id_int = int(pet_id)
        except (TypeError, ValueError):
            raise AssertionError(f"Pet id is not integer-compatible: {pet_id!r}")

        # Delete the pet using DELETE /pet/\{petId\} (summary: Deletes a pet.)
        delete_response = requests.delete(
            f"{BASE_URL}/pet/{pet_id_int}",
            timeout=10,
        )
        assert delete_response.status_code == 200, (
            f"Failed to delete pet with id {pet_id_int}: "
            f"{delete_response.status_code} {delete_response.text}"
        )

        # Retrieve inventory again after deletion using /store/inventory
        followup = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
        assert followup.status_code == 200, (
            f"Failed to retrieve inventory after deletion: "
            f"{followup.status_code} {followup.text}"
        )

        followup_data = followup.json()
        if not isinstance(followup_data, dict):
            raise AssertionError(
                f"Follow-up inventory response is not an object/map: {followup_data!r}"
            )

        safe_followup_inventory = {}
        for k, v in followup_data.items():
            try:
                safe_followup_inventory[str(k)] = int(v)
            except (TypeError, ValueError):
                raise AssertionError(
                    f"Follow-up inventory value for status '{k}' is not integer-compatible: {v!r}"
                )

        context.status_deleted = status_to_delete
        context.followup_request = followup
        context.followup_response = safe_followup_inventory

    except Exception as e:
        print(f"Error in When step for MR16: {e}")
        raise


@then('the follow-up output should show, for that specific status, a quantity that is exactly one less than the corresponding value in the seed output for MR16, assuming at least one pet with that status existed initially.')
def _mr_MR16_followup_output(context):
    try:
        if not hasattr(context, "status_deleted"):
            raise AssertionError("Deleted status not stored in context.")
        if not isinstance(context.seed_response, dict):
            raise AssertionError("Seed inventory missing or invalid in context.")
        if not isinstance(context.followup_response, dict):
            raise AssertionError("Follow-up inventory missing or invalid in context.")

        status_to_check = context.status_deleted
        if status_to_check not in context.seed_response:
            raise AssertionError(
                f"Status '{status_to_check}' not present in seed inventory."
            )

        seed_quantity = context.seed_response[status_to_check]
        followup_quantity = context.followup_response.get(status_to_check, 0)

        if not isinstance(seed_quantity, int):
            raise AssertionError(
                f"Seed quantity for status '{status_to_check}' is not int: {seed_quantity!r}"
            )
        if not isinstance(followup_quantity, int):
            raise AssertionError(
                f"Follow-up quantity for status '{status_to_check}' is not int: {followup_quantity!r}"
            )

        expected = seed_quantity - 1
        assert followup_quantity == expected, (
            f"Expected quantity for status '{status_to_check}' to be {expected}, "
            f"but got {followup_quantity}. Seed={seed_quantity}, Follow-up={followup_quantity}"
        )

    except Exception as e:
        print(f"Error in Then step for MR16: {e}")
        raise
