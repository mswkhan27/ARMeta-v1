from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that retrieves a user by user name, producing a seed output with the user's details for MR12.")
def _mr_MR12_seed_input(context):
    # Create a user to ensure it exists
    user_data = {
        "id": 10,
        "username": "testuser",
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1
    }

    response = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    context.seed_request = response

    # Defensive JSON parsing
    try:
        context.seed_response = response.json()
    except ValueError:
        context.seed_response = {}

    assert response.status_code == 200, f"Failed to create user: {response.text}"

    # Safely extract username from either request or response
    context.user_name = context.seed_response.get("username") or user_data["username"]

    # Retrieve the user to get the seed output
    get_resp = requests.get(f"{BASE_URL}/user/{context.user_name}", timeout=10)
    context.get_user_request = get_resp
    try:
        context.get_user_response = get_resp.json()
    except ValueError:
        context.get_user_response = {}

    assert get_resp.status_code == 200, f"Failed to retrieve user: {get_resp.text}"


@when("a follow-up input is created by updating the user's details and then retrieving the same user again, yielding a follow-up output for MR12.")
def _mr_MR12_followup_input(context):
    # Ensure we have an initial user response dictionary
    original_user = context.get_user_response if isinstance(context.get_user_response, dict) else {}

    user_id = original_user.get("id", 10)
    username = original_user.get("username", context.user_name)

    updated_user_data = {
        "id": user_id,
        "username": username,
        "firstName": "Jane",
        "lastName": original_user.get("lastName", "Doe"),
        "email": "jane.doe@example.com",
        "password": "newpassword",
        "phone": "0987654321",
        "userStatus": original_user.get("userStatus", 1),
    }

    update_resp = requests.put(
        f"{BASE_URL}/user/{context.user_name}",
        json=updated_user_data,
        timeout=10,
    )
    context.update_user_request = update_resp
    assert update_resp.status_code == 200, f"Failed to update user: {update_resp.text}"

    followup_resp = requests.get(f"{BASE_URL}/user/{context.user_name}", timeout=10)
    context.followup_request = followup_resp
    try:
        context.followup_response = followup_resp.json()
    except ValueError:
        context.followup_response = {}

    assert followup_resp.status_code == 200, f"Failed to retrieve updated user: {followup_resp.text}"


@then("the follow-up output should show the updated values for the fields provided in the update request for MR12.")
def _mr_MR12_followup_output(context):
    resp = context.followup_response if isinstance(context.followup_response, dict) else {}

    assert resp.get("firstName") == "Jane", "First name was not updated correctly."
    assert resp.get("lastName") == "Doe", "Last name should remain unchanged."
    assert resp.get("email") == "jane.doe@example.com", "Email was not updated correctly."
    assert resp.get("phone") == "0987654321", "Phone number was not updated correctly."

# ----




@given("a seed input that retrieves a user by user name, producing a seed output with the user's details for MR14.")
def step_mr_MR14_seed_input(context):
    # Create a user for testing
    user_data = {
        "id": 10,
        "username": "testuser",
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1
    }

    create_response = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    try:
        create_json = create_response.json()
    except ValueError:
        create_json = None

    assert create_response.status_code == 200, (
        f"Failed to create user: status={create_response.status_code}, "
        f"body={create_response.text}"
    )

    # Retrieve the user to get the seed output
    seed_response = requests.get(f"{BASE_URL}/user/testuser", timeout=10)
    try:
        seed_json = seed_response.json()
    except ValueError:
        seed_json = None

    assert seed_response.status_code == 200, (
        f"Failed to retrieve user: status={seed_response.status_code}, "
        f"body={seed_response.text}"
    )

    context.seed_request = seed_response
    context.seed_response = seed_json
    context.created_user_response = create_json


@when("a follow-up input is created by logging the user out and then retrieving the same user again, yielding a follow-up output for MR14.")
def step_mr_MR14_followup_input(context):
    # Log the user out
    logout_response = requests.get(f"{BASE_URL}/user/logout", timeout=10)
    try:
        logout_json = logout_response.json()
    except ValueError:
        logout_json = None

    assert logout_response.status_code == 200, (
        f"Failed to log out user: status={logout_response.status_code}, "
        f"body={logout_response.text}"
    )

    # Retrieve the user again to get the follow-up output
    followup_response = requests.get(f"{BASE_URL}/user/testuser", timeout=10)
    try:
        followup_json = followup_response.json()
    except ValueError:
        followup_json = None

    assert followup_response.status_code == 200, (
        f"Failed to retrieve user after logout: status={followup_response.status_code}, "
        f"body={followup_response.text}"
    )

    context.logout_response = logout_response
    context.logout_json = logout_json
    context.followup_request = followup_response
    context.followup_response = followup_json


@then("the follow-up output should be identical to the seed output for MR14, as logging out does not change stored user data.")
def step_mr_MR14_followup_output(context):
    assert context.seed_response is not None, "Seed response JSON is None or invalid."
    assert context.followup_response is not None, "Follow-up response JSON is None or invalid."

    # Ensure comparison uses JSON structures only
    seed_serialized = json.dumps(context.seed_response, sort_keys=True)
    followup_serialized = json.dumps(context.followup_response, sort_keys=True)

    assert seed_serialized == followup_serialized, (
        "Follow-up output does not match seed output.\n"
        f"Seed: {seed_serialized}\n"
        f"Follow-up: {followup_serialized}"
    )
