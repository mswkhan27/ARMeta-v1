Feature: Iteration 3 MRs

  Scenario: MR12 Updating a user's details should reflect in subsequent retrievals
    Given a seed input that retrieves a user by user name, producing a seed output with the user's details for MR12.
    When a follow-up input is created by updating the user's details and then retrieving the same user again, yielding a follow-up output for MR12.
    Then the follow-up output should show the updated values for the fields provided in the update request for MR12.

  Scenario: MR14 Logging out should not affect the user's stored data
    Given a seed input that retrieves a user by user name, producing a seed output with the user's details for MR14.
    When a follow-up input is created by logging the user out and then retrieving the same user again, yielding a follow-up output for MR14.
    Then the follow-up output should be identical to the seed output for MR14, as logging out does not change stored user data.
