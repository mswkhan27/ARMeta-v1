Feature: Iteration 2 MRs

  Scenario: MR5 Deleting a user should make the user inaccessible
    Given a seed input that retrieves a user by a valid username, producing a seed output with that user's details for MR5.
    When a follow-up input is created by deleting the user with the same username, and then attempting to retrieve the user again, yielding a follow-up output for MR5.
    Then the follow-up output should indicate that the user is not found (for example, via an appropriate error response), differing from the seed output which contained the user's details for MR5.

  Scenario: MR7 Logging in multiple times with the same credentials should behave consistently
    Given a seed input that attempts to log in with valid credentials, producing a seed output that is a successful login response body and associated headers for MR7.
    When a follow-up input is created by logging in again with the same valid credentials, yielding a follow-up output for MR7.
    Then the follow-up output should again be a successful login response of the same type (for example, a non-empty string body and relevant headers), consistent with the seed output pattern for MR7, even if the exact body value may be the same or different.

  Scenario: MR8 Retrieving inventory should reflect current stock levels by status
    Given a seed input that retrieves the pet inventory grouped by status, producing a seed output that maps each status to a quantity for MR8.
    When a follow-up input is created by adding a new pet with a specific valid status, and then retrieving the inventory again, yielding a follow-up output for MR8.
    Then the follow-up output should show a quantity for the specific status that is at least one greater than (or, if the status key was previously absent, at least 1 instead of absent in) the corresponding value in the seed output for MR8, assuming no concurrent deletions or updates reduce that status count.

  Scenario: MR9 Finding pets by tags should return pets with those tags
    Given a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR9.
    When a follow-up input is created by adding a new pet that includes the same tag value in its tag list, and then retrieving pets filtered by that tag value again, yielding a follow-up output for MR9.
    Then the follow-up output should include the newly added pet among the returned pets with that tag, making it a superset of or equal to the seed output list for MR9, assuming no concurrent deletions of pets with that tag.
