from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that retrieves a user by a valid username, producing a seed output with that user's details for MR5.")
def _mr_MR5_seed_input(context):
    username = "testuser_mr5"
    user_data = {
        "id": 10,
        "username": username,
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1,
    }

    # Create a user to ensure it exists
    create_resp = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    context.seed_create_status = create_resp.status_code

    # Safely parse JSON if possible
    try:
        context.seed_create_body = create_resp.json()
    except ValueError:
        context.seed_create_body = create_resp.text

    assert create_resp.status_code == 200, (
        f"Failed to create user: status={create_resp.status_code}, "
        f"body={context.seed_create_body}"
    )

    # Retrieve the user to get the seed output
    get_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    context.seed_get_status = get_resp.status_code

    try:
        context.seed_get_body = get_resp.json()
    except ValueError:
        context.seed_get_body = get_resp.text

    assert get_resp.status_code == 200, (
        f"Failed to retrieve user: status={get_resp.status_code}, "
        f"body={context.seed_get_body}"
    )

    # Store username for later steps to avoid hard‑coding
    context.username_mr5 = username


@when("a follow-up input is created by deleting the user with the same username, and then attempting to retrieve the user again, yielding a follow-up output for MR5.")
def _mr_MR5_followup_input(context):
    username = getattr(context, "username_mr5", "testuser_mr5")

    # Delete the user
    delete_resp = requests.delete(f"{BASE_URL}/user/{username}", timeout=10)
    context.followup_delete_status = delete_resp.status_code

    try:
        context.followup_delete_body = delete_resp.json()
    except ValueError:
        context.followup_delete_body = delete_resp.text

    assert delete_resp.status_code == 200, (
        f"Failed to delete user: status={delete_resp.status_code}, "
        f"body={context.followup_delete_body}"
    )

    # Attempt to retrieve the user again
    get_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    context.followup_get_status = get_resp.status_code

    try:
        context.followup_get_body = get_resp.json()
    except ValueError:
        context.followup_get_body = get_resp.text


@then("the follow-up output should indicate that the user is not found (for example, via an appropriate error response), differing from the seed output which contained the user's details for MR5.")
def _mr_MR5_followup_output(context):
    status = getattr(context, "followup_get_status", None)
    body = getattr(context, "followup_get_body", None)

    assert status == 404, (
        f"Expected 404 when retrieving deleted user, "
        f"got status={status}, body={body}"
    )

# ----




@given('a seed input that attempts to log in with valid credentials, producing a seed output that is a successful login response body and associated headers for MR7.')
def step_mr_MR7_seed_input(context):
    context.username = "validUser"      # Replace with actual valid username if needed
    context.password = "validPassword"  # Replace with actual valid password if needed

    context.seed_request = {
        "username": context.username,
        "password": context.password
    }

    try:
        response = requests.get(
            f"{BASE_URL}/user/login",
            params=context.seed_request,
            timeout=10
        )
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"MR7 Given step failed during login request: {e}") from e

    context.seed_response = response

    # Validate response type and headers safely
    # Body is specified as string in the OpenAPI, so use .text instead of .json()
    body = context.seed_response.text
    assert isinstance(body, str), "Seed response body is not a string"
    assert body.strip() != "", "Seed response body is empty"

    # Headers should be present according to spec
    headers = context.seed_response.headers or {}
    assert 'X-Rate-Limit' in headers, "Missing X-Rate-Limit header in seed response"
    assert 'X-Expires-After' in headers, "Missing X-Expires-After header in seed response"


@when('a follow-up input is created by logging in again with the same valid credentials, yielding a follow-up output for MR7.')
def step_mr_MR7_followup_input(context):
    assert hasattr(context, "seed_request"), "Seed request not found in context; Given step may have failed"

    try:
        response = requests.get(
            f"{BASE_URL}/user/login",
            params=context.seed_request,
            timeout=10
        )
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"MR7 When step failed during follow-up login request: {e}") from e

    context.followup_response = response


@then('the follow-up output should again be a successful login response of the same type (for example, a non-empty string body and relevant headers), consistent with the seed output pattern for MR7, even if the exact body value may be the same or different.')
def step_mr_MR7_followup_output(context):
    assert hasattr(context, "seed_response"), "Seed response not found in context; Given step may have failed"
    assert hasattr(context, "followup_response"), "Follow-up response not found in context; When step may have failed"

    followup = context.followup_response
    seed = context.seed_response

    # Status code check
    assert followup.status_code == 200, f"Follow-up response was not successful, status: {followup.status_code}"

    # Body type and non-empty check (string per OpenAPI)
    followup_body = followup.text
    seed_body = seed.text

    assert isinstance(followup_body, str), "Follow-up response body is not a string"
    assert followup_body.strip() != "", "Follow-up response body is empty"

    # Consistency of type: both should be strings
    assert isinstance(seed_body, str), "Seed response body is not a string"
    # They may be equal or different; we only enforce type and non-empty pattern

    # Header checks: presence and type consistency
    followup_headers = followup.headers or {}
    seed_headers = seed.headers or {}

    for header_name in ['X-Rate-Limit', 'X-Expires-After']:
        assert header_name in followup_headers, f"Missing {header_name} header in follow-up response"
        assert header_name in seed_headers, f"Missing {header_name} header in seed response"

        # Ensure header types are consistent between seed and follow-up
        seed_val = seed_headers.get(header_name)
        follow_val = followup_headers.get(header_name)

        # Convert to string for safe comparison without raising type errors
        if seed_val is not None and follow_val is not None:
            assert isinstance(str(seed_val), str), f"{header_name} in seed response is not convertible to string"
            assert isinstance(str(follow_val), str), f"{header_name} in follow-up response is not convertible to string"

# ----

import time



@given('a seed input that retrieves the pet inventory grouped by status, producing a seed output that maps each status to a quantity for MR8.')
def _mr_MR8_seed_input(context):
    url = f"{BASE_URL}/store/inventory"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        # Response is expected to be an object mapping status -> integer
        data = response.json()
        if not isinstance(data, dict):
            raise ValueError(f"Expected inventory as JSON object, got {type(data).__name__}")
        # Ensure all values are integers (or safely castable)
        safe_data = {}
        for k, v in data.items():
            try:
                safe_data[str(k)] = int(v)
            except (TypeError, ValueError):
                raise ValueError(f"Inventory value for status '{k}' is not an integer: {v!r}")
        context.seed_response = safe_data
        context.seed_request = {"method": "GET", "url": url}
    except (requests.RequestException, ValueError) as e:
        print(f"Error in MR8 Given step: {e}")
        raise


@when('a follow-up input is created by adding a new pet with a specific valid status, and then retrieving the inventory again, yielding a follow-up output for MR8.')
def _mr_MR8_followup_input(context):
    pet_url = f"{BASE_URL}/pet"
    inventory_url = f"{BASE_URL}/store/inventory"
    status = "available"  # valid status according to the OpenAPI spec

    # Create a new pet with the chosen status
    new_pet = {
        "name": "Buddy",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": status
    }

    try:
        add_pet_response = requests.post(pet_url, json=new_pet, timeout=10)
        add_pet_response.raise_for_status()
        # Optionally validate that we received a Pet object
        try:
            pet_data = add_pet_response.json()
            if not isinstance(pet_data, dict):
                raise ValueError(f"Expected created pet as JSON object, got {type(pet_data).__name__}")
        except (ValueError, json.JSONDecodeError):
            # If body is not JSON, we still proceed as the inventory endpoint is independent
            pet_data = None

        # Small delay to allow inventory to update if backend is eventually consistent
        time.sleep(0.2)

        followup_response = requests.get(inventory_url, timeout=10)
        followup_response.raise_for_status()
        data = followup_response.json()
        if not isinstance(data, dict):
            raise ValueError(f"Expected inventory as JSON object, got {type(data).__name__}")
        safe_data = {}
        for k, v in data.items():
            try:
                safe_data[str(k)] = int(v)
            except (TypeError, ValueError):
                raise ValueError(f"Inventory value for status '{k}' is not an integer: {v!r}")

        context.followup_response = safe_data
        context.followup_request = {
            "add_pet": {"method": "POST", "url": pet_url, "body": new_pet},
            "get_inventory": {"method": "GET", "url": inventory_url},
        }
        context._mr8_status = status
    except (requests.RequestException, ValueError) as e:
        print(f"Error in MR8 When step: {e}")
        raise


@then('the follow-up output should show a quantity for the specific status that is at least one greater than (or, if the status key was previously absent, at least 1 instead of absent in) the corresponding value in the seed output for MR8, assuming no concurrent deletions or updates reduce that status count.')
def _mr_MR8_followup_output(context):
    try:
        status = getattr(context, "_mr8_status", "available")

        seed_inventory = getattr(context, "seed_response", None)
        followup_inventory = getattr(context, "followup_response", None)

        if not isinstance(seed_inventory, dict):
            raise ValueError("Seed inventory is missing or not a JSON object.")
        if not isinstance(followup_inventory, dict):
            raise ValueError("Follow-up inventory is missing or not a JSON object.")

        seed_quantity = int(seed_inventory.get(status, 0))
        followup_raw = followup_inventory.get(status, 0)
        try:
            followup_quantity = int(followup_raw)
        except (TypeError, ValueError):
            raise ValueError(f"Follow-up quantity for status '{status}' is not an integer: {followup_raw!r}")

        expected_min = seed_quantity + 1
        assert followup_quantity >= expected_min, (
            f"Expected follow-up quantity for status '{status}' to be at least {expected_min}, "
            f"but got {followup_quantity}. Seed was {seed_quantity}."
        )
    except Exception as e:
        print(f"Error in MR8 Then step: {e}")
        raise

# ----




@given('a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR9.')
def _mr_MR9_seed_input(context):
    tag_value = "tag1"  # Example tag value from API description
    context.tag_value = tag_value

    context.seed_request = {
        "tags": [tag_value]
    }

    response = requests.get(
        f"{BASE_URL}/pet/findByTags",
        params=context.seed_request,
        timeout=10
    )
    response.raise_for_status()

    try:
        seed_response = response.json()
    except ValueError as exc:
        raise AssertionError(f"Seed response is not valid JSON: {exc}") from exc

    if not isinstance(seed_response, list):
        raise AssertionError(f"Expected seed response to be a list, got {type(seed_response).__name__}")

    context.seed_response = seed_response


@when('a follow-up input is created by adding a new pet that includes the same tag value in its tag list, and then retrieving pets filtered by that tag value again, yielding a follow-up output for MR9.')
def _mr_MR9_followup_input(context):
    tag_value = getattr(context, "tag_value", "tag1")

    new_pet = {
        "name": "New Pet MR9",
        "photoUrls": ["http://example.com/photo.jpg"],
        "tags": [{"name": tag_value}],
        "status": "available"
    }

    add_response = requests.post(
        f"{BASE_URL}/pet",
        json=new_pet,
        timeout=10
    )
    add_response.raise_for_status()

    try:
        added_pet = add_response.json()
    except ValueError as exc:
        raise AssertionError(f"Add-pet response is not valid JSON: {exc}") from exc

    if not isinstance(added_pet, dict):
        raise AssertionError(f"Expected added pet to be an object, got {type(added_pet).__name__}")

    added_pet_id = added_pet.get("id")
    if not isinstance(added_pet_id, int):
        raise AssertionError(f"Expected added pet to have an integer 'id', got: {added_pet_id!r}")

    context.added_pet_id = added_pet_id

    # Small delay to reduce risk of eventual consistency issues
    time.sleep(0.2)

    followup_response = requests.get(
        f"{BASE_URL}/pet/findByTags",
        params={"tags": [tag_value]},
        timeout=10
    )
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except ValueError as exc:
        raise AssertionError(f"Follow-up response is not valid JSON: {exc}") from exc

    if not isinstance(followup_data, list):
        raise AssertionError(f"Expected follow-up response to be a list, got {type(followup_data).__name__}")

    context.followup_response = followup_data


@then('the follow-up output should include the newly added pet among the returned pets with that tag, making it a superset of or equal to the seed output list for MR9, assuming no concurrent deletions of pets with that tag.')
def _mr_MR9_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response is missing from context")
    if not hasattr(context, "followup_response"):
        raise AssertionError("followup_response is missing from context")
    if not hasattr(context, "added_pet_id"):
        raise AssertionError("added_pet_id is missing from context")

    seed_list = context.seed_response
    followup_list = context.followup_response

    if not isinstance(seed_list, list):
        raise AssertionError(f"Expected seed_response to be a list, got {type(seed_list).__name__}")
    if not isinstance(followup_list, list):
        raise AssertionError(f"Expected followup_response to be a list, got {type(followup_list).__name__}")

    def safe_get_id(pet):
        if not isinstance(pet, dict):
            return None
        pet_id = pet.get("id")
        return pet_id if isinstance(pet_id, int) else None

    seed_pet_ids = {pid for pid in (safe_get_id(p) for p in seed_list) if pid is not None}
    followup_pet_ids = {pid for pid in (safe_get_id(p) for p in followup_list) if pid is not None}

    added_pet_id = context.added_pet_id

    # MR condition 1: follow-up result is a superset or equal to seed result
    if not seed_pet_ids.issubset(followup_pet_ids):
        missing = seed_pet_ids - followup_pet_ids
        raise AssertionError(f"Follow-up output is not a superset of seed output; missing seed pet IDs: {missing}")

    # MR condition 2: newly added pet is present in follow-up output
    if added_pet_id not in followup_pet_ids:
        raise AssertionError(
            f"Newly added pet with id {added_pet_id} is not present in follow-up output filtered by the same tag."
        )
