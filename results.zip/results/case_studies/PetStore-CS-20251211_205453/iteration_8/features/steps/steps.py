from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that attempts to retrieve a pet by a specific valid numeric ID, producing a seed output that may indicate that no pet is currently associated with that ID for MR31.')
def step_mr_MR31_seed_input(context):
    pet_id = 1  # Using a valid numeric ID for the test
    context.pet_id = pet_id

    try:
        response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to GET /pet/{{petId}} failed: {e}")

    context.seed_status_code = response.status_code

    # Safely attempt to parse JSON only if content is present and content-type is JSON
    seed_json = None
    if response.content:
        try:
            seed_json = response.json()
        except ValueError:
            seed_json = None

    if response.status_code == 200 and isinstance(seed_json, dict):
        context.seed_response = seed_json
    elif response.status_code == 404:
        context.seed_response = None  # No pet found
    else:
        # For any other status code, just store whatever was received
        context.seed_response = seed_json


@when('a follow-up input is created by adding a new pet whose representation includes that same valid ID, and then retrieving the pet by that ID again, yielding a follow-up output for MR31.')
def step_mr_MR31_followup_input(context):
    pet_id = getattr(context, "pet_id", 1)

    new_pet = {
        "id": int(pet_id),
        "name": "Doggie",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    try:
        # Add the new pet
        create_response = requests.post(f"{BASE_URL}/pet", json=new_pet, timeout=10)
        context.create_status_code = create_response.status_code
        try:
            context.create_response = create_response.json() if create_response.content else None
        except ValueError:
            context.create_response = None

        # Retrieve the pet by ID again
        retrieve_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        context.followup_status_code = retrieve_response.status_code

        followup_json = None
        if retrieve_response.content:
            try:
                followup_json = retrieve_response.json()
            except ValueError:
                followup_json = None

        context.followup_response = followup_json
    except requests.RequestException as e:
        raise AssertionError(f"Error during follow-up input for MR31: {e}")


@then('the follow-up output should indicate the presence of a pet resource associated with that ID, differing from the seed output if the pet did not exist before for MR31.')
def step_mr_MR31_followup_output(context):
    pet_id = getattr(context, "pet_id", 1)

    # Ensure the follow-up request succeeded with an OK response
    assert getattr(context, "followup_status_code", None) == 200, (
        f"Expected 200 when retrieving pet after creation, got "
        f"{getattr(context, 'followup_status_code', None)}"
    )

    followup = getattr(context, "followup_response", None)
    assert isinstance(followup, dict), "Follow-up response should be a JSON object"

    # Safely access keys to avoid KeyError / TypeError
    assert followup.get("id") == int(pet_id), f"The pet ID in the follow-up response should be {pet_id}"
    assert followup.get("name") == "Doggie", "The pet name should be 'Doggie'"
    assert followup.get("status") == "available", "The pet status should be 'available'"

    # If the seed response indicated no such pet, the follow-up should now have a pet
    if context.seed_response is None:
        assert followup is not None, "A pet should be present after creation for MR31"

# ----




@given('a seed input that retrieves the list of pets filtered by a valid status value (available, pending, or sold), producing a seed output with a count of pets for that status for MR32.')
def step_mr_MR32_seed_input(context):
    status = 'available'  # Using 'available' as the valid status
    url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": status}

    seed_request = requests.get(url, params=params, timeout=10)
    context.seed_status_code = seed_request.status_code

    try:
        seed_response = seed_request.json()
    except ValueError as e:
        raise AssertionError(f"Seed response is not valid JSON: {e}")

    if not isinstance(seed_response, list):
        raise AssertionError(f"Seed response is not a list, got {type(seed_response).__name__}")

    context.seed_response = seed_response
    context.seed_count = len(seed_response)
    context.seed_status = status


@when('a follow-up input is created by adding a new pet whose status property is set to that same status value, and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR32.')
def step_mr_MR32_followup_input(context):
    status = getattr(context, "seed_status", "available")

    new_pet = {
        "name": "New Pet MR32",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": status
    }

    add_url = f"{BASE_URL}/pet"
    add_response = requests.post(add_url, json=new_pet, timeout=10)
    context.add_pet_status_code = add_response.status_code

    if add_response.status_code != 200:
        raise AssertionError(f"Failed to add new pet, status code: {add_response.status_code}")

    try:
        added_pet = add_response.json()
    except ValueError as e:
        raise AssertionError(f"Add-pet response is not valid JSON: {e}")

    if not isinstance(added_pet, dict):
        raise AssertionError(f"Add-pet response is not an object, got {type(added_pet).__name__}")

    context.added_pet = added_pet

    followup_url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": status}
    followup_request = requests.get(followup_url, params=params, timeout=10)
    context.followup_status_code = followup_request.status_code

    try:
        followup_response = followup_request.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response is not valid JSON: {e}")

    if not isinstance(followup_response, list):
        raise AssertionError(f"Follow-up response is not a list, got {type(followup_response).__name__}")

    context.followup_response = followup_response
    context.followup_count = len(followup_response)


@then('the follow-up output should have a count of pets for that status that is at least one more than the seed output for MR32, assuming no other changes occurred to pets with that status in between and that the added pet was not already present with that status.')
def step_mr_MR32_followup_output(context):
    if not hasattr(context, "seed_count"):
        raise AssertionError("Seed count is missing from context")
    if not hasattr(context, "followup_count"):
        raise AssertionError("Follow-up count is missing from context")

    seed_count = context.seed_count
    followup_count = context.followup_count

    if not isinstance(seed_count, int):
        raise AssertionError(f"Seed count is not an int, got {type(seed_count).__name__}")
    if not isinstance(followup_count, int):
        raise AssertionError(f"Follow-up count is not an int, got {type(followup_count).__name__}")

    if followup_count < seed_count + 1:
        raise AssertionError(
            f"Follow-up count ({followup_count}) is not at least one more than seed count ({seed_count})"
        )

# ----




@given('a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR33.')
def _mr_MR33_seed_input(context):
    tag_value = "tag1"  # Example tag value, corresponds to description of /pet/findByTags
    context.tag_value = tag_value

    context.seed_request = {'tags': [tag_value]}
    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params=context.seed_request,
            timeout=10,
        )
        response.raise_for_status()
        data = response.json()
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in GIVEN step for MR33: {e}") from e
    except ValueError as e:
        raise AssertionError(f"Non-JSON response in GIVEN step for MR33: {e}") from e

    if not isinstance(data, list):
        raise AssertionError(f"Expected list from /pet/findByTags, got {type(data)}")
    context.seed_response = data


@when('a follow-up input is created by adding a new pet whose tag list includes that same tag value, and then retrieving pets filtered by that tag value again, yielding a follow-up output for MR33.')
def _mr_MR33_followup_input(context):
    tag_value = getattr(context, "tag_value", "tag1")

    new_pet = {
        "name": "New Pet MR33",
        "photoUrls": ["http://example.com/photo.jpg"],
        "tags": [{"id": 1, "name": tag_value}],
        "status": "available",
    }

    try:
        add_response = requests.post(
            f"{BASE_URL}/pet",
            json=new_pet,
            timeout=10,
        )
        add_response.raise_for_status()
        added_pet = add_response.json()
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error when adding pet in WHEN step for MR33: {e}") from e
    except ValueError as e:
        raise AssertionError(f"Non-JSON response when adding pet in WHEN step for MR33: {e}") from e

    if not isinstance(added_pet, dict):
        raise AssertionError(f"Expected dict when adding pet, got {type(added_pet)}")

    context.added_pet = added_pet
    added_pet_id = added_pet.get("id")

    context.followup_request = {'tags': [tag_value]}
    try:
        followup_response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params=context.followup_request,
            timeout=10,
        )
        followup_response.raise_for_status()
        followup_data = followup_response.json()
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error when retrieving pets in WHEN step for MR33: {e}") from e
    except ValueError as e:
        raise AssertionError(f"Non-JSON response when retrieving pets in WHEN step for MR33: {e}") from e

    if not isinstance(followup_data, list):
        raise AssertionError(f"Expected list from /pet/findByTags in follow-up, got {type(followup_data)}")

    context.followup_response = followup_data
    context.added_pet_id = added_pet_id


@then('the follow-up output should include the newly added pet among the returned pets with that tag, making the follow-up list a superset of or equal to the seed output list for MR33.')
def _mr_MR33_followup_output(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    if not isinstance(seed, list):
        raise AssertionError(f"Seed response is not a list, got {type(seed)}")
    if not isinstance(followup, list):
        raise AssertionError(f"Follow-up response is not a list, got {type(followup)}")

    added_pet = getattr(context, "added_pet", None)
    if not isinstance(added_pet, dict):
        raise AssertionError("Added pet data is missing or not a dict")

    added_pet_id = context.added_pet_id if hasattr(context, "added_pet_id") else added_pet.get("id")
    added_pet_name = added_pet.get("name")

    # Check that the newly added pet is present in the follow-up response
    def _safe_get(pet: dict, key: str):
        return pet.get(key) if isinstance(pet, dict) else None

    new_pet_found = False
    for pet in followup:
        pet_id = _safe_get(pet, "id")
        pet_name = _safe_get(pet, "name")
        if added_pet_id is not None and pet_id == added_pet_id:
            new_pet_found = True
            break
        if added_pet_name is not None and pet_name == added_pet_name:
            new_pet_found = True
            break

    if not new_pet_found:
        raise AssertionError("Newly added pet is not found in the follow-up output")

    # Superset check based on pet IDs when available, otherwise fall back to names
    seed_ids = {_safe_get(p, "id") for p in seed if isinstance(p, dict) and _safe_get(p, "id") is not None}
    followup_ids = {_safe_get(p, "id") for p in followup if isinstance(p, dict) and _safe_get(p, "id") is not None}

    if seed_ids and followup_ids:
        if not seed_ids.issubset(followup_ids):
            raise AssertionError("Follow-up output is not a superset of seed output based on pet IDs")
    else:
        seed_names = {(_safe_get(p, "name") or "") for p in seed if isinstance(p, dict)}
        followup_names = {(_safe_get(p, "name") or "") for p in followup if isinstance(p, dict)}
        if not seed_names.issubset(followup_names):
            raise AssertionError("Follow-up output is not a superset of seed output based on pet names")
