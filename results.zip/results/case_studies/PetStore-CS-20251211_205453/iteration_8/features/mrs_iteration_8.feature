Feature: Iteration 8 MRs

  Scenario: MR31 Adding a new pet with a chosen ID should make it retrievable by that ID
    Given a seed input that attempts to retrieve a pet by a specific valid numeric ID, producing a seed output that may indicate that no pet is currently associated with that ID for MR31.
    When a follow-up input is created by adding a new pet whose representation includes that same valid ID, and then retrieving the pet by that ID again, yielding a follow-up output for MR31.
    Then the follow-up output should indicate the presence of a pet resource associated with that ID, differing from the seed output if the pet did not exist before for MR31.

  Scenario: MR32 Adding a pet with a specific status should increase the number of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a valid status value (available, pending, or sold), producing a seed output with a count of pets for that status for MR32.
    When a follow-up input is created by adding a new pet whose status property is set to that same status value, and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR32.
    Then the follow-up output should have a count of pets for that status that is at least one more than the seed output for MR32, assuming no other changes occurred to pets with that status in between and that the added pet was not already present with that status.

  Scenario: MR33 Adding a pet with a specific tag should make it retrievable when filtering by that tag
    Given a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR33.
    When a follow-up input is created by adding a new pet whose tag list includes that same tag value, and then retrieving pets filtered by that tag value again, yielding a follow-up output for MR33.
    Then the follow-up output should include the newly added pet among the returned pets with that tag, making the follow-up list a superset of or equal to the seed output list for MR33.
