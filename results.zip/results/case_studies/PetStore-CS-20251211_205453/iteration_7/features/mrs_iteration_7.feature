Feature: Iteration 7 MRs

  Scenario: MR26 Adding a new pet with a previously unused ID should make it retrievable by that ID
    Given a seed input that attempts to retrieve a pet by a specific valid ID, producing a seed output that may indicate that no pet is currently associated with that ID for MR26.
    When a follow-up input is created by adding a new pet whose ID is set to that same valid ID using the operation that creates a new pet in the store, and then retrieving the pet by that ID again, yielding a follow-up output for MR26.
    Then the follow-up output should indicate the presence of a pet with that ID, differing from the seed output if the pet did not exist before for MR26.

  Scenario: MR27 Updating a pet's name while keeping all other fields the same should only change the name field
    Given a seed input that retrieves a pet by a valid ID, producing a seed output with that pet's current details for MR27.
    When a follow-up input is created by sending an update request for the same pet ID in which only the name field is changed and all other pet fields are provided with the same values as in the seed output, and then retrieving the pet again by that ID, yielding a follow-up output for MR27.
    Then the follow-up output should have the updated name while all other pet fields remain identical to the corresponding fields in the seed output for MR27.

  Scenario: MR28 Adding a pet with a specific status should increase the number of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a valid status value (available, pending, or sold), producing a seed output with a count of pets for that status for MR28.
    When a follow-up input is created by adding a new pet whose status is set to that same status value, and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR28.
    Then the follow-up output should have a count of pets for that status that is exactly one more than the seed output for MR28, assuming no other changes occurred to pets with that status in between.

  Scenario: MR29 Deleting a pet should make it inaccessible by ID
    Given a seed input that retrieves a pet by a valid ID for which a pet currently exists, producing a seed output with that pet's details for MR29.
    When a follow-up input is created by deleting the pet with that same valid ID and then attempting to retrieve the pet again by that ID, yielding a follow-up output for MR29.
    Then the follow-up output should indicate that the pet is not found for that ID, differing from the seed output which contained the pet's details for MR29.

  Scenario: MR30 Adding a pet with a specific tag should make it retrievable when filtering by that tag
    Given a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR30.
    When a follow-up input is created by adding a new pet that includes that same tag value in its tag list, and then retrieving pets filtered by that tag value again, yielding a follow-up output for MR30.
    Then the follow-up output should include the newly added pet among the returned pets with that tag, making the follow-up list a superset of or equal to the seed output list for MR30.
