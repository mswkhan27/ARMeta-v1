from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that attempts to retrieve a pet by a specific valid ID, producing a seed output that may indicate that no pet is currently associated with that ID for MR26.')
def _mr_MR26_seed_input(context):
    pet_id = 99999  # Use an ID that is very unlikely to be used
    context.pet_id = int(pet_id)

    url = f"{BASE_URL}/pet/{context.pet_id}"
    try:
        seed_response = requests.get(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error during seed request for MR26: {e}") from e

    context.seed_status_code = seed_response.status_code
    context.seed_body = None
    try:
        if seed_response.content:
            context.seed_body = seed_response.json()
    except ValueError:
        context.seed_body = seed_response.text

    # Allow for both cases: pet exists already or does not exist yet
    # The MR only requires that the follow-up output differs if it did not exist before.
    if context.seed_status_code == 404:
        context.misc = "No pet found with the given ID."
    elif context.seed_status_code == 200:
        context.misc = "Pet already existed with the given ID."
    else:
        raise AssertionError(
            f"Unexpected seed response status code for MR26: {context.seed_status_code}"
        )


@when('a follow-up input is created by adding a new pet whose ID is set to that same valid ID using the operation that creates a new pet in the store, and then retrieving the pet by that ID again, yielding a follow-up output for MR26.')
def _mr_MR26_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AssertionError("pet_id not found in context; Given step may have failed.")

    pet_id = context.pet_id
    new_pet = {
        "id": pet_id,
        "name": "Buddy",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }

    create_url = f"{BASE_URL}/pet"
    try:
        create_response = requests.post(create_url, json=new_pet, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error during pet creation for MR26: {e}") from e

    context.create_status_code = create_response.status_code
    context.create_body = None
    try:
        if create_response.content:
            context.create_body = create_response.json()
    except ValueError:
        context.create_body = create_response.text

    if context.create_status_code != 200:
        raise AssertionError(
            f"Failed to add or update pet for MR26. "
            f"Expected 200, got {context.create_status_code}. Body: {context.create_body}"
        )

    get_url = f"{BASE_URL}/pet/{pet_id}"
    try:
        followup_response = requests.get(get_url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error during follow-up retrieval for MR26: {e}") from e

    context.followup_status_code = followup_response.status_code
    context.followup_body_raw = followup_response.content
    try:
        context.followup_body = followup_response.json()
    except ValueError:
        context.followup_body = followup_response.text


@then('the follow-up output should indicate the presence of a pet with that ID, differing from the seed output if the pet did not exist before for MR26.')
def _mr_MR26_followup_output(context):
    if not hasattr(context, "pet_id"):
        raise AssertionError("pet_id not found in context; previous steps may have failed.")

    pet_id = context.pet_id

    if context.followup_status_code != 200:
        raise AssertionError(
            f"Expected status code 200 when retrieving pet after creation for MR26, "
            f"got {context.followup_status_code}. Body: {context.followup_body}"
        )

    if not isinstance(context.followup_body, dict):
        raise AssertionError(
            f"Expected JSON object in follow-up response for MR26, got: {context.followup_body}"
        )

    followup_pet = context.followup_body

    if "id" not in followup_pet:
        raise AssertionError("Follow-up pet JSON has no 'id' field for MR26.")
    if "name" not in followup_pet:
        raise AssertionError("Follow-up pet JSON has no 'name' field for MR26.")
    if "status" not in followup_pet:
        raise AssertionError("Follow-up pet JSON has no 'status' field for MR26.")

    if not isinstance(followup_pet["id"], int):
        raise AssertionError(
            f"Expected 'id' to be int in follow-up pet for MR26, got {type(followup_pet['id'])}."
        )

    assert followup_pet["id"] == pet_id, (
        f"The pet ID in follow-up response ({followup_pet['id']}) should match the one used for adding ({pet_id}) for MR26."
    )
    assert followup_pet["name"] == "Buddy", (
        f"The pet name in follow-up response should be 'Buddy' for MR26, got '{followup_pet['name']}'."
    )
    assert followup_pet["status"] == "available", (
        f"The pet status in follow-up response should be 'available' for MR26, got '{followup_pet['status']}'."
    )

    if context.seed_status_code == 404:
        # Pet did not exist before; now it must exist and differ from "no pet" state
        assert context.followup_status_code == 200, (
            "MR26 violation: pet did not exist before (404), but could not be retrieved after creation."
        )

# ----

import copy



@given("a seed input that retrieves a pet by a valid ID, producing a seed output with that pet's current details for MR27.")
def _mr_MR27_seed_input(context):
    pet_id = 1  # Assuming we are using a valid pet ID

    try:
        response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request error in Given step for MR27: {e}") from e

    if response.status_code != 200:
        raise AssertionError(f"Expected status code 200 in Given step for MR27, got {response.status_code}")

    try:
        seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in Given step for MR27: {e}") from e

    if not isinstance(seed_response, dict):
        raise AssertionError(f"Expected seed response to be a JSON object, got {type(seed_response)}")

    context.seed_request = response
    context.seed_response = seed_response

    pet_id_value = seed_response.get("id")
    if not isinstance(pet_id_value, int):
        raise AssertionError(f"Expected 'id' in seed response to be int, got {type(pet_id_value)}")
    context.pet_id = pet_id_value


@when("a follow-up input is created by sending an update request for the same pet ID in which only the name field is changed and all other pet fields are provided with the same values as in the seed output, and then retrieving the pet again by that ID, yielding a follow-up output for MR27.")
def _mr_MR27_followup_input(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response is missing from context in When step for MR27")

    seed_response = context.seed_response
    if not isinstance(seed_response, dict):
        raise AssertionError(f"Expected seed_response to be dict, got {type(seed_response)}")

    pet_id = context.pet_id

    updated_pet = copy.deepcopy(seed_response)
    updated_pet["name"] = "UpdatedName"

    try:
        followup_update_response = requests.put(
            f"{BASE_URL}/pet",
            json=updated_pet,
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"Request error during update in When step for MR27: {e}") from e

    if followup_update_response.status_code != 200:
        raise AssertionError(
            f"Expected status code 200 for update in When step for MR27, "
            f"got {followup_update_response.status_code}"
        )

    try:
        followup_get_response = requests.get(
            f"{BASE_URL}/pet/{pet_id}",
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"Request error during follow-up get in When step for MR27: {e}") from e

    if followup_get_response.status_code != 200:
        raise AssertionError(
            f"Expected status code 200 for follow-up get in When step for MR27, "
            f"got {followup_get_response.status_code}"
        )

    try:
        followup_response_json = followup_get_response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in follow-up get in When step for MR27: {e}") from e

    if not isinstance(followup_response_json, dict):
        raise AssertionError(
            f"Expected follow-up response to be a JSON object, got {type(followup_response_json)}"
        )

    context.followup_request = followup_update_response
    context.followup_get_request = followup_get_response
    context.followup_response = followup_response_json


@then("the follow-up output should have the updated name while all other pet fields remain identical to the corresponding fields in the seed output for MR27.")
def _mr_MR27_followup_output(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AssertionError("Missing seed_response or followup_response in Then step for MR27")

    seed_response = context.seed_response
    followup_response = context.followup_response

    if not isinstance(seed_response, dict) or not isinstance(followup_response, dict):
        raise AssertionError(
            f"Expected both seed_response and followup_response to be dicts, "
            f"got {type(seed_response)} and {type(followup_response)}"
        )

    updated_name = followup_response.get("name")
    if updated_name != "UpdatedName":
        raise AssertionError(
            f"Expected follow-up pet name to be 'UpdatedName', got {updated_name!r}"
        )

    for key, seed_value in seed_response.items():
        if key == "name":
            continue
        if key not in followup_response:
            raise AssertionError(f"Key {key!r} missing in follow-up response for MR27")
        followup_value = followup_response[key]
        if followup_value != seed_value:
            raise AssertionError(
                f"Field {key!r} differs between seed and follow-up for MR27: "
                f"seed={seed_value!r}, followup={followup_value!r}"
            )

# ----




@given('a seed input that retrieves the list of pets filtered by a valid status value (available, pending, or sold), producing a seed output with a count of pets for that status for MR28.')
def step_mr_MR28_seed_input(context):
    status = 'available'  # Using 'available' as a valid status defined in the OpenAPI spec
    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByStatus",
            params={'status': status},
            timeout=10,
        )
        response.raise_for_status()
    except requests.RequestException as e:
        raise RuntimeError(f"HTTP error in Given step for MR28: {e}") from e

    try:
        data = response.json()
    except ValueError as e:
        raise RuntimeError(f"Invalid JSON in Given step for MR28: {e}") from e

    if not isinstance(data, list):
        raise TypeError(f"Expected list response for /pet/findByStatus, got {type(data).__name__}")

    context.seed_response = data
    context.seed_request = {'status': status}
    context.seed_count = len(data)


@when('a follow-up input is created by adding a new pet whose status is set to that same status value, and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR28.')
def step_mr_MR28_followup_input(context):
    if not hasattr(context, 'seed_request') or 'status' not in context.seed_request:
        raise RuntimeError("seed_request with 'status' must be set in Given step before When step for MR28.")

    status = context.seed_request['status']
    if not isinstance(status, str):
        raise TypeError(f"Expected status to be a string, got {type(status).__name__}")

    new_pet = {
        "name": "New Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": status,
    }

    try:
        add_response = requests.post(
            f"{BASE_URL}/pet",
            json=new_pet,
            timeout=10,
        )
        add_response.raise_for_status()
    except requests.RequestException as e:
        raise RuntimeError(f"HTTP error while adding pet in When step for MR28: {e}") from e

    try:
        followup_response = requests.get(
            f"{BASE_URL}/pet/findByStatus",
            params={'status': status},
            timeout=10,
        )
        followup_response.raise_for_status()
    except requests.RequestException as e:
        raise RuntimeError(f"HTTP error while retrieving pets in When step for MR28: {e}") from e

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise RuntimeError(f"Invalid JSON in When step for MR28: {e}") from e

    if not isinstance(followup_data, list):
        raise TypeError(f"Expected list response for /pet/findByStatus, got {type(followup_data).__name__}")

    context.followup_response = followup_data
    context.followup_count = len(followup_data)


@then('the follow-up output should have a count of pets for that status that is exactly one more than the seed output for MR28, assuming no other changes occurred to pets with that status in between.')
def step_mr_MR28_followup_output(context):
    if not hasattr(context, 'seed_count'):
        raise RuntimeError("seed_count must be set in Given step before Then step for MR28.")
    if not hasattr(context, 'followup_count'):
        raise RuntimeError("followup_count must be set in When step before Then step for MR28.")

    seed_count = context.seed_count
    followup_count = context.followup_count

    if not isinstance(seed_count, int):
        raise TypeError(f"Expected seed_count to be int, got {type(seed_count).__name__}")
    if not isinstance(followup_count, int):
        raise TypeError(f"Expected followup_count to be int, got {type(followup_count).__name__}")

    expected = seed_count + 1
    assert followup_count == expected, (
        f"Expected follow-up count to be {expected}, but got {followup_count}."
    )

# ----




@given("a seed input that retrieves a pet by a valid ID for which a pet currently exists, producing a seed output with that pet's details for MR29.")
def _mr_MR29_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }
    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    response.raise_for_status()

    # Safely parse JSON
    try:
        seed_json = response.json()
    except ValueError as e:
        raise AssertionError(f"Response from /pet is not valid JSON: {e}\nBody: {response.text}") from e

    # Ensure ID exists and is of correct type
    pet_id = seed_json.get("id")
    if pet_id is None:
        raise AssertionError(f"Created pet response missing 'id': {json.dumps(seed_json, ensure_ascii=False)}")
    if not isinstance(pet_id, int):
        raise AssertionError(f"Created pet 'id' is not an integer: {pet_id} (type={type(pet_id)})")

    context.seed_response = seed_json
    context.seed_request = pet_data
    context.pet_id = pet_id


@when("a follow-up input is created by deleting the pet with that same valid ID and then attempting to retrieve the pet again by that ID, yielding a follow-up output for MR29.")
def _mr_MR29_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AssertionError("Context is missing 'pet_id' from the Given step.")

    # Delete the pet
    delete_response = requests.delete(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
    delete_response.raise_for_status()

    # Attempt to retrieve the deleted pet
    followup_response = requests.get(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
    context.followup_response = followup_response


@then("the follow-up output should indicate that the pet is not found for that ID, differing from the seed output which contained the pet's details for MR29.")
def _mr_MR29_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AssertionError("Context is missing 'followup_response' from the When step.")

    response = context.followup_response
    assert response.status_code == 404, f"Expected status code 404 for pet not found, got {response.status_code} with body: {response.text}"

    # Try to parse JSON, but don't fail the test on non-JSON body
    try:
        body = response.json()
    except ValueError:
        body = None

    if isinstance(body, dict):
        message = body.get("message")
        # Only assert message if it exists, to avoid brittle tests and KeyErrors
        if message is not None:
            assert "not found" in str(message).lower(), f"Expected 'not found' in error message, got: {message}"

# ----

import time



@given('a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR30.')
def _mr_MR30_seed_input(context):
    tag_value = "tag1"  # Example tag value
    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params={"tags": tag_value},
            timeout=10,
        )
        response.raise_for_status()
        data = response.json()

        # Normalize to list safely
        if isinstance(data, list):
            seed_pets = data
        elif data is None:
            seed_pets = []
        else:
            # Unexpected type; coerce to empty list to avoid TypeError downstream
            seed_pets = []

        context.seed_response = seed_pets
        context.seed_request = {'tags': tag_value}
        context.mr30_tag_value = tag_value
    except requests.RequestException as e:
        print(f"HTTP error in GIVEN step for MR30: {e}")
        raise
    except ValueError as e:
        # JSON decoding error
        print(f"JSON decode error in GIVEN step for MR30: {e}")
        raise
    except Exception as e:
        print(f"Unexpected error in GIVEN step for MR30: {e}")
        raise


@when('a follow-up input is created by adding a new pet that includes that same tag value in its tag list, and then retrieving pets filtered by that tag value again, yielding a follow-up output for MR30.')
def _mr_MR30_followup_input(context):
    tag_value = getattr(context, "mr30_tag_value", "tag1")

    new_pet = {
        "name": "New Pet MR30",
        "photoUrls": ["http://example.com/photo.jpg"],
        "tags": [{"id": 1, "name": tag_value}],
        "status": "available",
    }

    try:
        # Add new pet
        add_response = requests.post(
            f"{BASE_URL}/pet",
            json=new_pet,
            timeout=10,
        )
        add_response.raise_for_status()
        created_pet = add_response.json() if add_response.content else None
        context.mr30_created_pet = created_pet

        # Retrieve pets again by the same tag using the same endpoint as in GIVEN
        followup_response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params={"tags": tag_value},
            timeout=10,
        )
        followup_response.raise_for_status()
        data = followup_response.json()

        if isinstance(data, list):
            followup_pets = data
        elif data is None:
            followup_pets = []
        else:
            followup_pets = []

        context.followup_response = followup_pets
        context.followup_request = {'tags': tag_value}
    except requests.RequestException as e:
        print(f"HTTP error in WHEN step for MR30: {e}")
        raise
    except ValueError as e:
        print(f"JSON decode error in WHEN step for MR30: {e}")
        raise
    except Exception as e:
        print(f"Unexpected error in WHEN step for MR30: {e}")
        raise


@then('the follow-up output should include the newly added pet among the returned pets with that tag, making the follow-up list a superset of or equal to the seed output list for MR30.')
def _mr_MR30_followup_output(context):
    try:
        seed_pets = getattr(context, "seed_response", []) or []
        followup_pets = getattr(context, "followup_response", []) or []
        created_pet = getattr(context, "mr30_created_pet", None)

        if not isinstance(seed_pets, list):
            seed_pets = []
        if not isinstance(followup_pets, list):
            followup_pets = []

        # Extract IDs safely, skip items without valid integer-like ids
        def extract_ids(pets):
            ids = set()
            for pet in pets:
                if not isinstance(pet, dict):
                    continue
                pet_id = pet.get("id")
                if isinstance(pet_id, int):
                    ids.add(pet_id)
            return ids

        seed_pet_ids = extract_ids(seed_pets)
        followup_pet_ids = extract_ids(followup_pets)

        created_pet_id = None
        if isinstance(created_pet, dict):
            cp_id = created_pet.get("id")
            if isinstance(cp_id, int):
                created_pet_id = cp_id

        # MR core check: follow-up set should be a superset (or equal) of seed set
        assert seed_pet_ids.issubset(followup_pet_ids), (
            "Seed output pets are not all present in follow-up output."
        )

        # If we have a concrete created pet id, ensure it is present
        if created_pet_id is not None:
            assert created_pet_id in followup_pet_ids, (
                "Newly added pet is not present in the follow-up output."
            )
    except AssertionError as e:
        print(f"Assertion error in THEN step for MR30: {e}")
        raise
    except Exception as e:
        print(f"Unexpected error in THEN step for MR30: {e}")
        raise
