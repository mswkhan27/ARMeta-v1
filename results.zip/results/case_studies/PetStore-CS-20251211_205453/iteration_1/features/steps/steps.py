from behave import given, when, then
import os
import json
import requests
from requests.exceptions import RequestException

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _safe_get_json(response):
    try:
        return response.json()
    except ValueError:
        return None


def _create_pet_payload(pet_id=1):
    return {
        "id": int(pet_id),
        "name": "doggie",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }


@given("a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR4.")
def _mr_MR4_seed_input(context):
    try:
        pet_data = _create_pet_payload(1)

        create_resp = requests.post(
            f"{BASE_URL}/pet",
            json=pet_data,
            timeout=10
        )
        create_body = _safe_get_json(create_resp)

        assert create_resp.status_code == 200, (
            f"Failed to create pet, status={create_resp.status_code}, body={create_body}"
        )

        get_resp = requests.get(
            f"{BASE_URL}/pet/1",
            timeout=10
        )
        get_body = _safe_get_json(get_resp)

        assert get_resp.status_code == 200, (
            f"Failed to retrieve pet, status={get_resp.status_code}, body={get_body}"
        )
        assert isinstance(get_body, dict), "Pet response is not a JSON object"

        context.seed_request = get_resp
        context.seed_response = get_body

        for key in ("id", "name", "status", "photoUrls"):
            assert key in context.seed_response, f"Missing '{key}' in seed_response"
    except (AssertionError, RequestException) as e:
        assert False, f"Error in Given step for MR4: {e}"
    except Exception as e:
        assert False, f"Unexpected error in Given step for MR4: {e}"


@when("a follow-up input is created by first uploading an image for the same pet ID and then retrieving the pet again, yielding a follow-up output with the updated pet details for MR4.")
def _mr_MR4_followup_input(context):
    try:
        if not hasattr(context, "seed_response"):
            assert False, "seed_response not found in context"

        pet_id = context.seed_response.get("id")
        assert isinstance(pet_id, int), f"pet_id must be int, got {type(pet_id)}"

        files = None
        temp_file = None
        try:
            temp_file_path = os.path.join(os.getcwd(), "temp_image.jpg")
            with open(temp_file_path, "wb") as f:
                f.write(b"\xFF\xD8\xFF\xE0")  # minimal jpeg header bytes

            temp_file = open(temp_file_path, "rb")
            files = {"file": temp_file}

            upload_resp = requests.post(
                f"{BASE_URL}/pet/{pet_id}/uploadImage",
                files=files,
                timeout=10
            )
            upload_body = _safe_get_json(upload_resp)

            assert upload_resp.status_code == 200, (
                f"Failed to upload image, status={upload_resp.status_code}, body={upload_body}"
            )
        finally:
            if temp_file and not temp_file.closed:
                temp_file.close()
            try:
                if 'temp_file_path' in locals() and os.path.exists(temp_file_path):
                    os.remove(temp_file_path)
            except OSError:
                pass

        followup_resp = requests.get(
            f"{BASE_URL}/pet/{pet_id}",
            timeout=10
        )
        followup_body = _safe_get_json(followup_resp)

        assert followup_resp.status_code == 200, (
            f"Failed to retrieve pet after upload, status={followup_resp.status_code}, body={followup_body}"
        )
        assert isinstance(followup_body, dict), "Follow-up pet response is not a JSON object"

        context.followup_request = followup_resp
        context.followup_response = followup_body

        for key in ("id", "name", "status", "photoUrls"):
            assert key in context.followup_response, f"Missing '{key}' in followup_response"
    except (AssertionError, RequestException) as e:
        assert False, f"Error in When step for MR4: {e}"
    except Exception as e:
        assert False, f"Unexpected error in When step for MR4: {e}"


@then("the follow-up output should have the same pet details as the seed output for MR4, since uploading an image does not modify the stored pet attributes.")
def _mr_MR4_followup_output(context):
    try:
        if not hasattr(context, "seed_response"):
            assert False, "seed_response not found in context"
        if not hasattr(context, "followup_response"):
            assert False, "followup_response not found in context"

        seed = context.seed_response
        followup = context.followup_response

        assert isinstance(seed, dict) and isinstance(followup, dict), \
            "Seed and follow-up responses must be JSON objects"

        assert followup.get("id") == seed.get("id"), "Pet ID does not match"
        assert followup.get("name") == seed.get("name"), "Pet name has changed"
        assert followup.get("status") == seed.get("status"), "Pet status has changed"

        seed_photos = seed.get("photoUrls") or []
        followup_photos = followup.get("photoUrls") or []
        assert seed_photos == followup_photos, "Pet photoUrls have changed"
    except AssertionError as e:
        assert False, f"Assertion error in Then step for MR4: {e}"
    except Exception as e:
        assert False, f"Unexpected error in Then step for MR4: {e}"
