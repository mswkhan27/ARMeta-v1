Feature: Iteration 1 MRs

  Scenario: MR4 Uploading an image for a pet should not change the pet's other attributes
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR4.
    When a follow-up input is created by first uploading an image for the same pet ID and then retrieving the pet again, yielding a follow-up output with the updated pet details for MR4.
    Then the follow-up output should have the same pet details as the seed output for MR4, since uploading an image does not modify the stored pet attributes.
