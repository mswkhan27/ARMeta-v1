Feature: Iteration 7 MRs

  Scenario: Finding pets by tags should return a superset when additional valid tags are included
    Given a seed input that retrieves pets by a specific, valid tag value in the query, producing a seed output with a list of pets associated with that tag for MR23, while the underlying pet data remains unchanged between calls.
    When a follow-up input is created by adding an additional, distinct, valid tag value to the same query (so that pets matching any of the provided tags are considered) and retrieving pets again, yielding a follow-up output for MR23.
    Then the follow-up output should be a superset of the seed output, containing all pets from the seed output plus any additional pets that match at least one of the specified tag values for MR23, assuming no changes to the stored pets between the two calls.

  Scenario: Updating a pet's name should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier as defined in the store, producing a seed output with the pet's current name for MR24.
    When a follow-up input is created by updating the pet's name while keeping the same identifier in the store and then retrieving the same pet by that identifier again, yielding a follow-up output for MR24.
    Then the follow-up output should reflect the updated name for that pet, and the pet's identifier and other unchanged attributes should remain the same as in the seed output for MR24.
