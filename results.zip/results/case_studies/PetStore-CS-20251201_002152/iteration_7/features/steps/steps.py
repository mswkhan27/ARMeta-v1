from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that retrieves pets by a specific, valid tag value in the query, producing a seed output with a list of pets associated with that tag for MR23, while the underlying pet data remains unchanged between calls.')
def step_mr_MR23_seed_input(context):
    tag = "dog"

    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params={"tags": tag},
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error during seed request for MR23: {e}")

    context.seed_request = response

    # Safely parse JSON
    try:
        context.seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Seed response is not valid JSON: {e}; raw text: {response.text}")

    if response.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve pets by tag '{tag}'. "
            f"Status: {response.status_code}, Body: {context.seed_response!r}"
        )

    if not isinstance(context.seed_response, list):
        raise AssertionError(
            f"Seed response is not a list. Got type: {type(context.seed_response).__name__}, "
            f"value: {context.seed_response!r}"
        )


@when('a follow-up input is created by adding an additional, distinct, valid tag value to the same query (so that pets matching any of the provided tags are considered) and retrieving pets again, yielding a follow-up output for MR23.')
def step_mr_MR23_followup_input(context):
    base_tag = "dog"
    additional_tag = "cat"
    tags_value = f"{base_tag},{additional_tag}"

    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params={"tags": tags_value},
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error during follow-up request for MR23: {e}")

    context.followup_request = response

    # Safely parse JSON
    try:
        context.followup_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response is not valid JSON: {e}; raw text: {response.text}")

    if response.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve pets by tags '{tags_value}'. "
            f"Status: {response.status_code}, Body: {context.followup_response!r}"
        )

    if not isinstance(context.followup_response, list):
        raise AssertionError(
            f"Follow-up response is not a list. Got type: {type(context.followup_response).__name__}, "
            f"value: {context.followup_response!r}"
        )


@then('the follow-up output should be a superset of the seed output, containing all pets from the seed output plus any additional pets that match at least one of the specified tag values for MR23, assuming no changes to the stored pets between the two calls.')
def step_mr_MR23_followup_output(context):
    # Defensive checks to avoid AttributeError / TypeError
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is missing from context.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response is missing from context.")

    if not isinstance(context.seed_response, list):
        raise AssertionError(
            f"Seed response is not a list in Then step. Got type: {type(context.seed_response).__name__}"
        )
    if not isinstance(context.followup_response, list):
        raise AssertionError(
            f"Follow-up response is not a list in Then step. Got type: {type(context.followup_response).__name__}"
        )

    # Extract pet IDs safely, ignoring malformed items
    seed_pet_ids = set()
    for idx, pet in enumerate(context.seed_response):
        if isinstance(pet, dict):
            pet_id = pet.get("id")
            if isinstance(pet_id, int):
                seed_pet_ids.add(pet_id)

    followup_pet_ids = set()
    for idx, pet in enumerate(context.followup_response):
        if isinstance(pet, dict):
            pet_id = pet.get("id")
            if isinstance(pet_id, int):
                followup_pet_ids.add(pet_id)

    if not seed_pet_ids:
        # If no valid IDs in the seed, the MR cannot be meaningfully evaluated
        raise AssertionError(
            f"No valid integer 'id' values found in seed response: {context.seed_response!r}"
        )

    if not followup_pet_ids:
        raise AssertionError(
            f"No valid integer 'id' values found in follow-up response: {context.followup_response!r}"
        )

    # Superset check
    if not followup_pet_ids.issuperset(seed_pet_ids):
        raise AssertionError(
            "Follow-up output is not a superset of the seed output.\n"
            f"Seed IDs: {sorted(seed_pet_ids)}\n"
            f"Follow-up IDs: {sorted(followup_pet_ids)}"
        )

    # Ensure there is at least one new pet in the follow-up
    new_pets = followup_pet_ids - seed_pet_ids
    if not new_pets:
        raise AssertionError(
            "No new pets found in the follow-up output compared to the seed output.\n"
            f"Seed IDs: {sorted(seed_pet_ids)}\n"
            f"Follow-up IDs: {sorted(followup_pet_ids)}"
        )

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


@given(
    "a seed input that retrieves a pet by its identifier as defined in the store, producing a seed output with the pet's current name for MR24."
)
def step_mr_MR24_seed_input(context):
    try:
        pet_data = {
            "id": 1,
            "name": "doggie",
            "photoUrls": ["url1", "url2"],
            "status": "available",
        }

        create_resp = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        try:
            create_body = create_resp.json()
        except ValueError:
            create_body = {}

        assert create_resp.status_code == 200, (
            f"Failed to create pet. Status: {create_resp.status_code}, Body: {create_body}"
        )

        # Now retrieve the pet by its identifier to get the seed output
        pet_id = create_body.get("id", pet_data["id"])
        get_resp = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        try:
            get_body = get_resp.json()
        except ValueError:
            get_body = {}

        assert get_resp.status_code == 200, (
            f"Failed to retrieve pet by id. Status: {get_resp.status_code}, Body: {get_body}"
        )

        context.seed_response = get_body
    except AssertionError as e:
        print(f"Assertion error in Given step for MR24: {e}")
        assert False
    except Exception as e:
        print(f"Unexpected error in Given step for MR24: {e}")
        assert False


@when(
    "a follow-up input is created by updating the pet's name while keeping the same identifier in the store and then retrieving the same pet by that identifier again, yielding a follow-up output for MR24."
)
def step_mr_MR24_followup_input(context):
    try:
        seed = getattr(context, "seed_response", None)
        assert isinstance(seed, dict), "seed_response is not available or not a dict"

        seed_id = seed.get("id")
        assert seed_id is not None, "seed_response does not contain 'id'"

        # Prepare updated pet data using seed values, keeping unchanged attributes
        updated_pet_data = {
            "id": seed_id,
            "name": "doggie_updated",
            "photoUrls": seed.get("photoUrls") or [],
            "status": seed.get("status"),
        }

        update_resp = requests.put(f"{BASE_URL}/pet", json=updated_pet_data, timeout=10)
        try:
            update_body = update_resp.json()
        except ValueError:
            update_body = {}

        assert update_resp.status_code == 200, (
            f"Failed to update pet. Status: {update_resp.status_code}, Body: {update_body}"
        )

        # Retrieve the updated pet by the same identifier
        followup_resp = requests.get(f"{BASE_URL}/pet/{seed_id}", timeout=10)
        try:
            followup_body = followup_resp.json()
        except ValueError:
            followup_body = {}

        assert followup_resp.status_code == 200, (
            f"Failed to retrieve updated pet. Status: {followup_resp.status_code}, Body: {followup_body}"
        )

        context.followup_response = followup_body
    except AssertionError as e:
        print(f"Assertion error in When step for MR24: {e}")
        assert False
    except Exception as e:
        print(f"Unexpected error in When step for MR24: {e}")
        assert False


@then(
    "the follow-up output should reflect the updated name for that pet, and the pet's identifier and other unchanged attributes should remain the same as in the seed output for MR24."
)
def step_mr_MR24_followup_output(context):
    try:
        seed = getattr(context, "seed_response", None)
        followup = getattr(context, "followup_response", None)

        assert isinstance(seed, dict), "seed_response is not available or not a dict"
        assert isinstance(followup, dict), "followup_response is not available or not a dict"

        seed_id = seed.get("id")
        followup_id = followup.get("id")
        seed_photos = seed.get("photoUrls") or []
        followup_photos = followup.get("photoUrls") or []
        seed_status = seed.get("status")
        followup_status = followup.get("status")

        assert followup.get("name") == "doggie_updated", "Pet name was not updated correctly."
        assert followup_id == seed_id, "Pet ID should remain the same."
        assert followup_photos == seed_photos, "Photo URLs should remain the same."
        assert followup_status == seed_status, "Pet status should remain the same."
    except AssertionError as e:
        print(f"Assertion error in Then step for MR24: {e}")
        assert False
    except Exception as e:
        print(f"Unexpected error in Then step for MR24: {e}")
        assert False
