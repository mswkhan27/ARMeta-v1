Feature: Iteration 1 MRs

  Scenario: Uploading an image for a pet should not alter the pet's other attributes
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current attributes for MR4.
    When a follow-up input is created by uploading an image for the same pet identifier and then retrieving that pet again, yielding a follow-up output for MR4.
    Then the follow-up output should have the same pet attributes as the seed output for MR4, since uploading an image does not modify the pet representation returned by the service.

  Scenario: Updating a user's information should reflect in subsequent retrieval of that user
    Given a seed input that retrieves a user by their username, producing a seed output with the user's current information for MR7.
    When a follow-up input is created by updating the user's information while keeping the same username, and then retrieving the same user by that username again, yielding a follow-up output for MR7.
    Then the follow-up output should reflect the updated information for that user, and the user's username should remain the same as in the seed output for MR7.
