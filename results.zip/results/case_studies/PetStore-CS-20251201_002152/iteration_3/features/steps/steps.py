from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


@given("a seed input that successfully retrieves a user by their username, producing a seed output with a 200 status code and the user's details for MR9.")
def _mr_MR9_seed_input(context):
    username = "testuser"
    user_data = {
        "id": 1,
        "username": username,
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1,
    }

    # Create the user first
    create_resp = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    context.seed_create_response = create_resp

    if create_resp.status_code != 200:
        raise AssertionError(
            f"Failed to create user for MR9: status={create_resp.status_code}, body={create_resp.text}"
        )

    # Now retrieve the user to get the actual seed output
    get_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    context.seed_get_response = get_resp

    if get_resp.status_code != 200:
        raise AssertionError(
            f"Expected 200 when retrieving created user for MR9, "
            f"got {get_resp.status_code}: {get_resp.text}"
        )

    # Safely parse JSON (if any) without raising TypeError/ValueError on non‑JSON
    try:
        context.seed_user_body = get_resp.json()
    except ValueError:
        context.seed_user_body = None


@when("a follow-up input is created by deleting the user using the same username and then attempting to retrieve the user again, yielding a follow-up output for MR9.")
def _mr_MR9_followup_input(context):
    username = "testuser"

    # Delete the user
    delete_resp = requests.delete(f"{BASE_URL}/user/{username}", timeout=10)
    context.followup_delete_response = delete_resp

    if delete_resp.status_code != 200:
        raise AssertionError(
            f"Failed to delete user for MR9: status={delete_resp.status_code}, body={delete_resp.text}"
        )

    # Attempt to retrieve the user again
    followup_get_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    context.followup_get_response = followup_get_resp

    # No JSON parsing here to avoid unnecessary ValueError; only status is needed


@then("the follow-up output should return a 404 status code indicating the user is not found, differing from the seed output which contained the user's details for MR9.")
def _mr_MR9_followup_output(context):
    # Ensure the seed retrieval was indeed successful and had 200
    if context.seed_get_response.status_code != 200:
        raise AssertionError(
            f"Precondition for MR9 violated: expected seed GET 200, "
            f"got {context.seed_get_response.status_code}: {context.seed_get_response.text}"
        )

    resp = context.followup_get_response
    if resp.status_code != 404:
        raise AssertionError(
            f"Expected follow-up GET to return 404 for deleted user in MR9, "
            f"got {resp.status_code}: {resp.text}"
        )

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that retrieves pets by a specific tag value in the query, producing a seed output with a list of pets for MR10.')
def _mr_MR10_seed_input(context):
    # Use a fixed, valid tag value for reproducibility
    tag = "tag1"
    url = f"{BASE_URL}/pet/findByTags"
    params = {"tags": tag}

    response = requests.get(url, params=params, timeout=10)
    try:
        data = response.json()
    except ValueError:
        raise AssertionError(f"Response is not valid JSON. Status: {response.status_code}, Body: {response.text}")

    assert response.status_code == 200, f"Failed to retrieve pets: {data}"

    if not isinstance(data, list):
        raise AssertionError(f"Expected a list of pets, got: {type(data).__name__}")

    context.seed_request = response
    context.seed_response = data
    context.seed_tag = tag


@when('a follow-up input is created by adding an additional tag value to the same query and retrieving pets again, yielding a follow-up output for MR10.')
def _mr_MR10_followup_input(context):
    # Base tag from the seed step
    base_tag = getattr(context, "seed_tag", None)
    if not base_tag or not isinstance(base_tag, str):
        raise AssertionError("seed_tag is missing or invalid in context.")

    additional_tag = "tag2"

    url = f"{BASE_URL}/pet/findByTags"
    # Pass tags as comma-separated string per API description
    params = {"tags": f"{base_tag},{additional_tag}"}

    response = requests.get(url, params=params, timeout=10)
    try:
        data = response.json()
    except ValueError:
        raise AssertionError(f"Follow-up response is not valid JSON. Status: {response.status_code}, Body: {response.text}")

    assert response.status_code == 200, f"Failed to retrieve pets with additional tag: {data}"

    if not isinstance(data, list):
        raise AssertionError(f"Expected a list of pets for follow-up, got: {type(data).__name__}")

    context.followup_request = response
    context.followup_response = data
    context.additional_tag = additional_tag


@then('the follow-up output should be a superset of the seed output, containing all pets from the seed output plus any additional pets that match the newly added tag value for MR10.')
def _mr_MR10_followup_output(context):
    seed_response = getattr(context, "seed_response", None)
    followup_response = getattr(context, "followup_response", None)

    if seed_response is None or followup_response is None:
        raise AssertionError("Seed or follow-up response missing from context.")

    if not isinstance(seed_response, list) or not isinstance(followup_response, list):
        raise AssertionError(
            f"Expected both seed and follow-up responses to be lists, "
            f"got {type(seed_response).__name__} and {type(followup_response).__name__}."
        )

    try:
        seed_ids = {pet["id"] for pet in seed_response if isinstance(pet, dict) and "id" in pet}
        followup_ids = {pet["id"] for pet in followup_response if isinstance(pet, dict) and "id" in pet}
    except TypeError as e:
        raise AssertionError(f"Error while extracting IDs from responses: {e}")

    if not seed_ids:
        raise AssertionError("No valid pet IDs found in seed response; cannot verify superset property.")

    assert seed_ids.issubset(followup_ids), (
        "Follow-up output is not a superset of seed output: "
        f"missing IDs: {seed_ids - followup_ids}"
    )

    new_pets = followup_ids - seed_ids
    assert len(new_pets) > 0, "No new pets found in follow-up output; expected at least one additional pet."

# ----




@given('a seed input that retrieves the pet inventory by status, producing a seed output with the current inventory counts mapped by status for MR11.')
def _mr_MR11_seed_input(context):
    response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    response.raise_for_status()
    try:
        seed_json = response.json()
        if not isinstance(seed_json, dict):
            raise ValueError(f"Expected inventory to be an object/map, got: {type(seed_json)}")
    except ValueError as ve:
        raise AssertionError(f"Failed to parse seed inventory JSON: {ve}") from ve

    context.seed_response = seed_json
    context.seed_request = None  # No request body for GET


@when('a follow-up input is created by adding a new pet with a specific status and then retrieving the inventory again, yielding a follow-up output for MR11.')
def _mr_MR11_followup_input(context):
    # Choose a valid status as per schema enum
    pet_status = "available"

    new_pet = {
        "name": "NewPet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": pet_status
    }

    add_response = requests.post(f"{BASE_URL}/pet", json=new_pet, timeout=10)
    add_response.raise_for_status()

    # Retrieve inventory again
    followup_response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    followup_response.raise_for_status()
    try:
        followup_json = followup_response.json()
        if not isinstance(followup_json, dict):
            raise ValueError(f"Expected inventory to be an object/map, got: {type(followup_json)}")
    except ValueError as ve:
        raise AssertionError(f"Failed to parse follow-up inventory JSON: {ve}") from ve

    context.followup_response = followup_json
    context.followup_request = {
        "pet": new_pet,
        "status": pet_status
    }


@then('the follow-up output should show an increased count in the inventory map for the status of the newly added pet compared to the corresponding count in the seed output for MR11.')
def _mr_MR11_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is missing on context.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response is missing on context.")

    status_key = context.followup_request.get("status", "available")

    seed_value = context.seed_response.get(status_key, 0)
    followup_value = context.followup_response.get(status_key, 0)

    # Ensure values are numeric and safely comparable
    try:
        seed_count = int(seed_value)
    except (TypeError, ValueError):
        raise AssertionError(f"Seed inventory count for status '{status_key}' is not an integer: {seed_value!r}")

    try:
        followup_count = int(followup_value)
    except (TypeError, ValueError):
        raise AssertionError(f"Follow-up inventory count for status '{status_key}' is not an integer: {followup_value!r}")

    expected = seed_count + 1
    assert followup_count == expected, (
        f"Expected follow-up count for status '{status_key}' to be {expected}, "
        f"but got {followup_count}. Seed inventory: {json.dumps(context.seed_response)}, "
        f"follow-up inventory: {json.dumps(context.followup_response)}"
    )

# ----




@given('a seed input that logs a user into the system using a username and password, producing a seed output with a 200 status code and a successful login response for MR12.')
def step_mr_MR12_seed_input(context):
    context.username = "testuser"
    context.password = "testpassword"
    context.seed_request = {
        "username": context.username,
        "password": context.password
    }

    response = requests.get(
        f"{BASE_URL}/user/login",
        params=context.seed_request,
        timeout=10
    )
    context.seed_response = response

    assert response.status_code == 200, (
        f"Expected 200 but got {response.status_code}"
    )
    # Ensure response body is safely parsed to avoid unexpected exceptions later
    try:
        context.seed_response_body = response.json()
    except ValueError:
        context.seed_response_body = response.text


@when('a follow-up input is created by logging the user out and then logging in again with the same username and password, yielding a follow-up output for MR12.')
def step_mr_MR12_followup_input(context):
    logout_response = requests.get(
        f"{BASE_URL}/user/logout",
        timeout=10
    )
    context.logout_response = logout_response

    assert logout_response.status_code == 200, (
        f"Expected 200 but got {logout_response.status_code}"
    )

    followup_response = requests.get(
        f"{BASE_URL}/user/login",
        params=context.seed_request,
        timeout=10
    )
    context.followup_response = followup_response

    assert followup_response.status_code == 200, (
        f"Expected 200 but got {followup_response.status_code}"
    )

    # Safely parse follow-up response body
    try:
        context.followup_response_body = followup_response.json()
    except ValueError:
        context.followup_response_body = followup_response.text


@then('the follow-up output should be a 200 status code with a successful login response, similar to the seed output, indicating that logging out does not prevent subsequent logins for MR12.')
def step_mr_MR12_followup_output(context):
    # Re-assert status codes to be explicit in the Then step
    assert context.seed_response.status_code == 200, (
        f"Seed login expected 200 but got {context.seed_response.status_code}"
    )
    assert context.followup_response.status_code == 200, (
        f"Follow-up login expected 200 but got {context.followup_response.status_code}"
    )

    # Compare response bodies in a safe, type-agnostic way
    seed_body = context.seed_response_body
    followup_body = context.followup_response_body

    # If both are JSON-serializable, compare their JSON dumps to avoid subtle type issues
    try:
        seed_serialized = json.dumps(seed_body, sort_keys=True)
        followup_serialized = json.dumps(followup_body, sort_keys=True)
        assert seed_serialized == followup_serialized, (
            "Follow-up response body does not match seed response body"
        )
    except (TypeError, ValueError):
        # Fallback: direct comparison if serialization is not possible
        assert followup_body == seed_body, (
            "Follow-up response body does not match seed response body (fallback comparison)"
        )

# ----




@given('a seed input that creates a list of users in a single request body, producing a seed output with a 200 status code indicating a successful operation for MR13.')
def _mr_MR13_create_users(context):
    users = [
        {
            "id": 10,
            "username": "user1",
            "firstName": "John",
            "lastName": "Doe",
            "email": "john.doe@example.com",
            "password": "password1",
            "phone": "1234567890",
            "userStatus": 1
        },
        {
            "id": 11,
            "username": "user2",
            "firstName": "Jane",
            "lastName": "Doe",
            "email": "jane.doe@example.com",
            "password": "password2",
            "phone": "0987654321",
            "userStatus": 1
        }
    ]
    context.seed_request = users

    response = requests.post(f"{BASE_URL}/user/createWithList", json=users, timeout=10)
    context.seed_status_code = response.status_code
    try:
        context.seed_response = response.json()
    except ValueError:
        context.seed_response = response.text

    assert context.seed_status_code == 200, (
        f"Expected 200 but got {context.seed_status_code}: {context.seed_response}"
    )


@when('a follow-up input is created by retrieving each user by their username from the originally provided list, yielding a follow-up output for MR13.')
def _mr_MR13_retrieve_users(context):
    followup_responses = []

    for user in context.seed_request:
        username = user.get('username')
        assert isinstance(username, str) and username, "Username must be a non-empty string"

        response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
        status_code = response.status_code
        try:
            body = response.json()
        except ValueError:
            body = response.text

        followup_responses.append(
            {
                "status_code": status_code,
                "body": body,
                "username": username,
            }
        )

        assert status_code == 200, (
            f"Expected 200 but got {status_code} for user {username}: {body}"
        )

    context.followup_response = followup_responses


@then('the follow-up output should include successful retrieval responses with details for each user created in the seed input, confirming that all users are retrievable for MR13.')
def _mr_MR13_verify_users(context):
    assert hasattr(context, "seed_request"), "seed_request missing from context"
    assert hasattr(context, "followup_response"), "followup_response missing from context"

    for seed_user, followup in zip(context.seed_request, context.followup_response):
        body = followup.get("body")
        status_code = followup.get("status_code")
        username = followup.get("username")

        assert status_code == 200, (
            f"Expected 200 but got {status_code} for user {username}: {body}"
        )
        assert isinstance(body, dict), f"Expected JSON object for user {username}, got: {type(body).__name__}"

        for field in ["username", "firstName", "lastName", "email", "phone", "userStatus"]:
            expected_value = seed_user.get(field)
            actual_value = body.get(field)
            assert actual_value == expected_value, (
                f"Mismatch for field '{field}' of user '{username}': "
                f"expected {expected_value!r}, got {actual_value!r}"
            )
