Feature: Iteration 3 MRs

  Scenario: Deleting a user should result in a 404 error when trying to retrieve the same user
    Given a seed input that successfully retrieves a user by their username, producing a seed output with a 200 status code and the user's details for MR9.
    When a follow-up input is created by deleting the user using the same username and then attempting to retrieve the user again, yielding a follow-up output for MR9.
    Then the follow-up output should return a 404 status code indicating the user is not found, differing from the seed output which contained the user's details for MR9.

  Scenario: Finding pets by tags should return a superset when additional tags are included
    Given a seed input that retrieves pets by a specific tag value in the query, producing a seed output with a list of pets for MR10.
    When a follow-up input is created by adding an additional tag value to the same query and retrieving pets again, yielding a follow-up output for MR10.
    Then the follow-up output should be a superset of the seed output, containing all pets from the seed output plus any additional pets that match the newly added tag value for MR10.

  Scenario: Retrieving pet inventory should reflect changes after adding a new pet
    Given a seed input that retrieves the pet inventory by status, producing a seed output with the current inventory counts mapped by status for MR11.
    When a follow-up input is created by adding a new pet with a specific status and then retrieving the inventory again, yielding a follow-up output for MR11.
    Then the follow-up output should show an increased count in the inventory map for the status of the newly added pet compared to the corresponding count in the seed output for MR11.

  Scenario: Logging out a user should not affect the ability to log in again
    Given a seed input that logs a user into the system using a username and password, producing a seed output with a 200 status code and a successful login response for MR12.
    When a follow-up input is created by logging the user out and then logging in again with the same username and password, yielding a follow-up output for MR12.
    Then the follow-up output should be a 200 status code with a successful login response, similar to the seed output, indicating that logging out does not prevent subsequent logins for MR12.

  Scenario: Creating users with a list should result in all users being retrievable
    Given a seed input that creates a list of users in a single request body, producing a seed output with a 200 status code indicating a successful operation for MR13.
    When a follow-up input is created by retrieving each user by their username from the originally provided list, yielding a follow-up output for MR13.
    Then the follow-up output should include successful retrieval responses with details for each user created in the seed input, confirming that all users are retrievable for MR13.
