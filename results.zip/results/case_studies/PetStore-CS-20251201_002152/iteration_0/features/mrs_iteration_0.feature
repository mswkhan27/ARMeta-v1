Feature: Iteration 0 MRs

  Scenario: Adding a new pet should increase the total count of pets with a specific status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR1.
    When a follow-up input is created by adding a new pet whose status is set to 'available', and then retrieving the list of pets filtered by status 'available' again, yielding a follow-up output for MR1.
    Then the follow-up output should have a count of pets with status available that is one more than the seed output for MR1.

  Scenario: Updating a pet's status should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR2.
    When a follow-up input is created by updating the pet's status to 'sold' and then retrieving the same pet by the same identifier again, yielding a follow-up output for MR2.
    Then the follow-up output should reflect the updated status 'sold' for that pet, and the pet's identifier should remain the same as in the seed output for MR2.

  Scenario: Deleting a pet should decrease the total count of pets with a specific status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR3, and selecting one pet from this list.
    When a follow-up input is created by deleting the selected pet and then retrieving the list of pets filtered by status 'available' again, yielding a follow-up output for MR3.
    Then the follow-up output should have a count of pets with status available that is one less than the seed output for MR3.
