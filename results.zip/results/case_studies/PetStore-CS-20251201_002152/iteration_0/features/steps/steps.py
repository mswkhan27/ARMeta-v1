from behave import given, when, then
import os
import json
import requests
import time

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR1.")
def _mr_MR1_seed_input(context):
    # Retrieve the list of pets with status 'available'
    response = requests.get(f"{BASE_URL}/pet/findByStatus", params={"status": "available"}, timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Response is not valid JSON for MR1 GIVEN step: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"Expected a list of pets, but got {type(data).__name__}")

    context.seed_response = data
    context.seed_request = {"status": "available"}
    context.seed_count = len(data)


@when("a follow-up input is created by adding a new pet whose status is set to 'available', and then retrieving the list of pets filtered by status 'available' again, yielding a follow-up output for MR1.")
def _mr_MR1_followup_input(context):
    # Ensure seed_count exists to avoid AttributeError
    if not hasattr(context, "seed_count"):
        raise AssertionError("seed_count is not set; GIVEN step may have failed or not run.")

    # Create a new pet with status 'available'
    new_pet = {
        "name": "New Available Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }

    add_response = requests.post(f"{BASE_URL}/pet", json=new_pet, timeout=10)
    add_response.raise_for_status()

    # Optionally parse to ensure it's valid JSON, but we don't depend on its structure here
    try:
        _ = add_response.json()
    except ValueError:
        # The API spec says it returns a Pet; if not JSON, fail explicitly
        raise AssertionError("Add pet response is not valid JSON in MR1 WHEN step.")

    # Retrieve the list of pets with status 'available' again
    followup_response = requests.get(f"{BASE_URL}/pet/findByStatus", params={"status": "available"}, timeout=10)
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response is not valid JSON for MR1 WHEN step: {e}")

    if not isinstance(followup_data, list):
        raise AssertionError(f"Expected a list of pets in follow-up, but got {type(followup_data).__name__}")

    context.followup_response = followup_data
    context.followup_count = len(followup_data)


@then("the follow-up output should have a count of pets with status available that is one more than the seed output for MR1.")
def _mr_MR1_followup_output(context):
    if not hasattr(context, "seed_count") or not hasattr(context, "followup_count"):
        raise AssertionError("seed_count or followup_count is missing; GIVEN/WHEN steps may have failed or not run.")

    expected = context.seed_count + 1
    actual = context.followup_count

    assert actual == expected, (
        f"Expected follow-up count to be {expected}, but got {actual}."
    )

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR2.")
def step_mr_MR2_seed_input(context):
    try:
        # Create a pet to ensure it exists
        pet_data = {
            "id": 1,
            "name": "doggie",
            "photoUrls": ["url1"],
            "status": "available",
        }
        create_resp = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)

        # Ensure the pet is created successfully and response is JSON
        assert create_resp.status_code == 200, f"Failed to create pet: {create_resp.text}"
        try:
            created_pet = create_resp.json()
        except ValueError:
            assert False, f"Create pet response is not valid JSON: {create_resp.text}"

        # Defensive access to id
        pet_id = created_pet.get("id")
        assert pet_id is not None, f"'id' not present in create pet response: {created_pet}"

        # Retrieve the pet to get the seed output
        seed_resp = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        assert seed_resp.status_code == 200, f"Failed to retrieve pet: {seed_resp.text}"
        try:
            seed_pet = seed_resp.json()
        except ValueError:
            assert False, f"Retrieve pet response is not valid JSON: {seed_resp.text}"

        # Store in context
        context.seed_request = seed_resp
        context.seed_response = seed_pet

    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"Error in Given step for MR2: {e}")


@when("a follow-up input is created by updating the pet's status to 'sold' and then retrieving the same pet by the same identifier again, yielding a follow-up output for MR2.")
def step_mr_MR2_followup_input(context):
    try:
        seed_pet = getattr(context, "seed_response", None)
        assert isinstance(seed_pet, dict), f"seed_response must be a dict, got {type(seed_pet)}"

        pet_id = seed_pet.get("id")
        assert pet_id is not None, f"'id' not present in seed_response: {seed_pet}"

        name = seed_pet.get("name", "doggie")
        photo_urls = seed_pet.get("photoUrls", ["url1"])

        update_data = {
            "id": pet_id,
            "name": name,
            "photoUrls": photo_urls,
            "status": "sold",
        }

        update_resp = requests.put(f"{BASE_URL}/pet", json=update_data, timeout=10)
        assert update_resp.status_code == 200, f"Failed to update pet: {update_resp.text}"
        try:
            updated_pet = update_resp.json()
        except ValueError:
            assert False, f"Update pet response is not valid JSON: {update_resp.text}"

        updated_id = updated_pet.get("id", pet_id)

        # Retrieve the pet again to get the follow-up output
        followup_resp = requests.get(f"{BASE_URL}/pet/{updated_id}", timeout=10)
        assert followup_resp.status_code == 200, f"Failed to retrieve updated pet: {followup_resp.text}"
        try:
            followup_pet = followup_resp.json()
        except ValueError:
            assert False, f"Retrieve updated pet response is not valid JSON: {followup_resp.text}"

        context.followup_request = followup_resp
        context.followup_response = followup_pet

    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"Error in When step for MR2: {e}")


@then("the follow-up output should reflect the updated status 'sold' for that pet, and the pet's identifier should remain the same as in the seed output for MR2.")
def step_mr_MR2_followup_output(context):
    try:
        followup = getattr(context, "followup_response", None)
        seed = getattr(context, "seed_response", None)

        assert isinstance(followup, dict), f"followup_response must be a dict, got {type(followup)}"
        assert isinstance(seed, dict), f"seed_response must be a dict, got {type(seed)}"

        followup_status = followup.get("status")
        followup_id = followup.get("id")
        seed_id = seed.get("id")

        assert followup_status == "sold", f"Expected status 'sold', but got {followup_status}"
        assert followup_id == seed_id, f"Expected id {seed_id}, but got {followup_id}"

    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"Error in Then step for MR2: {e}")

# ----




@given("a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR3, and selecting one pet from this list.")
def step_mr_MR3_seed_input(context):
    # Retrieve the list of pets with status 'available'
    seed_url = f"{BASE_URL}/pet/findByStatus"
    try:
        response = requests.get(seed_url, params={"status": "available"}, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Request to {seed_url} failed: {e}")

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in seed response: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"Expected list of pets from {seed_url}, got {type(data).__name__}")

    # Ensure we have at least one pet to select; if none, create one using POST /pet
    if len(data) == 0:
        new_pet = {
            "name": "Test Pet MR3",
            "photoUrls": ["http://example.com/photo.jpg"],
            "status": "available"
        }
        create_url = f"{BASE_URL}/pet"
        try:
            create_response = requests.post(create_url, json=new_pet, timeout=10)
            create_response.raise_for_status()
        except requests.RequestException as e:
            raise AssertionError(f"Request to {create_url} failed: {e}")

        try:
            created_pet = create_response.json()
        except ValueError as e:
            raise AssertionError(f"Invalid JSON in create pet response: {e}")

        if not isinstance(created_pet, dict):
            raise AssertionError(f"Expected created pet as object, got {type(created_pet).__name__}")

        data = [created_pet]

    # Store the seed list and count
    context.seed_response = data
    context.seed_count = len(data)

    # Select one pet from the list, ensuring it has a valid integer id
    selected_pet = data[0]
    if not isinstance(selected_pet, dict):
        raise AssertionError(f"Expected pet object, got {type(selected_pet).__name__}")

    pet_id = selected_pet.get("id")
    if not isinstance(pet_id, int):
        raise AssertionError(f"Selected pet has invalid or missing 'id': {pet_id!r}")

    context.selected_pet = selected_pet
    context.selected_pet_id = pet_id


@when("a follow-up input is created by deleting the selected pet and then retrieving the list of pets filtered by status 'available' again, yielding a follow-up output for MR3.")
def step_mr_MR3_followup_input(context):
    if not hasattr(context, "selected_pet_id"):
        raise AssertionError("selected_pet_id not found in context; Given step may have failed.")

    pet_id = context.selected_pet_id
    delete_url = f"{BASE_URL}/pet/{pet_id}"
    try:
        delete_response = requests.delete(delete_url, timeout=10)
        delete_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Request to {delete_url} failed: {e}")

    # Retrieve the list of pets with status 'available' again
    followup_url = f"{BASE_URL}/pet/findByStatus"
    try:
        followup_request = requests.get(followup_url, params={"status": "available"}, timeout=10)
        followup_request.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Request to {followup_url} failed: {e}")

    try:
        followup_data = followup_request.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in follow-up response: {e}")

    if not isinstance(followup_data, list):
        raise AssertionError(f"Expected list of pets from {followup_url}, got {type(followup_data).__name__}")

    context.followup_response = followup_data
    context.followup_count = len(followup_data)


@then("the follow-up output should have a count of pets with status available that is one less than the seed output for MR3.")
def step_mr_MR3_followup_output(context):
    if not hasattr(context, "seed_count") or not hasattr(context, "followup_count"):
        raise AssertionError("Missing seed_count or followup_count in context; previous steps may have failed.")

    seed_count = context.seed_count
    followup_count = context.followup_count

    if not isinstance(seed_count, int) or not isinstance(followup_count, int):
        raise AssertionError(f"Counts must be integers, got seed_count={seed_count!r}, followup_count={followup_count!r}")

    expected = seed_count - 1
    assert followup_count == expected, (
        f"Expected follow-up count to be {expected}, but got {followup_count}. "
        f"(seed_count={seed_count})"
    )
