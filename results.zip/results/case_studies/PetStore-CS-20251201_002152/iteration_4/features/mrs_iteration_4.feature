Feature: Iteration 4 MRs

  Scenario: Updating a pet's name should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current name for MR15.
    When a follow-up input is created by updating the pet's name while keeping the same identifier and then retrieving the same pet by that identifier again, yielding a follow-up output for MR15.
    Then the follow-up output should reflect the updated name for that pet, and the pet's identifier should remain the same as in the seed output for MR15.

  Scenario: Adding a new pet should not decrease the total count of pets with a specific status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR16.
    When a follow-up input is created by adding a new pet whose status is set to 'available', and then retrieving the list of pets filtered by status 'available' again, yielding a follow-up output for MR16.
    Then the follow-up output should have a count of pets with status 'available' that is greater than or equal to the count from the seed output for MR16.

  Scenario: Deleting a pet should result in a 404 error when trying to retrieve the same pet
    Given a seed input that successfully retrieves a pet by its identifier, producing a seed output with a 200 status and the pet's details for MR17.
    When a follow-up input is created by deleting the pet using the same identifier and then attempting to retrieve the pet again, yielding a follow-up output for MR17.
    Then the follow-up output should return a 404 error indicating the pet is not found, differing from the seed output which contained the pet's details for MR17.

  Scenario: Retrieving inventory should reflect changes after placing a new order
    Given a seed input that retrieves the inventory by status, producing a seed output with the current counts mapped by status for MR18.
    When a follow-up input is created by placing a new order with a specific status and then retrieving the inventory again, yielding a follow-up output for MR18.
    Then the follow-up output should show a count in the inventory map for the status of the newly placed order that is greater than or equal to the corresponding count in the seed output for MR18.
