from behave import given, when, then
import os
import json
import requests
from requests.exceptions import RequestException

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current name for MR15.")
def step_mr_MR15_seed_input(context):
    try:
        pet_data = {
            "name": "doggie",
            "photoUrls": ["url1", "url2"],
            "status": "available",
        }
        response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        response.raise_for_status()

        try:
            seed_response = response.json()
        except ValueError:
            raise AssertionError("Response from POST /pet is not valid JSON")

        if not isinstance(seed_response, dict):
            raise AssertionError("Seed response from POST /pet is not a JSON object")

        pet_id = seed_response.get("id")
        if pet_id is None:
            raise AssertionError("Seed response JSON does not contain 'id'")
        if not isinstance(pet_id, int):
            raise AssertionError(f"'id' in seed response is not an integer: {pet_id}")

        context.seed_request = pet_data
        context.pet_id = pet_id

        response = requests.get(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
        response.raise_for_status()

        try:
            seed_get_response = response.json()
        except ValueError:
            raise AssertionError("Response from GET /pet/\\{petId\\} is not valid JSON")

        if not isinstance(seed_get_response, dict):
            raise AssertionError("Seed response from GET /pet/\\{petId\\} is not a JSON object")

        if "name" not in seed_get_response:
            raise AssertionError("Seed response from GET /pet/\\{petId\\} does not contain 'name'")

        context.seed_response = seed_get_response

    except RequestException as e:
        raise AssertionError(f"HTTP error in Given step for MR15: {e}") from e
    except Exception as e:
        raise AssertionError(f"Unexpected error in Given step for MR15: {e}") from e


@when("a follow-up input is created by updating the pet's name while keeping the same identifier and then retrieving the same pet by that identifier again, yielding a follow-up output for MR15.")
def step_mr_MR15_followup_input(context):
    try:
        if not hasattr(context, "pet_id"):
            raise AssertionError("Context is missing 'pet_id' from Given step")
        if not hasattr(context, "seed_response"):
            raise AssertionError("Context is missing 'seed_response' from Given step")

        seed_resp = context.seed_response
        photo_urls = seed_resp.get("photoUrls") or []
        if not isinstance(photo_urls, list):
            raise AssertionError("'photoUrls' in seed response is not a list")

        status = seed_resp.get("status", "available")
        if status is None:
            status = "available"

        updated_name = "doggie_updated"
        update_data = {
            "id": context.pet_id,
            "name": updated_name,
            "photoUrls": photo_urls,
            "status": status,
        }

        response = requests.put(f"{BASE_URL}/pet", json=update_data, timeout=10)
        response.raise_for_status()

        response = requests.get(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
        response.raise_for_status()

        try:
            followup_response = response.json()
        except ValueError:
            raise AssertionError("Response from GET /pet/\\{petId\\} after update is not valid JSON")

        if not isinstance(followup_response, dict):
            raise AssertionError("Follow-up response from GET /pet/\\{petId\\} is not a JSON object")

        context.followup_response = followup_response
        context.updated_name = updated_name

    except RequestException as e:
        raise AssertionError(f"HTTP error in When step for MR15: {e}") from e
    except Exception as e:
        raise AssertionError(f"Unexpected error in When step for MR15: {e}") from e


@then("the follow-up output should reflect the updated name for that pet, and the pet's identifier should remain the same as in the seed output for MR15.")
def step_mr_MR15_followup_output(context):
    try:
        if not hasattr(context, "followup_response"):
            raise AssertionError("Context is missing 'followup_response' from When step")
        if not hasattr(context, "pet_id"):
            raise AssertionError("Context is missing 'pet_id' from previous steps")

        followup = context.followup_response

        if "name" not in followup:
            raise AssertionError("Follow-up response JSON does not contain 'name'")
        if "id" not in followup:
            raise AssertionError("Follow-up response JSON does not contain 'id'")

        expected_name = getattr(context, "updated_name", "doggie_updated")
        actual_name = followup.get("name")
        actual_id = followup.get("id")

        assert actual_name == expected_name, (
            f"The pet's name was not updated correctly. "
            f"Expected '{expected_name}', got '{actual_name}'"
        )
        assert actual_id == context.pet_id, (
            f"The pet's identifier has changed. "
            f"Expected '{context.pet_id}', got '{actual_id}'"
        )

    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"Unexpected error in Then step for MR15: {e}") from e

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR16.")
def step_mr_MR16_seed_input(context):
    # Retrieve the list of pets with status 'available'
    url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}

    response = requests.get(url, params=params, timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except json.JSONDecodeError as e:
        raise AssertionError(f"Expected JSON response for seed step MR16, got decode error: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"Expected a list of pets for seed step MR16, got: {type(data).__name__}")

    context.seed_response = data
    context.seed_request = params
    context.seed_count = len(data)


@when("a follow-up input is created by adding a new pet whose status is set to 'available', and then retrieving the list of pets filtered by status 'available' again, yielding a follow-up output for MR16.")
def step_mr_MR16_followup_input(context):
    # Create a new pet with status 'available'
    url_add_pet = f"{BASE_URL}/pet"
    new_pet = {
        "name": "New Available Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    add_response = requests.post(url_add_pet, json=new_pet, timeout=10)
    add_response.raise_for_status()

    # Retrieve the list of pets with status 'available' again
    url_find = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}

    followup_response = requests.get(url_find, params=params, timeout=10)
    followup_response.raise_for_status()

    try:
        data = followup_response.json()
    except json.JSONDecodeError as e:
        raise AssertionError(f"Expected JSON response for follow-up step MR16, got decode error: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"Expected a list of pets for follow-up step MR16, got: {type(data).__name__}")

    context.followup_response = data
    context.followup_count = len(data)


@then("the follow-up output should have a count of pets with status 'available' that is greater than or equal to the count from the seed output for MR16.")
def step_mr_MR16_followup_output(context):
    if not hasattr(context, "seed_count") or not hasattr(context, "followup_count"):
        raise AssertionError("Missing seed_count or followup_count in context for MR16 assertion.")

    seed_count = context.seed_count
    followup_count = context.followup_count

    if not isinstance(seed_count, int) or not isinstance(followup_count, int):
        raise AssertionError(
            f"Counts must be integers for MR16 assertion, got seed_count={type(seed_count).__name__}, "
            f"followup_count={type(followup_count).__name__}"
        )

    assert followup_count >= seed_count, (
        f"Expected follow-up count {followup_count} to be greater than or equal to seed count {seed_count}."
    )

# ----




@given("a seed input that successfully retrieves a pet by its identifier, producing a seed output with a 200 status and the pet's details for MR17.")
def step_mr_MR17_seed_input(context):
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }
    try:
        response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        response.raise_for_status()
        data = response.json() if response.content else {}
    except (requests.exceptions.RequestException, ValueError) as e:
        raise AssertionError(f"Error in GIVEN step for MR17 while creating pet: {e}")

    pet_id = data.get("id")
    if pet_id is None:
        raise AssertionError(f"Pet creation response does not contain 'id': {json.dumps(data, ensure_ascii=False)}")

    context.seed_request = pet_data
    context.seed_response = data
    context.pet_id = pet_id

    try:
        get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in GIVEN step for MR17 while retrieving pet: {e}")

    if get_response.status_code != 200:
        raise AssertionError(
            f"Expected 200 when retrieving created pet, got {get_response.status_code}. "
            f"Body: {get_response.text}"
        )

    try:
        context.seed_get_response = get_response.json() if get_response.content else {}
    except ValueError:
        raise AssertionError(
            f"Failed to decode JSON from seed GET response. Status: {get_response.status_code}, "
            f"Body: {get_response.text}"
        )


@when("a follow-up input is created by deleting the pet using the same identifier and then attempting to retrieve the pet again, yielding a follow-up output for MR17.")
def step_mr_MR17_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AssertionError("pet_id is missing in context; GIVEN step may have failed or not run.")

    pet_id = context.pet_id
    try:
        delete_response = requests.delete(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        # Do not raise_for_status here; we assert explicitly in THEN
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in WHEN step for MR17 while deleting pet: {e}")

    context.delete_response = delete_response

    try:
        followup_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in WHEN step for MR17 while retrieving deleted pet: {e}")

    context.followup_response = followup_response


@then("the follow-up output should return a 404 error indicating the pet is not found, differing from the seed output which contained the pet's details for MR17.")
def step_mr_MR17_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AssertionError("followup_response is missing in context; WHEN step may have failed or not run.")

    status_code = getattr(context.followup_response, "status_code", None)
    if status_code is None:
        raise AssertionError("followup_response has no status_code; invalid response object.")

    assert status_code == 404, (
        f"Expected 404 after deleting pet, got {status_code}. "
        f"Body: {context.followup_response.text}"
    )

# ----

import time



@given('a seed input that retrieves the inventory by status, producing a seed output with the current counts mapped by status for MR18.')
def _mr_MR18_seed_input(context):
    response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    response.raise_for_status()

    try:
        seed_json = response.json()
    except ValueError as exc:
        raise AssertionError(f"Seed inventory response is not valid JSON: {exc}") from exc

    if not isinstance(seed_json, dict):
        raise AssertionError(f"Expected inventory to be an object/map, got: {type(seed_json).__name__}")

    context.seed_response = seed_json
    context.seed_request = None  # No body for GET request


@when('a follow-up input is created by placing a new order with a specific status and then retrieving the inventory again, yielding a follow-up output for MR18.')
def _mr_MR18_followup_input(context):
    order_data = {
        "petId": 198772,
        "quantity": 1,
        "status": "placed",
        "complete": False
    }

    order_response = requests.post(f"{BASE_URL}/store/order", json=order_data, timeout=10)
    order_response.raise_for_status()

    try:
        order_json = order_response.json()
    except ValueError as exc:
        raise AssertionError(f"Order response is not valid JSON: {exc}") from exc

    if not isinstance(order_json, dict):
        raise AssertionError(f"Expected order response to be an object, got: {type(order_json).__name__}")

    inventory_response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    inventory_response.raise_for_status()

    try:
        followup_json = inventory_response.json()
    except ValueError as exc:
        raise AssertionError(f"Follow-up inventory response is not valid JSON: {exc}") from exc

    if not isinstance(followup_json, dict):
        raise AssertionError(f"Expected follow-up inventory to be an object/map, got: {type(followup_json).__name__}")

    context.followup_response = followup_json
    context.followup_request = order_json


@then('the follow-up output should show a count in the inventory map for the status of the newly placed order that is greater than or equal to the corresponding count in the seed output for MR18.')
def _mr_MR18_followup_output(context):
    if not isinstance(context.followup_request, dict):
        raise AssertionError("Follow-up request (order response) is not stored as an object.")

    new_order_status = context.followup_request.get('status')
    if not isinstance(new_order_status, str) or not new_order_status:
        raise AssertionError(f"New order status is missing or invalid in follow-up request: {new_order_status!r}")

    if not isinstance(context.seed_response, dict):
        raise AssertionError("Seed response is not a dictionary/map.")
    if not isinstance(context.followup_response, dict):
        raise AssertionError("Follow-up response is not a dictionary/map.")

    seed_raw = context.seed_response.get(new_order_status, 0)
    followup_raw = context.followup_response.get(new_order_status, 0)

    try:
        seed_count = int(seed_raw)
    except (TypeError, ValueError):
        raise AssertionError(f"Seed inventory count for status '{new_order_status}' is not an integer: {seed_raw!r}")

    try:
        followup_count = int(followup_raw)
    except (TypeError, ValueError):
        raise AssertionError(f"Follow-up inventory count for status '{new_order_status}' is not an integer: {followup_raw!r}")

    if followup_count < seed_count:
        raise AssertionError(
            f"Expected follow-up count for status '{new_order_status}' to be >= {seed_count}, "
            f"but got {followup_count}."
        )
