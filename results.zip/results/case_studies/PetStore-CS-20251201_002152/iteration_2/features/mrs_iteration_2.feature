Feature: Iteration 2 MRs

  Scenario: Deleting a pet should result in a 404 error when trying to retrieve the same pet
    Given a seed input that successfully retrieves a pet by its identifier, producing a seed output with a 200 status and the pet's details for MR5.
    When a follow-up input is created by deleting the pet using the same identifier and then attempting to retrieve the pet again, yielding a follow-up output for MR5.
    Then the follow-up output should return a 404 error indicating the pet is not found, differing from the seed output which contained the pet's details for MR5.

  Scenario: Deleting an order should result in a 404 error when trying to retrieve the same order
    Given a seed input that successfully retrieves an order by its identifier, producing a seed output with a 200 status and the order's details for MR6.
    When a follow-up input is created by deleting the order using the same identifier (within the valid identifier range for deletion) and then attempting to retrieve the order again, yielding a follow-up output for MR6.
    Then the follow-up output should return a 404 error indicating the order is not found, differing from the seed output which contained the order's details for MR6.

  Scenario: Logging in a user should provide expiration information that updates on subsequent logins
    Given a seed input that logs in a user with valid credentials, producing a seed output with a successful login response including rate limit and expiration header details for MR8.
    When a follow-up input is created by logging in the same user again with the same credentials, yielding a follow-up output for MR8.
    Then the follow-up output should represent another successful login, with the expiration header indicating a time that is later than or equal to that in the seed output, and potentially differing response details for MR8.
