from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that successfully retrieves a pet by its identifier, producing a seed output with a 200 status and the pet's details for MR5.")
def _mr_MR5_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    context.seed_request = response

    if response.status_code != 200:
        raise AssertionError(f"Failed to create pet: HTTP {response.status_code} - {response.text}")

    # Retrieve the pet to get the seed output
    pet_id = pet_data.get("id")
    if pet_id is None:
        raise AssertionError("Pet ID is missing in pet_data")

    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    context.seed_response = get_response

    if get_response.status_code != 200:
        raise AssertionError(f"Failed to retrieve pet: HTTP {get_response.status_code} - {get_response.text}")

    # Ensure response body is valid JSON with an 'id' field
    try:
        body = get_response.json()
    except ValueError as e:
        raise AssertionError(f"Seed response is not valid JSON: {e}")

    if "id" not in body:
        raise AssertionError("Seed response JSON does not contain 'id' field")


@when("a follow-up input is created by deleting the pet using the same identifier and then attempting to retrieve the pet again, yielding a follow-up output for MR5.")
def _mr_MR5_followup_input(context):
    # Safely extract pet_id from prior JSON
    try:
        seed_body = context.seed_response.json()
    except ValueError as e:
        raise AssertionError(f"Seed response is not valid JSON in WHEN step: {e}")

    pet_id = seed_body.get("id")
    if pet_id is None:
        raise AssertionError("Seed response JSON does not contain 'id' field in WHEN step")

    # Delete the pet
    delete_response = requests.delete(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    context.followup_request = delete_response

    if delete_response.status_code != 200:
        raise AssertionError(f"Failed to delete pet: HTTP {delete_response.status_code} - {delete_response.text}")

    # Attempt to retrieve the pet again
    followup_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    context.followup_response = followup_response


@then("the follow-up output should return a 404 error indicating the pet is not found, differing from the seed output which contained the pet's details for MR5.")
def _mr_MR5_followup_output(context):
    status = context.followup_response.status_code
    if status != 404:
        raise AssertionError(
            f"Expected 404 but got {status}: {context.followup_response.text}"
        )

    # Compare JSON bodies where possible, but avoid raising on invalid JSON
    seed_json = None
    followup_json = None

    try:
        seed_json = context.seed_response.json()
    except ValueError:
        # If seed is not JSON, use text as fallback
        seed_json = context.seed_response.text

    try:
        followup_json = context.followup_response.json()
    except ValueError:
        # If follow-up is not JSON, use text as fallback
        followup_json = context.followup_response.text

    if seed_json == followup_json:
        raise AssertionError("Seed output should differ from follow-up output.")

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


@given("a seed input that successfully retrieves an order by its identifier, producing a seed output with a 200 status and the order's details for MR6.")
def _mr_MR6_seed_input(context):
    # Create a new order to ensure it exists
    order_data = {
        "petId": 198772,
        "quantity": 1,
        "status": "placed",
        "complete": True,
    }

    response = requests.post(f"{BASE_URL}/store/order", json=order_data, timeout=10)
    context.seed_request = response

    try:
        seed_json = response.json()
    except ValueError:
        seed_json = {}
    context.seed_response = seed_json

    assert response.status_code == 200, f"Failed to create order: {seed_json}"

    order_id = seed_json.get("id")
    assert order_id is not None, f"No 'id' in seed_response: {seed_json}"
    assert isinstance(order_id, int), f"Order id is not int: {order_id!r}"

    # Retrieve the created order to satisfy the 'successfully retrieves an order' part
    get_resp = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    context.seed_get_request = get_resp
    try:
        seed_get_json = get_resp.json()
    except ValueError:
        seed_get_json = {}
    context.seed_get_response = seed_get_json

    assert get_resp.status_code == 200, (
        f"Failed to retrieve created order: {get_resp.status_code}, body={seed_get_json}"
    )


@when("a follow-up input is created by deleting the order using the same identifier (within the valid identifier range for deletion) and then attempting to retrieve the order again, yielding a follow-up output for MR6.")
def _mr_MR6_followup_input(context):
    order_id = context.seed_response.get("id")
    assert order_id is not None, f"No 'id' in seed_response: {context.seed_response}"
    assert isinstance(order_id, int), f"Order id is not int: {order_id!r}"

    delete_resp = requests.delete(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    context.delete_request = delete_resp
    # Response body for delete may not be JSON; ignore JSON errors safely
    try:
        context.delete_response = delete_resp.json()
    except ValueError:
        context.delete_response = delete_resp.text

    assert delete_resp.status_code == 200, (
        f"Failed to delete order: {delete_resp.status_code}, body={context.delete_response}"
    )

    followup_req = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    context.followup_request = followup_req
    try:
        followup_json = followup_req.json()
    except ValueError:
        followup_json = {}
    context.followup_response = followup_json


@then("the follow-up output should return a 404 error indicating the order is not found, differing from the seed output which contained the order's details for MR6.")
def _mr_MR6_followup_output(context):
    assert context.followup_request is not None, "followup_request is not set"
    status_code = getattr(context.followup_request, "status_code", None)
    assert status_code == 404, (
        f"Expected 404 but got {status_code}: {json.dumps(context.followup_response, ensure_ascii=False)}"
    )

# ----

from datetime import datetime



@given('a seed input that logs in a user with valid credentials, producing a seed output with a successful login response including rate limit and expiration header details for MR8.')
def _mr_MR8_seed_login(context):
    try:
        context.username = "testuser"
        context.password = "testpassword"
        context.seed_request = {
            "username": context.username,
            "password": context.password
        }

        response = requests.get(
            f"{BASE_URL}/user/login",
            params=context.seed_request,
            timeout=10
        )

        assert response.status_code == 200, (
            f"Failed to log in: status={response.status_code}, body={response.text}"
        )

        context.seed_response = response
        context.rate_limit = response.headers.get('X-Rate-Limit')
        context.expiration_time_header = response.headers.get('X-Expires-After')

        # Parse expiration time safely (may be None or invalid format)
        context.expiration_time = None
        if context.expiration_time_header:
            try:
                context.expiration_time = datetime.fromisoformat(
                    context.expiration_time_header.replace('Z', '+00:00')
                )
            except (TypeError, ValueError):
                # Leave as None if parsing fails; Then step will handle this case
                context.expiration_time = None

    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"Error in Given step: MR8 Seed Login - {e}") from e


@when('a follow-up input is created by logging in the same user again with the same credentials, yielding a follow-up output for MR8.')
def _mr_MR8_followup_login(context):
    try:
        # Ensure seed_request exists to avoid AttributeError
        seed_request = getattr(context, 'seed_request', None)
        assert isinstance(seed_request, dict), "seed_request is missing or invalid in context"

        response = requests.get(
            f"{BASE_URL}/user/login",
            params=seed_request,
            timeout=10
        )

        assert response.status_code == 200, (
            f"Failed to log in again: status={response.status_code}, body={response.text}"
        )

        context.followup_response = response

    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"Error in When step: MR8 Follow-up Login - {e}") from e


@then('the follow-up output should represent another successful login, with the expiration header indicating a time that is later than or equal to that in the seed output, and potentially differing response details for MR8.')
def _mr_MR8_assert_followup(context):
    try:
        followup_response = getattr(context, 'followup_response', None)
        assert followup_response is not None, "followup_response is missing from context"

        # Check follow-up status code again defensively
        assert followup_response.status_code == 200, (
            f"Follow-up login not successful: status={followup_response.status_code}, "
            f"body={followup_response.text}"
        )

        followup_expiration_header = followup_response.headers.get('X-Expires-After')

        # If either expiration header is missing, we can only assert that at least
        # one expiration header exists, since MR talks about expiration information.
        seed_exp_header = getattr(context, 'expiration_time_header', None)

        assert followup_expiration_header or seed_exp_header, (
            "No expiration information present in either seed or follow-up response headers."
        )

        # Parse follow-up expiration safely
        followup_expiration = None
        if followup_expiration_header:
            try:
                followup_expiration = datetime.fromisoformat(
                    followup_expiration_header.replace('Z', '+00:00')
                )
            except (TypeError, ValueError):
                followup_expiration = None

        seed_expiration = getattr(context, 'expiration_time', None)

        # Only compare times if both are successfully parsed
        if seed_expiration is not None and followup_expiration is not None:
            assert followup_expiration >= seed_expiration, (
                f"Expiration time did not update correctly: "
                f"seed={seed_expiration.isoformat()}, "
                f"followup={followup_expiration.isoformat()}"
            )

        # Optionally check that response body is a string per OpenAPI (not required but safe)
        try:
            body_text = followup_response.text
            assert isinstance(body_text, str), "Follow-up response body is not text"
        except Exception:
            # Do not fail MR solely on body parsing issues
            pass

    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"Error in Then step: MR8 Assert Follow-up - {e}") from e
