
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: Adding a new pet should increase the total count of pets with a specific status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR1.
    When a follow-up input is created by adding a new pet whose status is set to 'available', and then retrieving the list of pets filtered by status 'available' again, yielding a follow-up output for MR1.
    Then the follow-up output should have a count of pets with status available that is one more than the seed output for MR1.

  Scenario: Updating a pet's status should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR2.
    When a follow-up input is created by updating the pet's status to 'sold' and then retrieving the same pet by the same identifier again, yielding a follow-up output for MR2.
    Then the follow-up output should reflect the updated status 'sold' for that pet, and the pet's identifier should remain the same as in the seed output for MR2.

  Scenario: Deleting a pet should decrease the total count of pets with a specific status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR3, and selecting one pet from this list.
    When a follow-up input is created by deleting the selected pet and then retrieving the list of pets filtered by status 'available' again, yielding a follow-up output for MR3.
    Then the follow-up output should have a count of pets with status available that is one less than the seed output for MR3.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: Uploading an image for a pet should not alter the pet's other attributes
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current attributes for MR4.
    When a follow-up input is created by uploading an image for the same pet identifier and then retrieving that pet again, yielding a follow-up output for MR4.
    Then the follow-up output should have the same pet attributes as the seed output for MR4, since uploading an image does not modify the pet representation returned by the service.

  Scenario: Updating a user's information should reflect in subsequent retrieval of that user
    Given a seed input that retrieves a user by their username, producing a seed output with the user's current information for MR7.
    When a follow-up input is created by updating the user's information while keeping the same username, and then retrieving the same user by that username again, yielding a follow-up output for MR7.
    Then the follow-up output should reflect the updated information for that user, and the user's username should remain the same as in the seed output for MR7.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: Deleting a pet should result in a 404 error when trying to retrieve the same pet
    Given a seed input that successfully retrieves a pet by its identifier, producing a seed output with a 200 status and the pet's details for MR5.
    When a follow-up input is created by deleting the pet using the same identifier and then attempting to retrieve the pet again, yielding a follow-up output for MR5.
    Then the follow-up output should return a 404 error indicating the pet is not found, differing from the seed output which contained the pet's details for MR5.

  Scenario: Deleting an order should result in a 404 error when trying to retrieve the same order
    Given a seed input that successfully retrieves an order by its identifier, producing a seed output with a 200 status and the order's details for MR6.
    When a follow-up input is created by deleting the order using the same identifier (within the valid identifier range for deletion) and then attempting to retrieve the order again, yielding a follow-up output for MR6.
    Then the follow-up output should return a 404 error indicating the order is not found, differing from the seed output which contained the order's details for MR6.

  Scenario: Logging in a user should provide expiration information that updates on subsequent logins
    Given a seed input that logs in a user with valid credentials, producing a seed output with a successful login response including rate limit and expiration header details for MR8.
    When a follow-up input is created by logging in the same user again with the same credentials, yielding a follow-up output for MR8.
    Then the follow-up output should represent another successful login, with the expiration header indicating a time that is later than or equal to that in the seed output, and potentially differing response details for MR8.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: Deleting a user should result in a 404 error when trying to retrieve the same user
    Given a seed input that successfully retrieves a user by their username, producing a seed output with a 200 status code and the user's details for MR9.
    When a follow-up input is created by deleting the user using the same username and then attempting to retrieve the user again, yielding a follow-up output for MR9.
    Then the follow-up output should return a 404 status code indicating the user is not found, differing from the seed output which contained the user's details for MR9.

  Scenario: Finding pets by tags should return a superset when additional tags are included
    Given a seed input that retrieves pets by a specific tag value in the query, producing a seed output with a list of pets for MR10.
    When a follow-up input is created by adding an additional tag value to the same query and retrieving pets again, yielding a follow-up output for MR10.
    Then the follow-up output should be a superset of the seed output, containing all pets from the seed output plus any additional pets that match the newly added tag value for MR10.

  Scenario: Retrieving pet inventory should reflect changes after adding a new pet
    Given a seed input that retrieves the pet inventory by status, producing a seed output with the current inventory counts mapped by status for MR11.
    When a follow-up input is created by adding a new pet with a specific status and then retrieving the inventory again, yielding a follow-up output for MR11.
    Then the follow-up output should show an increased count in the inventory map for the status of the newly added pet compared to the corresponding count in the seed output for MR11.

  Scenario: Logging out a user should not affect the ability to log in again
    Given a seed input that logs a user into the system using a username and password, producing a seed output with a 200 status code and a successful login response for MR12.
    When a follow-up input is created by logging the user out and then logging in again with the same username and password, yielding a follow-up output for MR12.
    Then the follow-up output should be a 200 status code with a successful login response, similar to the seed output, indicating that logging out does not prevent subsequent logins for MR12.

  Scenario: Creating users with a list should result in all users being retrievable
    Given a seed input that creates a list of users in a single request body, producing a seed output with a 200 status code indicating a successful operation for MR13.
    When a follow-up input is created by retrieving each user by their username from the originally provided list, yielding a follow-up output for MR13.
    Then the follow-up output should include successful retrieval responses with details for each user created in the seed input, confirming that all users are retrievable for MR13.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: Updating a pet's name should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current name for MR15.
    When a follow-up input is created by updating the pet's name while keeping the same identifier and then retrieving the same pet by that identifier again, yielding a follow-up output for MR15.
    Then the follow-up output should reflect the updated name for that pet, and the pet's identifier should remain the same as in the seed output for MR15.

  Scenario: Adding a new pet should not decrease the total count of pets with a specific status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR16.
    When a follow-up input is created by adding a new pet whose status is set to 'available', and then retrieving the list of pets filtered by status 'available' again, yielding a follow-up output for MR16.
    Then the follow-up output should have a count of pets with status 'available' that is greater than or equal to the count from the seed output for MR16.

  Scenario: Deleting a pet should result in a 404 error when trying to retrieve the same pet
    Given a seed input that successfully retrieves a pet by its identifier, producing a seed output with a 200 status and the pet's details for MR17.
    When a follow-up input is created by deleting the pet using the same identifier and then attempting to retrieve the pet again, yielding a follow-up output for MR17.
    Then the follow-up output should return a 404 error indicating the pet is not found, differing from the seed output which contained the pet's details for MR17.

  Scenario: Retrieving inventory should reflect changes after placing a new order
    Given a seed input that retrieves the inventory by status, producing a seed output with the current counts mapped by status for MR18.
    When a follow-up input is created by placing a new order with a specific status and then retrieving the inventory again, yielding a follow-up output for MR18.
    Then the follow-up output should show a count in the inventory map for the status of the newly placed order that is greater than or equal to the corresponding count in the seed output for MR18.


# --- From iteration_5\features\mrs_iteration_5.feature ---

Feature: Iteration 5 MRs

  Scenario: Updating a pet's name should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current name for MR20.
    When a follow-up input is created by updating the pet's name while keeping the same identifier via an appropriate update operation and then retrieving the same pet by that identifier again, yielding a follow-up output for MR20.
    Then the follow-up output should reflect the updated name for that pet, and the pet's identifier should remain the same as in the seed output for MR20.


# --- From iteration_6\features\mrs_iteration_6.feature ---

Feature: Iteration 6 MRs

  Scenario: Finding pets by tags should return a superset when additional tags are included
    Given a seed input that retrieves pets by a specific tag value in the query, producing a seed output with a list of pets associated with that tag for MR21, assuming no pets are added, removed, or modified between calls.
    When a follow-up input is created by adding an additional, distinct tag value to the same query and retrieving pets again, yielding a follow-up output for MR21.
    Then the follow-up output should be a superset of the seed output, containing all pets from the seed output (since they still match the original tag filter) plus any additional pets that match either of the specified tag values for MR21, assuming the underlying pet data remains unchanged.

  Scenario: Updating a pet's name should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current name and identifier for MR22.
    When a follow-up input is created by updating the pet's name while keeping the same identifier via an appropriate update operation, and then retrieving the same pet by that identifier again, yielding a follow-up output for MR22.
    Then the follow-up output should reflect the updated name for that pet, and the pet's identifier should remain the same as in the seed output for MR22, assuming the update operation was successful.


# --- From iteration_7\features\mrs_iteration_7.feature ---

Feature: Iteration 7 MRs

  Scenario: Finding pets by tags should return a superset when additional valid tags are included
    Given a seed input that retrieves pets by a specific, valid tag value in the query, producing a seed output with a list of pets associated with that tag for MR23, while the underlying pet data remains unchanged between calls.
    When a follow-up input is created by adding an additional, distinct, valid tag value to the same query (so that pets matching any of the provided tags are considered) and retrieving pets again, yielding a follow-up output for MR23.
    Then the follow-up output should be a superset of the seed output, containing all pets from the seed output plus any additional pets that match at least one of the specified tag values for MR23, assuming no changes to the stored pets between the two calls.

  Scenario: Updating a pet's name should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier as defined in the store, producing a seed output with the pet's current name for MR24.
    When a follow-up input is created by updating the pet's name while keeping the same identifier in the store and then retrieving the same pet by that identifier again, yielding a follow-up output for MR24.
    Then the follow-up output should reflect the updated name for that pet, and the pet's identifier and other unchanged attributes should remain the same as in the seed output for MR24.


# --- From iteration_8\features\mrs_iteration_8.feature ---

Feature: Iteration 8 MRs

  Scenario: Adding a new pet with a specific ID should allow retrieval of that pet by the same ID
    Given a seed input that adds a new pet with a specific ID using the pet-creation operation, producing a seed output indicating successful creation for MR25.
    When a follow-up input is created by retrieving the pet using the same ID with the pet-retrieval-by-identifier operation, yielding a follow-up output for MR25.
    Then the follow-up output should return the pet details matching the ID used in the seed input, confirming the pet's existence and details as in the seed output for MR25.

  Scenario: Updating a pet's status should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier using the pet-retrieval-by-identifier operation, producing a seed output with the pet's current status for MR26.
    When a follow-up input is created by updating the pet's status using the pet-update-with-form-data operation and then retrieving the same pet by the same identifier again using the pet-retrieval-by-identifier operation, yielding a follow-up output for MR26.
    Then the follow-up output should reflect the updated status for that pet, and the pet's identifier should remain the same as in the seed output for MR26.

  Scenario: Adding a new pet should not affect the retrieval of existing pets
    Given a seed input that retrieves a list of existing pets using a pet-search operation (for example, filtered by a specific status), producing a seed output with their details for MR27.
    When a follow-up input is created by adding a new pet using the pet-creation operation and then retrieving the list of pets again using the same search criteria with the pet-search operation, yielding a follow-up output for MR27.
    Then the follow-up output should include all pets from the seed output, and any existing pet details should remain unchanged; additionally, if the newly added pet matches the search criteria, it should appear in the follow-up output for MR27.

  Scenario: Updating a pet's name should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier using the pet-retrieval-by-identifier operation, producing a seed output with the pet's current name for MR29.
    When a follow-up input is created by updating the pet's name using the pet-update-with-form-data operation and then retrieving the same pet by that identifier again using the pet-retrieval-by-identifier operation, yielding a follow-up output for MR29.
    Then the follow-up output should reflect the updated name for that pet, and the pet's identifier should remain the same as in the seed output for MR29.

