Feature: Iteration 5 MRs

  Scenario: Updating a pet's name should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current name for MR20.
    When a follow-up input is created by updating the pet's name while keeping the same identifier via an appropriate update operation and then retrieving the same pet by that identifier again, yielding a follow-up output for MR20.
    Then the follow-up output should reflect the updated name for that pet, and the pet's identifier should remain the same as in the seed output for MR20.
