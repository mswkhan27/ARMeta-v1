from behave import given, when, then
import os
import json
import requests
import time

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current name for MR20.")
def _mr_MR20_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "id": 20,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available",
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    try:
        response_data = response.json()
    except ValueError:
        response_data = {}

    assert response.status_code == 200, f"Failed to create pet: {response_data}"

    # Retrieve the pet to get the seed output
    seed_response = requests.get(f"{BASE_URL}/pet/20", timeout=10)
    try:
        seed_response_data = seed_response.json()
    except ValueError:
        seed_response_data = {}

    assert (
        seed_response.status_code == 200
    ), f"Failed to retrieve pet: {seed_response_data}"

    context.seed_request = seed_response
    context.seed_response = seed_response_data


@when(
    "a follow-up input is created by updating the pet's name while keeping the same identifier via an appropriate update operation and then retrieving the same pet by that identifier again, yielding a follow-up output for MR20."
)
def _mr_MR20_followup_input(context):
    photo_urls = context.seed_response.get("photoUrls") or []
    status = context.seed_response.get("status") or "available"

    updated_pet_data = {
        "id": 20,
        "name": "doggie_updated",
        "photoUrls": photo_urls,
        "status": status,
    }

    update_response = requests.put(f"{BASE_URL}/pet", json=updated_pet_data, timeout=10)
    try:
        update_response_data = update_response.json()
    except ValueError:
        update_response_data = {}

    assert (
        update_response.status_code == 200
    ), f"Failed to update pet: {update_response_data}"

    followup_response = requests.get(f"{BASE_URL}/pet/20", timeout=10)
    try:
        followup_response_data = followup_response.json()
    except ValueError:
        followup_response_data = {}

    assert (
        followup_response.status_code == 200
    ), f"Failed to retrieve updated pet: {followup_response_data}"

    context.followup_request = followup_response
    context.followup_response = followup_response_data


@then(
    "the follow-up output should reflect the updated name for that pet, and the pet's identifier should remain the same as in the seed output for MR20."
)
def _mr_MR20_followup_output(context):
    followup_name = context.followup_response.get("name")
    followup_id = context.followup_response.get("id")
    seed_id = context.seed_response.get("id")

    assert (
        followup_name == "doggie_updated"
    ), f"Expected name 'doggie_updated', but got {followup_name}"
    assert followup_id == seed_id, f"Expected id {seed_id}, but got {followup_id}"
