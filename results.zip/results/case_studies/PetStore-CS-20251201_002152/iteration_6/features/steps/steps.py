from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that retrieves pets by a specific tag value in the query, producing a seed output with a list of pets associated with that tag for MR21, assuming no pets are added, removed, or modified between calls.')
def step_mr_MR21_seed_input(context):
    # Define the tag to filter by (must be a string)
    tag = "dog"

    url = f"{BASE_URL}/pet/findByTags"
    params = {"tags": tag}

    response = requests.get(url, params=params, timeout=10)
    status_code = getattr(response, "status_code", None)
    if status_code != 200:
        raise AssertionError(
            f"Failed to retrieve pets by tag: {status_code} - {getattr(response, 'text', '')}"
        )

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Response is not valid JSON: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"Expected a list of pets, got: {type(data).__name__}")

    context.seed_request = response
    context.seed_response = data
    context.seed_tag = tag


@when('a follow-up input is created by adding an additional, distinct tag value to the same query and retrieving pets again, yielding a follow-up output for MR21.')
def step_mr_MR21_followup_input(context):
    # Define an additional tag to filter by
    additional_tag = "cat"

    # Persist additional_tag on context for later checks
    context.additional_tag = additional_tag

    base_tag = getattr(context, "seed_tag", None)
    if not isinstance(base_tag, str):
        raise AssertionError("seed_tag is not set or not a string in context")

    url = f"{BASE_URL}/pet/findByTags"
    # Per OpenAPI, 'tags' is an array, explode=true; using list so requests encodes correctly
    params = [("tags", base_tag), ("tags", additional_tag)]

    response = requests.get(url, params=params, timeout=10)
    status_code = getattr(response, "status_code", None)
    if status_code != 200:
        raise AssertionError(
            f"Failed to retrieve pets by tags: {status_code} - {getattr(response, 'text', '')}"
        )

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response is not valid JSON: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"Expected a list of pets in follow-up, got: {type(data).__name__}")

    context.followup_request = response
    context.followup_response = data


@then('the follow-up output should be a superset of the seed output, containing all pets from the seed output (since they still match the original tag filter) plus any additional pets that match either of the specified tag values for MR21, assuming the underlying pet data remains unchanged.')
def step_mr_MR21_followup_output(context):
    seed_response = getattr(context, "seed_response", None)
    followup_response = getattr(context, "followup_response", None)
    additional_tag = getattr(context, "additional_tag", None)

    if not isinstance(seed_response, list):
        raise AssertionError("seed_response is not set or not a list")
    if not isinstance(followup_response, list):
        raise AssertionError("followup_response is not set or not a list")
    if not isinstance(additional_tag, str):
        raise AssertionError("additional_tag is not set or not a string")

    # Safely extract IDs, skipping pets without numeric IDs
    seed_ids = set()
    for pet in seed_response:
        if isinstance(pet, dict) and "id" in pet:
            seed_ids.add(pet["id"])

    followup_ids = set()
    for pet in followup_response:
        if isinstance(pet, dict) and "id" in pet:
            followup_ids.add(pet["id"])

    if not seed_ids.issubset(followup_ids):
        raise AssertionError("Follow-up output is not a superset of seed output.")

    # Optional: verify there is at least one pet with the additional tag in the follow-up response
    additional_tag_pets = []
    for pet in followup_response:
        if not isinstance(pet, dict):
            continue
        tags = pet.get("tags", [])
        if not isinstance(tags, list):
            continue
        tag_names = [
            t.get("name")
            for t in tags
            if isinstance(t, dict) and "name" in t
        ]
        if additional_tag in tag_names:
            additional_tag_pets.append(pet)

    if not additional_tag_pets:
        raise AssertionError("No additional pets found with the additional tag in follow-up response.")

# ----




@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current name and identifier for MR22.")
def step_mr_MR22_seed_input(context):
    # Create a pet to ensure it exists (addPet: POST /pet)
    pet_data = {
        "id": 1,
        "name": "Fluffy",
        "photoUrls": ["http://example.com/photo1.jpg"],
        "status": "available"
    }
    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    try:
        response_body = response.json()
    except ValueError:
        response_body = {}

    assert response.status_code == 200, f"Failed to create pet: {response.status_code}, body={response_body}"

    context.seed_request = response
    context.seed_response = response_body

    # Retrieve the pet by ID (getPetById: GET /pet/\{petId\}) to align with the MR wording
    pet_id = context.seed_response.get("id")
    assert pet_id is not None, f"Seed response missing 'id': {context.seed_response}"

    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    try:
        get_body = get_response.json()
    except ValueError:
        get_body = {}

    assert get_response.status_code == 200, (
        f"Failed to retrieve pet by id: {get_response.status_code}, body={get_body}"
    )
    assert isinstance(get_body, dict), f"Expected dict body from GET /pet/{{petId}}, got: {type(get_body)}"

    context.seed_get_request = get_response
    context.seed_get_response = get_body

    # Ensure the seed has name and id as per MR
    assert "id" in context.seed_get_response, f"'id' not in seed_get_response: {context.seed_get_response}"
    assert "name" in context.seed_get_response, f"'name' not in seed_get_response: {context.seed_get_response}"


@when("a follow-up input is created by updating the pet's name while keeping the same identifier via an appropriate update operation, and then retrieving the same pet by that identifier again, yielding a follow-up output for MR22.")
def step_mr_MR22_followup_input(context):
    # Use updatePet: PUT /pet (update an existing pet by Id)
    seed_pet = getattr(context, "seed_get_response", None)
    assert isinstance(seed_pet, dict), f"seed_get_response is not a dict: {seed_pet}"

    pet_id = seed_pet.get("id")
    assert pet_id is not None, f"Seed pet missing 'id': {seed_pet}"

    updated_name = "FluffyUpdated"

    # Preserve existing fields where available to avoid schema issues
    updated_pet_data = {
        "id": pet_id,
        "name": updated_name,
        "photoUrls": seed_pet.get("photoUrls") or ["http://example.com/photo1.jpg"],
        "status": seed_pet.get("status") or "available",
    }
    if "category" in seed_pet:
        updated_pet_data["category"] = seed_pet["category"]
    if "tags" in seed_pet:
        updated_pet_data["tags"] = seed_pet["tags"]

    update_response = requests.put(f"{BASE_URL}/pet", json=updated_pet_data, timeout=10)
    try:
        update_body = update_response.json()
    except ValueError:
        update_body = {}

    assert update_response.status_code == 200, (
        f"Failed to update pet: {update_response.status_code}, body={update_body}"
    )

    context.update_request = update_response
    context.update_response = update_body

    # Retrieve the updated pet by ID (getPetById: GET /pet/\{petId\})
    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    try:
        get_body = get_response.json()
    except ValueError:
        get_body = {}

    assert get_response.status_code == 200, (
        f"Failed to retrieve updated pet: {get_response.status_code}, body={get_body}"
    )
    assert isinstance(get_body, dict), f"Expected dict body from GET /pet/{{petId}}, got: {type(get_body)}"

    context.followup_request = get_response
    context.followup_response = get_body
    context.updated_name = updated_name


@then("the follow-up output should reflect the updated name for that pet, and the pet's identifier should remain the same as in the seed output for MR22, assuming the update operation was successful.")
def step_mr_MR22_followup_output(context):
    followup = getattr(context, "followup_response", None)
    seed_pet = getattr(context, "seed_get_response", None)
    updated_name = getattr(context, "updated_name", None)

    assert isinstance(followup, dict), f"followup_response is not a dict: {followup}"
    assert isinstance(seed_pet, dict), f"seed_get_response is not a dict: {seed_pet}"
    assert updated_name is not None, "updated_name not set in context"

    assert "name" in followup, f"'name' not in followup_response: {followup}"
    assert "id" in followup, f"'id' not in followup_response: {followup}"
    assert "id" in seed_pet, f"'id' not in seed_get_response: {seed_pet}"

    assert followup["name"] == updated_name, (
        f"Expected name '{updated_name}', but got '{followup['name']}'"
    )
    assert followup["id"] == seed_pet["id"], (
        f"Expected id '{seed_pet['id']}', but got '{followup['id']}'"
    )
