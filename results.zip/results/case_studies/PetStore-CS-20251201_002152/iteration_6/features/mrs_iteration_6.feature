Feature: Iteration 6 MRs

  Scenario: Finding pets by tags should return a superset when additional tags are included
    Given a seed input that retrieves pets by a specific tag value in the query, producing a seed output with a list of pets associated with that tag for MR21, assuming no pets are added, removed, or modified between calls.
    When a follow-up input is created by adding an additional, distinct tag value to the same query and retrieving pets again, yielding a follow-up output for MR21.
    Then the follow-up output should be a superset of the seed output, containing all pets from the seed output (since they still match the original tag filter) plus any additional pets that match either of the specified tag values for MR21, assuming the underlying pet data remains unchanged.

  Scenario: Updating a pet's name should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current name and identifier for MR22.
    When a follow-up input is created by updating the pet's name while keeping the same identifier via an appropriate update operation, and then retrieving the same pet by that identifier again, yielding a follow-up output for MR22.
    Then the follow-up output should reflect the updated name for that pet, and the pet's identifier should remain the same as in the seed output for MR22, assuming the update operation was successful.
