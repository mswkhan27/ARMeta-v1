Feature: Iteration 8 MRs

  Scenario: Adding a new pet with a specific ID should allow retrieval of that pet by the same ID
    Given a seed input that adds a new pet with a specific ID using the pet-creation operation, producing a seed output indicating successful creation for MR25.
    When a follow-up input is created by retrieving the pet using the same ID with the pet-retrieval-by-identifier operation, yielding a follow-up output for MR25.
    Then the follow-up output should return the pet details matching the ID used in the seed input, confirming the pet's existence and details as in the seed output for MR25.

  Scenario: Updating a pet's status should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier using the pet-retrieval-by-identifier operation, producing a seed output with the pet's current status for MR26.
    When a follow-up input is created by updating the pet's status using the pet-update-with-form-data operation and then retrieving the same pet by the same identifier again using the pet-retrieval-by-identifier operation, yielding a follow-up output for MR26.
    Then the follow-up output should reflect the updated status for that pet, and the pet's identifier should remain the same as in the seed output for MR26.

  Scenario: Adding a new pet should not affect the retrieval of existing pets
    Given a seed input that retrieves a list of existing pets using a pet-search operation (for example, filtered by a specific status), producing a seed output with their details for MR27.
    When a follow-up input is created by adding a new pet using the pet-creation operation and then retrieving the list of pets again using the same search criteria with the pet-search operation, yielding a follow-up output for MR27.
    Then the follow-up output should include all pets from the seed output, and any existing pet details should remain unchanged; additionally, if the newly added pet matches the search criteria, it should appear in the follow-up output for MR27.

  Scenario: Updating a pet's name should reflect in subsequent retrieval of that pet
    Given a seed input that retrieves a pet by its identifier using the pet-retrieval-by-identifier operation, producing a seed output with the pet's current name for MR29.
    When a follow-up input is created by updating the pet's name using the pet-update-with-form-data operation and then retrieving the same pet by that identifier again using the pet-retrieval-by-identifier operation, yielding a follow-up output for MR29.
    Then the follow-up output should reflect the updated name for that pet, and the pet's identifier should remain the same as in the seed output for MR29.
