from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that adds a new pet with a specific ID using the pet-creation operation, producing a seed output indicating successful creation for MR25.')
def _mr_MR25_create_pet(context):
    pet_data = {
        "id": 25,
        "name": "doggie",
        "photoUrls": ["http://example.com/photo1.jpg"],
        "status": "available"
    }
    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)

    # Ensure we have a JSON-decoding-safe flow
    try:
        response_json = response.json()
    except ValueError:
        response_json = None

    context.seed_request = response
    context.seed_response = response_json

    assert response.status_code == 200, f"Failed to create pet: status={response.status_code}, body={response.text}"

    # Ensure the response is a dict and contains an 'id'
    assert isinstance(response_json, dict), f"Unexpected response type for seed_response: {type(response_json)}"
    assert 'id' in response_json, f"'id' not found in seed_response: {response_json}"


@when('a follow-up input is created by retrieving the pet using the same ID with the pet-retrieval-by-identifier operation, yielding a follow-up output for MR25.')
def _mr_MR25_retrieve_pet(context):
    # Safely obtain pet_id from the seed_response
    seed_response = getattr(context, 'seed_response', None)
    assert isinstance(seed_response, dict), f"seed_response is not a dict or not set: {seed_response}"

    pet_id = seed_response.get('id')
    assert pet_id is not None, f"seed_response does not contain 'id': {seed_response}"

    # According to the OpenAPI spec, petId is int64; ensure it's an integer to avoid TypeError
    try:
        pet_id_int = int(pet_id)
    except (TypeError, ValueError) as e:
        raise AssertionError(f"Invalid pet id value in seed_response ('id'={pet_id}): {e}")

    response = requests.get(f"{BASE_URL}/pet/{pet_id_int}", timeout=10)

    try:
        response_json = response.json()
    except ValueError:
        response_json = None

    context.followup_request = response
    context.followup_response = response_json

    assert response.status_code == 200, f"Failed to retrieve pet: status={response.status_code}, body={response.text}"
    assert isinstance(response_json, dict), f"Unexpected response type for followup_response: {type(response_json)}"


@then("the follow-up output should return the pet details matching the ID used in the seed input, confirming the pet's existence and details as in the seed output for MR25.")
def _mr_MR25_verify_pet(context):
    seed_response = getattr(context, 'seed_response', None)
    followup_response = getattr(context, 'followup_response', None)

    assert isinstance(seed_response, dict), f"seed_response is not a dict or not set: {seed_response}"
    assert isinstance(followup_response, dict), f"followup_response is not a dict or not set: {followup_response}"

    for key in ['id', 'name', 'status']:
        assert key in seed_response, f"Key '{key}' missing from seed_response: {seed_response}"
        assert key in followup_response, f"Key '{key}' missing from followup_response: {followup_response}"

    # Explicitly cast IDs to int to avoid type mismatch issues (e.g., '25' vs 25)
    try:
        seed_id = int(seed_response['id'])
        followup_id = int(followup_response['id'])
    except (TypeError, ValueError) as e:
        raise AssertionError(f"ID values are not valid integers: seed_id={seed_response.get('id')}, "
                             f"followup_id={followup_response.get('id')}, error={e}")

    assert followup_id == seed_id, f"Pet ID does not match: seed_id={seed_id}, followup_id={followup_id}"
    assert followup_response['name'] == seed_response['name'], (
        f"Pet name does not match: seed_name={seed_response['name']}, "
        f"followup_name={followup_response['name']}"
    )
    assert followup_response['status'] == seed_response['status'], (
        f"Pet status does not match: seed_status={seed_response['status']}, "
        f"followup_status={followup_response['status']}"
    )

# ----

from urllib.parse import urlencode

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


@given("a seed input that retrieves a pet by its identifier using the pet-retrieval-by-identifier operation, producing a seed output with the pet's current status for MR26.")
def _mr_MR26_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1"],
        "status": "available",
    }

    create_resp = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    context.seed_request = create_resp
    try:
        seed_body = create_resp.json()
    except ValueError:
        raise AssertionError(f"Create pet did not return JSON. Status: {create_resp.status_code}, Body: {create_resp.text!r}")

    if not isinstance(seed_body, dict):
        raise AssertionError(f"Create pet response JSON is not an object: {seed_body!r}")

    pet_id = seed_body.get("id")
    if pet_id is None:
        raise AssertionError(f"Create pet response JSON missing 'id': {seed_body!r}")

    context.seed_response = seed_body
    context.pet_id = pet_id

    # Retrieve the pet by ID (pet-retrieval-by-identifier: GET /pet/\{petId\})
    get_resp = requests.get(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
    context.get_request = get_resp
    try:
        get_body = get_resp.json()
    except ValueError:
        raise AssertionError(f"Get pet did not return JSON. Status: {get_resp.status_code}, Body: {get_resp.text!r}")

    if not isinstance(get_body, dict):
        raise AssertionError(f"Get pet response JSON is not an object: {get_body!r}")

    context.get_response = get_body

    if get_body.get("id") != context.seed_response.get("id"):
        raise AssertionError(f"Pet ID does not match: seed={context.seed_response.get('id')!r}, got={get_body.get('id')!r}")

    if get_body.get("status") != context.seed_response.get("status"):
        raise AssertionError(f"Pet status does not match: seed={context.seed_response.get('status')!r}, got={get_body.get('status')!r}")


@when("a follow-up input is created by updating the pet's status using the pet-update-with-form-data operation and then retrieving the same pet by the same identifier again using the pet-retrieval-by-identifier operation, yielding a follow-up output for MR26.")
def _mr_MR26_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AssertionError("pet_id not found in context from Given step")

    updated_status = "sold"

    # pet-update-with-form-data: POST /pet/\{petId\} with query params name/status
    query = urlencode({"status": updated_status})
    update_url = f"{BASE_URL}/pet/{context.pet_id}?{query}"
    update_resp = requests.post(update_url, timeout=10)
    context.update_request = update_resp

    # The spec says this returns a Pet in 200 but some implementations may not.
    try:
        update_body = update_resp.json()
    except ValueError:
        update_body = None

    context.update_response = update_body

    # Retrieve the pet again (pet-retrieval-by-identifier: GET /pet/\{petId\})
    follow_resp = requests.get(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
    context.followup_request = follow_resp
    try:
        follow_body = follow_resp.json()
    except ValueError:
        raise AssertionError(f"Follow-up get pet did not return JSON. Status: {follow_resp.status_code}, Body: {follow_resp.text!r}")

    if not isinstance(follow_body, dict):
        raise AssertionError(f"Follow-up get pet response JSON is not an object: {follow_body!r}")

    context.followup_response = follow_body

    if follow_body.get("id") != context.seed_response.get("id"):
        raise AssertionError(
            f"Pet ID does not match after update: seed={context.seed_response.get('id')!r}, followup={follow_body.get('id')!r}"
        )

    if follow_body.get("status") != updated_status:
        raise AssertionError(
            f"Pet status was not updated correctly: expected={updated_status!r}, got={follow_body.get('status')!r}"
        )


@then("the follow-up output should reflect the updated status for that pet, and the pet's identifier should remain the same as in the seed output for MR26.")
def _mr_MR26_followup_output(context):
    if not hasattr(context, "followup_response") or not hasattr(context, "seed_response"):
        raise AssertionError("Required responses not found in context for Then step")

    follow_status = context.followup_response.get("status")
    if follow_status != "sold":
        raise AssertionError(f"Follow-up output status does not reflect the updated status. Expected 'sold', got {follow_status!r}")

    follow_id = context.followup_response.get("id")
    seed_id = context.seed_response.get("id")
    if follow_id != seed_id:
        raise AssertionError(f"Pet ID has changed after update. Seed={seed_id!r}, followup={follow_id!r}")

# ----

from typing import Any, Dict, List



def _safe_get_json(response: requests.Response) -> Any:
    try:
        return response.json()
    except ValueError:
        # Response is not JSON; return raw text to avoid TypeError later
        return response.text


def _ensure_pets_list(data: Any) -> List[Dict[str, Any]]:
    """
    Normalize the pets response into a list of dicts.
    If it's not a list, return an empty list to avoid TypeError in comprehensions.
    """
    if isinstance(data, list):
        # Keep only dict-like entries
        return [p for p in data if isinstance(p, dict)]
    return []


@given('a seed input that retrieves a list of existing pets using a pet-search operation (for example, filtered by a specific status), producing a seed output with their details for MR27.')
def _mr_MR27_seed_input(context):
    # Use the pet-search operation: GET /pet/findByStatus with query parameter "status"
    params = {"status": "available"}
    response = requests.get(f"{BASE_URL}/pet/findByStatus", params=params, timeout=10)
    response.raise_for_status()

    raw_seed = _safe_get_json(response)
    context.seed_response_raw = raw_seed
    context.seed_response = _ensure_pets_list(raw_seed)
    context.seed_request = params


@when('a follow-up input is created by adding a new pet using the pet-creation operation and then retrieving the list of pets again using the same search criteria with the pet-search operation, yielding a follow-up output for MR27.')
def _mr_MR27_followup_input(context):
    # Create a new pet using POST /pet (pet-creation operation: addPet)
    new_pet = {
        "name": "NewDog",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }
    create_response = requests.post(
        f"{BASE_URL}/pet",
        json=new_pet,
        timeout=10,
    )
    create_response.raise_for_status()

    create_body = _safe_get_json(create_response)
    context.created_pet = create_body if isinstance(create_body, dict) else {}

    # Retrieve the list of pets again using the same search criteria: GET /pet/findByStatus
    params = dict(getattr(context, "seed_request", {"status": "available"}))
    followup_response = requests.get(f"{BASE_URL}/pet/findByStatus", params=params, timeout=10)
    followup_response.raise_for_status()

    raw_followup = _safe_get_json(followup_response)
    context.followup_response_raw = raw_followup
    context.followup_response = _ensure_pets_list(raw_followup)
    context.followup_request = params


@then('the follow-up output should include all pets from the seed output, and any existing pet details should remain unchanged; additionally, if the newly added pet matches the search criteria, it should appear in the follow-up output for MR27.')
def _mr_MR27_followup_output(context):
    # Work only with normalized lists to avoid TypeError
    seed_pets = _ensure_pets_list(getattr(context, "seed_response", []))
    followup_pets = _ensure_pets_list(getattr(context, "followup_response", []))

    # Build dictionaries keyed by id where possible, safely handling missing/invalid ids
    def pets_by_id(pets: List[Dict[str, Any]]) -> Dict[Any, Dict[str, Any]]:
        result: Dict[Any, Dict[str, Any]] = {}
        for pet in pets:
            pet_id = pet.get("id")
            if pet_id is not None:
                result[pet_id] = pet
        return result

    seed_by_id = pets_by_id(seed_pets)
    followup_by_id = pets_by_id(followup_pets)

    # Check that all seed pets are still present in follow-up output
    missing_ids = [pid for pid in seed_by_id.keys() if pid not in followup_by_id]
    assert not missing_ids, f"Not all seed pets are present in follow-up output. Missing IDs: {missing_ids}"

    # Check that existing pet details (at least name and status) remain unchanged where those fields exist
    for pid, seed_pet in seed_by_id.items():
        followup_pet = followup_by_id.get(pid)
        assert followup_pet is not None, f"Pet with ID {pid} is missing in follow-up output."

        # Only compare fields that are present in both seed and follow-up to avoid KeyError/TypeError
        for field in ("name", "status"):
            if field in seed_pet and field in followup_pet:
                assert followup_pet[field] == seed_pet[field], (
                    f"Pet {field} changed for ID {pid}: "
                    f"seed={seed_pet[field]!r}, followup={followup_pet[field]!r}"
                )

    # If the newly added pet matches the search criteria ("available"), it should be in the follow-up output
    created_pet = getattr(context, "created_pet", {})
    created_name = created_pet.get("name")
    created_status = created_pet.get("status")

    if created_status == "available":
        # Find pets in follow-up with the created name (and id if available)
        created_id = created_pet.get("id")
        matching = []
        for pet in followup_pets:
            if not isinstance(pet, dict):
                continue
            if pet.get("name") != created_name:
                continue
            if created_id is not None and pet.get("id") != created_id:
                continue
            matching.append(pet)

        assert matching, (
            "The newly added pet that matches the search criteria is not present in the follow-up output."
        )

# ----




@given("a seed input that retrieves a pet by its identifier using the pet-retrieval-by-identifier operation, producing a seed output with the pet's current name for MR29.")
def _mr_MR29_seed_input(context):
    # Safely create a pet to ensure it exists, then retrieve it by ID (pet-retrieval-by-identifier)
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"]
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    response.raise_for_status()

    seed_created = response.json()
    if not isinstance(seed_created, dict):
        raise TypeError(f"Expected JSON object when creating pet, got: {type(seed_created)}")

    pet_id = seed_created.get("id")
    if pet_id is None:
        raise ValueError("Created pet has no 'id' field in response")

    # Retrieve by identifier using pet-retrieval-by-identifier operation: GET /pet/{petId}
    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    get_response.raise_for_status()

    seed_retrieved = get_response.json()
    if not isinstance(seed_retrieved, dict):
        raise TypeError(f"Expected JSON object when retrieving pet, got: {type(seed_retrieved)}")

    if "name" not in seed_retrieved:
        raise ValueError("Retrieved pet has no 'name' field in response")

    context.seed_request = pet_data
    context.seed_created = seed_created
    context.seed_response = seed_retrieved
    context.pet_id = pet_id


@when("a follow-up input is created by updating the pet's name using the pet-update-with-form-data operation and then retrieving the same pet by that identifier again using the pet-retrieval-by-identifier operation, yielding a follow-up output for MR29.")
def _mr_MR29_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AttributeError("Context is missing 'pet_id' from Given step")
    if not hasattr(context, "seed_response"):
        raise AttributeError("Context is missing 'seed_response' from Given step")

    pet_id = context.pet_id

    # Update the pet's name using pet-update-with-form-data: POST /pet/{petId} with query params
    updated_name = "doggie_updated"
    update_params = {"name": updated_name}

    update_response = requests.post(f"{BASE_URL}/pet/{pet_id}", params=update_params, timeout=10)
    update_response.raise_for_status()

    # Retrieve the updated pet again using pet-retrieval-by-identifier: GET /pet/{petId}
    followup_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    followup_response.raise_for_status()

    followup_json = followup_response.json()
    if not isinstance(followup_json, dict):
        raise TypeError(f"Expected JSON object when retrieving updated pet, got: {type(followup_json)}")

    if "name" not in followup_json:
        raise ValueError("Updated pet retrieval has no 'name' field in response")
    if "id" not in followup_json:
        raise ValueError("Updated pet retrieval has no 'id' field in response")

    context.followup_request = {"name": updated_name}
    context.followup_response = followup_json


@then("the follow-up output should reflect the updated name for that pet, and the pet's identifier should remain the same as in the seed output for MR29.")
def _mr_MR29_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AttributeError("Context is missing 'followup_response' from When step")
    if not hasattr(context, "followup_request"):
        raise AttributeError("Context is missing 'followup_request' from When step")
    if not hasattr(context, "seed_response"):
        raise AttributeError("Context is missing 'seed_response' from Given step")

    followup = context.followup_response
    followup_name = followup.get("name")
    followup_id = followup.get("id")

    if followup_name is None:
        raise ValueError("Follow-up response is missing 'name'")
    if followup_id is None:
        raise ValueError("Follow-up response is missing 'id'")

    expected_name = context.followup_request.get("name")
    if expected_name is None:
        raise ValueError("Follow-up request is missing 'name'")

    seed_id = context.seed_response.get("id")
    if seed_id is None:
        raise ValueError("Seed response is missing 'id'")

    assert followup_name == expected_name, "The pet's name was not updated correctly."
    assert followup_id == seed_id, "The pet's identifier has changed."
