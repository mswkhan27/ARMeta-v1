Feature: Iteration 0 MRs

  Scenario: MR1 Adding a role to a user should include the new role in the user's role list
    Given a seed input that retrieves a user's details, including the current set of roles, producing a seed output with the user's roles for MR1.
    When a follow-up input is created by invoking an operation that adds a new role to the same user and then retrieving the user's details again, yielding a follow-up output for MR1.
    Then the follow-up output should include all roles from the seed output plus the newly added role for MR1, with no previously existing role removed.

  Scenario: MR2 Removing a role from a user should exclude the role from the user's role list
    Given a seed input that retrieves a user's details, including the current set of roles, producing a seed output with the user's roles for MR2.
    When a follow-up input is created by invoking an operation that removes one existing role from the same user and then retrieving the user's details again, yielding a follow-up output for MR2.
    Then the follow-up output should contain all roles from the seed output except the removed role for MR2; the removed role must no longer appear in the user's role list.

  Scenario: MR3 Updating user information should primarily affect the updated fields
    Given a seed input that retrieves a user's current information, producing a seed output with the user's details for MR3.
    When a follow-up input is created by invoking an operation that updates one field in the user's information and then retrieving the user's details again, yielding a follow-up output for MR3.
    Then the follow-up output should reflect a change in the explicitly updated field for MR3, while other business data fields that were not updated should remain identical to the seed output; only server-managed metadata (such as timestamps or audit fields) may differ.

  Scenario: MR4 Creating a new user should increase the total user count
    Given a seed input that retrieves the current list of users, producing a seed output with the total user count for MR4.
    When a follow-up input is created by creating a new user and then retrieving the list of users again, yielding a follow-up output for MR4.
    Then the follow-up output should have a user count that is exactly one more than the seed output for MR4, assuming no other user-creation or deletion operations occur between the two retrievals.

  Scenario: MR5 Deleting a user should decrease the total user count
    Given a seed input that retrieves the current list of users, producing a seed output with the total user count for MR5.
    When a follow-up input is created by deleting an existing user and then retrieving the list of users again, yielding a follow-up output for MR5.
    Then the follow-up output should have a user count that is exactly one less than the seed output for MR5, assuming no other user-creation or deletion operations occur between the two retrievals.
