from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given("a seed input that retrieves a user's details, including the current set of roles, producing a seed output with the user's roles for MR1.")
def _mr_MR1_seed_input(context):
    # Create a user for testing (minimal, valid CreateOrUpdateUserDTO)
    user_data = {
        "username": "testuser_mr1",
        "password": "testpass",
        "name": "Test",
        "surname": "User",
        "email": "testuser_mr1@example.com",
        "enabled": True,
        "secured": False
    }

    response = requests.post(
        f"{BASE_URL}/users",
        json=user_data,
        timeout=10
    )
    response.raise_for_status()

    try:
        created_user = response.json()
    except ValueError:
        raise AssertionError("Response from /users POST is not valid JSON")

    if not isinstance(created_user, dict):
        raise AssertionError("Created user response is not a JSON object")

    user_id = created_user.get('id')
    if user_id is None:
        raise AssertionError("Created user response does not contain 'id'")

    context.user_id = user_id

    # Retrieve the user's details (getUserById)
    response = requests.get(
        f"{BASE_URL}/users/{context.user_id}",
        timeout=10
    )
    response.raise_for_status()

    try:
        user_details = response.json()
    except ValueError:
        raise AssertionError("Response from /users/{id} GET is not valid JSON")

    if not isinstance(user_details, dict):
        raise AssertionError("User details response is not a JSON object")

    context.seed_response = user_details


@when("a follow-up input is created by invoking an operation that adds a new role to the same user and then retrieving the user's details again, yielding a follow-up output for MR1.")
def _mr_MR1_followup_input(context):
    # Create a new role (createRole)
    role_name = "MR1_NEW_ROLE"
    response = requests.post(
        f"{BASE_URL}/users/rbac/roles",
        json=role_name,
        timeout=10
    )
    response.raise_for_status()

    try:
        role_response = response.json()
    except ValueError:
        raise AssertionError("Response from /users/rbac/roles POST is not valid JSON")

    if not isinstance(role_response, dict):
        raise AssertionError("Role creation response is not a JSON object")

    role_id = role_response.get('id')
    role_string = role_response.get('role')

    if role_id is None:
        raise AssertionError("Role creation response does not contain 'id'")
    if not isinstance(role_string, str):
        raise AssertionError("Role creation response does not contain a valid 'role' string")

    context.role_id = role_id
    context.role_string = role_string

    # Add the role to the user (addRole)
    response = requests.post(
        f"{BASE_URL}/users/{context.user_id}/roles/{context.role_id}",
        timeout=10
    )
    response.raise_for_status()

    # Retrieve the user's details again (getUserById)
    response = requests.get(
        f"{BASE_URL}/users/{context.user_id}",
        timeout=10
    )
    response.raise_for_status()

    try:
        followup_user_details = response.json()
    except ValueError:
        raise AssertionError("Response from /users/{id} GET (follow-up) is not valid JSON")

    if not isinstance(followup_user_details, dict):
        raise AssertionError("Follow-up user details response is not a JSON object")

    context.followup_response = followup_user_details


@then("the follow-up output should include all roles from the seed output plus the newly added role for MR1, with no previously existing role removed.")
def _mr_MR1_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response is missing from context")
    if not hasattr(context, "followup_response"):
        raise AssertionError("followup_response is missing from context")
    if not hasattr(context, "role_string"):
        raise AssertionError("role_string is missing from context")

    seed_roles_raw = context.seed_response.get('roles', [])
    followup_roles_raw = context.followup_response.get('roles', [])

    if seed_roles_raw is None:
        seed_roles_raw = []
    if followup_roles_raw is None:
        followup_roles_raw = []

    if not isinstance(seed_roles_raw, list):
        raise AssertionError("Seed 'roles' field is not a list")
    if not isinstance(followup_roles_raw, list):
        raise AssertionError("Follow-up 'roles' field is not a list")

    # Convert to sets of strings safely
    seed_roles = {str(r) for r in seed_roles_raw}
    followup_roles = {str(r) for r in followup_roles_raw}

    # The API returns roles as strings (UserDTO.roles: array of string)
    new_role = str(context.role_string)

    if new_role not in followup_roles:
        raise AssertionError("New role was not added to the user's roles list")

    if not seed_roles.issubset(followup_roles):
        raise AssertionError("Some existing roles were removed from the user's roles list")

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


def safe_get_json(response):
    try:
        return response.json()
    except ValueError:
        return {}


@given("a seed input that retrieves a user's details, including the current set of roles, producing a seed output with the user's roles for MR2.")
def step_mr_MR2_seed_input(context):
    try:
        # 1. Create a user for testing
        user_data = {
            "username": "testuser_mr2",
            "password": "password",
            "name": "Test",
            "surname": "User",
            "email": "testuser_mr2@example.com",
        }
        create_user_resp = requests.post(f"{BASE_URL}/users", json=user_data, timeout=10)
        create_user_resp.raise_for_status()
        created_user = safe_get_json(create_user_resp)

        user_id = created_user.get("id")
        if user_id is None:
            raise RuntimeError("Created user response does not contain 'id'")

        context.user_id = user_id

        # 2. Ensure at least one role exists (create role "MR2_ROLE" if needed)
        roles_resp = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
        roles_resp.raise_for_status()
        roles_list = safe_get_json(roles_resp)
        if not isinstance(roles_list, list):
            raise RuntimeError("Roles list response is not a list")

        mr2_role = None
        for role in roles_list:
            if isinstance(role, dict) and role.get("role") == "MR2_ROLE":
                mr2_role = role
                break

        if mr2_role is None:
            create_role_resp = requests.post(
                f"{BASE_URL}/users/rbac/roles",
                json="MR2_ROLE",
                timeout=10,
            )
            create_role_resp.raise_for_status()
            mr2_role = safe_get_json(create_role_resp)

        role_id = mr2_role.get("id")
        if role_id is None:
            raise RuntimeError("Role response does not contain 'id'")

        context.role_id_to_remove = role_id

        # 3. Assign the role to the user so it appears in the user's role list
        add_role_resp = requests.post(
            f"{BASE_URL}/users/{context.user_id}/roles/{context.role_id_to_remove}",
            timeout=10,
        )
        add_role_resp.raise_for_status()

        # 4. Retrieve the user's details (seed output)
        user_details_resp = requests.get(
            f"{BASE_URL}/users/{context.user_id}", timeout=10
        )
        user_details_resp.raise_for_status()
        context.seed_response = safe_get_json(user_details_resp)
        context.seed_request = user_data
    except Exception as e:
        print(f"Error in Given step for MR2: {e}")
        raise


@when("a follow-up input is created by invoking an operation that removes one existing role from the same user and then retrieving the user's details again, yielding a follow-up output for MR2.")
def step_mr_MR2_followup_input(context):
    try:
        if not hasattr(context, "user_id") or not hasattr(context, "role_id_to_remove"):
            raise RuntimeError("Context is missing user_id or role_id_to_remove")

        # Remove the role from the user
        remove_role_resp = requests.delete(
            f"{BASE_URL}/users/{context.user_id}/roles/{context.role_id_to_remove}",
            timeout=10,
        )
        remove_role_resp.raise_for_status()

        # Retrieve the user's details again (follow-up output)
        followup_resp = requests.get(
            f"{BASE_URL}/users/{context.user_id}", timeout=10
        )
        followup_resp.raise_for_status()
        context.followup_response = safe_get_json(followup_resp)
    except Exception as e:
        print(f"Error in When step for MR2: {e}")
        raise


@then("the follow-up output should contain all roles from the seed output except the removed role for MR2; the removed role must no longer appear in the user's role list.")
def step_mr_MR2_followup_output(context):
    try:
        if not hasattr(context, "seed_response") or not hasattr(
            context, "followup_response"
        ):
            raise RuntimeError("Context is missing seed_response or followup_response")

        seed_roles = context.seed_response.get("roles") or []
        followup_roles = context.followup_response.get("roles") or []

        if not isinstance(seed_roles, list) or not isinstance(followup_roles, list):
            raise RuntimeError("Roles fields are not lists in responses")

        seed_roles_set = set(seed_roles)
        followup_roles_set = set(followup_roles)

        removed_roles = seed_roles_set - followup_roles_set

        # There must be at least one removed role
        assert removed_roles, "No role was removed between seed and follow-up outputs."

        # All follow-up roles must be a subset of seed roles
        assert followup_roles_set.issubset(
            seed_roles_set
        ), "Follow-up roles contain roles not present in the seed output."

    except AssertionError as e:
        print(f"Assertion error in Then step for MR2: {e}")
        raise
    except Exception as e:
        print(f"Error in Then step for MR2: {e}")
        raise

# ----




def _safe_json(response):
    try:
        return response.json()
    except ValueError:
        return None


@given("a seed input that retrieves a user's current information, producing a seed output with the user's details for MR3.")
def step_mr_MR3_seed_input(context):
    # Prepare a valid CreateOrUpdateUserDTO payload
    user_data = {
        "username": "testuser_mr3",
        "password": "password123",
        "name": "Test",
        "surname": "User",
        "email": "testuser_mr3@example.com",
        "gender": "male",
        "enabled": True,
        "secured": False,
    }

    # Create a user (POST /users)
    create_resp = requests.post(f"{BASE_URL}/users", json=user_data, timeout=10)
    create_body = _safe_json(create_resp)
    context.create_user_response = create_resp
    context.create_user_body = create_body

    assert 200 <= create_resp.status_code < 300, (
        f"Failed to create user, status={create_resp.status_code}, body={create_resp.text}"
    )
    assert isinstance(create_body, dict), "Create user response is not a JSON object"
    assert "id" in create_body, "Create user response missing 'id' field"

    user_id = create_body["id"]
    context.user_id = user_id

    # Retrieve the created user's information (GET /users/{id})
    get_resp = requests.get(f"{BASE_URL}/users/{user_id}", timeout=10)
    get_body = _safe_json(get_resp)
    context.seed_request = get_resp
    context.seed_response = get_body

    assert get_resp.status_code == 200, (
        f"Failed to retrieve user, status={get_resp.status_code}, body={get_resp.text}"
    )
    assert isinstance(get_body, dict), "Seed user response is not a JSON object"


@when("a follow-up input is created by invoking an operation that updates one field in the user's information and then retrieving the user's details again, yielding a follow-up output for MR3.")
def step_mr_MR3_followup_input(context):
    assert hasattr(context, "user_id"), "Context missing user_id from Given step"
    assert isinstance(context.seed_response, dict), "Seed response not available or invalid"

    user_id = context.user_id
    seed = context.seed_response

    # Build a full update payload based on CreateOrUpdateUserDTO using seed response
    update_payload = {
        "username": seed.get("username"),
        "password": "password123",  # required by DTO, keep same to avoid unwanted changes
        "name": seed.get("name"),
        "surname": seed.get("surname"),
        "email": "updateduser_mr3@example.com",  # the only business field we intend to change
        "gender": seed.get("gender"),
        "enabled": seed.get("enabled"),
        "secured": seed.get("secured"),
        "address": seed.get("addressDTO", {}).get("address") if isinstance(seed.get("addressDTO"), dict) else None,
        "address2": seed.get("addressDTO", {}).get("address2") if isinstance(seed.get("addressDTO"), dict) else None,
        "city": seed.get("addressDTO", {}).get("city") if isinstance(seed.get("addressDTO"), dict) else None,
        "country": seed.get("addressDTO", {}).get("country") if isinstance(seed.get("addressDTO"), dict) else None,
        "zipCode": seed.get("addressDTO", {}).get("zipCode") if isinstance(seed.get("addressDTO"), dict) else None,
        "contactNote": seed.get("contactDTO", {}).get("contactNote") if isinstance(seed.get("contactDTO"), dict) else None,
        "facebook": seed.get("contactDTO", {}).get("facebook") if isinstance(seed.get("contactDTO"), dict) else None,
        "linkedin": seed.get("contactDTO", {}).get("linkedin") if isinstance(seed.get("contactDTO"), dict) else None,
        "phone": seed.get("contactDTO", {}).get("phone") if isinstance(seed.get("contactDTO"), dict) else None,
        "skype": seed.get("contactDTO", {}).get("skype") if isinstance(seed.get("contactDTO"), dict) else None,
        "website": seed.get("contactDTO", {}).get("website") if isinstance(seed.get("contactDTO"), dict) else None,
        "note": seed.get("note"),
        "birthDate": seed.get("birthDate"),
    }

    # Remove keys with value None to avoid potential validation issues
    update_payload = {k: v for k, v in update_payload.items() if v is not None}

    # Update user (PUT /users/{id})
    put_resp = requests.put(f"{BASE_URL}/users/{user_id}", json=update_payload, timeout=10)
    context.update_user_response = put_resp
    assert 200 <= put_resp.status_code < 300, (
        f"Failed to update user, status={put_resp.status_code}, body={put_resp.text}"
    )

    # Retrieve the updated user's information
    follow_resp = requests.get(f"{BASE_URL}/users/{user_id}", timeout=10)
    follow_body = _safe_json(follow_resp)
    context.followup_request = follow_resp
    context.followup_response = follow_body

    assert follow_resp.status_code == 200, (
        f"Failed to retrieve updated user, status={follow_resp.status_code}, body={follow_resp.text}"
    )
    assert isinstance(follow_body, dict), "Follow-up user response is not a JSON object"


@then("the follow-up output should reflect a change in the explicitly updated field for MR3, while other business data fields that were not updated should remain identical to the seed output; only server-managed metadata (such as timestamps or audit fields) may differ.")
def step_mr_MR3_followup_output(context):
    seed = context.seed_response
    follow = context.followup_response

    assert isinstance(seed, dict), "Seed response is not a JSON object"
    assert isinstance(follow, dict), "Follow-up response is not a JSON object"

    # Updated field must change
    assert follow.get("email") == "updateduser_mr3@example.com", (
        f"Email was not updated correctly. Expected 'updateduser_mr3@example.com', got '{follow.get('email')}'"
    )

    # Fields that should remain unchanged (business data)
    for field in ["username", "name", "surname", "gender", "note", "enabled", "secured", "birthDate"]:
        if field in seed:
            assert seed.get(field) == follow.get(field), (
                f"Field '{field}' should remain unchanged. "
                f"Seed='{seed.get(field)}', Follow-up='{follow.get(field)}'"
            )

    # Nested addressDTO and contactDTO: compare element-wise where present
    def compare_nested(obj_name, keys):
        seed_obj = seed.get(obj_name) if isinstance(seed.get(obj_name), dict) else {}
        follow_obj = follow.get(obj_name) if isinstance(follow.get(obj_name), dict) else {}
        for k in keys:
            if k in seed_obj:
                assert seed_obj.get(k) == follow_obj.get(k), (
                    f"Field '{obj_name}.{k}' should remain unchanged. "
                    f"Seed='{seed_obj.get(k)}', Follow-up='{follow_obj.get(k)}'"
                )

    compare_nested("addressDTO", ["address", "address2", "city", "country", "zipCode"])
    compare_nested(
        "contactDTO",
        ["contactNote", "email", "facebook", "linkedin", "phone", "skype", "website"],
    )

    # Server-managed metadata may differ; we just ensure they exist when present in seed
    for meta in ["creationDt", "updatedDt", "loginDt"]:
        if meta in seed and seed.get(meta) is not None:
            assert meta in follow, f"Follow-up response missing metadata field '{meta}'"

# ----

import time



@given('a seed input that retrieves the current list of users, producing a seed output with the total user count for MR4.')
def step_mr_MR4_seed_input(context):
    url = f"{BASE_URL}/users"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        try:
            data = response.json()
            if not isinstance(data, dict):
                raise ValueError("Response JSON is not an object")
        except ValueError as e:
            print(f"Error parsing JSON in GIVEN step for MR4 from {url}: {e}")
            raise

        user_list = data.get('userList', [])
        if not isinstance(user_list, list):
            user_list = []

        context.seed_response = data
        context.seed_request = response.request
        context.seed_user_count = len(user_list)
    except (requests.RequestException, ValueError, TypeError) as e:
        print(f"Error in GIVEN step for MR4 (GET {url}): {e}")
        raise


@when('a follow-up input is created by creating a new user and then retrieving the list of users again, yielding a follow-up output for MR4.')
def step_mr_MR4_followup_input(context):
    # According to OpenAPI, /users/register expects RegisterUserAccountDTO
    new_user_data = {
        "username": "newuser_mr4",
        "password": "password123",
        "name": "New",
        "surname": "User",
        "email": "newuser_mr4@example.com",
        "gender": "other"
    }

    register_url = f"{BASE_URL}/users/register"
    list_url = f"{BASE_URL}/users"

    try:
        # Create a new user via registerNewUserAccountUsingPOST
        create_response = requests.post(register_url, json=new_user_data, timeout=10)
        create_response.raise_for_status()
        # Optionally validate JSON but don't assume any specific shape
        try:
            _ = create_response.json()
        except ValueError:
            # If body is not JSON, ignore for MR purpose
            pass

        # Small delay to allow backend to persist user if needed
        time.sleep(0.2)

        # Retrieve the updated list of users
        followup_response = requests.get(list_url, timeout=10)
        followup_response.raise_for_status()
        try:
            followup_data = followup_response.json()
            if not isinstance(followup_data, dict):
                raise ValueError("Follow-up response JSON is not an object")
        except ValueError as e:
            print(f"Error parsing JSON in WHEN step for MR4 from {list_url}: {e}")
            raise

        followup_user_list = followup_data.get('userList', [])
        if not isinstance(followup_user_list, list):
            followup_user_list = []

        context.followup_response = followup_data
        context.followup_request = followup_response.request
        context.followup_user_count = len(followup_user_list)
    except (requests.RequestException, ValueError, TypeError) as e:
        print(f"Error in WHEN step for MR4 (POST {register_url} / GET {list_url}): {e}")
        raise


@then('the follow-up output should have a user count that is exactly one more than the seed output for MR4, assuming no other user-creation or deletion operations occur between the two retrievals.')
def step_mr_MR4_followup_output(context):
    try:
        seed_count = int(getattr(context, "seed_user_count", 0))
        followup_count = int(getattr(context, "followup_user_count", 0))
        assert followup_count == seed_count + 1, (
            f"Expected user count to be {seed_count + 1}, but got {followup_count}."
        )
    except (TypeError, ValueError) as e:
        print(f"Type conversion error in THEN step for MR4: {e}")
        raise
    except AssertionError as e:
        print(f"Assertion error in THEN step for MR4: {e}")
        raise

# ----




def _safe_get_user_list(context):
    """
    Safely call GET /users and return the user list (always a list).
    """
    response = requests.get(f"{BASE_URL}/users", timeout=10)
    response.raise_for_status()
    try:
        data = response.json()
    except ValueError:
        data = {}
    if not isinstance(data, dict):
        data = {}
    user_list = data.get("userList")
    if not isinstance(user_list, list):
        user_list = []
    context.last_users_response_raw = data
    return user_list


def _safe_create_user():
    """
    Safely call POST /users with a minimal valid CreateOrUpdateUserDTO body.
    Returns parsed response JSON as dict or {}.
    """
    # Payload aligned with CreateOrUpdateUserDTO from the OpenAPI spec
    user_data = {
        "username": "testuser_mr5",
        "password": "password123",
        "email": "testuser_mr5@example.com",
        "name": "Test",
        "surname": "User",
        "enabled": True,
        "secured": False,
    }
    response = requests.post(f"{BASE_URL}/users", json=user_data, timeout=10)
    response.raise_for_status()
    try:
        data = response.json()
    except ValueError:
        data = {}
    if not isinstance(data, dict):
        data = {}
    return data


def _safe_delete_user(user_id):
    """
    Safely call DELETE /users/{id}.
    """
    # id is int64 in OpenAPI; ensure it is an int before formatting
    try:
        user_id_int = int(user_id)
    except (TypeError, ValueError):
        raise ValueError(f"Invalid user_id for deletion: {user_id!r}")
    response = requests.delete(f"{BASE_URL}/users/{user_id_int}", timeout=10)
    response.raise_for_status()
    return response


@given(
    "a seed input that retrieves the current list of users, producing a seed output with the total user count for MR5."
)
def step_mr_MR5_seed_input(context):
    response = requests.get(f"{BASE_URL}/users", timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError:
        data = {}

    if not isinstance(data, dict):
        data = {}

    context.seed_response = data
    context.seed_request_method = response.request.method
    context.seed_request_url = response.request.url

    user_list = data.get("userList")
    if not isinstance(user_list, list):
        user_list = []

    context.seed_user_count = len(user_list)


@when(
    "a follow-up input is created by deleting an existing user and then retrieving the list of users again, yielding a follow-up output for MR5."
)
def step_mr_MR5_followup_input(context):
    # Ensure there is at least one user to delete
    if not isinstance(context.seed_user_count, int) or context.seed_user_count < 0:
        context.seed_user_count = 0

    if context.seed_user_count == 0:
        _safe_create_user()
        # After creation, update the seed user count to be consistent for MR
        user_list_after_create = _safe_get_user_list(context)
        context.seed_user_count = len(user_list_after_create)

    # Retrieve the current list of users again to get an ID for deletion
    user_list = _safe_get_user_list(context)

    if not user_list:
        raise RuntimeError("No users available to delete for MR5.")

    first_user = user_list[0]
    if not isinstance(first_user, dict):
        raise RuntimeError("Unexpected user entry format; expected object with 'id' field.")

    user_id_to_delete = first_user.get("id")
    if user_id_to_delete is None:
        raise RuntimeError("User object does not contain 'id' field required for deletion.")

    _safe_delete_user(user_id_to_delete)

    # Retrieve the list of users again after deletion
    followup_user_list = _safe_get_user_list(context)
    context.followup_response = context.last_users_response_raw
    context.followup_user_count = len(followup_user_list)


@then(
    "the follow-up output should have a user count that is exactly one less than the seed output for MR5, assuming no other user-creation or deletion operations occur between the two retrievals."
)
def step_mr_MR5_followup_output(context):
    if not isinstance(context.seed_user_count, int):
        raise AssertionError(f"Seed user count is not an integer: {context.seed_user_count!r}")
    if not isinstance(context.followup_user_count, int):
        raise AssertionError(f"Follow-up user count is not an integer: {context.followup_user_count!r}")

    expected_count = context.seed_user_count - 1
    actual_count = context.followup_user_count

    assert actual_count == expected_count, (
        f"Expected user count to be {expected_count}, but got {actual_count}."
    )
