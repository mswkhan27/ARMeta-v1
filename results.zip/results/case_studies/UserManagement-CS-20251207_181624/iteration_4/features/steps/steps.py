from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the current list of roles, producing a seed output whose total role count is derived from the number of items returned for MR20.')
def step_mr_MR20_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    response.raise_for_status()

    # /users/rbac/roles returns an array of RoleDTO
    try:
        seed_roles = response.json()
    except ValueError as e:
        raise AssertionError(f"Response body is not valid JSON: {e}")

    if not isinstance(seed_roles, list):
        raise AssertionError(f"Expected list of roles, got: {type(seed_roles).__name__}")

    context.seed_response = seed_roles
    context.seed_request = response.request
    context.seed_role_count = len(seed_roles)


@when('a follow-up input is created by invoking the DELETE operation on a specific role using its roleId, and then retrieving the list of roles again, yielding a follow-up output for MR20.')
def step_mr_MR20_followup_input(context):
    # Ensure seed_response is available and is a non-empty list
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response not found on context; Given step may have failed.")
    if not isinstance(context.seed_response, list):
        raise AssertionError(f"seed_response should be a list, got: {type(context.seed_response).__name__}")
    if len(context.seed_response) == 0:
        raise AssertionError("Seed response is empty, cannot proceed with deletion for MR20.")

    first_role = context.seed_response[0]
    if not isinstance(first_role, dict):
        raise AssertionError(f"Expected first role to be a dict, got: {type(first_role).__name__}")

    role_id_to_delete = first_role.get("id", None)
    if role_id_to_delete is None:
        raise AssertionError("First role object does not contain 'id' field; cannot determine roleId to delete.")

    # roleId is int64 in the OpenAPI spec; ensure we can convert safely
    try:
        role_id_to_delete_int = int(role_id_to_delete)
    except (TypeError, ValueError):
        raise AssertionError(f"roleId value is not convertible to int: {role_id_to_delete!r}")

    delete_response = requests.delete(
        f"{BASE_URL}/users/rbac/roles/{role_id_to_delete_int}",
        timeout=10
    )
    # Accept 200 or 204 as successful deletion per spec
    if delete_response.status_code not in (200, 204):
        raise AssertionError(
            f"Expected DELETE /users/rbac/roles/{{roleId}} to return 200 or 204, "
            f"got {delete_response.status_code} with body: {delete_response.text}"
        )

    followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_roles = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response body is not valid JSON: {e}")

    if not isinstance(followup_roles, list):
        raise AssertionError(f"Expected follow-up roles to be a list, got: {type(followup_roles).__name__}")

    context.followup_response = followup_roles
    context.followup_request = followup_response.request
    context.followup_role_count = len(followup_roles)


@then('the follow-up output should have a role count that is exactly one less than the seed output for MR20, assuming the delete operation succeeds for an existing role and no other role-creation or deletion operations occur between the two retrievals.')
def step_mr_MR20_followup_output(context):
    if not hasattr(context, "seed_role_count"):
        raise AssertionError("seed_role_count not found on context; Given step may have failed.")
    if not hasattr(context, "followup_role_count"):
        raise AssertionError("followup_role_count not found on context; When step may have failed.")

    try:
        seed_count = int(context.seed_role_count)
        followup_count = int(context.followup_role_count)
    except (TypeError, ValueError):
        raise AssertionError(
            f"Role counts must be numeric. seed_role_count={context.seed_role_count!r}, "
            f"followup_role_count={context.followup_role_count!r}"
        )

    expected_count = seed_count - 1
    if followup_count != expected_count:
        raise AssertionError(
            f"Expected role count to be {expected_count}, but got {followup_count}."
        )

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


@given('a seed input that invokes the salt-generation operation, producing a seed output with a generated salt value represented as a string for MR21.')
def step_mr_MR21_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/salt", timeout=10)
    response.raise_for_status()

    # Safely store seed response as string
    context.seed_response = response.text if response.text is not None else ""
    assert isinstance(context.seed_response, str), "Seed output is not a string."


@when('a follow-up input is created by invoking the salt-generation operation again under the same conditions, yielding a follow-up output with another generated string value for MR21.')
def step_mr_MR21_followup_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/salt", timeout=10)
    response.raise_for_status()

    # Safely store follow-up response as string
    context.followup_response = response.text if response.text is not None else ""
    assert isinstance(context.followup_response, str), "Follow-up output is not a string."


@then('the follow-up output is expected to contain a salt value that is different from the seed output for MR21, indicating variability between successive salt-generation calls while still conforming to the documented string return type.')
def step_mr_MR21_assert_different(context):
    seed = getattr(context, "seed_response", "")
    followup = getattr(context, "followup_response", "")
    assert isinstance(seed, str), "Seed response missing or not a string."
    assert isinstance(followup, str), "Follow-up response missing or not a string."
    assert followup != seed, "Follow-up output is not different from seed output."

# ----




@given("a seed input that retrieves the current error state using the HEAD method, producing a seed output with the response status and headers for MR22.")
def step_mr_MR22_seed_input(context):
    url = f"{BASE_URL}/error"
    response = requests.head(url, timeout=10)

    # Store request/response details on context for later inspection
    context.seed_request = {
        "method": "HEAD",
        "url": url,
    }
    context.seed_response = response

    # According to OpenAPI for /error HEAD: 200 or 204 are valid success codes
    assert response.status_code in (200, 204), f"Expected status code 200 or 204, got {response.status_code}"


@when("a follow-up input is created by invoking the HEAD operation on the error resource again under the same conditions, yielding a follow-up output for MR22.")
def step_mr_MR22_followup_input(context):
    url = f"{BASE_URL}/error"
    response = requests.head(url, timeout=10)

    context.followup_request = {
        "method": "HEAD",
        "url": url,
    }
    context.followup_response = response

    assert response.status_code in (200, 204), f"Expected status code 200 or 204, got {response.status_code}"


@then('the follow-up output should return a status of either "OK" (200) or "No Content" (204), consistent with the documented responses for this operation, and if any body is present it should conform to the generic object schema used for error representations for MR22, although a body may be absent for HEAD responses.')
def step_mr_MR22_followup_output(context):
    response = getattr(context, "followup_response", None)
    assert response is not None, "followup_response is not set on context"

    status_code = response.status_code
    assert status_code in (200, 204), f"Expected status code 200 or 204, got {status_code}"

    # For HEAD, a body is typically absent; if present and JSON, verify it is an object.
    # Avoid TypeError/ValueError by safely attempting JSON parsing.
    text = response.text or ""
    if status_code == 200 and text.strip():
        try:
            body = response.json()
        except ValueError:
            # Not valid JSON while a body is present – violates the documented object schema.
            assert False, "Expected JSON object body for 200 response, got non-JSON content"
        else:
            assert isinstance(body, dict), "Expected response body to be a JSON object (dictionary) for 200 response"

# ----




def _safe_parse_json(response):
    try:
        return response.json()
    except ValueError:
        # No JSON body or invalid JSON, normalize as None
        return None


@given("a seed input that retrieves the current error state using the OPTIONS method, producing a seed output with the response status, headers, and any generic object body for MR23.")
def step_mr_MR23_seed_input(context):
    response = requests.options(f"{BASE_URL}/error", timeout=10)
    context.seed_request = response
    context.seed_response = _safe_parse_json(response)

    # According to the OpenAPI spec for /error OPTIONS, valid success codes are 200 and 204
    assert response.status_code in [200, 204], "Expected status code 200 or 204 for seed request"


@when("a follow-up input is created by invoking the OPTIONS operation on the error resource again under the same conditions, yielding a follow-up output for MR23.")
def step_mr_MR23_followup_input(context):
    response = requests.options(f"{BASE_URL}/error", timeout=10)
    context.followup_request = response
    context.followup_response = _safe_parse_json(response)

    # Ensure follow-up request also returns documented success status
    assert response.status_code in [200, 204], "Expected status code 200 or 204 for follow-up request"


@then("the follow-up output should be consistent with the seed output for MR23 in terms of response status code being one of the documented success codes and the presence and structure of any generic object body, assuming no configuration or deployment changes occur between the two calls.")
def step_mr_MR23_followup_output(context):
    # Verify both responses are using documented success codes
    assert context.seed_request.status_code in [200, 204], "Seed response status code is not 200 or 204"
    assert context.followup_request.status_code in [200, 204], "Follow-up response status code is not 200 or 204"

    # Check consistency of body presence (both JSON, both non-JSON/empty)
    seed_has_body = context.seed_response is not None
    followup_has_body = context.followup_response is not None
    assert seed_has_body == followup_has_body, "Inconsistent presence of response body between seed and follow-up"

    # If bodies are present, compare their structure (keys/types) rather than exact values
    if seed_has_body and isinstance(context.seed_response, dict) and isinstance(context.followup_response, dict):
        assert set(context.seed_response.keys()) == set(
            context.followup_response.keys()
        ), "Response body keys differ between seed and follow-up"
    elif seed_has_body and isinstance(context.seed_response, list) and isinstance(context.followup_response, list):
        # Compare element type consistency for lists
        seed_types = {type(el).__name__ for el in context.seed_response}
        followup_types = {type(el).__name__ for el in context.followup_response}
        assert seed_types == followup_types, "Response list element types differ between seed and follow-up"

# ----




@given('a seed input that retrieves the current error state using the PATCH method, producing a seed output with the error details represented as a generic object when a body is returned for MR24.')
def step_mr_MR24_seed_input(context):
    context.seed_request = {"errorDetail": "Sample error detail"}
    try:
        response = requests.patch(f"{BASE_URL}/error", json=context.seed_request, timeout=10)
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Request failed in MR24 Given step: {e}") from e

    # Only 200 or 204 are documented for PATCH /error
    if response.status_code not in (200, 204):
        raise AssertionError(
            f"Unexpected status code in MR24 Given step: {response.status_code}"
        )

    context.seed_response = response

    if response.status_code == 200:
        # Guard against non-JSON response bodies
        try:
            body = response.json()
        except ValueError as e:
            raise AssertionError(
                f"Expected JSON body for 200 response in MR24 Given step, but could not decode JSON: {e}"
            ) from e
        if not isinstance(body, dict):
            raise AssertionError(
                f"Expected response body to be a JSON object (dict), got {type(body)}"
            )


@when('a follow-up input is created by invoking the PATCH operation on the error resource again under the same conditions, yielding a follow-up output for MR24.')
def step_mr_MR24_followup_input(context):
    context.followup_request = {"errorDetail": "Sample error detail"}
    try:
        response = requests.patch(f"{BASE_URL}/error", json=context.followup_request, timeout=10)
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Request failed in MR24 When step: {e}") from e

    # Do not call raise_for_status to allow explicit checking of documented 200/204
    context.followup_response = response


@then("the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation, and any returned body for a 200 response should conform to the generic object schema used for error representations for MR24.")
def step_mr_MR24_followup_output(context):
    response = getattr(context, "followup_response", None)
    if response is None:
        raise AssertionError("followup_response is not set in context")

    status_code = getattr(response, "status_code", None)
    if status_code is None:
        raise AssertionError("followup_response has no status_code")

    if status_code not in (200, 204):
        raise AssertionError(f"Expected status 200 or 204, got {status_code}")

    if status_code == 200:
        try:
            followup_body = response.json()
        except ValueError as e:
            raise AssertionError(
                f"Expected JSON body for 200 response in MR24 Then step, but could not decode JSON: {e}"
            ) from e

        if not isinstance(followup_body, dict):
            raise AssertionError(
                f"Expected response body to be a JSON object (dict), got {type(followup_body)}"
            )

    elif status_code == 204:
        # response.text may be non-empty on some clients even for 204, so be defensive
        content = getattr(response, "content", b"")
        if content not in (b"", None):
            raise AssertionError(
                f"Expected no content for 204 response, but received: {content!r}"
            )
