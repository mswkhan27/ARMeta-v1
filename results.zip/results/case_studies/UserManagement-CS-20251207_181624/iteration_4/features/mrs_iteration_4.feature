Feature: Iteration 4 MRs

  Scenario: MR20 Deleting a role should result in a reduced role list
    Given a seed input that retrieves the current list of roles, producing a seed output whose total role count is derived from the number of items returned for MR20.
    When a follow-up input is created by invoking the DELETE operation on a specific role using its roleId, and then retrieving the list of roles again, yielding a follow-up output for MR20.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR20, assuming the delete operation succeeds for an existing role and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR21 Generating a salt should produce a different value across calls
    Given a seed input that invokes the salt-generation operation, producing a seed output with a generated salt value represented as a string for MR21.
    When a follow-up input is created by invoking the salt-generation operation again under the same conditions, yielding a follow-up output with another generated string value for MR21.
    Then the follow-up output is expected to contain a salt value that is different from the seed output for MR21, indicating variability between successive salt-generation calls while still conforming to the documented string return type.

  Scenario: MR22 Invoking HEAD on error should return a documented success response
    Given a seed input that retrieves the current error state using the HEAD method, producing a seed output with the response status and headers for MR22.
    When a follow-up input is created by invoking the HEAD operation on the error resource again under the same conditions, yielding a follow-up output for MR22.
    Then the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation, and if any body is present it should conform to the generic object schema used for error representations for MR22, although a body may be absent for HEAD responses.

  Scenario: MR23 Invoking OPTIONS on error should return a consistent response structure
    Given a seed input that retrieves the current error state using the OPTIONS method, producing a seed output with the response status, headers, and any generic object body for MR23.
    When a follow-up input is created by invoking the OPTIONS operation on the error resource again under the same conditions, yielding a follow-up output for MR23.
    Then the follow-up output should be consistent with the seed output for MR23 in terms of response status code being one of the documented success codes and the presence and structure of any generic object body, assuming no configuration or deployment changes occur between the two calls.

  Scenario: MR24 Invoking PATCH on error should return a documented success response
    Given a seed input that retrieves the current error state using the PATCH method, producing a seed output with the error details represented as a generic object when a body is returned for MR24.
    When a follow-up input is created by invoking the PATCH operation on the error resource again under the same conditions, yielding a follow-up output for MR24.
    Then the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation, and any returned body for a 200 response should conform to the generic object schema used for error representations for MR24.
