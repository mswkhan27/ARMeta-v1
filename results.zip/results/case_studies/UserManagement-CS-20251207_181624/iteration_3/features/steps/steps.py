from behave import given, when, then
import os, json, requests, time

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')

@given('a seed input that retrieves the current error state, producing a seed output with the error details represented as a generic object for MR16.')
def step_mr_MR16_seed_input(context):
    try:
        response = requests.get(f"{BASE_URL}/error", timeout=10)
        response.raise_for_status()
        context.seed_response = response.json()
        context.seed_request = response.request
    except requests.exceptions.RequestException as e:
        print(f"Error in Given step for MR16: {e}")
        raise

@when('a follow-up input is created by invoking the DELETE operation on the error resource, yielding a follow-up output for MR16.')
def step_mr_MR16_followup_input(context):
    try:
        response = requests.delete(f"{BASE_URL}/error", timeout=10)
        response.raise_for_status()
        context.followup_response = response.json() if response.status_code != 204 else None
        context.followup_request = response.request
    except requests.exceptions.RequestException as e:
        print(f"Error in When step for MR16: {e}")
        raise

@then('the follow-up output should return a status of either \'OK\' (200) with a generic object body or \'No Content\' (204), consistent with the documented responses for this operation, and any returned body should conform to the generic object schema used for error representations for MR16.')
def step_mr_MR16_followup_output(context):
    try:
        assert context.followup_response is None or isinstance(context.followup_response, dict), "Follow-up response body is not a valid object."
        assert context.followup_response is None or context.followup_response.get('status') in ['OK', 'No Content'], "Follow-up response status is not as expected."
    except AssertionError as e:
        print(f"Assertion error in Then step for MR16: {e}")
        raise

# ----

import os
import json
import requests



@given('a seed input that retrieves the current list of roles, producing a seed output with the total role count for MR17.')
def _mr_MR17_seed_input(context):
    try:
        response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
        response.raise_for_status()
        data = response.json()

        # Ensure the response is a list as per OpenAPI (array of RoleDTO)
        if not isinstance(data, list):
            raise ValueError(f"Expected list of roles, got {type(data).__name__}")

        context.seed_response = data
        context.seed_request = response.request
        context.seed_role_count = len(data)

        if context.seed_role_count == 0:
            raise RuntimeError("Seed role list is empty; MR17 requires at least one role to delete.")
    except Exception as e:
        print(f"Error in Given step for MR17: {e}")
        raise


@when('a follow-up input is created by invoking the DELETE operation on a specific role using its roleId, and then retrieving the list of roles again, yielding a follow-up output for MR17.')
def _mr_MR17_followup_input(context):
    try:
        # Safely get the first role and its id
        if not hasattr(context, "seed_response") or not isinstance(context.seed_response, list):
            raise RuntimeError("Seed response is not available or invalid.")

        if not context.seed_response:
            raise RuntimeError("No roles available to delete in When step.")

        first_role = context.seed_response[0]
        if not isinstance(first_role, dict) or "id" not in first_role:
            raise ValueError("First role object does not contain an 'id' field.")

        role_id = first_role["id"]

        # Ensure role_id is an integer as required by the OpenAPI spec (int64)
        try:
            role_id_int = int(role_id)
        except (TypeError, ValueError):
            raise ValueError(f"Role id is not convertible to int: {role_id!r}")

        delete_response = requests.delete(f"{BASE_URL}/users/rbac/roles/{role_id_int}", timeout=10)
        delete_response.raise_for_status()

        followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
        followup_response.raise_for_status()
        followup_data = followup_response.json()

        if not isinstance(followup_data, list):
            raise ValueError(f"Expected list of roles in follow-up, got {type(followup_data).__name__}")

        context.followup_response = followup_data
        context.followup_request = followup_response.request
        context.followup_role_count = len(followup_data)
    except Exception as e:
        print(f"Error in When step for MR17: {e}")
        raise


@then('the follow-up output should have a role count that is exactly one less than the seed output for MR17, assuming the delete operation succeeds and no other role-creation or deletion operations occur between the two retrievals.')
def _mr_MR17_assert_followup_output(context):
    try:
        if not hasattr(context, "seed_role_count") or not hasattr(context, "followup_role_count"):
            raise RuntimeError("Role counts are not available for assertion.")

        expected_count = context.seed_role_count - 1
        actual_count = context.followup_role_count

        assert actual_count == expected_count, (
            f"Expected role count to be {expected_count}, but got {actual_count}."
        )
    except AssertionError as e:
        print(f"Assertion error in Then step for MR17: {e}")
        raise
    except Exception as e:
        print(f"Unexpected error in Then step for MR17: {e}")
        raise

# ----




@given('a seed input that retrieves the current list of users, producing a seed output with the total user count for MR19.')
def _mr_MR19_seed_input(context):
    response = requests.get(f"{BASE_URL}/users", timeout=10)
    response.raise_for_status()

    try:
        body = response.json()
    except ValueError:
        body = {}

    if isinstance(body, dict):
        user_list = body.get('userList') or []
        if not isinstance(user_list, list):
            user_list = []
    else:
        user_list = []

    context.seed_response = body
    context.seed_request = response.request
    context.seed_user_count = len(user_list)


@when('a follow-up input is created by invoking the POST operation that registers a new user account, and then retrieving the list of users again, yielding a follow-up output for MR19.')
def _mr_MR19_followup_input(context):
    new_user_data = {
        "username": "newuser_mr19",
        "password": "password123",
        "name": "New",
        "surname": "User",
        "email": "newuser_mr19@example.com",
        "gender": "other"
    }

    register_response = requests.post(
        f"{BASE_URL}/users/register",
        json=new_user_data,
        timeout=10
    )
    register_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/users", timeout=10)
    followup_response.raise_for_status()

    try:
        body = followup_response.json()
    except ValueError:
        body = {}

    if isinstance(body, dict):
        user_list = body.get('userList') or []
        if not isinstance(user_list, list):
            user_list = []
    else:
        user_list = []

    context.followup_response = body
    context.followup_request = followup_response.request
    context.followup_user_count = len(user_list)


@then('the follow-up output should have a user count that is exactly one more than the seed output for MR19, assuming the registration operation succeeds and no other user-creation or deletion operations occur between the two retrievals.')
def _mr_MR19_assert_user_count(context):
    expected = getattr(context, "seed_user_count", 0) + 1
    actual = getattr(context, "followup_user_count", 0)
    assert actual == expected, (
        f"Expected user count to be {expected}, but got {actual}."
    )
