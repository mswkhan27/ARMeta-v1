Feature: Iteration 3 MRs

  Scenario: MR16 Deleting an error should return a documented success response
    Given a seed input that retrieves the current error state, producing a seed output with the error details represented as a generic object for MR16.
    When a follow-up input is created by invoking the DELETE operation on the error resource, yielding a follow-up output for MR16.
    Then the follow-up output should return a status of either 'OK' (200) with a generic object body or 'No Content' (204), consistent with the documented responses for this operation, and any returned body should conform to the generic object schema used for error representations for MR16.

  Scenario: MR17 Deleting a role should result in a reduced role list
    Given a seed input that retrieves the current list of roles, producing a seed output with the total role count for MR17.
    When a follow-up input is created by invoking the DELETE operation on a specific role using its roleId, and then retrieving the list of roles again, yielding a follow-up output for MR17.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR17, assuming the delete operation succeeds and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR19 Registering a new user should increase the user count
    Given a seed input that retrieves the current list of users, producing a seed output with the total user count for MR19.
    When a follow-up input is created by invoking the POST operation that registers a new user account, and then retrieving the list of users again, yielding a follow-up output for MR19.
    Then the follow-up output should have a user count that is exactly one more than the seed output for MR19, assuming the registration operation succeeds and no other user-creation or deletion operations occur between the two retrievals.
