from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


@given('a seed input that retrieves the current list of roles, producing a seed output with the total role count and including a specific existing role identified by its roleId for MR31.')
def step_mr_MR31_seed_input(context):
    url = f"{BASE_URL}/users/rbac/roles"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()

        try:
            data = response.json()
        except ValueError:
            raise AssertionError(f"Expected JSON response from GET {url}, got invalid JSON")

        if not isinstance(data, list):
            raise AssertionError(f"Expected a list of roles from GET {url}, got {type(data).__name__}")

        if not data:
            raise AssertionError(f"No roles available from GET {url}; MR31 requires at least one existing role")

        first_role = data[0]
        if not isinstance(first_role, dict):
            raise AssertionError(
                f"Expected each role to be an object/dict, got {type(first_role).__name__} for first element"
            )

        role_id = first_role.get("id", None)
        if role_id is None:
            raise AssertionError("First role object does not contain 'id' field required for MR31")

        if not isinstance(role_id, int):
            raise AssertionError(f"Expected 'id' of role to be int, got {type(role_id).__name__}")

        context.seed_response = data
        context.seed_request = response.request
        context.role_id = role_id
        context.seed_count = len(data)

    except (requests.RequestException, AssertionError) as e:
        print(f"Error in Given step for MR31: {str(e)}")
        raise


@when('a follow-up input is created by invoking the DELETE operation on that existing role using its roleId, and, after a successful deletion response, retrieving the list of roles again, yielding a follow-up output for MR31.')
def step_mr_MR31_followup_input(context):
    if not hasattr(context, "role_id"):
        raise AssertionError("Context is missing 'role_id' from Given step; cannot perform DELETE")

    role_id = context.role_id
    if not isinstance(role_id, int):
        raise AssertionError(f"'role_id' in context must be int, got {type(role_id).__name__}")

    delete_url = f"{BASE_URL}/users/rbac/roles/{role_id}"
    list_url = f"{BASE_URL}/users/rbac/roles"

    try:
        delete_response = requests.delete(delete_url, timeout=10)
        delete_response.raise_for_status()

        followup_response = requests.get(list_url, timeout=10)
        followup_response.raise_for_status()

        try:
            followup_data = followup_response.json()
        except ValueError:
            raise AssertionError(f"Expected JSON response from GET {list_url}, got invalid JSON")

        if not isinstance(followup_data, list):
            raise AssertionError(
                f"Expected a list of roles from GET {list_url} after deletion, got {type(followup_data).__name__}"
            )

        context.followup_response = followup_data
        context.followup_count = len(followup_data)

    except (requests.RequestException, AssertionError) as e:
        print(f"Error in When step for MR31: {str(e)}")
        raise


@then('the follow-up output should have a role count that is exactly one less than the seed output for MR31, provided that the specified role was present in the seed list, the delete operation succeeds, and no other role-creation or deletion operations occur between the two retrievals.')
def step_mr_MR31_assert_followup_output(context):
    if not hasattr(context, "seed_count") or not hasattr(context, "followup_count"):
        raise AssertionError("Missing seed_count or followup_count in context for MR31 assertion")

    seed_count = context.seed_count
    followup_count = context.followup_count

    if not isinstance(seed_count, int):
        raise AssertionError(f"'seed_count' must be int, got {type(seed_count).__name__}")
    if not isinstance(followup_count, int):
        raise AssertionError(f"'followup_count' must be int, got {type(followup_count).__name__}")

    try:
        assert followup_count == seed_count - 1, (
            f"Expected role count to be {seed_count - 1} after deletion, "
            f"but got {followup_count} (seed_count={seed_count})."
        )
    except AssertionError as e:
        print(f"Assertion error in Then step for MR31: {str(e)}")
        raise

# ----




@given("a seed input that retrieves the current error state using the HEAD method, producing a seed output with the response status and headers for MR32 under specific authentication and authorization conditions.")
def step_mr_MR32_seed_input(context):
    url = f"{BASE_URL}/error"
    try:
        response = requests.head(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"RequestException in Given step for MR32: {e}")

    context.seed_response = response

    status = getattr(response, "status_code", None)
    if status is None:
        raise AssertionError("Seed response has no status_code")

    if status not in (200, 204, 401, 403):
        raise AssertionError(f"Unexpected status code in seed response: {status}")


@when("a follow-up input is created by invoking the HEAD operation on the same error resource again under the same authentication, authorization, and request conditions, yielding a follow-up output for MR32.")
def step_mr_MR32_followup_input(context):
    url = f"{BASE_URL}/error"
    try:
        response = requests.head(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"RequestException in When step for MR32: {e}")

    context.followup_response = response


@then("the follow-up output should return a status that is one of the documented response codes for this operation (200, 204, 401, or 403) and should match the seed output status when the conditions are unchanged; if a body is present with a 200 response, it should conform to the generic object schema used for error representations for MR32, although a body may be absent for HEAD responses.")
def step_mr_MR32_followup_output(context):
    seed_response = getattr(context, "seed_response", None)
    followup_response = getattr(context, "followup_response", None)

    if seed_response is None:
        raise AssertionError("seed_response is not set in context")
    if followup_response is None:
        raise AssertionError("followup_response is not set in context")

    seed_status = getattr(seed_response, "status_code", None)
    followup_status = getattr(followup_response, "status_code", None)

    if seed_status is None:
        raise AssertionError("Seed response has no status_code")
    if followup_status is None:
        raise AssertionError("Follow-up response has no status_code")

    if followup_status not in (200, 204, 401, 403):
        raise AssertionError(f"Unexpected status code in follow-up response: {followup_status}")

    if followup_status != seed_status:
        raise AssertionError(
            f"Follow-up response status ({followup_status}) does not match seed response status ({seed_status})"
        )
