Feature: Iteration 7 MRs

  Scenario: MR31 Deleting an existing role should result in a reduced role list
    Given a seed input that retrieves the current list of roles, producing a seed output with the total role count and including a specific existing role identified by its roleId for MR31.
    When a follow-up input is created by invoking the DELETE operation on that existing role using its roleId, and, after a successful deletion response, retrieving the list of roles again, yielding a follow-up output for MR31.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR31, provided that the specified role was present in the seed list, the delete operation succeeds, and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR32 Invoking HEAD on the error resource twice under the same conditions should yield consistent documented responses
    Given a seed input that retrieves the current error state using the HEAD method, producing a seed output with the response status and headers for MR32 under specific authentication and authorization conditions.
    When a follow-up input is created by invoking the HEAD operation on the same error resource again under the same authentication, authorization, and request conditions, yielding a follow-up output for MR32.
    Then the follow-up output should return a status that is one of the documented response codes for this operation (200, 204, 401, or 403) and should match the seed output status when the conditions are unchanged; if a body is present with a 200 response, it should conform to the generic object schema used for error representations for MR32, although a body may be absent for HEAD responses.
