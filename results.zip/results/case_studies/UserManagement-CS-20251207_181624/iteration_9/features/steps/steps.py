from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


def _safe_get_json(response):
    try:
        return response.json()
    except ValueError:
        return None


@given("a seed input that retrieves the current list of roles, producing a seed output with the total role count for MR35.")
def step_mr_MR35_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    response.raise_for_status()

    data = _safe_get_json(response)
    if not isinstance(data, list):
        raise TypeError(f"Expected list of roles from /users/rbac/roles, got: {type(data).__name__}")

    context.seed_response = data
    context.seed_request = response.request
    context.seed_role_count = len(data)

    if context.seed_role_count == 0:
        raise ValueError("No roles available to delete for MR35; seed role list is empty.")


@when("a follow-up input is created by invoking the DELETE operation on a specific role using its roleId, and then retrieving the list of roles again, yielding a follow-up output for MR35.")
def step_mr_MR35_followup_input(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, list):
        raise TypeError("seed_response is missing or not a list in context for MR35.")

    first_role = context.seed_response[0]
    if not isinstance(first_role, dict):
        raise TypeError(f"Expected first role to be a dict, got: {type(first_role).__name__}")

    role_id_to_delete = first_role.get("id")
    if role_id_to_delete is None:
        raise ValueError("First role in seed_response does not contain 'id' field.")
    try:
        role_id_to_delete = int(role_id_to_delete)
    except (TypeError, ValueError):
        raise ValueError(f"Role id is not convertible to int: {role_id_to_delete!r}")

    delete_response = requests.delete(
        f"{BASE_URL}/users/rbac/roles/{role_id_to_delete}", timeout=10
    )
    if delete_response.status_code not in (200, 204):
        delete_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    followup_response.raise_for_status()

    followup_data = _safe_get_json(followup_response)
    if not isinstance(followup_data, list):
        raise TypeError(
            f"Expected list of roles from /users/rbac/roles after delete, got: {type(followup_data).__name__}"
        )

    context.followup_response = followup_data
    context.followup_request = followup_response.request
    context.followup_role_count = len(followup_data)


@then("the follow-up output should have a role count that is exactly one less than the seed output for MR35, assuming the delete operation returns a success status (such as 200 or 204), the targeted role existed before deletion, and no other role-creation or deletion operations occur between the two retrievals.")
def step_mr_MR35_followup_output(context):
    if not hasattr(context, "seed_role_count") or not isinstance(context.seed_role_count, int):
        raise TypeError("seed_role_count is missing or not an int in context for MR35.")
    if not hasattr(context, "followup_role_count") or not isinstance(context.followup_role_count, int):
        raise TypeError("followup_role_count is missing or not an int in context for MR35.")

    expected_count = context.seed_role_count - 1
    actual_count = context.followup_role_count

    assert actual_count == expected_count, (
        f"Expected role count to be {expected_count} after deletion, but got {actual_count}."
    )

# ----




@given("a seed input that retrieves the current error state using the HEAD method, producing a seed output with the response status and headers for MR36.")
def step_mr_MR36_seed_input(context):
    context.seed_response = requests.head(f"{BASE_URL}/error", timeout=10)
    status = context.seed_response.status_code
    if status not in (200, 204):
        raise AssertionError(f"Unexpected status code in seed response: {status}")


@when("a follow-up input is created by invoking the HEAD operation on the error resource again under the same conditions, yielding a follow-up output for MR36.")
def step_mr_MR36_followup_input(context):
    context.followup_response = requests.head(f"{BASE_URL}/error", timeout=10)
    status = context.followup_response.status_code
    if status not in (200, 204):
        raise AssertionError(f"Unexpected status code in follow-up response: {status}")


@then("under identical authorization and access conditions, the follow-up output's status code should match the seed output's status code and, when successful, be either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation; if any body is present it should conform to a generic object schema for MR36, although a body may be absent for HEAD responses.")
def step_mr_MR36_assert_followup_output(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    if seed is None or followup is None:
        raise AssertionError("Seed or follow-up response is missing from context.")

    if followup.status_code != seed.status_code:
        raise AssertionError(
            f"Status codes do not match: seed={seed.status_code}, follow-up={followup.status_code}"
        )

    if followup.status_code not in (200, 204):
        raise AssertionError(
            f"Status code is not OK (200) or No Content (204): {followup.status_code}"
        )
