Feature: Iteration 9 MRs

  Scenario: MR35 Deleting a role should result in a reduced role list
    Given a seed input that retrieves the current list of roles, producing a seed output with the total role count for MR35.
    When a follow-up input is created by invoking the DELETE operation on a specific role using its roleId, and then retrieving the list of roles again, yielding a follow-up output for MR35.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR35, assuming the delete operation returns a success status (such as 200 or 204), the targeted role existed before deletion, and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR36 Invoking HEAD on error should return a documented success response
    Given a seed input that retrieves the current error state using the HEAD method, producing a seed output with the response status and headers for MR36.
    When a follow-up input is created by invoking the HEAD operation on the error resource again under the same conditions, yielding a follow-up output for MR36.
    Then under identical authorization and access conditions, the follow-up output's status code should match the seed output's status code and, when successful, be either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation; if any body is present it should conform to a generic object schema for MR36, although a body may be absent for HEAD responses.
