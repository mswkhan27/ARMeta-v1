from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the current list of roles, producing a seed output with the total role count for MR25.')
def step_mr_MR25_seed_input(context):
    url = f"{BASE_URL}/users/rbac/roles"
    try:
        response = requests.get(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to {url} failed: {e}")

    if response.status_code != 200:
        raise AssertionError(f"Expected HTTP 200 from GET {url}, got {response.status_code}")

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Response from GET {url} is not valid JSON: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"Expected a list of roles from GET {url}, got {type(data).__name__}")

    context.seed_response = data
    context.seed_request = response.request
    context.seed_role_count = len(data)

    # Track whether we could delete a role (at least one exists)
    context.role_existed_for_deletion = context.seed_role_count > 0


@when('a follow-up input is created by invoking the DELETE operation on a specific role using its roleId, and then retrieving the list of roles again under the same conditions, yielding a follow-up output for MR25.')
def step_mr_MR25_followup_input(context):
    url_list = f"{BASE_URL}/users/rbac/roles"

    if not getattr(context, "role_existed_for_deletion", False):
        # No roles to delete; just re-fetch list to keep context consistent
        try:
            followup_response = requests.get(url_list, timeout=10)
        except requests.RequestException as e:
            raise AssertionError(f"Request to {url_list} failed: {e}")

        if followup_response.status_code != 200:
            raise AssertionError(f"Expected HTTP 200 from GET {url_list}, got {followup_response.status_code}")

        try:
            followup_data = followup_response.json()
        except ValueError as e:
            raise AssertionError(f"Response from GET {url_list} is not valid JSON: {e}")

        if not isinstance(followup_data, list):
            raise AssertionError(f"Expected a list of roles from GET {url_list}, got {type(followup_data).__name__}")

        context.followup_response = followup_data
        context.followup_role_count = len(followup_data)
        context.delete_status_code = None
        return

    first_role = context.seed_response[0]
    role_id_to_delete = first_role.get('id')

    if role_id_to_delete is None:
        raise AssertionError("First role in seed_response does not contain an 'id' field.")

    url_delete = f"{BASE_URL}/users/rbac/roles/{role_id_to_delete}"

    try:
        delete_response = requests.delete(url_delete, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to DELETE {url_delete} failed: {e}")

    # Store status code for Then step to verify documented success status
    context.delete_status_code = delete_response.status_code

    if delete_response.status_code not in (200, 204):
        raise AssertionError(
            f"Expected documented success status (200 or 204) from DELETE {url_delete}, "
            f"got {delete_response.status_code}"
        )

    try:
        followup_response = requests.get(url_list, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to {url_list} failed: {e}")

    if followup_response.status_code != 200:
        raise AssertionError(f"Expected HTTP 200 from GET {url_list}, got {followup_response.status_code}")

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Response from GET {url_list} is not valid JSON: {e}")

    if not isinstance(followup_data, list):
        raise AssertionError(f"Expected a list of roles from GET {url_list}, got {type(followup_data).__name__}")

    context.followup_response = followup_data
    context.followup_role_count = len(followup_data)


@then('the follow-up output should have a role count that is exactly one less than the seed output for MR25, provided the targeted role existed, the delete operation returns a documented success status and no other role-creation or deletion operations occur between the two retrievals.')
def step_mr_MR25_followup_output(context):
    if not getattr(context, "role_existed_for_deletion", False):
        # No role existed to delete; MR precondition not satisfied, so we skip strict count check.
        return

    delete_status = getattr(context, "delete_status_code", None)
    if delete_status not in (200, 204):
        raise AssertionError(
            f"MR25 precondition violated: delete_status_code is {delete_status}, "
            f"expected 200 or 204 for documented success."
        )

    expected_count = context.seed_role_count - 1
    actual_count = context.followup_role_count

    if actual_count != expected_count:
        raise AssertionError(
            f"Expected role count to be {expected_count} after deletion, but got {actual_count}."
        )

# ----




@given('a seed input that invokes the HEAD method on the error resource, producing a seed output with the response status and headers for MR26.')
def step_mr_MR26_seed_input(context):
    url = f"{BASE_URL}/error"
    context.seed_request = {
        "method": "HEAD",
        "url": url,
    }
    try:
        response = requests.head(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to {url} failed: {e}")
    context.seed_response = response
    assert response is not None, "Seed response is None"
    assert response.status_code in (200, 204), f"Expected status code 200 or 204, got {response.status_code}"


@when('a follow-up input is created by invoking the HEAD operation on the same resource again under the same conditions, yielding a follow-up output for MR26.')
def step_mr_MR26_followup_input(context):
    url = f"{BASE_URL}/error"
    context.followup_request = {
        "method": "HEAD",
        "url": url,
    }
    try:
        response = requests.head(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to {url} failed: {e}")
    context.followup_response = response
    assert response is not None, "Follow-up response is None"
    assert response.status_code in (200, 204), f"Expected status code 200 or 204, got {response.status_code}"


@then("the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation; if any body is present for a 200 response it should conform to a generic object schema (a JSON object with arbitrary properties) for MR26, although a body may be absent for HEAD responses.")
def step_mr_MR26_followup_output(context):
    response = getattr(context, "followup_response", None)
    assert response is not None, "Follow-up response is missing from context"
    status_code = getattr(response, "status_code", None)
    assert isinstance(status_code, int), f"Response status_code is not int: {status_code!r}"
    assert status_code in (200, 204), f"Expected status code 200 or 204, got {status_code}"

    # For HEAD, a body is typically absent; only validate JSON if a non-empty body is present.
    content = getattr(response, "content", b"")
    if status_code == 200 and content:
        text = None
        try:
            text = response.text
        except Exception:
            # If text access fails, skip body validation but keep status assertion
            return

        if text is None or text.strip() == "":
            # Empty body is allowed even with 200
            return

        try:
            body = response.json()
        except (ValueError, json.JSONDecodeError):
            raise AssertionError("Expected response body to be valid JSON for status 200")

        assert isinstance(body, dict), f"Response body should be a JSON object, got {type(body).__name__}"

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


@given("a seed input that invokes the POST method on the error resource, producing a seed output with any returned details represented as a generic object for MR27.")
def step_mr_MR27_seed_input(context):
    context.seed_request = {}
    try:
        response = requests.post(f"{BASE_URL}/error", json=context.seed_request, timeout=10)
    except requests.RequestException as e:
        print(f"Request exception in Given step for MR27: {e}")
        assert False

    # Save full response details in context for later checks if needed
    context.seed_status_code = response.status_code
    context.seed_headers = response.headers

    # Try to parse JSON safely; if not JSON, store raw text but avoid TypeError
    try:
        context.seed_response = response.json()
    except ValueError:
        context.seed_response = None
        context.seed_response_text = response.text


@when("a follow-up input is created by invoking the POST operation on the same resource again under the same conditions, yielding a follow-up output for MR27.")
def step_mr_MR27_followup_input(context):
    context.followup_request = {}
    try:
        response = requests.post(f"{BASE_URL}/error", json=context.followup_request, timeout=10)
    except requests.RequestException as e:
        print(f"Request exception in When step for MR27: {e}")
        assert False

    context.followup_status_code = response.status_code
    context.followup_headers = response.headers

    try:
        context.followup_response = response.json()
    except ValueError:
        context.followup_response = None
        context.followup_response_text = response.text


@then("the follow-up output should return a status of either 'OK' (200) or 'Created' (201), consistent with the documented responses for this operation, and any returned body should conform to a generic object schema (a JSON object with arbitrary properties) for MR27.")
def step_mr_MR27_followup_output(context):
    try:
        # Status code must be one of the documented success codes: 200 or 201
        assert context.followup_status_code in (200, 201)

        # If there is a JSON body, it must be an object (dict) per generic object schema
        if context.followup_response is not None:
            assert isinstance(context.followup_response, dict)
    except AssertionError as e:
        print(f"Assertion error in Then step for MR27: {e}")
        assert False

# ----




@given('a seed input that invokes the PUT method on the error resource, producing a seed output with any returned details represented as a generic object for MR28.')
def step_mr_MR28_seed_input(context):
    context.seed_request = {"exampleKey": "exampleValue"}
    try:
        response = requests.put(f"{BASE_URL}/error", json=context.seed_request, timeout=10)
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Request error in Given step for MR28: {e}") from e

    context.seed_response = response
    # Do not raise for status here to allow explicit verification in Then step if needed


@when('a follow-up input is created by invoking the PUT operation on the same resource again under the same conditions, yielding a follow-up output for MR28.')
def step_mr_MR28_followup_input(context):
    seed_request = getattr(context, "seed_request", None)
    if not isinstance(seed_request, dict):
        raise AssertionError("Seed request is not available or not a dictionary in context.")

    try:
        response = requests.put(f"{BASE_URL}/error", json=seed_request, timeout=10)
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Request error in When step for MR28: {e}") from e

    context.followup_response = response
    # Again, avoid raise_for_status to keep assertion logic centralized


@then("the follow-up output should return a status of either 'OK' (200) or 'Created' (201), consistent with the documented responses for this operation, and any returned body should conform to a generic object schema (a JSON object with arbitrary properties) for MR28.")
def step_mr_MR28_followup_output(context):
    followup_response = getattr(context, "followup_response", None)
    if followup_response is None:
        raise AssertionError("Follow-up response is not available in context.")

    status_code = getattr(followup_response, "status_code", None)
    if not isinstance(status_code, int):
        raise AssertionError(f"Follow-up response has invalid status_code: {status_code!r}")

    if status_code not in (200, 201):
        raise AssertionError(f"Expected status 200 or 201 but got {status_code}")

    # Body may be empty or non-JSON; treat empty body as acceptable, JSON object must be dict
    text_body = followup_response.text or ""
    if not text_body.strip():
        return

    try:
        followup_body = followup_response.json()
    except (ValueError, json.JSONDecodeError) as e:
        raise AssertionError(f"Follow-up response body is not valid JSON: {e}") from e

    if not isinstance(followup_body, dict):
        raise AssertionError("Follow-up response body is not a JSON object (expected generic object schema).")
