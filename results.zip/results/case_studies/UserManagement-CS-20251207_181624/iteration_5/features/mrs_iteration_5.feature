Feature: Iteration 5 MRs

  Scenario: MR25 Deleting a role should result in a reduced role list
    Given a seed input that retrieves the current list of roles, producing a seed output with the total role count for MR25.
    When a follow-up input is created by invoking the DELETE operation on a specific role using its roleId, and then retrieving the list of roles again under the same conditions, yielding a follow-up output for MR25.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR25, provided the targeted role existed, the delete operation returns a documented success status and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR26 Invoking HEAD on error should return a documented success response
    Given a seed input that invokes the HEAD method on the error resource, producing a seed output with the response status and headers for MR26.
    When a follow-up input is created by invoking the HEAD operation on the same resource again under the same conditions, yielding a follow-up output for MR26.
    Then the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation; if any body is present for a 200 response it should conform to a generic object schema (a JSON object with arbitrary properties) for MR26, although a body may be absent for HEAD responses.

  Scenario: MR27 Invoking POST on error should return a documented success response
    Given a seed input that invokes the POST method on the error resource, producing a seed output with any returned details represented as a generic object for MR27.
    When a follow-up input is created by invoking the POST operation on the same resource again under the same conditions, yielding a follow-up output for MR27.
    Then the follow-up output should return a status of either 'OK' (200) or 'Created' (201), consistent with the documented responses for this operation, and any returned body should conform to a generic object schema (a JSON object with arbitrary properties) for MR27.

  Scenario: MR28 Invoking PUT on error should return a documented success response
    Given a seed input that invokes the PUT method on the error resource, producing a seed output with any returned details represented as a generic object for MR28.
    When a follow-up input is created by invoking the PUT operation on the same resource again under the same conditions, yielding a follow-up output for MR28.
    Then the follow-up output should return a status of either 'OK' (200) or 'Created' (201), consistent with the documented responses for this operation, and any returned body should conform to a generic object schema (a JSON object with arbitrary properties) for MR28.
