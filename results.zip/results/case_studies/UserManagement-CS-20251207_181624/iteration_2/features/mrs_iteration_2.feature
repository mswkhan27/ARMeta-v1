Feature: Iteration 2 MRs

  Scenario: MR11 Deleting a role should remove it from the role list
    Given a seed input that retrieves the current list of roles, producing a seed output with the total role count and at least one existing role for MR11.
    When a follow-up input is created by successfully deleting one of the existing roles from the seed output through the role-deletion operation and then retrieving the list of roles again, yielding a follow-up output for MR11.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR11, assuming no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR13 Registering a new user should increase the total user count
    Given a seed input that retrieves the current list of users, producing a seed output with the total user count for MR13.
    When a follow-up input is created by successfully registering a new user account through the user-registration operation and then retrieving the list of users again, yielding a follow-up output for MR13.
    Then the follow-up output should have a user count that is exactly one more than the seed output for MR13, assuming no other user-creation or deletion operations occur between the two retrievals and that all registered users are included in the user list.

  Scenario: MR14 Logging in should return consistent user identity details
    Given a seed input that contains valid login credentials, producing a seed output with user details for MR14.
    When a follow-up input is created by using the same valid login credentials to log in again, yielding a follow-up output for MR14.
    Then the follow-up output should contain the same stable user identity information (such as user id, username, and name-related fields) as the seed output for MR14, indicating consistent user identity details retrieval upon login, even if time-related fields differ between calls.

  Scenario: MR15 Generating a salt should produce a different value across calls
    Given a seed input that invokes the salt-generation operation, producing a seed output with a generated salt value for MR15.
    When a follow-up input is created by invoking the salt-generation operation again under the same conditions, yielding a follow-up output for MR15.
    Then the follow-up output is expected to contain a salt value that is different from the seed output for MR15, indicating variability between successive salt-generation calls.
