from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the current list of roles, producing a seed output with the total role count and at least one existing role for MR11.')
def step_mr_MR11_seed_input(context):
    url = f"{BASE_URL}/users/rbac/roles"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()

        if not isinstance(data, list):
            raise AssertionError(f"Expected a list of roles, but got type {type(data).__name__}")

        if len(data) == 0:
            raise AssertionError("No roles found in the seed output.")

        # Ensure each role has an 'id' that can be used in the DELETE call
        for role in data:
            if not isinstance(role, dict) or 'id' not in role:
                raise AssertionError("Each role item must be an object containing an 'id' field.")

        context.seed_response = data
        context.seed_request = response.request
    except (requests.RequestException, ValueError) as e:
        # ValueError can be raised by response.json()
        print(f"Error in step_mr_MR11_seed_input when calling {url}: {str(e)}")
        raise
    except AssertionError as e:
        print(f"Assertion in step_mr_MR11_seed_input: {str(e)}")
        raise


@when('a follow-up input is created by successfully deleting one of the existing roles from the seed output through the role-deletion operation and then retrieving the list of roles again, yielding a follow-up output for MR11.')
def step_mr_MR11_followup_input(context):
    if not hasattr(context, 'seed_response'):
        raise AssertionError("seed_response not found in context. The Given step may have failed or not run.")

    # Safely pick the first role's id
    first_role = context.seed_response[0]
    role_id_to_delete = first_role.get('id')

    if role_id_to_delete is None:
        raise AssertionError("Selected role does not contain an 'id' field.")

    # Ensure role_id_to_delete is an integer, as required by the API (int64)
    try:
        role_id_to_delete_int = int(role_id_to_delete)
    except (TypeError, ValueError):
        raise AssertionError(f"Role id '{role_id_to_delete}' is not convertible to integer as required by the API.")

    delete_url = f"{BASE_URL}/users/rbac/roles/{role_id_to_delete_int}"
    list_url = f"{BASE_URL}/users/rbac/roles"

    try:
        delete_response = requests.delete(delete_url, timeout=10)
        delete_response.raise_for_status()

        followup_response = requests.get(list_url, timeout=10)
        followup_response.raise_for_status()
        followup_data = followup_response.json()

        if not isinstance(followup_data, list):
            raise AssertionError(f"Expected a list of roles in follow-up response, but got type {type(followup_data).__name__}")

        context.followup_response = followup_data
        context.followup_request = followup_response.request
    except (requests.RequestException, ValueError) as e:
        print(f"Error in step_mr_MR11_followup_input when calling {delete_url} or {list_url}: {str(e)}")
        raise
    except AssertionError as e:
        print(f"Assertion in step_mr_MR11_followup_input: {str(e)}")
        raise


@then('the follow-up output should have a role count that is exactly one less than the seed output for MR11, assuming no other role-creation or deletion operations occur between the two retrievals.')
def step_mr_MR11_followup_output(context):
    if not hasattr(context, 'seed_response'):
        raise AssertionError("seed_response not found in context. The Given step may have failed or not run.")
    if not hasattr(context, 'followup_response'):
        raise AssertionError("followup_response not found in context. The When step may have failed or not run.")

    seed = context.seed_response
    followup = context.followup_response

    if not isinstance(seed, list):
        raise AssertionError(f"Expected seed_response to be a list, but got type {type(seed).__name__}")
    if not isinstance(followup, list):
        raise AssertionError(f"Expected followup_response to be a list, but got type {type(followup).__name__}")

    expected_count = len(seed) - 1
    actual_count = len(followup)

    try:
        assert actual_count == expected_count, (
            f"Expected role count to be {expected_count}, but got {actual_count}."
        )
    except AssertionError as e:
        print(f"Assertion in step_mr_MR11_followup_output: {str(e)}")
        raise

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090').rstrip('/')


@given('a seed input that retrieves the current list of users, producing a seed output with the total user count for MR13.')
def _mr_MR13_seed_input(context):
    url = f"{BASE_URL}/users"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()

        try:
            body = response.json()
        except ValueError:
            raise AssertionError(f"GET {url} did not return valid JSON")

        if not isinstance(body, dict):
            raise AssertionError(f"GET {url} returned JSON of type {type(body)}, expected object")

        user_list = body.get('userList', [])
        if user_list is None:
            user_list = []
        if not isinstance(user_list, list):
            raise AssertionError(f"'userList' is of type {type(user_list)}, expected list")

        context.seed_response = body
        context.seed_request = response.request
        context.seed_user_count = len(user_list)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in Given step for MR13 while calling {url}: {e}") from e


@when('a follow-up input is created by successfully registering a new user account through the user-registration operation and then retrieving the list of users again, yielding a follow-up output for MR13.')
def _mr_MR13_followup_input(context):
    register_url = f"{BASE_URL}/users/register"
    list_url = f"{BASE_URL}/users"

    new_user_data = {
        "username": "mr13_user",
        "password": "password123",
        "name": "New",
        "surname": "User",
        "email": "mr13_user@example.com",
        "gender": "other"
    }

    try:
        register_response = requests.post(register_url, json=new_user_data, timeout=10)
        register_response.raise_for_status()

        followup_response = requests.get(list_url, timeout=10)
        followup_response.raise_for_status()

        try:
            body = followup_response.json()
        except ValueError:
            raise AssertionError(f"GET {list_url} did not return valid JSON")

        if not isinstance(body, dict):
            raise AssertionError(f"GET {list_url} returned JSON of type {type(body)}, expected object")

        user_list = body.get('userList', [])
        if user_list is None:
            user_list = []
        if not isinstance(user_list, list):
            raise AssertionError(f"'userList' is of type {type(user_list)}, expected list")

        context.followup_response = body
        context.followup_request = followup_response.request
        context.followup_user_count = len(user_list)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in When step for MR13 while calling {register_url} or {list_url}: {e}") from e


@then('the follow-up output should have a user count that is exactly one more than the seed output for MR13, assuming no other user-creation or deletion operations occur between the two retrievals and that all registered users are included in the user list.')
def _mr_MR13_followup_output(context):
    if not hasattr(context, 'seed_user_count'):
        raise AssertionError("seed_user_count is not set on context")
    if not hasattr(context, 'followup_user_count'):
        raise AssertionError("followup_user_count is not set on context")

    try:
        expected = context.seed_user_count + 1
    except TypeError as e:
        raise AssertionError(f"User counts are not numeric: "
                             f"seed_user_count={context.seed_user_count!r}, "
                             f"followup_user_count={context.followup_user_count!r}") from e

    assert context.followup_user_count == expected, (
        f"Expected user count to be {expected}, but got {context.followup_user_count}."
    )

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


def _safe_get(d, key, default=None):
    if isinstance(d, dict):
        return d.get(key, default)
    return default


@given("a seed input that contains valid login credentials, producing a seed output with user details for MR14.")
def step_mr_MR14_seed_input(context):
    context.seed_request = {
        "username": "testuser",
        "password": "testpassword",
    }

    response = requests.post(
        f"{BASE_URL}/login",
        json=context.seed_request,
        timeout=10,
    )
    response.raise_for_status()

    try:
        data = response.json()
        if not isinstance(data, dict):
            raise ValueError("Login response is not a JSON object")
    except (ValueError, json.JSONDecodeError) as e:
        raise AssertionError(f"Failed to decode seed login response as JSON object: {e}") from e

    context.seed_response = data


@when("a follow-up input is created by using the same valid login credentials to log in again, yielding a follow-up output for MR14.")
def step_mr_MR14_followup_input(context):
    if not hasattr(context, "seed_request") or not isinstance(context.seed_request, dict):
        raise AssertionError("seed_request is missing or invalid in context")

    response = requests.post(
        f"{BASE_URL}/login",
        json=context.seed_request,
        timeout=10,
    )
    response.raise_for_status()

    try:
        data = response.json()
        if not isinstance(data, dict):
            raise ValueError("Login response is not a JSON object")
    except (ValueError, json.JSONDecodeError) as e:
        raise AssertionError(f"Failed to decode follow-up login response as JSON object: {e}") from e

    context.followup_response = data


@then("the follow-up output should contain the same stable user identity information (such as user id, username, and name-related fields) as the seed output for MR14, indicating consistent user identity details retrieval upon login, even if time-related fields differ between calls.")
def step_mr_MR14_followup_output(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("seed_response is missing or invalid in context")
    if not hasattr(context, "followup_response") or not isinstance(context.followup_response, dict):
        raise AssertionError("followup_response is missing or invalid in context")

    seed = context.seed_response
    follow = context.followup_response

    # Extract fields safely to avoid KeyError / TypeError
    seed_id = _safe_get(seed, "id")
    follow_id = _safe_get(follow, "id")
    seed_username = _safe_get(seed, "username")
    follow_username = _safe_get(follow, "username")
    seed_name = _safe_get(seed, "name")
    follow_name = _safe_get(follow, "name")
    seed_surname = _safe_get(seed, "surname")
    follow_surname = _safe_get(follow, "surname")

    # Assert stable identity fields
    assert seed_id is not None, "Seed response missing 'id'"
    assert follow_id is not None, "Follow-up response missing 'id'"
    assert follow_id == seed_id, f"User ID does not match: seed={seed_id}, follow-up={follow_id}"

    assert seed_username, "Seed response missing or empty 'username'"
    assert follow_username, "Follow-up response missing or empty 'username'"
    assert follow_username == seed_username, (
        f"Username does not match: seed={seed_username}, follow-up={follow_username}"
    )

    # Name-related fields (name and surname) should be stable if present
    if seed_name is not None or follow_name is not None:
        assert follow_name == seed_name, (
            f"Name does not match: seed={seed_name}, follow-up={follow_name}"
        )

    if seed_surname is not None or follow_surname is not None:
        assert follow_surname == seed_surname, (
            f"Surname does not match: seed={seed_surname}, follow-up={follow_surname}"
        )

    # Time-related fields may differ; if both present, just ensure they are strings
    seed_login_dt = _safe_get(seed, "loginDt")
    follow_login_dt = _safe_get(follow, "loginDt")
    if seed_login_dt is not None and follow_login_dt is not None:
        assert isinstance(seed_login_dt, str), "'loginDt' in seed_response should be a string when present"
        assert isinstance(follow_login_dt, str), "'loginDt' in followup_response should be a string when present"

# ----




@given('a seed input that invokes the salt-generation operation, producing a seed output with a generated salt value for MR15.')
def step_mr_MR15_seed_input(context):
    url = f"{BASE_URL}/users/rbac/salt"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in Given step for MR15 when calling {url}: {e}") from e

    # Response schema is a plain string per OpenAPI, so use text safely
    context.seed_response = response.text
    context.seed_request = response.request


@when('a follow-up input is created by invoking the salt-generation operation again under the same conditions, yielding a follow-up output for MR15.')
def step_mr_MR15_followup_input(context):
    url = f"{BASE_URL}/users/rbac/salt"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in When step for MR15 when calling {url}: {e}") from e

    context.followup_response = response.text
    context.followup_request = response.request


@then('the follow-up output is expected to contain a salt value that is different from the seed output for MR15, indicating variability between successive salt-generation calls.')
def step_mr_MR15_assert_variability(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    if seed is None:
        raise AssertionError("Seed response is not available in context.")
    if followup is None:
        raise AssertionError("Follow-up response is not available in context.")

    if not isinstance(seed, str):
        raise AssertionError(f"Seed response is not a string as expected: {type(seed)}")
    if not isinstance(followup, str):
        raise AssertionError(f"Follow-up response is not a string as expected: {type(followup)}")

    assert followup != seed, (
        "The follow-up salt value is not different from the seed salt value; "
        "expected variability between successive /users/rbac/salt calls."
    )
