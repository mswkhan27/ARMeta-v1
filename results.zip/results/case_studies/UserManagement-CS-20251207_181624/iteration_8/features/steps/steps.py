from behave import given, when, then
import os
import json
import requests
import time

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


@given(
    "a seed input that retrieves the current list of roles under valid authorization, "
    "producing a seed output with the total role count for MR33."
)
def step_mr_MR33_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError:
        raise AssertionError("Seed roles response is not valid JSON")

    if not isinstance(data, list):
        raise AssertionError(f"Expected roles list (array), got {type(data).__name__}")

    context.seed_response = data
    context.seed_request = response.request
    context.seed_role_count = len(data)


@when(
    "a follow-up input is created by invoking the DELETE operation on a specific existing role "
    "using its roleId, and then retrieving the list of roles again under the same authorization "
    "conditions, yielding a follow-up output for MR33."
)
def step_mr_MR33_followup_input(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is not available in context")

    if not isinstance(context.seed_response, list):
        raise AssertionError(
            f"Seed response must be a list, got {type(context.seed_response).__name__}"
        )

    if len(context.seed_response) == 0:
        raise AssertionError("No roles available to delete in seed response")

    first_role = context.seed_response[0]
    if not isinstance(first_role, dict):
        raise AssertionError(
            f"Expected role object to be dict, got {type(first_role).__name__}"
        )

    role_id = first_role.get("id")
    if role_id is None:
        raise AssertionError("Role object does not contain 'id' field")

    try:
        role_id_int = int(role_id)
    except (TypeError, ValueError):
        raise AssertionError(f"Role id is not convertible to int: {role_id!r}")

    delete_response = requests.delete(
        f"{BASE_URL}/users/rbac/roles/{role_id_int}", timeout=10
    )
    if delete_response.status_code not in (200, 204):
        raise AssertionError(
            f"Unexpected status code for delete: {delete_response.status_code}"
        )

    followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except ValueError:
        raise AssertionError("Follow-up roles response is not valid JSON")

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"Expected follow-up roles list (array), got {type(followup_data).__name__}"
        )

    context.followup_response = followup_data
    context.followup_request = followup_response.request
    context.followup_role_count = len(followup_data)


@then(
    "the follow-up output should have a role count that is exactly one less than the seed output "
    "for MR33, assuming the delete operation completes successfully with a documented success "
    "status (such as 200 or 204) and no other role-creation or deletion operations occur "
    "between the two retrievals."
)
def step_mr_MR33_assert_followup_output(context):
    if not hasattr(context, "seed_role_count"):
        raise AssertionError("Seed role count is not available in context")
    if not hasattr(context, "followup_role_count"):
        raise AssertionError("Follow-up role count is not available in context")

    seed_count = context.seed_role_count
    followup_count = context.followup_role_count

    try:
        seed_count_int = int(seed_count)
        followup_count_int = int(followup_count)
    except (TypeError, ValueError):
        raise AssertionError(
            f"Role counts must be numeric. Seed: {seed_count!r}, follow-up: {followup_count!r}"
        )

    assert followup_count_int == seed_count_int - 1, (
        f"Expected role count to be {seed_count_int - 1}, "
        f"but got {followup_count_int}."
    )

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the current error state using the HEAD method under valid authorization, producing a seed output with the response status and headers for MR34.')
def step_mr_MR34_seed_input(context):
    url = f"{BASE_URL}/error"
    try:
        response = requests.head(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to {url} failed: {e}") from e

    context.seed_response = response
    status = getattr(response, "status_code", None)
    if status not in (200, 204):
        raise AssertionError(f"Expected status 200 or 204, got {status}")


@when('a follow-up input is created by invoking the HEAD operation on the same error resource again under the same conditions, yielding a follow-up output for MR34.')
def step_mr_MR34_followup_input(context):
    url = f"{BASE_URL}/error"
    try:
        response = requests.head(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to {url} failed: {e}") from e

    context.followup_response = response
    status = getattr(response, "status_code", None)
    if status not in (200, 204):
        raise AssertionError(f"Expected status 200 or 204, got {status}")


@then('the follow-up output should return a status of either "OK" (200) or "No Content" (204), consistent with the documented successful responses for this operation; in the 200 case, if any body is present it should conform to the generic object schema defined for successful error responses for MR34, although a body may be absent for HEAD responses, and this MR assumes that unauthorized or forbidden responses (such as 401 or 403) do not occur in either call.')
def step_mr_MR34_followup_output(context):
    response = getattr(context, "followup_response", None)
    if response is None:
        raise AssertionError("followup_response is missing from context")

    status = getattr(response, "status_code", None)
    if status not in (200, 204):
        raise AssertionError(f"Expected status 200 or 204, got {status}")

    if status == 200:
        # For HEAD, body is usually empty, but if present it must be a JSON object (dict)
        text = response.text or ""
        if not text.strip():
            return

        try:
            body = response.json()
        except ValueError:
            raise AssertionError("Expected JSON body for 200 response, but parsing failed")

        if not isinstance(body, dict):
            raise AssertionError("Response body should be a JSON object (dictionary) for 200 response")
