Feature: Iteration 8 MRs

  Scenario: MR33 Deleting a role should result in a reduced role list
    Given a seed input that retrieves the current list of roles under valid authorization, producing a seed output with the total role count for MR33.
    When a follow-up input is created by invoking the DELETE operation on a specific existing role using its roleId, and then retrieving the list of roles again under the same authorization conditions, yielding a follow-up output for MR33.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR33, assuming the delete operation completes successfully with a documented success status (such as 200 or 204) and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR34 Invoking HEAD on error should return a documented success response
    Given a seed input that retrieves the current error state using the HEAD method under valid authorization, producing a seed output with the response status and headers for MR34.
    When a follow-up input is created by invoking the HEAD operation on the same error resource again under the same conditions, yielding a follow-up output for MR34.
    Then the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented successful responses for this operation; in the 200 case, if any body is present it should conform to the generic object schema defined for successful error responses for MR34, although a body may be absent for HEAD responses, and this MR assumes that unauthorized or forbidden responses (such as 401 or 403) do not occur in either call.
