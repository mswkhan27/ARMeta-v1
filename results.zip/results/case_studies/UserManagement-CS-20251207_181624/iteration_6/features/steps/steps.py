from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the current list of roles as an array of role objects, producing a seed output with the total role count derived from that list for MR29.')
def step_mr_MR29_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    try:
        response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Failed to retrieve initial role list for MR29: {e}") from e

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Response from /users/rbac/roles is not valid JSON: {e}") from e

    if not isinstance(data, list):
        raise AssertionError(
            f"Expected /users/rbac/roles to return a list, but got {type(data).__name__}: {data}"
        )

    context.seed_response = data
    context.seed_request = response.request
    context.seed_output_count = len(data)


@when('a follow-up input is created by invoking the DELETE operation on a specific role using its roleId (where that roleId is present in the seed role list), and then retrieving the list of roles again, yielding a follow-up output for MR29.')
def step_mr_MR29_followup_input(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response not found in context. GIVEN step may have failed or not been executed.")

    seed_roles = context.seed_response
    if not isinstance(seed_roles, list):
        raise AssertionError(
            f"Seed response is expected to be a list, but got {type(seed_roles).__name__}: {seed_roles}"
        )

    if not seed_roles:
        raise AssertionError("Seed response is empty; cannot proceed with deletion for MR29.")

    first_role = seed_roles[0]
    if not isinstance(first_role, dict):
        raise AssertionError(
            f"Each role should be a dict/object, but got {type(first_role).__name__}: {first_role}"
        )

    if "id" not in first_role:
        raise AssertionError(f"Role object does not contain 'id' field: {first_role}")

    role_id = first_role["id"]
    if not isinstance(role_id, int):
        raise AssertionError(f"Role id should be an integer (int64), but got {type(role_id).__name__}: {role_id}")

    delete_response = requests.delete(f"{BASE_URL}/users/rbac/roles/{role_id}", timeout=10)

    # Allow any 2xx success code, but ensure it is a documented success (200 or 204 preferred)
    if not (200 <= delete_response.status_code < 300):
        raise AssertionError(
            f"DELETE /users/rbac/roles/{{roleId}} did not succeed. "
            f"Status: {delete_response.status_code}, Body: {delete_response.text}"
        )

    followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    try:
        followup_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Failed to retrieve follow-up role list for MR29: {e}") from e

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response from /users/rbac/roles is not valid JSON: {e}") from e

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"Expected follow-up /users/rbac/roles to return a list, but got {type(followup_data).__name__}: {followup_data}"
        )

    context.followup_response = followup_data
    context.followup_request = followup_response.request
    context.followup_output_count = len(followup_data)


@then('the follow-up output should have a role count that is exactly one less than the seed output for MR29, provided the delete operation completes successfully (for example, returning a documented success status such as 200 or 204), the targeted role existed in the seed list, and no other role-creation or deletion operations occur between the two retrievals.')
def step_mr_MR29_followup_output(context):
    if not hasattr(context, "seed_output_count"):
        raise AssertionError("Seed output count not found in context; GIVEN step may not have run correctly.")
    if not hasattr(context, "followup_output_count"):
        raise AssertionError("Follow-up output count not found in context; WHEN step may not have run correctly.")

    seed_count = context.seed_output_count
    followup_count = context.followup_output_count

    if not isinstance(seed_count, int):
        raise AssertionError(f"Seed output count must be int, got {type(seed_count).__name__}: {seed_count}")
    if not isinstance(followup_count, int):
        raise AssertionError(f"Follow-up output count must be int, got {type(followup_count).__name__}: {followup_count}")

    expected = seed_count - 1
    assert followup_count == expected, (
        f"Expected role count after deletion to be {expected}, but got {followup_count}. "
        f"Seed roles: {seed_count}, Follow-up roles: {followup_count}"
    )

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


@given("a seed input that invokes the error handling resource using the HEAD method, producing a seed output with the response status and headers for MR30.")
def step_mr_MR30_seed_input(context):
    url = f"{BASE_URL}/error"
    try:
        response = requests.head(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to {url} failed in Given step for MR30: {e}") from e

    if response is None:
        raise AssertionError("No response received in Given step for MR30")

    if response.status_code not in (200, 204):
        raise AssertionError(
            f"Expected status code 200 or 204 in Given step for MR30, got {response.status_code}"
        )

    context.seed_response = response
    context.seed_request = {
        "method": "HEAD",
        "url": url,
        "status_code": response.status_code,
        "headers": dict(response.headers) if response.headers is not None else {},
    }


@when("a follow-up input is created by invoking the HEAD operation on the same resource again under the same conditions, yielding a follow-up output for MR30.")
def step_mr_MR30_followup_input(context):
    url = f"{BASE_URL}/error"
    try:
        response = requests.head(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to {url} failed in When step for MR30: {e}") from e

    if response is None:
        raise AssertionError("No response received in When step for MR30")

    if response.status_code not in (200, 204):
        raise AssertionError(
            f"Expected status code 200 or 204 in When step for MR30, got {response.status_code}"
        )

    context.followup_response = response
    context.followup_request = {
        "method": "HEAD",
        "url": url,
        "status_code": response.status_code,
        "headers": dict(response.headers) if response.headers is not None else {},
    }


@then("the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation; if the status is 200 and any body is present it should conform to the documented generic object schema for this resource, while for a 204 response no body should be present, and the status and header structure should remain consistent between the seed and follow-up calls for MR30.")
def step_mr_MR30_followup_output(context):
    followup = getattr(context, "followup_response", None)
    seed = getattr(context, "seed_response", None)

    if followup is None or seed is None:
        raise AssertionError("Seed or follow-up response missing in Then step for MR30")

    status = followup.status_code
    if status not in (200, 204):
        raise AssertionError(
            f"Expected status code 200 or 204 in Then step for MR30, got {status}"
        )

    # For HEAD, a body is generally not expected; enforce no body for both 200 and 204
    content = followup.content if hasattr(followup, "content") else b""
    if content not in (b"", None):
        raise AssertionError(
            f"Expected no response body for HEAD request in Then step for MR30, "
            f"but received content of length {len(content)}"
        )

    # Compare header structure (set of header names)
    seed_headers = dict(seed.headers) if seed.headers is not None else {}
    followup_headers = dict(followup.headers) if followup.headers is not None else {}

    if set(seed_headers.keys()) != set(followup_headers.keys()):
        raise AssertionError(
            "Header structure (set of header names) should remain consistent between "
            "seed and follow-up responses for MR30"
        )
