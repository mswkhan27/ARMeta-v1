Feature: Iteration 6 MRs

  Scenario: MR29 Deleting a role should result in a reduced role list
    Given a seed input that retrieves the current list of roles as an array of role objects, producing a seed output with the total role count derived from that list for MR29.
    When a follow-up input is created by invoking the DELETE operation on a specific role using its roleId (where that roleId is present in the seed role list), and then retrieving the list of roles again, yielding a follow-up output for MR29.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR29, provided the delete operation completes successfully (for example, returning a documented success status such as 200 or 204), the targeted role existed in the seed list, and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR30 Invoking HEAD on error should return a documented success response
    Given a seed input that invokes the error handling resource using the HEAD method, producing a seed output with the response status and headers for MR30.
    When a follow-up input is created by invoking the HEAD operation on the same resource again under the same conditions, yielding a follow-up output for MR30.
    Then the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation; if the status is 200 and any body is present it should conform to the documented generic object schema for this resource, while for a 204 response no body should be present, and the status and header structure should remain consistent between the seed and follow-up calls for MR30.
