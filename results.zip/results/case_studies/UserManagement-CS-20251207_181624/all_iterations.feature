
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a role to a user should include the new role in the user's role list
    Given a seed input that retrieves a user's details, including the current set of roles, producing a seed output with the user's roles for MR1.
    When a follow-up input is created by invoking an operation that adds a new role to the same user and then retrieving the user's details again, yielding a follow-up output for MR1.
    Then the follow-up output should include all roles from the seed output plus the newly added role for MR1, with no previously existing role removed.

  Scenario: MR2 Removing a role from a user should exclude the role from the user's role list
    Given a seed input that retrieves a user's details, including the current set of roles, producing a seed output with the user's roles for MR2.
    When a follow-up input is created by invoking an operation that removes one existing role from the same user and then retrieving the user's details again, yielding a follow-up output for MR2.
    Then the follow-up output should contain all roles from the seed output except the removed role for MR2; the removed role must no longer appear in the user's role list.

  Scenario: MR3 Updating user information should primarily affect the updated fields
    Given a seed input that retrieves a user's current information, producing a seed output with the user's details for MR3.
    When a follow-up input is created by invoking an operation that updates one field in the user's information and then retrieving the user's details again, yielding a follow-up output for MR3.
    Then the follow-up output should reflect a change in the explicitly updated field for MR3, while other business data fields that were not updated should remain identical to the seed output; only server-managed metadata (such as timestamps or audit fields) may differ.

  Scenario: MR4 Creating a new user should increase the total user count
    Given a seed input that retrieves the current list of users, producing a seed output with the total user count for MR4.
    When a follow-up input is created by creating a new user and then retrieving the list of users again, yielding a follow-up output for MR4.
    Then the follow-up output should have a user count that is exactly one more than the seed output for MR4, assuming no other user-creation or deletion operations occur between the two retrievals.

  Scenario: MR5 Deleting a user should decrease the total user count
    Given a seed input that retrieves the current list of users, producing a seed output with the total user count for MR5.
    When a follow-up input is created by deleting an existing user and then retrieving the list of users again, yielding a follow-up output for MR5.
    Then the follow-up output should have a user count that is exactly one less than the seed output for MR5, assuming no other user-creation or deletion operations occur between the two retrievals.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR6 Deleting a permission should remove it from the permission list
    Given a seed input that retrieves the current list of permissions, producing a seed output with the total permission count for MR6.
    When a follow-up input is created by deleting an existing permission through the permission-deletion operation and then retrieving the list of permissions again, yielding a follow-up output for MR6.
    Then the follow-up output should have a permission count that is exactly one less than the seed output for MR6, assuming no other permission-creation or deletion operations occur between the two retrievals.

  Scenario: MR7 Adding a permission to a role should include the new permission in the role's permission list
    Given a seed input that retrieves a role's details, including the current set of permissions, producing a seed output with the role's permissions for MR7.
    When a follow-up input is created by invoking the operation that adds a permission to a role for the same role and permission key, and then retrieving the role's details again, yielding a follow-up output for MR7.
    Then the follow-up output should include all permissions from the seed output plus the newly added permission for MR7, with no previously existing permission removed.

  Scenario: MR8 Removing a permission from a role should exclude the permission from the role's permission list
    Given a seed input that retrieves a role's details, including the current set of permissions, producing a seed output with the role's permissions for MR8.
    When a follow-up input is created by invoking the operation that removes a permission from a role for one existing permission on the same role and then retrieving the role's details again, yielding a follow-up output for MR8.
    Then the follow-up output should contain all permissions from the seed output except the removed permission for MR8; the removed permission must no longer appear in the role's permission list.

  Scenario: MR9 Generating a salt should be capable of producing different values across invocations
    Given a seed input that invokes the salt-generation operation, producing a seed output with a generated salt value for MR9.
    When a follow-up input is created by invoking the salt-generation operation again, yielding a follow-up output for MR9.
    Then the follow-up output is expected to contain a salt value that is different from the seed output for MR9, indicating variability between successive salt-generation calls.

  Scenario: MR10 Updating a permission should modify only the updated fields
    Given a seed input that retrieves a permission's current information, producing a seed output with the permission's details for MR10.
    When a follow-up input is created by invoking the permission-update operation to change one specific field in the permission's information and then retrieving the permission's details again, yielding a follow-up output for MR10.
    Then the follow-up output should reflect a change in the explicitly updated field for MR10, while other fields in the permission data that were not updated in the request should remain identical to the seed output.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR11 Deleting a role should remove it from the role list
    Given a seed input that retrieves the current list of roles, producing a seed output with the total role count and at least one existing role for MR11.
    When a follow-up input is created by successfully deleting one of the existing roles from the seed output through the role-deletion operation and then retrieving the list of roles again, yielding a follow-up output for MR11.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR11, assuming no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR13 Registering a new user should increase the total user count
    Given a seed input that retrieves the current list of users, producing a seed output with the total user count for MR13.
    When a follow-up input is created by successfully registering a new user account through the user-registration operation and then retrieving the list of users again, yielding a follow-up output for MR13.
    Then the follow-up output should have a user count that is exactly one more than the seed output for MR13, assuming no other user-creation or deletion operations occur between the two retrievals and that all registered users are included in the user list.

  Scenario: MR14 Logging in should return consistent user identity details
    Given a seed input that contains valid login credentials, producing a seed output with user details for MR14.
    When a follow-up input is created by using the same valid login credentials to log in again, yielding a follow-up output for MR14.
    Then the follow-up output should contain the same stable user identity information (such as user id, username, and name-related fields) as the seed output for MR14, indicating consistent user identity details retrieval upon login, even if time-related fields differ between calls.

  Scenario: MR15 Generating a salt should produce a different value across calls
    Given a seed input that invokes the salt-generation operation, producing a seed output with a generated salt value for MR15.
    When a follow-up input is created by invoking the salt-generation operation again under the same conditions, yielding a follow-up output for MR15.
    Then the follow-up output is expected to contain a salt value that is different from the seed output for MR15, indicating variability between successive salt-generation calls.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR16 Deleting an error should return a documented success response
    Given a seed input that retrieves the current error state, producing a seed output with the error details represented as a generic object for MR16.
    When a follow-up input is created by invoking the DELETE operation on the error resource, yielding a follow-up output for MR16.
    Then the follow-up output should return a status of either 'OK' (200) with a generic object body or 'No Content' (204), consistent with the documented responses for this operation, and any returned body should conform to the generic object schema used for error representations for MR16.

  Scenario: MR17 Deleting a role should result in a reduced role list
    Given a seed input that retrieves the current list of roles, producing a seed output with the total role count for MR17.
    When a follow-up input is created by invoking the DELETE operation on a specific role using its roleId, and then retrieving the list of roles again, yielding a follow-up output for MR17.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR17, assuming the delete operation succeeds and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR19 Registering a new user should increase the user count
    Given a seed input that retrieves the current list of users, producing a seed output with the total user count for MR19.
    When a follow-up input is created by invoking the POST operation that registers a new user account, and then retrieving the list of users again, yielding a follow-up output for MR19.
    Then the follow-up output should have a user count that is exactly one more than the seed output for MR19, assuming the registration operation succeeds and no other user-creation or deletion operations occur between the two retrievals.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR20 Deleting a role should result in a reduced role list
    Given a seed input that retrieves the current list of roles, producing a seed output whose total role count is derived from the number of items returned for MR20.
    When a follow-up input is created by invoking the DELETE operation on a specific role using its roleId, and then retrieving the list of roles again, yielding a follow-up output for MR20.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR20, assuming the delete operation succeeds for an existing role and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR21 Generating a salt should produce a different value across calls
    Given a seed input that invokes the salt-generation operation, producing a seed output with a generated salt value represented as a string for MR21.
    When a follow-up input is created by invoking the salt-generation operation again under the same conditions, yielding a follow-up output with another generated string value for MR21.
    Then the follow-up output is expected to contain a salt value that is different from the seed output for MR21, indicating variability between successive salt-generation calls while still conforming to the documented string return type.

  Scenario: MR22 Invoking HEAD on error should return a documented success response
    Given a seed input that retrieves the current error state using the HEAD method, producing a seed output with the response status and headers for MR22.
    When a follow-up input is created by invoking the HEAD operation on the error resource again under the same conditions, yielding a follow-up output for MR22.
    Then the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation, and if any body is present it should conform to the generic object schema used for error representations for MR22, although a body may be absent for HEAD responses.

  Scenario: MR23 Invoking OPTIONS on error should return a consistent response structure
    Given a seed input that retrieves the current error state using the OPTIONS method, producing a seed output with the response status, headers, and any generic object body for MR23.
    When a follow-up input is created by invoking the OPTIONS operation on the error resource again under the same conditions, yielding a follow-up output for MR23.
    Then the follow-up output should be consistent with the seed output for MR23 in terms of response status code being one of the documented success codes and the presence and structure of any generic object body, assuming no configuration or deployment changes occur between the two calls.

  Scenario: MR24 Invoking PATCH on error should return a documented success response
    Given a seed input that retrieves the current error state using the PATCH method, producing a seed output with the error details represented as a generic object when a body is returned for MR24.
    When a follow-up input is created by invoking the PATCH operation on the error resource again under the same conditions, yielding a follow-up output for MR24.
    Then the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation, and any returned body for a 200 response should conform to the generic object schema used for error representations for MR24.


# --- From iteration_5\features\mrs_iteration_5.feature ---

Feature: Iteration 5 MRs

  Scenario: MR25 Deleting a role should result in a reduced role list
    Given a seed input that retrieves the current list of roles, producing a seed output with the total role count for MR25.
    When a follow-up input is created by invoking the DELETE operation on a specific role using its roleId, and then retrieving the list of roles again under the same conditions, yielding a follow-up output for MR25.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR25, provided the targeted role existed, the delete operation returns a documented success status and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR26 Invoking HEAD on error should return a documented success response
    Given a seed input that invokes the HEAD method on the error resource, producing a seed output with the response status and headers for MR26.
    When a follow-up input is created by invoking the HEAD operation on the same resource again under the same conditions, yielding a follow-up output for MR26.
    Then the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation; if any body is present for a 200 response it should conform to a generic object schema (a JSON object with arbitrary properties) for MR26, although a body may be absent for HEAD responses.

  Scenario: MR27 Invoking POST on error should return a documented success response
    Given a seed input that invokes the POST method on the error resource, producing a seed output with any returned details represented as a generic object for MR27.
    When a follow-up input is created by invoking the POST operation on the same resource again under the same conditions, yielding a follow-up output for MR27.
    Then the follow-up output should return a status of either 'OK' (200) or 'Created' (201), consistent with the documented responses for this operation, and any returned body should conform to a generic object schema (a JSON object with arbitrary properties) for MR27.

  Scenario: MR28 Invoking PUT on error should return a documented success response
    Given a seed input that invokes the PUT method on the error resource, producing a seed output with any returned details represented as a generic object for MR28.
    When a follow-up input is created by invoking the PUT operation on the same resource again under the same conditions, yielding a follow-up output for MR28.
    Then the follow-up output should return a status of either 'OK' (200) or 'Created' (201), consistent with the documented responses for this operation, and any returned body should conform to a generic object schema (a JSON object with arbitrary properties) for MR28.


# --- From iteration_6\features\mrs_iteration_6.feature ---

Feature: Iteration 6 MRs

  Scenario: MR29 Deleting a role should result in a reduced role list
    Given a seed input that retrieves the current list of roles as an array of role objects, producing a seed output with the total role count derived from that list for MR29.
    When a follow-up input is created by invoking the DELETE operation on a specific role using its roleId (where that roleId is present in the seed role list), and then retrieving the list of roles again, yielding a follow-up output for MR29.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR29, provided the delete operation completes successfully (for example, returning a documented success status such as 200 or 204), the targeted role existed in the seed list, and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR30 Invoking HEAD on error should return a documented success response
    Given a seed input that invokes the error handling resource using the HEAD method, producing a seed output with the response status and headers for MR30.
    When a follow-up input is created by invoking the HEAD operation on the same resource again under the same conditions, yielding a follow-up output for MR30.
    Then the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation; if the status is 200 and any body is present it should conform to the documented generic object schema for this resource, while for a 204 response no body should be present, and the status and header structure should remain consistent between the seed and follow-up calls for MR30.


# --- From iteration_7\features\mrs_iteration_7.feature ---

Feature: Iteration 7 MRs

  Scenario: MR31 Deleting an existing role should result in a reduced role list
    Given a seed input that retrieves the current list of roles, producing a seed output with the total role count and including a specific existing role identified by its roleId for MR31.
    When a follow-up input is created by invoking the DELETE operation on that existing role using its roleId, and, after a successful deletion response, retrieving the list of roles again, yielding a follow-up output for MR31.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR31, provided that the specified role was present in the seed list, the delete operation succeeds, and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR32 Invoking HEAD on the error resource twice under the same conditions should yield consistent documented responses
    Given a seed input that retrieves the current error state using the HEAD method, producing a seed output with the response status and headers for MR32 under specific authentication and authorization conditions.
    When a follow-up input is created by invoking the HEAD operation on the same error resource again under the same authentication, authorization, and request conditions, yielding a follow-up output for MR32.
    Then the follow-up output should return a status that is one of the documented response codes for this operation (200, 204, 401, or 403) and should match the seed output status when the conditions are unchanged; if a body is present with a 200 response, it should conform to the generic object schema used for error representations for MR32, although a body may be absent for HEAD responses.


# --- From iteration_8\features\mrs_iteration_8.feature ---

Feature: Iteration 8 MRs

  Scenario: MR33 Deleting a role should result in a reduced role list
    Given a seed input that retrieves the current list of roles under valid authorization, producing a seed output with the total role count for MR33.
    When a follow-up input is created by invoking the DELETE operation on a specific existing role using its roleId, and then retrieving the list of roles again under the same authorization conditions, yielding a follow-up output for MR33.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR33, assuming the delete operation completes successfully with a documented success status (such as 200 or 204) and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR34 Invoking HEAD on error should return a documented success response
    Given a seed input that retrieves the current error state using the HEAD method under valid authorization, producing a seed output with the response status and headers for MR34.
    When a follow-up input is created by invoking the HEAD operation on the same error resource again under the same conditions, yielding a follow-up output for MR34.
    Then the follow-up output should return a status of either 'OK' (200) or 'No Content' (204), consistent with the documented successful responses for this operation; in the 200 case, if any body is present it should conform to the generic object schema defined for successful error responses for MR34, although a body may be absent for HEAD responses, and this MR assumes that unauthorized or forbidden responses (such as 401 or 403) do not occur in either call.


# --- From iteration_9\features\mrs_iteration_9.feature ---

Feature: Iteration 9 MRs

  Scenario: MR35 Deleting a role should result in a reduced role list
    Given a seed input that retrieves the current list of roles, producing a seed output with the total role count for MR35.
    When a follow-up input is created by invoking the DELETE operation on a specific role using its roleId, and then retrieving the list of roles again, yielding a follow-up output for MR35.
    Then the follow-up output should have a role count that is exactly one less than the seed output for MR35, assuming the delete operation returns a success status (such as 200 or 204), the targeted role existed before deletion, and no other role-creation or deletion operations occur between the two retrievals.

  Scenario: MR36 Invoking HEAD on error should return a documented success response
    Given a seed input that retrieves the current error state using the HEAD method, producing a seed output with the response status and headers for MR36.
    When a follow-up input is created by invoking the HEAD operation on the error resource again under the same conditions, yielding a follow-up output for MR36.
    Then under identical authorization and access conditions, the follow-up output's status code should match the seed output's status code and, when successful, be either 'OK' (200) or 'No Content' (204), consistent with the documented responses for this operation; if any body is present it should conform to a generic object schema for MR36, although a body may be absent for HEAD responses.

