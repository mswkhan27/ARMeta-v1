from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the current list of permissions, producing a seed output with the total permission count for MR6.')
def _mr_MR6_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Response from /users/rbac/permissions is not valid JSON: {e}")

    if not isinstance(data, list):
        raise AssertionError(
            f"Expected a list from /users/rbac/permissions, but got {type(data).__name__}: {data}"
        )

    context.seed_response = data
    context.seed_request = response.request
    context.seed_permission_count = len(data)


@when('a follow-up input is created by deleting an existing permission through the permission-deletion operation and then retrieving the list of permissions again, yielding a follow-up output for MR6.')
def _mr_MR6_followup_input(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response is not set in context. The Given step may have failed or not run.")

    if not isinstance(context.seed_response, list):
        raise AssertionError(
            f"seed_response must be a list, but is {type(context.seed_response).__name__}: {context.seed_response}"
        )

    if not context.seed_response:
        raise AssertionError(
            "No permissions available to delete in seed_response; cannot perform deletion for MR6."
        )

    first_perm = context.seed_response[0]
    if not isinstance(first_perm, dict):
        raise AssertionError(
            f"Each permission should be a dict, but first element is {type(first_perm).__name__}: {first_perm}"
        )

    permission_key = first_perm.get("permission")
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError(
            f"Permission object does not contain a valid 'permission' string field: {first_perm}"
        )

    delete_response = requests.delete(
        f"{BASE_URL}/users/rbac/permissions/{permission_key}",
        timeout=10
    )
    delete_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response from /users/rbac/permissions is not valid JSON: {e}")

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"Expected a list from follow-up /users/rbac/permissions, but got {type(followup_data).__name__}: {followup_data}"
        )

    context.followup_response = followup_data
    context.followup_request = followup_response.request
    context.followup_permission_count = len(followup_data)


@then('the follow-up output should have a permission count that is exactly one less than the seed output for MR6, assuming no other permission-creation or deletion operations occur between the two retrievals.')
def _mr_MR6_followup_output(context):
    if not hasattr(context, "seed_permission_count"):
        raise AssertionError("seed_permission_count not found in context.")
    if not hasattr(context, "followup_permission_count"):
        raise AssertionError("followup_permission_count not found in context.")

    seed_count = context.seed_permission_count
    followup_count = context.followup_permission_count

    if not isinstance(seed_count, int):
        raise AssertionError(f"seed_permission_count must be int, got {type(seed_count).__name__}: {seed_count}")
    if not isinstance(followup_count, int):
        raise AssertionError(f"followup_permission_count must be int, got {type(followup_count).__name__}: {followup_count}")

    expected = seed_count - 1
    assert followup_count == expected, (
        f"Expected permission count to be {expected}, but got {followup_count}."
    )

# ----




def _safe_get_json(response):
    try:
        return response.json()
    except ValueError:
        return {}


@given("a seed input that retrieves a role's details, including the current set of permissions, producing a seed output with the role's permissions for MR7.")
def _mr_MR7_seed_input(context):
    # Create a role if it doesn't exist (createRoleUsingPOST: POST /users/rbac/roles)
    role_data = "test_role"
    response = requests.post(
        f"{BASE_URL}/users/rbac/roles",
        json=role_data,
        timeout=10,
    )
    response.raise_for_status()
    role_body = _safe_get_json(response)
    context.role_id = role_body.get("id")
    if context.role_id is None:
        raise AssertionError("Role ID is missing in createRole response.")

    # Retrieve the role's details (getRoleByIdUsingGET: GET /users/rbac/roles/\{roleId\})
    response = requests.get(
        f"{BASE_URL}/users/rbac/roles/{context.role_id}",
        timeout=10,
    )
    response.raise_for_status()
    context.seed_response = _safe_get_json(response)
    context.seed_request = getattr(response.request, "body", None)


@when("a follow-up input is created by invoking the operation that adds a permission to a role for the same role and permission key, and then retrieving the role's details again, yielding a follow-up output for MR7.")
def _mr_MR7_followup_input(context):
    # Define the permission to add (createPermissionUsingPOST: POST /users/rbac/permissions)
    permission_data = {
        "enabled": True,
        "note": "MR7 test permission",
        "permission": "test_permission_mr7",
    }
    response = requests.post(
        f"{BASE_URL}/users/rbac/permissions",
        json=permission_data,
        timeout=10,
    )
    response.raise_for_status()
    perm_body = _safe_get_json(response)
    context.permission_key = perm_body.get("permission")
    if not context.permission_key:
        raise AssertionError("Permission key is missing in createPermission response.")

    # Add the permission to the role (addPermissionOnRoleUsingPOST: POST /users/rbac/roles/\{roleId\}/permissions/\{permissionKey\})
    response = requests.post(
        f"{BASE_URL}/users/rbac/roles/{context.role_id}/permissions/{context.permission_key}",
        timeout=10,
    )
    response.raise_for_status()

    # Retrieve the role's details again (getRoleByIdUsingGET: GET /users/rbac/roles/\{roleId\})
    response = requests.get(
        f"{BASE_URL}/users/rbac/roles/{context.role_id}",
        timeout=10,
    )
    response.raise_for_status()
    context.followup_response = _safe_get_json(response)
    context.followup_request = getattr(response.request, "body", None)


@then("the follow-up output should include all permissions from the seed output plus the newly added permission for MR7, with no previously existing permission removed.")
def _mr_MR7_followup_output(context):
    seed_permissions_raw = context.seed_response.get("permissions") or []
    followup_permissions_raw = context.followup_response.get("permissions") or []

    def _extract_permission_name(perm):
        if not isinstance(perm, dict):
            return None
        value = perm.get("permission")
        return value if isinstance(value, str) else None

    seed_permissions = {
        name
        for name in (_extract_permission_name(p) for p in seed_permissions_raw)
        if name is not None
    }
    followup_permissions = {
        name
        for name in (_extract_permission_name(p) for p in followup_permissions_raw)
        if name is not None
    }

    if not isinstance(context.permission_key, str):
        raise AssertionError("Stored permission_key is not a string.")

    assert context.permission_key in followup_permissions, "New permission was not added."
    assert seed_permissions.issubset(
        followup_permissions
    ), "Not all seed permissions are present in follow-up output."

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")




def _ensure_role_created():
    role_data = "TestRole"
    response = requests.post(
        f"{BASE_URL}/users/rbac/roles",
        json=role_data,
        timeout=10,
    )
    response.raise_for_status()
    body = _safe_get_json(response)
    role_id = body.get("id")
    if role_id is None:
        raise AssertionError("Role creation response does not contain 'id'.")
    if not isinstance(role_id, int):
        raise AssertionError(f"Role id should be int, got {type(role_id).__name__}.")
    return role_id


def _ensure_permission_created():
    permission_data = {
        "permission": "TestPermission",
        "enabled": True,
        "note": "MR8 test permission",
    }
    response = requests.post(
        f"{BASE_URL}/users/rbac/permissions",
        json=permission_data,
        timeout=10,
    )
    response.raise_for_status()
    body = _safe_get_json(response)
    permission_key = body.get("permission")
    if not permission_key:
        raise AssertionError("Permission creation response does not contain 'permission'.")
    return permission_key


def _get_role_details(role_id):
    response = requests.get(
        f"{BASE_URL}/users/rbac/roles/{role_id}",
        timeout=10,
    )
    response.raise_for_status()
    body = _safe_get_json(response)
    if not isinstance(body, dict):
        raise AssertionError("Role details response JSON is not an object.")
    return body


@given("a seed input that retrieves a role's details, including the current set of permissions, producing a seed output with the role's permissions for MR8.")
def step_mr_MR8_seed_input(context):
    role_id = _ensure_role_created()
    context.role_id = role_id
    seed_response = _get_role_details(role_id)
    permissions = seed_response.get("permissions", [])
    if permissions is None:
        permissions = []
    if not isinstance(permissions, list):
        raise AssertionError("Role 'permissions' field is not a list.")
    context.seed_response = seed_response


@when("a follow-up input is created by invoking the operation that removes a permission from a role for one existing permission on the same role and then retrieving the role's details again, yielding a follow-up output for MR8.")
def step_mr_MR8_followup_input(context):
    if not hasattr(context, "role_id"):
        raise AssertionError("role_id is not set in context from Given step.")
    role_id = context.role_id

    permission_key = _ensure_permission_created()
    context.permission_key = permission_key

    add_resp = requests.post(
        f"{BASE_URL}/users/rbac/roles/{role_id}/permissions/{permission_key}",
        timeout=10,
    )
    add_resp.raise_for_status()

    delete_resp = requests.delete(
        f"{BASE_URL}/users/rbac/roles/{role_id}/permissions/{permission_key}",
        timeout=10,
    )
    delete_resp.raise_for_status()

    followup_response = _get_role_details(role_id)
    permissions = followup_response.get("permissions", [])
    if permissions is None:
        permissions = []
    if not isinstance(permissions, list):
        raise AssertionError("Follow-up role 'permissions' field is not a list.")
    context.followup_response = followup_response


@then("the follow-up output should contain all permissions from the seed output except the removed permission for MR8; the removed permission must no longer appear in the role's permission list.")
def step_mr_MR8_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response is not available in context.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("followup_response is not available in context.")
    if not hasattr(context, "permission_key"):
        raise AssertionError("permission_key is not available in context.")

    seed_permissions_raw = context.seed_response.get("permissions", [])
    if seed_permissions_raw is None:
        seed_permissions_raw = []
    followup_permissions_raw = context.followup_response.get("permissions", [])
    if followup_permissions_raw is None:
        followup_permissions_raw = []

    if not isinstance(seed_permissions_raw, list):
        raise AssertionError("Seed 'permissions' field is not a list.")
    if not isinstance(followup_permissions_raw, list):
        raise AssertionError("Follow-up 'permissions' field is not a list.")

    def _extract_permission_keys(perm_list):
        keys = set()
        for item in perm_list:
            if isinstance(item, dict):
                key = item.get("permission")
                if isinstance(key, str):
                    keys.add(key)
        return keys

    seed_permissions = _extract_permission_keys(seed_permissions_raw)
    followup_permissions = _extract_permission_keys(followup_permissions_raw)

    removed_key = context.permission_key

    assert removed_key not in followup_permissions, (
        "Removed permission still exists in follow-up output."
    )

    expected_followup_permissions = seed_permissions - {removed_key}
    assert expected_followup_permissions.issubset(followup_permissions), (
        "Follow-up permissions do not contain all expected permissions after removal."
    )

# ----




@given('a seed input that invokes the salt-generation operation, producing a seed output with a generated salt value for MR9.')
def step_mr_MR9_seed_input(context):
    url = f"{BASE_URL}/users/rbac/salt"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error during seed salt-generation call (MR9): {e}")

    # /users/rbac/salt returns a plain string according to the OpenAPI spec
    context.seed_response = response.text if response.text is not None else ""
    context.seed_request = response.request


@when('a follow-up input is created by invoking the salt-generation operation again, yielding a follow-up output for MR9.')
def step_mr_MR9_followup_input(context):
    url = f"{BASE_URL}/users/rbac/salt"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error during follow-up salt-generation call (MR9): {e}")

    context.followup_response = response.text if response.text is not None else ""
    context.followup_request = response.request


@then('the follow-up output is expected to contain a salt value that is different from the seed output for MR9, indicating variability between successive salt-generation calls.')
def step_mr_MR9_followup_output(context):
    seed = getattr(context, "seed_response", "")
    followup = getattr(context, "followup_response", "")

    if not isinstance(seed, str):
        seed = str(seed)
    if not isinstance(followup, str):
        followup = str(followup)

    assert followup != seed, "The follow-up output is not different from the seed output for MR9."

# ----

import copy



@given("a seed input that retrieves a permission's current information, producing a seed output with the permission's details for MR10.")
def _mr_MR10_seed_input(context):
    # Retrieve the current permissions list
    response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
    response.raise_for_status()

    data = response.json()
    if not isinstance(data, list) or not data:
        raise AssertionError("No permissions found to retrieve for MR10.")

    seed_permission = data[0]
    if not isinstance(seed_permission, dict):
        raise AssertionError("Seed permission is not an object as expected.")

    # We need the permissionKey (string) to use /users/rbac/permissions/\{permissionKey\}
    permission_key = seed_permission.get("permission")
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError("Seed permission does not contain a valid 'permission' field to use as permissionKey.")

    context.seed_permission = seed_permission
    context.permission_key = permission_key

    # Make a separate copy to avoid accidental mutation
    context.seed_permission_copy = copy.deepcopy(seed_permission)


@when("a follow-up input is created by invoking the permission-update operation to change one specific field in the permission's information and then retrieving the permission's details again, yielding a follow-up output for MR10.")
def _mr_MR10_followup_input(context):
    if not hasattr(context, "seed_permission_copy") or not hasattr(context, "permission_key"):
        raise AssertionError("Seed permission or permission_key is not set in context for MR10.")

    seed_permission = context.seed_permission_copy
    if not isinstance(seed_permission, dict):
        raise AssertionError("Seed permission in context is not an object.")

    updated_permission = copy.deepcopy(seed_permission)
    # Change one specific field: 'note'
    updated_permission["note"] = "Updated note for testing"

    # Invoke the permission-update operation (PUT /users/rbac/permissions)
    update_response = requests.put(
        f"{BASE_URL}/users/rbac/permissions",
        json=updated_permission,
        timeout=10,
    )
    update_response.raise_for_status()

    # Retrieve the permission by key again (GET /users/rbac/permissions/\{permissionKey\})
    permission_key = context.permission_key
    followup_response = requests.get(
        f"{BASE_URL}/users/rbac/permissions/{permission_key}",
        timeout=10,
    )
    followup_response.raise_for_status()

    followup_data = followup_response.json()
    if not isinstance(followup_data, dict):
        raise AssertionError("Follow-up permission response is not an object.")

    context.followup_permission = followup_data
    context.updated_note_value = updated_permission["note"]


@then("the follow-up output should reflect a change in the explicitly updated field for MR10, while other fields in the permission data that were not updated in the request should remain identical to the seed output.")
def _mr_MR10_assert_followup_output(context):
    if not hasattr(context, "seed_permission_copy") or not hasattr(context, "followup_permission"):
        raise AssertionError("Context is missing seed or follow-up permission data for MR10.")

    seed_permission = context.seed_permission_copy
    followup_permission = context.followup_permission
    updated_note_value = getattr(context, "updated_note_value", "Updated note for testing")

    if not isinstance(seed_permission, dict) or not isinstance(followup_permission, dict):
        raise AssertionError("Seed or follow-up permission is not an object.")

    # Assert the updated field changed as expected
    assert followup_permission.get("note") == updated_note_value, (
        "The 'note' field was not updated correctly in MR10."
    )

    # Assert all other fields remain unchanged
    for key, seed_value in seed_permission.items():
        if key == "note":
            continue
        assert followup_permission.get(key) == seed_value, (
            f"The field '{key}' has changed unexpectedly in MR10."
        )
