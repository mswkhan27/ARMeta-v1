Feature: Iteration 1 MRs

  Scenario: MR6 Deleting a permission should remove it from the permission list
    Given a seed input that retrieves the current list of permissions, producing a seed output with the total permission count for MR6.
    When a follow-up input is created by deleting an existing permission through the permission-deletion operation and then retrieving the list of permissions again, yielding a follow-up output for MR6.
    Then the follow-up output should have a permission count that is exactly one less than the seed output for MR6, assuming no other permission-creation or deletion operations occur between the two retrievals.

  Scenario: MR7 Adding a permission to a role should include the new permission in the role's permission list
    Given a seed input that retrieves a role's details, including the current set of permissions, producing a seed output with the role's permissions for MR7.
    When a follow-up input is created by invoking the operation that adds a permission to a role for the same role and permission key, and then retrieving the role's details again, yielding a follow-up output for MR7.
    Then the follow-up output should include all permissions from the seed output plus the newly added permission for MR7, with no previously existing permission removed.

  Scenario: MR8 Removing a permission from a role should exclude the permission from the role's permission list
    Given a seed input that retrieves a role's details, including the current set of permissions, producing a seed output with the role's permissions for MR8.
    When a follow-up input is created by invoking the operation that removes a permission from a role for one existing permission on the same role and then retrieving the role's details again, yielding a follow-up output for MR8.
    Then the follow-up output should contain all permissions from the seed output except the removed permission for MR8; the removed permission must no longer appear in the role's permission list.

  Scenario: MR9 Generating a salt should be capable of producing different values across invocations
    Given a seed input that invokes the salt-generation operation, producing a seed output with a generated salt value for MR9.
    When a follow-up input is created by invoking the salt-generation operation again, yielding a follow-up output for MR9.
    Then the follow-up output is expected to contain a salt value that is different from the seed output for MR9, indicating variability between successive salt-generation calls.

  Scenario: MR10 Updating a permission should modify only the updated fields
    Given a seed input that retrieves a permission's current information, producing a seed output with the permission's details for MR10.
    When a follow-up input is created by invoking the permission-update operation to change one specific field in the permission's information and then retrieving the permission's details again, yielding a follow-up output for MR10.
    Then the follow-up output should reflect a change in the explicitly updated field for MR10, while other fields in the permission data that were not updated in the request should remain identical to the seed output.
