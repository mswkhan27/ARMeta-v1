from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


def _check_response_no_500(response, step_name: str) -> None:
    """
    Ensure the API did not return a 500-level error.
    Raise AssertionError so Behave marks the step as failed.
    """
    if response is None:
        raise AssertionError(f"{step_name}: No response received from the API.")
    if response.status_code >= 500:
        raise AssertionError(
            f"{step_name}: Server error {response.status_code} received from API. "
            f"Body: {response.text}"
        )


@given(
    "a seed input that retrieves a user by username, producing a seed output with the user's current information for MR6."
)
def _mr_MR6_seed_input(context):
    username = "testuser"
    context.seed_request = {"username": username}

    # User payload according to the /user POST (createUser) schema
    user_data = {
        "id": 1,
        "username": username,
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1,
    }

    # Create the user first to ensure it exists
    create_response = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    _check_response_no_500(create_response, "MR6 Given - create user")

    # If creation fails with a client error, fail early with clear message
    if create_response.status_code >= 400:
        raise AssertionError(
            f"MR6 Given - Failed to create user. "
            f"Status: {create_response.status_code}, Body: {create_response.text}"
        )

    # Now retrieve the user as the seed output
    get_response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    _check_response_no_500(get_response, "MR6 Given - get user")

    if get_response.status_code >= 400:
        raise AssertionError(
            f"MR6 Given - Failed to retrieve created user. "
            f"Status: {get_response.status_code}, Body: {get_response.text}"
        )

    try:
        context.seed_response = get_response.json()
    except ValueError as exc:
        raise AssertionError(
            f"MR6 Given - Response is not valid JSON. Body: {get_response.text}"
        ) from exc


@when(
    "a follow-up input is created by deleting the user with the same username, and then attempting to retrieve the user again, yielding a follow-up output for MR6."
)
def _mr_MR6_followup_input(context):
    username = context.seed_request.get("username")
    if not isinstance(username, str):
        raise AssertionError("MR6 When - Username in seed_request is missing or invalid.")

    # Delete the user
    delete_response = requests.delete(f"{BASE_URL}/user/{username}", timeout=10)
    _check_response_no_500(delete_response, "MR6 When - delete user")

    # We deliberately do not assert the delete status code here (it might be 200 or 404);
    # the MR is validated by the follow-up GET

    # Attempt to retrieve the user again
    followup_response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    _check_response_no_500(followup_response, "MR6 When - get user after delete")

    context.followup_response = followup_response


@then(
    "the follow-up output should indicate that the user is not found, differing from the seed output which contained the user's information for MR6."
)
def _mr_MR6_followup_output(context):
    followup_response = getattr(context, "followup_response", None)
    seed_response = getattr(context, "seed_response", None)
    seed_request = getattr(context, "seed_request", None)

    if followup_response is None:
        raise AssertionError("MR6 Then - followup_response is missing from context.")
    if seed_response is None:
        raise AssertionError("MR6 Then - seed_response is missing from context.")
    if not isinstance(seed_request, dict):
        raise AssertionError("MR6 Then - seed_request is missing or invalid in context.")

    # MR expectation: after deletion, user should not be found (404)
    if followup_response.status_code == 500:
        # Extra guard even though we check in When; ensures Then clearly fails on 500 as well
        raise AssertionError(
            f"MR6 Then - Server error 500 received for follow-up GET. Body: {followup_response.text}"
        )

    assert (
        followup_response.status_code == 404
    ), f"Expected 404 (user not found) after deletion, got {followup_response.status_code} with body: {followup_response.text}"

    # Validate that seed output actually contained the user's information
    username = seed_request.get("username")
    if not isinstance(username, str):
        raise AssertionError("MR6 Then - Username in seed_request is missing or invalid.")

    if not isinstance(seed_response, dict):
        raise AssertionError(
            f"MR6 Then - seed_response should be a JSON object, got: {type(seed_response)}"
        )

    actual_username = seed_response.get("username")
    assert (
        actual_username == username
    ), f"Seed output username mismatch. Expected '{username}', got '{actual_username}'."

# ----






@given(
    "a seed input that retrieves a pet by its identifier, producing a seed output that confirms the pet exists for MR8."
)
def step_mr_MR8_seed_input(context):
    # Create a pet to ensure it exists (POST /pet)
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["http://example.com/dog.jpg"],
        "status": "available",
    }

    try:
        create_resp = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Given step (create pet): request failed with error: {e}")

    _check_response_no_500(create_resp, "Given step (create pet)")

    try:
        create_body = create_resp.json()
    except ValueError:
        raise AssertionError(
            f"Given step (create pet): Response is not valid JSON. Status: {create_resp.status_code}, Body: {create_resp.text}"
        )

    if create_resp.status_code != 200:
        raise AssertionError(
            f"Given step (create pet): Expected status 200, got {create_resp.status_code}. Body: {create_body}"
        )

    # Extract pet id safely (fallback to provided id if missing)
    pet_id = create_body.get("id", pet_data["id"])
    context.seed_pet_id = pet_id
    context.seed_create_response = create_resp
    context.seed_create_body = create_body

    # Retrieve the pet by its identifier (GET /pet/\{petId\})
    try:
        get_resp = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Given step (get pet): request failed with error: {e}")

    _check_response_no_500(get_resp, "Given step (get pet)")

    try:
        get_body = get_resp.json()
    except ValueError:
        raise AssertionError(
            f"Given step (get pet): Response is not valid JSON. Status: {get_resp.status_code}, Body: {get_resp.text}"
        )

    if get_resp.status_code != 200:
        raise AssertionError(
            f"Given step (get pet): Expected status 200, got {get_resp.status_code}. Body: {get_body}"
        )

    context.seed_get_response = get_resp
    context.seed_get_body = get_body


@when(
    "a follow-up input is created by uploading a new image for the same pet, yielding a follow-up output for MR8."
)
def step_mr_MR8_followup_input(context):
    if not hasattr(context, "seed_pet_id"):
        raise AssertionError(
            "When step: seed_pet_id not found in context. Given step may have failed."
        )

    pet_id = context.seed_pet_id

    # Create a small dummy binary payload instead of relying on filesystem
    binary_content = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR"

    files = {
        # Field name isn't specified in the spec; 'file' is a common convention.
        # Content will be sent as application/octet-stream per OpenAPI.
        "file": ("dummy.png", binary_content, "application/octet-stream"),
    }

    try:
        upload_resp = requests.post(
            f"{BASE_URL}/pet/{pet_id}/uploadImage", files=files, timeout=10
        )
    except requests.RequestException as e:
        raise AssertionError(
            f"When step (upload image): request failed with error: {e}"
        )

    _check_response_no_500(upload_resp, "When step (upload image)")

    try:
        upload_body = upload_resp.json()
    except ValueError:
        raise AssertionError(
            f"When step (upload image): Response is not valid JSON. Status: {upload_resp.status_code}, Body: {upload_resp.text}"
        )

    context.followup_upload_response = upload_resp
    context.followup_upload_body = upload_body


@then(
    "the follow-up output should indicate a successful operation for the image upload and should not indicate that the pet was not found or that no file was uploaded for MR8."
)
def step_mr_MR8_followup_output(context):
    if not hasattr(context, "followup_upload_response"):
        raise AssertionError(
            "Then step: followup_upload_response not found in context. When step may have failed."
        )

    resp = context.followup_upload_response
    body = context.followup_upload_body

    _check_response_no_500(resp, "Then step (verify upload)")

    # Expect HTTP 200 for successful operation as per OpenAPI spec for /pet/\{petId\}/uploadImage
    if resp.status_code != 200:
        raise AssertionError(
            f"Then step (verify upload): Expected status 200, got {resp.status_code}. Body: {body}"
        )

    # ApiResponse schema: { code: int32, type: string, message: string }
    if not isinstance(body, dict):
        raise AssertionError(
            f"Then step (verify upload): Expected JSON object, got: {body}"
        )

    # 'code' is optional in schema, but if present, should be integer
    code = body.get("code", None)
    if code is not None and not isinstance(code, int):
        raise AssertionError(
            f"Then step (verify upload): Expected 'code' to be integer if present, got: {code} ({type(code)})"
        )

    # message should not indicate "Pet not found" or "No file uploaded"
    message = body.get("message", "")
    if not isinstance(message, str):
        raise AssertionError(
            f"Then step (verify upload): Expected 'message' to be a string if present, got: {message} ({type(message)})"
        )

    lowered_msg = message.lower()
    if "pet not found" in lowered_msg:
        raise AssertionError(
            f"Then step (verify upload): Response message incorrectly indicates pet not found: {message}"
        )
    if "no file uploaded" in lowered_msg:
        raise AssertionError(
            f"Then step (verify upload): Response message incorrectly indicates no file uploaded: {message}"
        )

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_server_error(response, step_label: str) -> None:
    """
    Ensure no 5xx error is silently ignored.
    Behave will mark the step as failed by raising AssertionError.
    """
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"{step_label}: Server error {response.status_code} for URL {response.url}"
        )


@given('a seed input that attempts to log in a user with valid credentials, producing a seed output containing a response body as a string and associated rate-limit and expiry headers for MR9.')
def step_mr_MR9_seed_login(context):
    context.username = "validUser"
    context.password = "validPassword"

    # Prepare query parameters exactly as defined in OpenAPI:
    # GET /user/login with query params "username" and "password".
    context.seed_request = {
        "username": context.username,
        "password": context.password
    }

    response = requests.get(
        f"{BASE_URL}/user/login",
        params=context.seed_request,
        timeout=10
    )

    _check_server_error(response, "MR9 seed login")

    # Let Behave handle non-2xx errors explicitly.
    if not (200 <= response.status_code < 300):
        raise AssertionError(
            f"MR9 seed login: Expected 2xx, got {response.status_code} for URL {response.url}"
        )

    context.seed_response = response

    # Defensive checks to avoid KeyError / TypeError downstream.
    # Headers may or may not be present per OpenAPI, so record presence safely.
    context.seed_rate_limit = context.seed_response.headers.get("X-Rate-Limit")
    context.seed_expires_after = context.seed_response.headers.get("X-Expires-After")

    # Response body should be a string according to OpenAPI; ensure type.
    context.seed_body = context.seed_response.text if context.seed_response.text is not None else ""


@when('a follow-up input is created by logging in the same user again with valid credentials, yielding a follow-up output for MR9.')
def step_mr_MR9_followup_login(context):
    # Reuse the exact same request parameters for metamorphic relation.
    if not hasattr(context, "seed_request"):
        raise AssertionError("MR9 follow-up login: seed_request not found in context")

    response = requests.get(
        f"{BASE_URL}/user/login",
        params=context.seed_request,
        timeout=10
    )

    _check_server_error(response, "MR9 follow-up login")

    if not (200 <= response.status_code < 300):
        raise AssertionError(
            f"MR9 follow-up login: Expected 2xx, got {response.status_code} for URL {response.url}"
        )

    context.followup_response = response
    context.followup_rate_limit = context.followup_response.headers.get("X-Rate-Limit")
    context.followup_expires_after = context.followup_response.headers.get("X-Expires-After")
    context.followup_body = context.followup_response.text if context.followup_response.text is not None else ""


@then('the follow-up output should again contain a response body as a string and include the same types of rate-limit and expiry headers as the seed output for MR9, indicating another successful login response.')
def step_mr_MR9_assert_followup_response(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AssertionError("MR9 assertion: missing seed or follow-up response in context")

    # Ensure status codes are successful and consistent.
    assert context.seed_response.status_code == 200, (
        f"MR9 assertion: Seed login expected 200, got {context.seed_response.status_code}"
    )
    assert context.followup_response.status_code == 200, (
        f"MR9 assertion: Follow-up login expected 200, got {context.followup_response.status_code}"
    )

    # Metamorphic relation: the follow-up should have the same *types* of headers.
    # "Same types" means that if the seed had a rate-limit header, so must follow-up; likewise for expiry.
    # We avoid KeyError by using `get` during setup.
    if context.seed_rate_limit is not None:
        assert context.followup_rate_limit is not None, (
            "MR9 assertion: Follow-up response missing X-Rate-Limit header present in seed response"
        )
    if context.seed_expires_after is not None:
        assert context.followup_expires_after is not None, (
            "MR9 assertion: Follow-up response missing X-Expires-After header present in seed response"
        )

    # Response body should be a string in both cases.
    assert isinstance(context.seed_body, str), "MR9 assertion: Seed response body is not a string"
    assert isinstance(context.followup_body, str), "MR9 assertion: Follow-up response body is not a string"
