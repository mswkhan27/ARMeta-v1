Feature: Iteration 1 MRs

  Scenario: MR6 Deleting a user should remove the user from the system
    Given a seed input that retrieves a user by username, producing a seed output with the user's current information for MR6.
    When a follow-up input is created by deleting the user with the same username, and then attempting to retrieve the user again, yielding a follow-up output for MR6.
    Then the follow-up output should indicate that the user is not found, differing from the seed output which contained the user's information for MR6.

  Scenario: MR8 Uploading an image for a pet should succeed for an existing pet
    Given a seed input that retrieves a pet by its identifier, producing a seed output that confirms the pet exists for MR8.
    When a follow-up input is created by uploading a new image for the same pet, yielding a follow-up output for MR8.
    Then the follow-up output should indicate a successful operation for the image upload and should not indicate that the pet was not found or that no file was uploaded for MR8.

  Scenario: MR9 Logging in a user should return a login response string and related headers
    Given a seed input that attempts to log in a user with valid credentials, producing a seed output containing a response body as a string and associated rate-limit and expiry headers for MR9.
    When a follow-up input is created by logging in the same user again with valid credentials, yielding a follow-up output for MR9.
    Then the follow-up output should again contain a response body as a string and include the same types of rate-limit and expiry headers as the seed output for MR9, indicating another successful login response.
