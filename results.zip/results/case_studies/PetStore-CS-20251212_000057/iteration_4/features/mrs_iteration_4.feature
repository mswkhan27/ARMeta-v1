Feature: Iteration 4 MRs

  Scenario: MR19 Finding pets by tags should return at least all pets matching each individual tag when tags are combined
    Given a seed input that retrieves pets filtered by a single specific tag, producing a seed output with a list of pets associated with that tag for MR19.
    When a follow-up input is created by retrieving pets using multiple tags, where the original tag is included among them (for example, provided as a comma-separated list), yielding a follow-up output for MR19.
    Then every pet present in the seed output should also appear in the follow-up output, ensuring that combining the original tag with additional tags does not exclude pets that matched the original tag for MR19.
