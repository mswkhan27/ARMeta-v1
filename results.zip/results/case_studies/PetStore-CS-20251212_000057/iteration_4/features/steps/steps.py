from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_response_no_500(response, step_name: str) -> None:
    """
    Ensure the API did not return a 500-level error.
    Raises AssertionError to make the Behave step fail if it did.
    """
    status_code = getattr(response, "status_code", None)
    if isinstance(status_code, int) and 500 <= status_code <= 599:
        # Include body if JSON, else text, but do not assume structure
        try:
            body = response.json()
        except ValueError:
            body = response.text
        raise AssertionError(
            f"{step_name}: Server error {status_code} from {response.request.method} {response.request.url}: {body}"
        )


@given('a seed input that retrieves pets filtered by a single specific tag, producing a seed output with a list of pets associated with that tag for MR19.')
def step_mr_MR19_seed_input(context):
    # Use a concrete tag; this can be adjusted if needed
    tag = "dog"

    # According to OpenAPI: /pet/findByTags, GET, query param 'tags' is an array of strings.
    # To avoid TypeError, always pass a list.
    context.seed_request = {'tags': [tag]}

    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params=context.seed_request,
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"Given step MR19: HTTP request failed: {e}")

    _check_response_no_500(response, "Given step MR19")

    # Raise for other HTTP errors (4xx, etc.)
    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"Given step MR19: Unexpected HTTP status {response.status_code}: {e}")

    # Safely parse JSON
    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Given step MR19: Response is not valid JSON: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"Given step MR19: Expected list of pets, got {type(data).__name__}")

    context.seed_response = data
    context.seed_tag = tag


@when('a follow-up input is created by retrieving pets using multiple tags, where the original tag is included among them (for example, provided as a comma-separated list), yielding a follow-up output for MR19.')
def step_mr_MR19_followup_input(context):
    # Ensure we have the original tag from the Given step
    original_tag = getattr(context, "seed_tag", None)
    if not isinstance(original_tag, str):
        raise AssertionError("When step MR19: seed_tag is not set properly from Given step")

    # Construct multiple tags including the original one
    additional_tag = "cat"
    # For OpenAPI `type: array` with explode=true, pass a list to requests
    tags_param = [original_tag, additional_tag]

    context.followup_request = {'tags': tags_param}

    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params=context.followup_request,
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"When step MR19: HTTP request failed: {e}")

    _check_response_no_500(response, "When step MR19")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"When step MR19: Unexpected HTTP status {response.status_code}: {e}")

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"When step MR19: Response is not valid JSON: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"When step MR19: Expected list of pets, got {type(data).__name__}")

    context.followup_response = data


@then('every pet present in the seed output should also appear in the follow-up output, ensuring that combining the original tag with additional tags does not exclude pets that matched the original tag for MR19.')
def step_mr_MR19_assertion(context):
    seed_response = getattr(context, "seed_response", None)
    followup_response = getattr(context, "followup_response", None)

    if not isinstance(seed_response, list):
        raise AssertionError(
            f"Then step MR19: seed_response is not a list (got {type(seed_response).__name__})"
        )
    if not isinstance(followup_response, list):
        raise AssertionError(
            f"Then step MR19: followup_response is not a list (got {type(followup_response).__name__})"
        )

    # Extract IDs defensively, ignoring items without a valid integer-like 'id'
    seed_ids = set()
    for pet in seed_response:
        if isinstance(pet, dict) and 'id' in pet:
            seed_ids.add(pet['id'])

    followup_ids = set()
    for pet in followup_response:
        if isinstance(pet, dict) and 'id' in pet:
            followup_ids.add(pet['id'])

    if not seed_ids:
        # If no valid IDs in seed, the MR is vacuously true but we still check types
        return

    if not seed_ids.issubset(followup_ids):
        missing = seed_ids - followup_ids
        raise AssertionError(
            f"Then step MR19: Not all seed pets are present in the follow-up output. "
            f"Missing IDs: {sorted(missing)}"
        )
