Feature: Iteration 2 MRs

  Scenario: MR10 Deleting an order should remove it from subsequent retrievals
    Given a seed input that retrieves an order by its identifier, producing a seed output that successfully returns that order's information for MR10.
    When a follow-up input is created by deleting the order with the same identifier, and then attempting to retrieve the order again, yielding a follow-up output for MR10.
    Then the follow-up output should no longer return the order's information and should instead indicate that the order cannot be found for that identifier, differing from the seed output which contained the order's details for MR10.

  Scenario: MR12 Retrieving inventory should reflect valid changes in pet status
    Given a seed input that retrieves the pet inventory grouped by status, producing a seed output with a map of status codes to quantities for MR12.
    When a follow-up input is created by updating the status of one or more existing pets to another valid status value and then retrieving the inventory again, yielding a follow-up output for MR12.
    Then the follow-up output should reflect the updated quantities for the affected status values (for example, a decrease in the old status and an increase in the new status), differing from the seed output in the counts for those statuses for MR12.

  Scenario: MR14 Creating users with a list should allow each user to be retrieved individually
    Given a seed input that creates a list of users with distinct usernames, producing a seed output confirming successful creation for MR14.
    When a follow-up input is created by retrieving each user by its username from that list, yielding a follow-up output for MR14.
    Then the follow-up output should successfully return each of the created users when queried by their usernames, and the returned user information should correspond to the users provided in the seed input for MR14.
