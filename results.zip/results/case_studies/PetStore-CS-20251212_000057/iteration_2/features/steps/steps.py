from behave import given, when, then
import os
import json
import requests
import time

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


def _check_500(response, step_name: str) -> None:
    """
    Fail-fast on HTTP 500 to avoid silently passing server errors.
    """
    if response is not None and response.status_code == 500:
        try:
            body = response.json()
        except ValueError:
            body = response.text
        raise AssertionError(
            f"HTTP 500 detected in {step_name}. "
            f"Response body: {body}"
        )


@given(
    "a seed input that retrieves an order by its identifier, producing a seed output that successfully returns that order's information for MR10."
)
def _mr_MR10_seed_input(context):
    # Create an order to ensure it exists
    order_data = {
        "petId": 198772,
        "quantity": 7,
        "status": "placed",
        "complete": True,
    }

    # Place order: POST /store/order
    response = requests.post(
        f"{BASE_URL}/store/order",
        json=order_data,
        timeout=10,
    )
    _check_500(response, "MR10 Given - create order")

    # Safely parse JSON
    try:
        response_json = response.json()
    except ValueError as exc:
        raise AssertionError(
            f"Failed to parse JSON response for created order. "
            f"Status: {response.status_code}, Body: {response.text}"
        ) from exc

    if response.status_code != 200:
        raise AssertionError(
            f"Failed to create order. "
            f"Expected status 200, got {response.status_code}. "
            f"Body: {response_json}"
        )

    # Validate presence and type of 'id'
    if "id" not in response_json:
        raise AssertionError(
            f"'id' field missing in order creation response: {response_json}"
        )
    order_id = response_json["id"]
    if not isinstance(order_id, int):
        raise AssertionError(
            f"'id' field should be integer, got {type(order_id).__name__}: {response_json}"
        )

    context.seed_order_id = order_id
    context.seed_create_response = response_json

    # Retrieve the order: GET /store/order/\{orderId\}
    get_response = requests.get(
        f"{BASE_URL}/store/order/{order_id}",
        timeout=10,
    )
    _check_500(get_response, "MR10 Given - get order")

    try:
        get_json = get_response.json()
    except ValueError as exc:
        raise AssertionError(
            f"Failed to parse JSON when retrieving order. "
            f"Status: {get_response.status_code}, Body: {get_response.text}"
        ) from exc

    if get_response.status_code != 200:
        raise AssertionError(
            f"Seed retrieval of order failed. "
            f"Expected status 200, got {get_response.status_code}. "
            f"Body: {get_json}"
        )

    context.seed_request = get_response
    context.seed_response = get_json


@when(
    "a follow-up input is created by deleting the order with the same identifier, and then attempting to retrieve the order again, yielding a follow-up output for MR10."
)
def _mr_MR10_followup_input(context):
    if not hasattr(context, "seed_order_id"):
        raise AssertionError("seed_order_id not found in context; Given step may have failed.")

    order_id = context.seed_order_id

    # Delete the order: DELETE /store/order/\{orderId\}
    delete_response = requests.delete(
        f"{BASE_URL}/store/order/{order_id}",
        timeout=10,
    )
    _check_500(delete_response, "MR10 When - delete order")

    # DELETE default response for success is 200 in spec
    if delete_response.status_code != 200:
        # Try to decode JSON, but don't fail with ValueError
        try:
            delete_body = delete_response.json()
        except ValueError:
            delete_body = delete_response.text
        raise AssertionError(
            f"Failed to delete order {order_id}. "
            f"Expected status 200, got {delete_response.status_code}. "
            f"Body: {delete_body}"
        )

    context.delete_response = delete_response

    # Attempt to retrieve the deleted order: GET /store/order/\{orderId\}
    followup_request = requests.get(
        f"{BASE_URL}/store/order/{order_id}",
        timeout=10,
    )
    _check_500(followup_request, "MR10 When - get deleted order")

    try:
        followup_json = followup_request.json()
    except ValueError:
        # If body is not JSON, still store text to avoid TypeError later
        followup_json = {"raw_body": followup_request.text}

    context.followup_request = followup_request
    context.followup_response = followup_json


@then(
    "the follow-up output should no longer return the order's information and should instead indicate that the order cannot be found for that identifier, differing from the seed output which contained the order's details for MR10."
)
def _mr_MR10_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response not found in context; Given step may have failed.")
    if not hasattr(context, "followup_request") or not hasattr(context, "followup_response"):
        raise AssertionError("followup_request/followup_response missing; When step may have failed.")

    followup_request = context.followup_request
    followup_response = context.followup_response

    _check_500(followup_request, "MR10 Then - verify followup")

    # After deletion, retrieval should not return the order's details.
    # According to spec, 404 is expected for not found.
    status_code = followup_request.status_code
    if status_code != 404:
        raise AssertionError(
            f"Expected 404 when retrieving deleted order, "
            f"got {status_code}. Body: {followup_response}"
        )

    # Ensure the follow-up output differs from the seed output
    try:
        seed_json = context.seed_response
        # Comparison must be safe even if followup_response is not native JSON of same shape
        if isinstance(followup_response, dict) and isinstance(seed_json, dict):
            if followup_response == seed_json:
                raise AssertionError(
                    "Follow-up response after deletion is identical to seed response; "
                    "expected them to differ."
                )
    except Exception as exc:
        # Any comparison issue should surface clearly, not as TypeError
        raise AssertionError(
            f"Error while comparing seed and follow-up responses: {exc}"
        ) from exc

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _safe_get_json(context, method, url, **kwargs):
    """Helper to call API, check for 500, and safely parse JSON."""
    response = requests.request(method, url, timeout=10, **kwargs)
    # Fail explicitly on server errors
    if 500 <= response.status_code < 600:
        assert False, f"Server error {response.status_code} for {method} {url}: {response.text}"
    try:
        data = response.json()
    except ValueError:
        assert False, f"Invalid JSON response for {method} {url}: {response.text}"
    return response, data


@given('a seed input that retrieves the pet inventory grouped by status, producing a seed output with a map of status codes to quantities for MR12.')
def step_mr_MR12_seed_input(context):
    response, data = _safe_get_json(context, "GET", f"{BASE_URL}/store/inventory")
    assert isinstance(data, dict), "Seed response is not a valid dictionary."
    context.seed_response = data
    context.seed_status_code = response.status_code


@when('a follow-up input is created by updating the status of one or more existing pets to another valid status value and then retrieving the inventory again, yielding a follow-up output for MR12.')
def step_mr_MR12_followup_input(context):
    # Create a new pet with a full valid schema so that inventory changes are well-defined
    new_pet = {
        "id": 99999,
        "name": "TestPet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    # Add the pet
    add_response, add_data = _safe_get_json(
        context,
        "POST",
        f"{BASE_URL}/pet",
        json=new_pet,
        headers={"Content-Type": "application/json"},
    )
    assert add_response.status_code == 200, f"Failed to add pet: {add_response.status_code} {add_response.text}"

    # Update the entire pet object with new status using PUT /pet as per OpenAPI
    updated_pet = dict(add_data)
    updated_pet["status"] = "sold"

    update_response, _ = _safe_get_json(
        context,
        "PUT",
        f"{BASE_URL}/pet",
        json=updated_pet,
        headers={"Content-Type": "application/json"},
    )
    assert update_response.status_code == 200, f"Failed to update pet: {update_response.status_code} {update_response.text}"

    # Retrieve the inventory again
    follow_response, follow_data = _safe_get_json(context, "GET", f"{BASE_URL}/store/inventory")
    assert isinstance(follow_data, dict), "Follow-up response is not a valid dictionary."
    context.followup_response = follow_data
    context.followup_status_code = follow_response.status_code


@then('the follow-up output should reflect the updated quantities for the affected status values (for example, a decrease in the old status and an increase in the new status), differing from the seed output in the counts for those statuses for MR12.')
def step_mr_MR12_followup_output(context):
    seed = getattr(context, "seed_response", None)
    follow = getattr(context, "followup_response", None)

    assert isinstance(seed, dict), "Seed response missing or invalid."
    assert isinstance(follow, dict), "Follow-up response missing or invalid."

    seed_available = seed.get("available", 0)
    seed_sold = seed.get("sold", 0)

    follow_available = follow.get("available", 0)
    follow_sold = follow.get("sold", 0)

    # We expect exactly one pet moved from available to sold
    try:
        assert follow_sold == seed_sold + 1, (
            f"Sold status count did not increase as expected. "
            f"Seed sold={seed_sold}, follow-up sold={follow_sold}"
        )
        assert follow_available == seed_available - 1, (
            f"Available status count did not decrease as expected. "
            f"Seed available={seed_available}, follow-up available={follow_available}"
        )
    except AssertionError as e:
        assert False, str(e)

# ----






@given('a seed input that creates a list of users with distinct usernames, producing a seed output confirming successful creation for MR14.')
def _mr_MR14_create_users(context):
    context.seed_request = [
        {
            "id": 1001,
            "username": "user1",
            "firstName": "John",
            "lastName": "Doe",
            "email": "john.doe@example.com",
            "password": "password1",
            "phone": "1234567890",
            "userStatus": 1
        },
        {
            "id": 1002,
            "username": "user2",
            "firstName": "Jane",
            "lastName": "Doe",
            "email": "jane.doe@example.com",
            "password": "password2",
            "phone": "0987654321",
            "userStatus": 1
        }
    ]

    try:
        response = requests.post(
            f"{BASE_URL}/user/createWithList",
            json=context.seed_request,
            timeout=10
        )
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Given step MR14: Request error while creating users: {e}") from e

    _check_500(response, "Given step MR14")

    # For this operation, a 200 response body is a single User; we don't strictly rely on it,
    # but we parse safely if JSON is present.
    context.seed_response = None
    if response.content:
        try:
            context.seed_response = response.json()
        except ValueError:
            # Non-JSON body; keep as text for debugging but avoid raising ValueError
            context.seed_response = response.text


@when('a follow-up input is created by retrieving each user by its username from that list, yielding a follow-up output for MR14.')
def _mr_MR14_retrieve_users(context):
    followup_response = []

    seed_request = getattr(context, "seed_request", None)
    if not isinstance(seed_request, list):
        raise AssertionError("When step MR14: seed_request is missing or not a list.")

    for user in seed_request:
        if not isinstance(user, dict):
            raise AssertionError("When step MR14: Each user in seed_request must be a dict.")
        username = user.get("username")
        if not isinstance(username, str) or not username:
            raise AssertionError("When step MR14: Each user must have a non-empty 'username' string.")

        try:
            response = requests.get(
                f"{BASE_URL}/user/{username}",
                timeout=10
            )
        except requests.exceptions.RequestException as e:
            raise AssertionError(f"When step MR14: Request error while retrieving user '{username}': {e}") from e

        _check_500(response, "When step MR14")

        try:
            user_data = response.json()
        except ValueError as e:
            raise AssertionError(
                f"When step MR14: Failed to parse JSON for user '{username}': {e}"
            ) from e

        followup_response.append(user_data)

    context.followup_response = followup_response


@then('the follow-up output should successfully return each of the created users when queried by their usernames, and the returned user information should correspond to the users provided in the seed input for MR14.')
def _mr_MR14_verify_users(context):
    seed_request = getattr(context, "seed_request", None)
    followup_response = getattr(context, "followup_response", None)

    if not isinstance(seed_request, list):
        raise AssertionError("Then step MR14: seed_request is missing or not a list.")
    if not isinstance(followup_response, list):
        raise AssertionError("Then step MR14: followup_response is missing or not a list.")

    assert len(followup_response) == len(seed_request), (
        f"Mismatch in number of users retrieved. "
        f"Expected {len(seed_request)}, got {len(followup_response)}."
    )

    # Index by username to avoid order assumptions
    expected_by_username = {}
    for u in seed_request:
        if not isinstance(u, dict):
            raise AssertionError("Then step MR14: Each user in seed_request must be a dict.")
        uname = u.get("username")
        if not isinstance(uname, str) or not uname:
            raise AssertionError("Then step MR14: Each user must have a non-empty 'username' string.")
        expected_by_username[uname] = u

    for actual_user in followup_response:
        if not isinstance(actual_user, dict):
            raise AssertionError("Then step MR14: Each retrieved user must be a dict.")
        actual_username = actual_user.get("username")
        if actual_username not in expected_by_username:
            raise AssertionError(
                f"Then step MR14: Retrieved unexpected user '{actual_username}'."
            )

        expected_user = expected_by_username[actual_username]

        # Compare selected stable fields
        for field in ["username", "firstName", "lastName", "email", "phone", "userStatus"]:
            expected_value = expected_user.get(field)
            actual_value = actual_user.get(field)
            assert expected_value == actual_value, (
                f"Field '{field}' does not match for user '{actual_username}'. "
                f"Expected '{expected_value}', got '{actual_value}'."
            )
