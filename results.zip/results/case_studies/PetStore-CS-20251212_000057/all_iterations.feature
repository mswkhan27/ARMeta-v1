
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet should increase the total count of pets for a given status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of available pets for MR1.
    When a follow-up input is created by adding a new pet whose status is set to 'available', yielding a follow-up output for MR1 by retrieving the list of pets filtered by status 'available' again.
    Then the follow-up output should have a count of available pets that is one more than the seed output for MR1.

  Scenario: MR2 Updating a pet's status should reflect in the status-filtered results
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR2.
    When a follow-up input is created by updating that pet so that its status is changed to 'sold', and then retrieving pets filtered by status 'sold', yielding a follow-up output for MR2.
    Then the follow-up output should include the updated pet in the results for status 'sold', and this status should differ from the pet's status in the seed output for MR2.

  Scenario: MR3 Deleting a pet should decrease the total count of pets for a given status
    Given a seed input that retrieves the list of pets filtered by a specific status (for example, 'available'), producing a seed output with a count of pets and including a particular pet identifier for MR3.
    When a follow-up input is created by deleting that identified pet and then retrieving the list of pets again using the same status filter, yielding a follow-up output for MR3.
    Then if the deleted pet was present in the seed output for that status, the follow-up output should have a count of pets for that status that is one less than the seed output for MR3.

  Scenario: MR5 Updating a user's information with otherwise identical data should only change the updated fields
    Given a seed input that retrieves a user by username, producing a seed output with the user's current information for MR5.
    When a follow-up input is created by updating the same user with a representation that is identical to the seed output except for a changed email value, and then retrieving the user again by username, yielding a follow-up output for MR5.
    Then the follow-up output should differ from the seed output only in the email field for MR5, with all other fields remaining the same.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR6 Deleting a user should remove the user from the system
    Given a seed input that retrieves a user by username, producing a seed output with the user's current information for MR6.
    When a follow-up input is created by deleting the user with the same username, and then attempting to retrieve the user again, yielding a follow-up output for MR6.
    Then the follow-up output should indicate that the user is not found, differing from the seed output which contained the user's information for MR6.

  Scenario: MR8 Uploading an image for a pet should succeed for an existing pet
    Given a seed input that retrieves a pet by its identifier, producing a seed output that confirms the pet exists for MR8.
    When a follow-up input is created by uploading a new image for the same pet, yielding a follow-up output for MR8.
    Then the follow-up output should indicate a successful operation for the image upload and should not indicate that the pet was not found or that no file was uploaded for MR8.

  Scenario: MR9 Logging in a user should return a login response string and related headers
    Given a seed input that attempts to log in a user with valid credentials, producing a seed output containing a response body as a string and associated rate-limit and expiry headers for MR9.
    When a follow-up input is created by logging in the same user again with valid credentials, yielding a follow-up output for MR9.
    Then the follow-up output should again contain a response body as a string and include the same types of rate-limit and expiry headers as the seed output for MR9, indicating another successful login response.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR10 Deleting an order should remove it from subsequent retrievals
    Given a seed input that retrieves an order by its identifier, producing a seed output that successfully returns that order's information for MR10.
    When a follow-up input is created by deleting the order with the same identifier, and then attempting to retrieve the order again, yielding a follow-up output for MR10.
    Then the follow-up output should no longer return the order's information and should instead indicate that the order cannot be found for that identifier, differing from the seed output which contained the order's details for MR10.

  Scenario: MR12 Retrieving inventory should reflect valid changes in pet status
    Given a seed input that retrieves the pet inventory grouped by status, producing a seed output with a map of status codes to quantities for MR12.
    When a follow-up input is created by updating the status of one or more existing pets to another valid status value and then retrieving the inventory again, yielding a follow-up output for MR12.
    Then the follow-up output should reflect the updated quantities for the affected status values (for example, a decrease in the old status and an increase in the new status), differing from the seed output in the counts for those statuses for MR12.

  Scenario: MR14 Creating users with a list should allow each user to be retrieved individually
    Given a seed input that creates a list of users with distinct usernames, producing a seed output confirming successful creation for MR14.
    When a follow-up input is created by retrieving each user by its username from that list, yielding a follow-up output for MR14.
    Then the follow-up output should successfully return each of the created users when queried by their usernames, and the returned user information should correspond to the users provided in the seed input for MR14.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR16 Retrieving inventory should reflect changes in pet status
    Given a seed input that retrieves the pet inventory by status, producing a seed output with a map of status codes to quantities for MR16.
    When a follow-up input is created by changing the status of at least one existing pet and then retrieving the inventory again, yielding a follow-up output for MR16.
    Then the follow-up output should reflect the updated quantities for the affected status values compared to the seed output, with counts adjusted for statuses corresponding to the status changes for MR16.

  Scenario: MR17 Logging out a user should complete successfully after login
    Given a seed input that logs a user into the system, producing a seed output with a successful login response for MR17.
    When a follow-up input is created by logging out the user, yielding a follow-up output for MR17.
    Then the follow-up output should indicate a successful logout operation, distinguishing it from the seed output which indicated a successful login for MR17.

  Scenario: MR18 Updating a pet's information should only change the specified fields
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current information for MR18.
    When a follow-up input is created by updating only the pet's name and then retrieving the pet again, yielding a follow-up output for MR18.
    Then the follow-up output should differ from the seed output only in the name field (assuming no other fields were modified in the update request), with all other fields remaining the same for MR18.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR19 Finding pets by tags should return at least all pets matching each individual tag when tags are combined
    Given a seed input that retrieves pets filtered by a single specific tag, producing a seed output with a list of pets associated with that tag for MR19.
    When a follow-up input is created by retrieving pets using multiple tags, where the original tag is included among them (for example, provided as a comma-separated list), yielding a follow-up output for MR19.
    Then every pet present in the seed output should also appear in the follow-up output, ensuring that combining the original tag with additional tags does not exclude pets that matched the original tag for MR19.


# --- From iteration_5\features\mrs_iteration_5.feature ---

Feature: Iteration 5 MRs

  Scenario: MR20 Adding a new pet with a specific ID should allow retrieval of that pet by ID
    Given a seed input that retrieves a pet by a specific integer identifier, producing a seed output indicating that the pet is not found for MR20.
    When a follow-up input is created by adding a new pet whose identifier is set to that same integer value, yielding a follow-up output for MR20 by retrieving the pet by that identifier again.
    Then the follow-up output should successfully return the pet's information for that identifier, differing from the seed output which indicated the pet was not found for MR20.

  Scenario: MR21 Adding a pet with a unique ID should not affect retrieval of other pets by status
    Given a seed input that retrieves a list of pets filtered by a specific status value (such as available, pending, or sold), producing a seed output with a list of pets for MR21.
    When a follow-up input is created by adding a new pet with an identifier not present in the seed output and with a status value different from the original filter status, yielding a follow-up output for MR21 by retrieving the list of pets with the original status again.
    Then the follow-up output should be identical to the seed output, as the newly added pet has a different status and therefore does not match the original status filter for MR21.

  Scenario: MR23 Adding a pet with a given status should reflect in status-filtered results
    Given a seed input that retrieves the list of pets filtered by a specific status value (available, pending, or sold), producing a seed output with a count of pets for MR23.
    When a follow-up input is created by adding a new pet whose status is set to that same status value, yielding a follow-up output for MR23 by retrieving the list of pets filtered by that status again.
    Then the follow-up output should have a count of pets that is exactly one more than the count in the seed output for MR23, assuming no other changes occur between the two retrievals.

  Scenario: MR24 Adding a pet with a given tag should allow retrieval by that tag
    Given a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR24.
    When a follow-up input is created by adding a new pet whose tag list includes that same tag value, yielding a follow-up output for MR24 by retrieving pets filtered by that tag again.
    Then the follow-up output should include the newly added pet associated with that tag, making it a strict superset of the seed output for MR24, assuming no other changes occur between the two retrievals.


# --- From iteration_6\features\mrs_iteration_6.feature ---

Feature: Iteration 6 MRs

  Scenario: MR25 Updating a pet's information using form data should only change the explicitly updated fields
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current information for MR25.
    When a follow-up input is created by updating only the pet's name using form data and then retrieving the pet again, yielding a follow-up output for MR25.
    Then the follow-up output should differ from the seed output in the name field while all other pet fields are expected to remain unchanged by this form update for MR25.

  Scenario: MR26 Adding a new pet with a specific identifier should allow later retrieval of that pet by the same identifier
    Given a seed input that retrieves a pet by a specific integer identifier, producing a seed output indicating that the pet is not found for MR26.
    When a follow-up input is created by adding a new pet whose identifier is set to that same integer value, and then retrieving the pet by that identifier again, yielding a follow-up output for MR26.
    Then the follow-up output should successfully return the pet's information for that identifier as a successful operation, differing from the seed output which indicated the pet was not found for MR26.

  Scenario: MR27 Updating a pet's status using form data should reflect in subsequent status-filtered results
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR27.
    When a follow-up input is created by updating the pet's status using form data to 'sold' and then retrieving pets filtered by status 'sold', yielding a follow-up output for MR27.
    Then the follow-up output should include the updated pet in the results for status 'sold', and this status should differ from the pet's status in the seed output for MR27.

  Scenario: MR28 Deleting a pet should remove it from subsequent retrievals by the same identifier
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's information for MR28.
    When a follow-up input is created by deleting the pet with the same identifier and then attempting to retrieve the pet again, yielding a follow-up output for MR28.
    Then the follow-up output should indicate that the pet is not found, differing from the seed output which contained the pet's information for MR28.

  Scenario: MR29 Uploading an image for an existing pet with a valid file should result in a successful upload response
    Given a seed input that retrieves a pet by its identifier, producing a seed output that confirms the pet exists for MR29.
    When a follow-up input is created by uploading a non-empty image file for the same pet, yielding a follow-up output for MR29.
    Then the follow-up output should indicate a successful operation for the image upload and should not indicate that the pet was not found or that no file was uploaded for MR29.

