from behave import given, when, then
import os
import json
import requests
import time

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


def _check_500(response, step_name: str) -> None:
    """
    Ensure no 500-range error responses slip through.
    Raises AssertionError if a 5xx status code is returned.
    """
    status = getattr(response, "status_code", None)
    if isinstance(status, int) and 500 <= status <= 599:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"{step_name}: Server returned 5xx status code {status}. Response body: {body}"
        )


@given(
    "a seed input that retrieves the list of pets filtered by status 'available', "
    "producing a seed output with a count of available pets for MR1."
)
def _mr_MR1_seed_input(context):
    url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}

    response = requests.get(url, params=params, timeout=10)
    _check_500(response, "GIVEN MR1")
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"GIVEN MR1: Failed to decode JSON response: {e}") from e

    if not isinstance(data, list):
        raise AssertionError(
            f"GIVEN MR1: Expected response to be a list, got {type(data).__name__}"
        )

    context.seed_response = data
    context.seed_request = params
    context.seed_count = len(data)


@when(
    "a follow-up input is created by adding a new pet whose status is set to 'available', "
    "yielding a follow-up output for MR1 by retrieving the list of pets filtered by "
    "status 'available' again."
)
def _mr_MR1_followup_input(context):
    new_pet = {
        "name": "New Available Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }

    add_url = f"{BASE_URL}/pet"
    add_response = requests.post(add_url, json=new_pet, timeout=10)
    _check_500(add_response, "WHEN MR1 - addPet")
    add_response.raise_for_status()

    # Optionally validate that the created pet has status 'available'
    try:
        created_pet = add_response.json()
    except ValueError:
        created_pet = None

    if created_pet is not None and isinstance(created_pet, dict):
        status_value = created_pet.get("status")
        if status_value is not None and status_value != "available":
            raise AssertionError(
                f"WHEN MR1: Created pet status is '{status_value}', expected 'available'"
            )

    followup_url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}
    followup_response = requests.get(followup_url, params=params, timeout=10)
    _check_500(followup_response, "WHEN MR1 - findPetsByStatus follow-up")
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"WHEN MR1: Failed to decode JSON response: {e}") from e

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"WHEN MR1: Expected follow-up response to be a list, got {type(followup_data).__name__}"
        )

    context.followup_response = followup_data
    context.followup_count = len(followup_data)


@then(
    "the follow-up output should have a count of available pets that is one more than "
    "the seed output for MR1."
)
def _mr_MR1_followup_output(context):
    if not hasattr(context, "seed_count"):
        raise AssertionError("THEN MR1: 'seed_count' is missing from context.")
    if not hasattr(context, "followup_count"):
        raise AssertionError("THEN MR1: 'followup_count' is missing from context.")

    seed_count = context.seed_count
    followup_count = context.followup_count

    if not isinstance(seed_count, int):
        raise AssertionError(
            f"THEN MR1: 'seed_count' should be int, got {type(seed_count).__name__}"
        )
    if not isinstance(followup_count, int):
        raise AssertionError(
            f"THEN MR1: 'followup_count' should be int, got {type(followup_count).__name__}"
        )

    expected = seed_count + 1
    if followup_count != expected:
        raise AssertionError(
            f"THEN MR1: Expected follow-up count to be {expected}, "
            f"but got {followup_count} (seed_count={seed_count})."
        )

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_response_no_500(response, step_name: str) -> None:
    """Ensure the API did not return a 500 error."""
    status = getattr(response, "status_code", None)
    if status == 500:
        body = None
        try:
            body = response.json()
        except Exception:
            body = response.text
        raise AssertionError(f"{step_name}: API returned 500 Internal Server Error. Response body: {body}")


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR2.")
def step_mr_MR2_seed_input(context):
    # Create a pet to ensure it exists (addPet: POST /pet)
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_no_500(response, "Given MR2 - create pet")

    try:
        seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Given MR2 - invalid JSON response when creating pet: {e}, body={response.text!r}")

    if response.status_code != 200:
        raise AssertionError(f"Given MR2 - Failed to create pet: status={response.status_code}, body={seed_response}")

    # Now retrieve the pet by its identifier (getPetById: GET /pet/{{petId}})
    pet_id = seed_response.get("id")
    if pet_id is None:
        raise AssertionError(f"Given MR2 - Created pet response missing 'id': {seed_response}")

    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(get_response, "Given MR2 - get pet by id")

    try:
        get_body = get_response.json()
    except ValueError as e:
        raise AssertionError(f"Given MR2 - invalid JSON response when retrieving pet by id: {e}, body={get_response.text!r}")

    if get_response.status_code != 200:
        raise AssertionError(
            f"Given MR2 - Failed to retrieve pet by id {pet_id}: "
            f"status={get_response.status_code}, body={get_body}"
        )

    if not isinstance(get_body, dict):
        raise AssertionError(f"Given MR2 - Expected dict body for getPetById, got {type(get_body).__name__}: {get_body!r}")

    # Store both creation and retrieval responses if needed; seed status should come from the retrieval
    context.seed_created_pet = seed_response
    context.seed_request_get = get_response
    context.seed_response = get_body

    # Defensive check for required fields to prevent KeyError/TypeError downstream
    if "id" not in context.seed_response or "status" not in context.seed_response:
        raise AssertionError(f"Given MR2 - Seed pet response missing required fields: {context.seed_response}")


@when("a follow-up input is created by updating that pet so that its status is changed to 'sold', and then retrieving pets filtered by status 'sold', yielding a follow-up output for MR2.")
def step_mr_MR2_followup_input(context):
    seed_pet = context.seed_response
    pet_id = seed_pet.get("id")
    if pet_id is None:
        raise AssertionError(f"When MR2 - Seed pet missing 'id': {seed_pet}")

    # Build safe update payload (updatePet: PUT /pet)
    update_data = {
        "id": pet_id,
        "name": seed_pet.get("name", "doggie"),
        "photoUrls": seed_pet.get("photoUrls") or ["url1"],
        "status": "sold"
    }

    update_response = requests.put(f"{BASE_URL}/pet", json=update_data, timeout=10)
    _check_response_no_500(update_response, "When MR2 - update pet")

    try:
        update_body = update_response.json()
    except ValueError:
        update_body = update_response.text

    if update_response.status_code != 200:
        raise AssertionError(
            f"When MR2 - Failed to update pet: status={update_response.status_code}, body={update_body}"
        )

    # Retrieve pets filtered by status 'sold' (findPetsByStatus: GET /pet/findByStatus)
    followup_request = requests.get(f"{BASE_URL}/pet/findByStatus", params={"status": "sold"}, timeout=10)
    _check_response_no_500(followup_request, "When MR2 - find pets by status 'sold'")

    try:
        followup_body = followup_request.json()
    except ValueError as e:
        raise AssertionError(
            f"When MR2 - invalid JSON response when retrieving pets by status 'sold': "
            f"{e}, body={followup_request.text!r}"
        )

    if followup_request.status_code != 200:
        raise AssertionError(
            f"When MR2 - Failed to retrieve pets by status 'sold': "
            f"status={followup_request.status_code}, body={followup_body}"
        )

    if not isinstance(followup_body, list):
        raise AssertionError(
            f"When MR2 - Expected list body for findPetsByStatus, got {type(followup_body).__name__}: {followup_body!r}"
        )

    context.followup_request = followup_request
    context.followup_response = followup_body


@then("the follow-up output should include the updated pet in the results for status 'sold', and this status should differ from the pet's status in the seed output for MR2.")
def step_mr_MR2_followup_output(context):
    followup_response = context.followup_response
    seed_pet = context.seed_response

    if not isinstance(followup_response, list):
        raise AssertionError(
            f"Then MR2 - Follow-up response is not a list: {type(followup_response).__name__}, body={followup_response!r}"
        )

    seed_id = seed_pet.get("id")
    if seed_id is None:
        raise AssertionError(f"Then MR2 - Seed pet missing 'id': {seed_pet}")

    seed_status = seed_pet.get("status")
    if seed_status is None:
        raise AssertionError(f"Then MR2 - Seed pet missing 'status': {seed_pet}")

    # Ensure updated pet is in the 'sold' results
    found = False
    for pet in followup_response:
        if not isinstance(pet, dict):
            # Skip non-dict entries instead of raising TypeError
            continue
        pet_id = pet.get("id")
        pet_status = pet.get("status")
        if pet_id == seed_id and pet_status == "sold":
            found = True
            break

    if not found:
        raise AssertionError(
            f"Then MR2 - Updated pet with id={seed_id} and status='sold' "
            f"not found in follow-up output: {json.dumps(followup_response, ensure_ascii=False)}"
        )

    if seed_status == "sold":
        raise AssertionError(
            "Then MR2 - Seed status should differ from follow-up status 'sold', "
            f"but seed status was already 'sold'. Seed pet: {seed_pet}"
        )

# ----






@given(
    "a seed input that retrieves the list of pets filtered by a specific status "
    "(for example, 'available'), producing a seed output with a count of pets and "
    "including a particular pet identifier for MR3."
)
def _mr_MR3_seed_input(context):
    status_value = "available"
    context.seed_status = status_value

    # Retrieve the list of pets filtered by the specific status
    response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params={"status": status_value},
        timeout=10,
    )
    _check_500(response, "MR3 seed: GET /pet/findByStatus")
    response.raise_for_status()

    try:
        seed_pets = response.json()
        if not isinstance(seed_pets, list):
            raise AssertionError(
                f"MR3 seed: Expected list from /pet/findByStatus, got {type(seed_pets).__name__}"
            )
    except ValueError as e:
        raise AssertionError(f"MR3 seed: Invalid JSON in response: {e}") from e

    # Ensure there is at least one pet; if not, create one with the desired status
    if not seed_pets:
        new_pet = {
            "name": "TestPet-MR3",
            "photoUrls": ["http://example.com/photo.jpg"],
            "status": status_value,
        }
        create_response = requests.post(
            f"{BASE_URL}/pet",
            json=new_pet,
            timeout=10,
        )
        _check_500(create_response, "MR3 seed: POST /pet")
        create_response.raise_for_status()

        try:
            created_pet = create_response.json()
            if not isinstance(created_pet, dict):
                raise AssertionError(
                    f"MR3 seed: Expected object from POST /pet, got {type(created_pet).__name__}"
                )
        except ValueError as e:
            raise AssertionError(f"MR3 seed: Invalid JSON in create response: {e}") from e

        seed_pets = [created_pet]

    # Safely extract ID and store seed data
    first_pet = seed_pets[0]
    pet_id = first_pet.get("id")
    if pet_id is None:
        raise AssertionError("MR3 seed: First pet has no 'id' field")

    context.seed_response = seed_pets
    context.seed_count = len(seed_pets)
    context.pet_id = pet_id


@when(
    "a follow-up input is created by deleting that identified pet and then retrieving "
    "the list of pets again using the same status filter, yielding a follow-up output for MR3."
)
def _mr_MR3_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AssertionError("MR3 follow-up: context.pet_id is missing from seed step")
    if not hasattr(context, "seed_status"):
        raise AssertionError("MR3 follow-up: context.seed_status is missing from seed step")

    pet_id = context.pet_id
    status_value = context.seed_status

    # Delete the identified pet
    delete_response = requests.delete(
        f"{BASE_URL}/pet/{pet_id}",
        timeout=10,
    )
    _check_500(delete_response, "MR3 follow-up: DELETE /pet/{petId}")
    delete_response.raise_for_status()

    # Retrieve the list of pets again with the same status filter
    followup_response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params={"status": status_value},
        timeout=10,
    )
    _check_500(followup_response, "MR3 follow-up: GET /pet/findByStatus")
    followup_response.raise_for_status()

    try:
        followup_pets = followup_response.json()
        if not isinstance(followup_pets, list):
            raise AssertionError(
                f"MR3 follow-up: Expected list from /pet/findByStatus, got {type(followup_pets).__name__}"
            )
    except ValueError as e:
        raise AssertionError(f"MR3 follow-up: Invalid JSON in response: {e}") from e

    context.followup_response = followup_pets
    context.followup_count = len(followup_pets)


@then(
    "if the deleted pet was present in the seed output for that status, the follow-up "
    "output should have a count of pets for that status that is one less than the seed output for MR3."
)
def _mr_MR3_assertion(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("MR3 then: context.seed_response is missing")
    if not hasattr(context, "followup_response"):
        raise AssertionError("MR3 then: context.followup_response is missing")
    if not hasattr(context, "pet_id"):
        raise AssertionError("MR3 then: context.pet_id is missing")

    seed_pets = context.seed_response
    followup_pets = context.followup_response
    seed_count = getattr(context, "seed_count", len(seed_pets))
    followup_count = getattr(context, "followup_count", len(followup_pets))

    # Check whether the deleted pet was actually present in the seed output
    deleted_in_seed = any(
        isinstance(p, dict) and p.get("id") == context.pet_id for p in seed_pets
    )

    if deleted_in_seed:
        expected = seed_count - 1
    else:
        # If the pet was not present, we do not expect the count to change
        expected = seed_count

    assert followup_count == expected, (
        f"MR3 then: Expected follow-up count to be {expected}, "
        f"but got {followup_count}. (deleted_in_seed={deleted_in_seed})"
    )

# ----

import copy





@given("a seed input that retrieves a user by username, producing a seed output with the user's current information for MR5.")
def _mr_MR5_seed_input(context):
    username = "theUser"

    # Create a user to ensure it exists (POST /user)
    user_data = {
        "id": 10,
        "username": username,
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "12345",
        "phone": "1234567890",
        "userStatus": 1,
    }

    create_resp = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    _check_response_no_500(create_resp, "MR5 Given - create user")

    # Retrieve the user to get the seed output (GET /user/{username})
    get_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    _check_response_no_500(get_resp, "MR5 Given - get seed user")

    # Safely parse JSON; avoid TypeError/ValueError from unexpected body
    try:
        seed_json = get_resp.json()
        if not isinstance(seed_json, dict):
            raise AssertionError(
                f"MR5 Given - Expected JSON object for user, got {type(seed_json).__name__}"
            )
    except ValueError as exc:
        raise AssertionError(f"MR5 Given - Invalid JSON in response: {exc}") from exc

    context.seed_response = seed_json
    context.username = username


@when("a follow-up input is created by updating the same user with a representation that is identical to the seed output except for a changed email value, and then retrieving the user again by username, yielding a follow-up output for MR5.")
def _mr_MR5_followup_input(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("MR5 When - seed_response not found in context")

    username = getattr(context, "username", None) or context.seed_response.get("username")
    if not isinstance(username, str):
        raise AssertionError("MR5 When - username is missing or not a string")

    # Use a deep copy to avoid mutating seed_response
    updated_user_data = copy.deepcopy(context.seed_response)
    # Ensure we change only the email field
    updated_user_data["email"] = "john.new@example.com"

    # Update user with PUT /user/{username}
    put_resp = requests.put(
        f"{BASE_URL}/user/{username}", json=updated_user_data, timeout=10
    )
    _check_response_no_500(put_resp, "MR5 When - update user")
    if put_resp.status_code != 200:
        raise AssertionError(
            f"MR5 When - Expected status 200 for update, got {put_resp.status_code}"
        )

    # Retrieve the user again (GET /user/{username})
    get_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    _check_response_no_500(get_resp, "MR5 When - get follow-up user")

    try:
        followup_json = get_resp.json()
        if not isinstance(followup_json, dict):
            raise AssertionError(
                f"MR5 When - Expected JSON object for user, got {type(followup_json).__name__}"
            )
    except ValueError as exc:
        raise AssertionError(f"MR5 When - Invalid JSON in response: {exc}") from exc

    context.followup_response = followup_json


@then("the follow-up output should differ from the seed output only in the email field for MR5, with all other fields remaining the same.")
def _mr_MR5_assert_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("MR5 Then - seed_response not found in context")
    if not hasattr(context, "followup_response"):
        raise AssertionError("MR5 Then - followup_response not found in context")

    seed = context.seed_response
    follow = context.followup_response

    if not isinstance(seed, dict) or not isinstance(follow, dict):
        raise AssertionError(
            f"MR5 Then - Expected dicts for seed and follow-up, got {type(seed).__name__} and {type(follow).__name__}"
        )

    # Fields that must remain the same according to MR5
    invariant_fields = ["id", "username", "firstName", "lastName", "password", "phone", "userStatus"]
    for field in invariant_fields:
        if field in seed or field in follow:
            assert seed.get(field) == follow.get(field), (
                f"MR5 Then - Field '{field}' changed between seed and follow-up: "
                f"{seed.get(field)!r} != {follow.get(field)!r}"
            )

    # Email must be different
    assert seed.get("email") != follow.get("email"), (
        f"MR5 Then - Expected email to change, but seed and follow-up both have {seed.get('email')!r}"
    )

    # Optionally ensure no other top-level fields changed
    seed_keys = set(seed.keys())
    follow_keys = set(follow.keys())
    common_keys = seed_keys & follow_keys

    for key in common_keys:
        if key in invariant_fields or key == "email":
            continue
        # For all other common fields, enforce equality to keep MR strict
        assert seed.get(key) == follow.get(key), (
            f"MR5 Then - Unexpected change in field '{key}': "
            f"{seed.get(key)!r} != {follow.get(key)!r}"
        )
