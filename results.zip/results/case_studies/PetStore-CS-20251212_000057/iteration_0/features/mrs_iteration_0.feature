Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet should increase the total count of pets for a given status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of available pets for MR1.
    When a follow-up input is created by adding a new pet whose status is set to 'available', yielding a follow-up output for MR1 by retrieving the list of pets filtered by status 'available' again.
    Then the follow-up output should have a count of available pets that is one more than the seed output for MR1.

  Scenario: MR2 Updating a pet's status should reflect in the status-filtered results
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR2.
    When a follow-up input is created by updating that pet so that its status is changed to 'sold', and then retrieving pets filtered by status 'sold', yielding a follow-up output for MR2.
    Then the follow-up output should include the updated pet in the results for status 'sold', and this status should differ from the pet's status in the seed output for MR2.

  Scenario: MR3 Deleting a pet should decrease the total count of pets for a given status
    Given a seed input that retrieves the list of pets filtered by a specific status (for example, 'available'), producing a seed output with a count of pets and including a particular pet identifier for MR3.
    When a follow-up input is created by deleting that identified pet and then retrieving the list of pets again using the same status filter, yielding a follow-up output for MR3.
    Then if the deleted pet was present in the seed output for that status, the follow-up output should have a count of pets for that status that is one less than the seed output for MR3.

  Scenario: MR5 Updating a user's information with otherwise identical data should only change the updated fields
    Given a seed input that retrieves a user by username, producing a seed output with the user's current information for MR5.
    When a follow-up input is created by updating the same user with a representation that is identical to the seed output except for a changed email value, and then retrieving the user again by username, yielding a follow-up output for MR5.
    Then the follow-up output should differ from the seed output only in the email field for MR5, with all other fields remaining the same.
