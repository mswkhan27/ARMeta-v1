from behave import given, when, then
import os
import json
import requests
import time

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, step_name: str) -> None:
    """Raise an AssertionError if the response status is 500."""
    status = getattr(response, "status_code", None)
    if status == 500:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unavailable>"
        raise AssertionError(
            f"MR25 {step_name}: Received 500 Internal Server Error from API. "
            f"Status: {status}, Body: {body}"
        )


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current information for MR25.")
def _mr_MR25_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available",
    }

    try:
        response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"MR25 Given: Failed to call POST /pet: {e}") from e

    _check_500(response, "Given - create pet")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"MR25 Given: Unexpected HTTP status from POST /pet: {e}") from e

    try:
        seed_response = response.json()
        if not isinstance(seed_response, dict):
            raise AssertionError("MR25 Given: Expected JSON object from POST /pet.")
    except ValueError as e:
        raise AssertionError(f"MR25 Given: Invalid JSON in response from POST /pet: {e}") from e

    pet_id = seed_response.get("id")
    if pet_id is None:
        raise AssertionError("MR25 Given: Response from POST /pet does not contain 'id' field.")
    try:
        # Ensure pet_id is an integer as required by /pet/{petId}
        pet_id_int = int(pet_id)
    except (TypeError, ValueError) as e:
        raise AssertionError(f"MR25 Given: 'id' field from POST /pet is not an integer-compatible value: {e}") from e

    context.seed_response = seed_response
    context.seed_request = pet_data
    context.pet_id = pet_id_int

    # Retrieve the pet to get the seed output
    try:
        response = requests.get(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"MR25 Given: Failed to call GET /pet/{{petId}}: {e}") from e

    _check_500(response, "Given - get pet")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"MR25 Given: Unexpected HTTP status from GET /pet/{{petId}}: {e}") from e

    try:
        seed_output = response.json()
        if not isinstance(seed_output, dict):
            raise AssertionError("MR25 Given: Expected JSON object from GET /pet/{petId}.")
    except ValueError as e:
        raise AssertionError(f"MR25 Given: Invalid JSON in response from GET /pet/{{petId}}: {e}") from e

    context.seed_output = seed_output


@when("a follow-up input is created by updating only the pet's name using form data and then retrieving the pet again, yielding a follow-up output for MR25.")
def _mr_MR25_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AssertionError("MR25 When: 'pet_id' is not available in context from Given step.")

    new_name = "doggie_updated"

    # Update the pet's name using form-style parameters on /pet/{petId}
    try:
        response = requests.post(
            f"{BASE_URL}/pet/{context.pet_id}",
            params={"name": new_name},
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"MR25 When: Failed to call POST /pet/{{petId}}: {e}") from e

    _check_500(response, "When - update pet with form")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"MR25 When: Unexpected HTTP status from POST /pet/{{petId}}: {e}") from e

    # Retrieve the pet again to get the follow-up output
    try:
        response = requests.get(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"MR25 When: Failed to call GET /pet/{{petId}} after update: {e}") from e

    _check_500(response, "When - get pet after update")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"MR25 When: Unexpected HTTP status from GET /pet/{{petId}} after update: {e}") from e

    try:
        followup_output = response.json()
        if not isinstance(followup_output, dict):
            raise AssertionError("MR25 When: Expected JSON object from GET /pet/{petId} after update.")
    except ValueError as e:
        raise AssertionError(f"MR25 When: Invalid JSON in response from GET /pet/{{petId}} after update: {e}") from e

    context.followup_output = followup_output


@then("the follow-up output should differ from the seed output in the name field while all other pet fields are expected to remain unchanged by this form update for MR25.")
def _mr_MR25_assert_followup_output(context):
    if not hasattr(context, "seed_output"):
        raise AssertionError("MR25 Then: 'seed_output' is not available in context.")
    if not hasattr(context, "followup_output"):
        raise AssertionError("MR25 Then: 'followup_output' is not available in context.")

    seed = context.seed_output
    follow = context.followup_output

    # Safely access fields with dict.get to avoid KeyError/TypeError
    seed_name = seed.get("name")
    follow_name = follow.get("name")

    if seed_name is None or follow_name is None:
        raise AssertionError("MR25 Then: 'name' field missing in seed or follow-up output.")

    if follow_name == seed_name:
        raise AssertionError("MR25 Then: Name field did not update as expected.")

    # ID must remain unchanged
    seed_id = seed.get("id")
    follow_id = follow.get("id")
    if seed_id != follow_id:
        raise AssertionError("MR25 Then: ID field should remain unchanged.")

    # photoUrls must remain unchanged
    seed_photos = seed.get("photoUrls")
    follow_photos = follow.get("photoUrls")
    if seed_photos != follow_photos:
        raise AssertionError("MR25 Then: Photo URLs should remain unchanged.")

    # status must remain unchanged
    seed_status = seed.get("status")
    follow_status = follow.get("status")
    if seed_status != follow_status:
        raise AssertionError("MR25 Then: Status should remain unchanged.")

# ----




def _check_response_no_500(response, step_name: str) -> None:
    """
    Ensure the API did not return a 500-level error.
    Raises AssertionError to fail the Behave step if encountered.
    """
    if response is None:
        raise AssertionError(f"{step_name}: No response object available.")
    status_code = getattr(response, "status_code", None)
    if status_code is None:
        raise AssertionError(f"{step_name}: Response has no status_code (possible TypeError).")
    if 500 <= status_code <= 599:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"{step_name}: Server error {status_code} received from API. Body: {body}"
        )


@given(
    'a seed input that retrieves a pet by a specific integer identifier, producing a seed output indicating that the pet is not found for MR26.'
)
def _mr_MR26_seed_input(context):
    pet_id = 1  # Example pet ID to check
    context.pet_id_for_mr26 = pet_id
    context.seed_request = requests.Request('GET', f'{BASE_URL}/pet/{pet_id}')

    try:
        response = requests.get(f'{BASE_URL}/pet/{pet_id}', timeout=10)
        context.seed_response = response
        _check_response_no_500(response, "MR26 seed step")
    except requests.RequestException as e:
        raise AssertionError(f"MR26 seed step: HTTP request failed: {e}")

    # Seed expectation: pet is not found
    if response.status_code != 404:
        raise AssertionError(
            f"MR26 seed step: Expected 404 (pet not found), got {response.status_code}"
        )


@when(
    'a follow-up input is created by adding a new pet whose identifier is set to that same integer value, and then retrieving the pet by that identifier again, yielding a follow-up output for MR26.'
)
def _mr_MR26_followup_input(context):
    pet_id = getattr(context, "pet_id_for_mr26", 1)

    new_pet = {
        "id": int(pet_id),
        "name": "Doggie",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }

    context.followup_request = requests.Request('POST', f'{BASE_URL}/pet', json=new_pet)

    # Add the pet
    try:
        add_response = requests.post(f'{BASE_URL}/pet', json=new_pet, timeout=10)
        context.add_pet_response = add_response
        _check_response_no_500(add_response, "MR26 follow-up add-pet step")
    except requests.RequestException as e:
        raise AssertionError(f"MR26 follow-up add-pet step: HTTP request failed: {e}")

    if add_response.status_code != 200:
        raise AssertionError(
            f"MR26 follow-up add-pet step: Expected 200 when adding new pet, got {add_response.status_code}"
        )

    # Retrieve the pet by ID
    try:
        get_response = requests.get(f'{BASE_URL}/pet/{pet_id}', timeout=10)
        context.followup_response = get_response
        _check_response_no_500(get_response, "MR26 follow-up get-pet step")
    except requests.RequestException as e:
        raise AssertionError(f"MR26 follow-up get-pet step: HTTP request failed: {e}")


@then(
    "the follow-up output should successfully return the pet's information for that identifier as a successful operation, differing from the seed output which indicated the pet was not found for MR26."
)
def _mr_MR26_followup_output(context):
    response = getattr(context, "followup_response", None)
    _check_response_no_500(response, "MR26 then step")

    if response.status_code != 200:
        raise AssertionError(
            f"MR26 then step: Expected 200 when retrieving pet, got {response.status_code}"
        )

    try:
        pet_data = response.json()
    except ValueError as e:
        raise AssertionError(f"MR26 then step: Failed to parse JSON response: {e}")

    expected_id = getattr(context, "pet_id_for_mr26", 1)

    if not isinstance(pet_data, dict):
        raise AssertionError(
            f"MR26 then step: Expected response body to be a JSON object, got {type(pet_data).__name__}"
        )

    if pet_data.get("id") != int(expected_id):
        raise AssertionError(
            f"MR26 then step: Pet ID does not match. Expected {expected_id}, got {pet_data.get('id')}"
        )

    if pet_data.get("name") != "Doggie":
        raise AssertionError(
            f"MR26 then step: Pet name does not match. Expected 'Doggie', got {pet_data.get('name')}"
        )

    if pet_data.get("status") != "available":
        raise AssertionError(
            f"MR26 then step: Pet status does not match. Expected 'available', got {pet_data.get('status')}"
        )

# ----






@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR27.")
def step_mr_MR27_seed_input(context):
    try:
        # Create a pet to ensure it exists (status 'available' so it can differ from 'sold' later)
        pet_data = {
            "name": "TestPet",
            "photoUrls": ["http://example.com/photo.jpg"],
            "status": "available"
        }
        response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        _check_500(response, "Given MR27 - create pet")
        response.raise_for_status()

        # Ensure JSON decoding is safe
        try:
            seed_json = response.json()
        except ValueError as e:
            raise AssertionError(f"Given MR27 - invalid JSON in create pet response: {e}")

        if not isinstance(seed_json, dict):
            raise AssertionError("Given MR27 - expected JSON object for created pet")

        pet_id = seed_json.get("id")
        if pet_id is None:
            raise AssertionError("Given MR27 - created pet has no 'id' field")

        # Retrieve the pet by its identifier to produce the seed output
        get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        _check_500(get_response, "Given MR27 - get pet by id")
        get_response.raise_for_status()

        try:
            pet_json = get_response.json()
        except ValueError as e:
            raise AssertionError(f"Given MR27 - invalid JSON in get pet by id response: {e}")

        if not isinstance(pet_json, dict):
            raise AssertionError("Given MR27 - expected JSON object when retrieving pet by id")

        context.seed_response = pet_json
        context.seed_request = pet_data
    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"Error in Given step for MR27: {e}")


@when("a follow-up input is created by updating the pet's status using form data to 'sold' and then retrieving pets filtered by status 'sold', yielding a follow-up output for MR27.")
def step_mr_MR27_followup_input(context):
    try:
        if not hasattr(context, "seed_response"):
            raise AssertionError("When MR27 - seed_response not found in context")

        pet = context.seed_response
        if not isinstance(pet, dict):
            raise AssertionError("When MR27 - seed_response is not a JSON object")

        pet_id = pet.get("id")
        if pet_id is None:
            raise AssertionError("When MR27 - seed_response missing 'id' field")

        # Update the pet's status to 'sold' using form data (query params per spec)
        update_response = requests.post(
            f"{BASE_URL}/pet/{pet_id}",
            params={"status": "sold"},
            timeout=10,
        )
        _check_500(update_response, "When MR27 - update pet with form data")
        update_response.raise_for_status()

        # Retrieve pets filtered by status 'sold'
        followup_response = requests.get(
            f"{BASE_URL}/pet/findByStatus",
            params={"status": "sold"},
            timeout=10,
        )
        _check_500(followup_response, "When MR27 - find pets by status 'sold'")
        followup_response.raise_for_status()

        try:
            followup_json = followup_response.json()
        except ValueError as e:
            raise AssertionError(f"When MR27 - invalid JSON in findByStatus response: {e}")

        if not isinstance(followup_json, list):
            raise AssertionError("When MR27 - expected a list from findByStatus")

        context.followup_response = followup_json
    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"Error in When step for MR27: {e}")


@then("the follow-up output should include the updated pet in the results for status 'sold', and this status should differ from the pet's status in the seed output for MR27.")
def step_mr_MR27_followup_output(context):
    try:
        if not hasattr(context, "seed_response"):
            raise AssertionError("Then MR27 - seed_response not found in context")
        if not hasattr(context, "followup_response"):
            raise AssertionError("Then MR27 - followup_response not found in context")

        seed_pet = context.seed_response
        followup_list = context.followup_response

        if not isinstance(seed_pet, dict):
            raise AssertionError("Then MR27 - seed_response is not a JSON object")
        if not isinstance(followup_list, list):
            raise AssertionError("Then MR27 - followup_response is not a list")

        seed_id = seed_pet.get("id")
        if seed_id is None:
            raise AssertionError("Then MR27 - seed_response missing 'id' field")

        # Ensure the updated pet is present in the 'sold' results
        matching_pets = [pet for pet in followup_list if isinstance(pet, dict) and pet.get("id") == seed_id]
        if not matching_pets:
            raise AssertionError("Updated pet not found in follow-up output for status 'sold'")

        updated_pet = matching_pets[0]
        if updated_pet.get("status") != "sold":
            raise AssertionError("Pet status in follow-up output is not 'sold'")

        # Ensure the original status was different from 'sold'
        seed_status = seed_pet.get("status")
        if seed_status is None:
            raise AssertionError("Then MR27 - seed_response missing 'status' field")
        if seed_status == "sold":
            raise AssertionError("Seed output status should differ from follow-up output status 'sold'")
    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"Error in Then step for MR27: {e}")

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")




@given(
    "a seed input that retrieves a pet by its identifier, producing a seed output with the pet's information for MR28."
)
def _mr_MR28_seed_input(context):
    # Seed pet data based on Pet schema; id must be int64, name and photoUrls are required.
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available",
    }

    try:
        # Create (or ensure existence of) the pet using POST /pet
        create_response = requests.post(
            f"{BASE_URL}/pet",
            json=pet_data,
            timeout=10,
        )
        _check_response_no_500(create_response, "MR28 Given - create pet")

        # The API spec indicates 200 on successful operation; other codes are invalid/validation errors.
        if create_response.status_code != 200:
            body = None
            try:
                body = create_response.json()
            except Exception:
                body = create_response.text
            raise AssertionError(f"MR28 Given - Failed to create pet. Status: {create_response.status_code}, Body: {body}")

        # Now retrieve the pet using GET /pet/\{petId\} to produce the seed output.
        seed_request = requests.get(
            f"{BASE_URL}/pet/{pet_data['id']}",
            timeout=10,
        )
        _check_response_no_500(seed_request, "MR28 Given - get pet by id")

        if seed_request.status_code != 200:
            body = None
            try:
                body = seed_request.json()
            except Exception:
                body = seed_request.text
            raise AssertionError(
                f"MR28 Given - Expected to retrieve pet successfully. "
                f"Status: {seed_request.status_code}, Body: {body}"
            )

        # Safely parse JSON
        try:
            context.seed_response = seed_request.json()
        except ValueError as e:
            raise AssertionError(f"MR28 Given - Failed to decode JSON from seed response: {e}")

        context.seed_request = seed_request

        # Basic sanity check on seed response structure
        if not isinstance(context.seed_response, dict):
            raise AssertionError(
                f"MR28 Given - Seed response is not a JSON object. Got: {type(context.seed_response)}"
            )

        # Ensure id in response is present and matches expected type
        pet_id = context.seed_response.get("id")
        if pet_id is None:
            raise AssertionError("MR28 Given - Seed response missing 'id' field.")
        try:
            # Ensure this can be treated as integer for path parameter usage
            context.seed_pet_id = int(pet_id)
        except (TypeError, ValueError) as e:
            raise AssertionError(f"MR28 Given - Invalid 'id' in seed response, expected int-like value: {e}")

    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"MR28 Given - Unexpected error: {e}")


@when(
    "a follow-up input is created by deleting the pet with the same identifier and then attempting to retrieve the pet again, yielding a follow-up output for MR28."
)
def _mr_MR28_followup_input(context):
    if not hasattr(context, "seed_pet_id"):
        raise AssertionError("MR28 When - 'seed_pet_id' not found in context; Given step may have failed.")

    pet_id = context.seed_pet_id

    try:
        # DELETE /pet/\{petId\}
        delete_response = requests.delete(
            f"{BASE_URL}/pet/{pet_id}",
            timeout=10,
        )
        _check_response_no_500(delete_response, "MR28 When - delete pet")

        # According to spec, successful delete returns 200.
        if delete_response.status_code != 200:
            body = None
            try:
                body = delete_response.json()
            except Exception:
                body = delete_response.text
            raise AssertionError(
                f"MR28 When - Failed to delete pet. Status: {delete_response.status_code}, Body: {body}"
            )

        # GET /pet/\{petId\} again to obtain follow-up output.
        followup_request = requests.get(
            f"{BASE_URL}/pet/{pet_id}",
            timeout=10,
        )
        _check_response_no_500(followup_request, "MR28 When - get pet after delete")

        context.followup_request = followup_request

        try:
            context.followup_response = followup_request.json()
        except ValueError:
            # In case of 404 without JSON body, keep raw text; avoid TypeError/ValueError later
            context.followup_response = {"raw_body": followup_request.text}

    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"MR28 When - Unexpected error: {e}")


@then(
    "the follow-up output should indicate that the pet is not found, differing from the seed output which contained the pet's information for MR28."
)
def _mr_MR28_followup_output(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_request"):
        raise AssertionError("MR28 Then - Missing context from previous steps.")

    # Seed output was successful retrieval with pet info
    if not isinstance(context.seed_response, dict):
        raise AssertionError(
            f"MR28 Then - Seed response must be a JSON object, got {type(context.seed_response)}."
        )

    # According to spec for GET /pet/\{petId\}, 404 means "Pet not found"
    status = context.followup_request.status_code
    if status != 404:
        body = None
        try:
            body = context.followup_request.json()
        except Exception:
            body = context.followup_request.text
        raise AssertionError(
            f"MR28 Then - Expected 404 (Pet not found) after deletion, "
            f"but got {status}. Body: {body}"
        )

    # If there is a JSON body and it is an object, we can optionally inspect "message"
    body = context.followup_response
    if isinstance(body, dict) and "message" in body:
        message = body.get("message")
        # The spec only says description "Pet not found", actual message may vary; compare loosely.
        if not isinstance(message, str) or "not found" not in message.lower():
            raise AssertionError(
                f"MR28 Then - Follow-up response message does not indicate missing pet. Message: {message}"
            )

# ----

from behave.runner import Context





@given('a seed input that retrieves a pet by its identifier, producing a seed output that confirms the pet exists for MR29.')
def step_mr_MR29_seed_input(context: Context) -> None:
    # Defensive initialization
    context.seed_request = None
    context.seed_response = None

    # Create a pet to ensure it exists (POST /pet as per OpenAPI: Add a new pet to the store.)
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["http://example.com/dog.jpg"],
        "status": "available"
    }

    try:
        response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        _check_response_no_500(response, "MR29 Given (create pet)")
        context.seed_request = response

        # Safely parse JSON
        try:
            seed_body = response.json()
        except ValueError:
            raise AssertionError(
                f"MR29 Given expected JSON response when creating pet, "
                f"got non-JSON body with status {response.status_code}: {response.text}"
            )

        context.seed_response = seed_body

        if response.status_code != 200:
            raise AssertionError(
                f"Failed to create pet in MR29 Given. "
                f"Status: {response.status_code}, Body: {json.dumps(seed_body, ensure_ascii=False)}"
            )

        # Validate that the created pet has an id
        pet_id = seed_body.get("id")
        if pet_id is None:
            raise AssertionError(
                f"MR29 Given: created pet response does not contain 'id': {json.dumps(seed_body, ensure_ascii=False)}"
            )

        # Confirm the pet exists by retrieving it (GET /pet/\{petId\} as per OpenAPI: Find pet by ID.)
        get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        _check_response_no_500(get_response, "MR29 Given (get pet by id)")

        try:
            get_body = get_response.json()
        except ValueError:
            raise AssertionError(
                f"MR29 Given expected JSON response when retrieving pet, "
                f"got non-JSON body with status {get_response.status_code}: {get_response.text}"
            )

        if get_response.status_code != 200:
            raise AssertionError(
                f"MR29 Given failed to confirm pet existence. "
                f"Status: {get_response.status_code}, Body: {json.dumps(get_body, ensure_ascii=False)}"
            )

        # Store confirmed pet id for later steps
        context.pet_id = pet_id

    except requests.RequestException as e:
        raise AssertionError(f"MR29 Given step encountered a network error: {e!r}")


@when('a follow-up input is created by uploading a non-empty image file for the same pet, yielding a follow-up output for MR29.')
def step_mr_MR29_followup_input(context: Context) -> None:
    context.followup_request = None
    context.followup_response = None

    # Retrieve pet_id safely
    pet_id = getattr(context, "pet_id", None)
    if pet_id is None:
        # Fallback to seed_response if available
        seed_resp = getattr(context, "seed_response", {})
        if isinstance(seed_resp, dict):
            pet_id = seed_resp.get("id")

    if pet_id is None:
        raise AssertionError("MR29 When: pet_id is not available from previous steps.")

    # Create a small non-empty temporary binary file to upload
    tmp_file_path = os.path.join(os.getcwd(), "mr29_temp_image.bin")
    try:
        # Ensure the file is non-empty
        with open(tmp_file_path, "wb") as tmp_file:
            tmp_file.write(b"\x89PNG\r\n\x1a\nMR29 test image content")

        # According to OpenAPI, /pet/\{petId\}/uploadImage expects application/octet-stream body.
        # We send it as raw data rather than 'files' multipart to match the spec.
        with open(tmp_file_path, "rb") as image_file:
            data = image_file.read()
            if not data:
                raise AssertionError("MR29 When: prepared upload file is unexpectedly empty.")

            response = requests.post(
                f"{BASE_URL}/pet/{pet_id}/uploadImage",
                data=data,
                headers={"Content-Type": "application/octet-stream"},
                timeout=10,
            )
            _check_response_no_500(response, "MR29 When (upload image)")
            context.followup_request = response

        # Parse follow-up response body safely
        try:
            followup_body = response.json()
        except ValueError:
            raise AssertionError(
                f"MR29 When expected JSON response from image upload, "
                f"got non-JSON body with status {response.status_code}: {response.text}"
            )

        context.followup_response = followup_body

    except OSError as e:
        raise AssertionError(f"MR29 When encountered a file I/O error: {e!r}")
    except requests.RequestException as e:
        raise AssertionError(f"MR29 When step encountered a network error: {e!r}")
    finally:
        # Cleanup temp file, ignore deletion errors
        try:
            if os.path.exists(tmp_file_path):
                os.remove(tmp_file_path)
        except OSError:
            pass


@then('the follow-up output should indicate a successful operation for the image upload and should not indicate that the pet was not found or that no file was uploaded for MR29.')
def step_mr_MR29_followup_output(context: Context) -> None:
    response = getattr(context, "followup_request", None)
    body = getattr(context, "followup_response", None)

    if response is None:
        raise AssertionError("MR29 Then: follow-up request is missing from context.")
    if body is None:
        # Try to parse if not already
        try:
            body = response.json()
        except ValueError:
            raise AssertionError(
                f"MR29 Then: follow-up response has no parsed body and is not valid JSON. "
                f"Status: {response.status_code}, Raw body: {response.text}"
            )

    _check_response_no_500(response, "MR29 Then (verification)")

    # The OpenAPI for /pet/\{petId\}/uploadImage says:
    # - 200: successful operation
    # - 400: No file uploaded
    # - 404: Pet not found
    status_code = response.status_code
    if status_code != 200:
        raise AssertionError(
            f"MR29 Then: expected successful upload (HTTP 200), "
            f"but got status {status_code} with body: {json.dumps(body, ensure_ascii=False)}"
        )

    # Body is ApiResponse with fields: code (int), type (string), message (string)
    if not isinstance(body, dict):
        raise AssertionError(
            f"MR29 Then: expected response body to be JSON object, got: {type(body).__name__}"
        )

    # Ensure required keys exist
    if "code" not in body or "message" not in body:
        raise AssertionError(
            f"MR29 Then: expected 'code' and 'message' in response body, got: {json.dumps(body, ensure_ascii=False)}"
        )

    # Ensure that the message does not indicate 'Pet not found' or 'No file uploaded'
    message = str(body.get("message", "") or "")
    lowered_message = message.lower()

    if "pet not found" in lowered_message:
        raise AssertionError(
            f"MR29 Then: response message incorrectly indicates pet not found: {json.dumps(body, ensure_ascii=False)}"
        )

    if "no file uploaded" in lowered_message:
        raise AssertionError(
            f"MR29 Then: response message incorrectly indicates no file uploaded: {json.dumps(body, ensure_ascii=False)}"
        )

    # Optionally, assert that the operation is considered successful via ApiResponse.code if present
    # The spec does not define exact semantics of 'code', but commonly 200 is used.
    api_code = body.get("code")
    if isinstance(api_code, int) and api_code >= 400:
        raise AssertionError(
            f"MR29 Then: ApiResponse.code indicates failure ({api_code}) "
            f"despite HTTP 200. Body: {json.dumps(body, ensure_ascii=False)}"
        )
