Feature: Iteration 6 MRs

  Scenario: MR25 Updating a pet's information using form data should only change the explicitly updated fields
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current information for MR25.
    When a follow-up input is created by updating only the pet's name using form data and then retrieving the pet again, yielding a follow-up output for MR25.
    Then the follow-up output should differ from the seed output in the name field while all other pet fields are expected to remain unchanged by this form update for MR25.

  Scenario: MR26 Adding a new pet with a specific identifier should allow later retrieval of that pet by the same identifier
    Given a seed input that retrieves a pet by a specific integer identifier, producing a seed output indicating that the pet is not found for MR26.
    When a follow-up input is created by adding a new pet whose identifier is set to that same integer value, and then retrieving the pet by that identifier again, yielding a follow-up output for MR26.
    Then the follow-up output should successfully return the pet's information for that identifier as a successful operation, differing from the seed output which indicated the pet was not found for MR26.

  Scenario: MR27 Updating a pet's status using form data should reflect in subsequent status-filtered results
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR27.
    When a follow-up input is created by updating the pet's status using form data to 'sold' and then retrieving pets filtered by status 'sold', yielding a follow-up output for MR27.
    Then the follow-up output should include the updated pet in the results for status 'sold', and this status should differ from the pet's status in the seed output for MR27.

  Scenario: MR28 Deleting a pet should remove it from subsequent retrievals by the same identifier
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's information for MR28.
    When a follow-up input is created by deleting the pet with the same identifier and then attempting to retrieve the pet again, yielding a follow-up output for MR28.
    Then the follow-up output should indicate that the pet is not found, differing from the seed output which contained the pet's information for MR28.

  Scenario: MR29 Uploading an image for an existing pet with a valid file should result in a successful upload response
    Given a seed input that retrieves a pet by its identifier, producing a seed output that confirms the pet exists for MR29.
    When a follow-up input is created by uploading a non-empty image file for the same pet, yielding a follow-up output for MR29.
    Then the follow-up output should indicate a successful operation for the image upload and should not indicate that the pet was not found or that no file was uploaded for MR29.
