Feature: Iteration 5 MRs

  Scenario: MR20 Adding a new pet with a specific ID should allow retrieval of that pet by ID
    Given a seed input that retrieves a pet by a specific integer identifier, producing a seed output indicating that the pet is not found for MR20.
    When a follow-up input is created by adding a new pet whose identifier is set to that same integer value, yielding a follow-up output for MR20 by retrieving the pet by that identifier again.
    Then the follow-up output should successfully return the pet's information for that identifier, differing from the seed output which indicated the pet was not found for MR20.

  Scenario: MR21 Adding a pet with a unique ID should not affect retrieval of other pets by status
    Given a seed input that retrieves a list of pets filtered by a specific status value (such as available, pending, or sold), producing a seed output with a list of pets for MR21.
    When a follow-up input is created by adding a new pet with an identifier not present in the seed output and with a status value different from the original filter status, yielding a follow-up output for MR21 by retrieving the list of pets with the original status again.
    Then the follow-up output should be identical to the seed output, as the newly added pet has a different status and therefore does not match the original status filter for MR21.

  Scenario: MR23 Adding a pet with a given status should reflect in status-filtered results
    Given a seed input that retrieves the list of pets filtered by a specific status value (available, pending, or sold), producing a seed output with a count of pets for MR23.
    When a follow-up input is created by adding a new pet whose status is set to that same status value, yielding a follow-up output for MR23 by retrieving the list of pets filtered by that status again.
    Then the follow-up output should have a count of pets that is exactly one more than the count in the seed output for MR23, assuming no other changes occur between the two retrievals.

  Scenario: MR24 Adding a pet with a given tag should allow retrieval by that tag
    Given a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR24.
    When a follow-up input is created by adding a new pet whose tag list includes that same tag value, yielding a follow-up output for MR24 by retrieving pets filtered by that tag again.
    Then the follow-up output should include the newly added pet associated with that tag, making it a strict superset of the seed output for MR24, assuming no other changes occur between the two retrievals.
