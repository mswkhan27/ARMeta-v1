from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, context_message: str) -> None:
    """
    Raise an AssertionError if the response indicates a 5xx server error.
    Ensures failures are visible in Behave reports.
    """
    status = getattr(response, "status_code", None)
    if isinstance(status, int) and 500 <= status <= 599:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"Server error {status} during {context_message}. Response body: {body}"
        )


@given(
    'a seed input that retrieves a pet by a specific integer identifier, producing a seed output indicating that the pet is not found for MR20.'
)
def _mr_MR20_seed_input(context):
    pet_id = 12345  # Example ID that we expect not to exist
    url = f"{BASE_URL}/pet/{pet_id}"
    context.seed_request = requests.Request("GET", url)

    try:
        response = requests.get(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error during seed GET /pet/{{petId}} for MR20: {e}") from e

    context.seed_response = response
    _check_500(response, "seed GET /pet/{petId} for MR20")

    # We expect the pet not to be found initially
    if response.status_code != 404:
        raise AssertionError(
            f"Expected 404 (Pet not found) for seed GET /pet/{{petId}}, "
            f"got {response.status_code}"
        )


@when(
    'a follow-up input is created by adding a new pet whose identifier is set to that same integer value, yielding a follow-up output for MR20 by retrieving the pet by that identifier again.'
)
def _mr_MR20_followup_input(context):
    pet_id = 12345  # Same ID as used in the seed input
    new_pet = {
        "id": pet_id,
        "name": "Buddy",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }

    post_url = f"{BASE_URL}/pet"
    get_url = f"{BASE_URL}/pet/{pet_id}"

    # Store the logical "request" descriptions in context (not actually sent)
    context.followup_request = {
        "add_pet": {
            "method": "POST",
            "url": post_url,
            "body": new_pet,
        },
        "get_pet": {
            "method": "GET",
            "url": get_url,
        },
    }

    # Add the new pet
    try:
        add_response = requests.post(
            post_url,
            json=new_pet,
            timeout=10,
            headers={"Content-Type": "application/json"},
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error during follow-up POST /pet for MR20: {e}") from e

    _check_500(add_response, "follow-up POST /pet for MR20")

    if add_response.status_code != 200:
        body = None
        try:
            body = add_response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"Failed to add new pet, expected 200 from POST /pet, "
            f"got {add_response.status_code}. Body: {body}"
        )

    # Retrieve the pet to confirm it was added
    try:
        get_response = requests.get(get_url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error during follow-up GET /pet/{{petId}} for MR20: {e}") from e

    _check_500(get_response, "follow-up GET /pet/{petId} for MR20")
    context.followup_response = get_response


@then(
    "the follow-up output should successfully return the pet's information for that identifier, differing from the seed output which indicated the pet was not found for MR20."
)
def _mr_MR20_followup_output(context):
    response = getattr(context, "followup_response", None)
    if response is None:
        raise AssertionError("followup_response is missing in context")

    if response.status_code != 200:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"Expected 200 when retrieving pet after adding it, "
            f"got {response.status_code}. Body: {body}"
        )

    try:
        pet_data = response.json()
    except (ValueError, json.JSONDecodeError) as e:
        raise AssertionError(f"Response body is not valid JSON for follow-up GET /pet/{{petId}}: {e}") from e

    if not isinstance(pet_data, dict):
        raise AssertionError(f"Expected JSON object for pet data, got: {type(pet_data).__name__}")

    expected_id = 12345
    expected_name = "Buddy"
    expected_status = "available"

    if pet_data.get("id") != expected_id:
        raise AssertionError(f"Pet ID does not match: expected {expected_id}, got {pet_data.get('id')}")
    if pet_data.get("name") != expected_name:
        raise AssertionError(f"Pet name does not match: expected {expected_name}, got {pet_data.get('name')}")
    if pet_data.get("status") != expected_status:
        raise AssertionError(
            f"Pet status does not match: expected {expected_status}, got {pet_data.get('status')}"
        )

# ----

import time





@given('a seed input that retrieves a list of pets filtered by a specific status value (such as available, pending, or sold), producing a seed output with a list of pets for MR21.')
def step_mr_MR21_seed_input(context):
    status = 'available'  # Example status from allowed enum
    url = f"{BASE_URL}/pet/findByStatus"

    try:
        response = requests.get(url, params={'status': status}, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Given MR21: Request to {url} failed: {e}")

    _check_500(response, "Given MR21")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"Given MR21: Non-success status {response.status_code} for {response.url}: {e}")

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Given MR21: Failed to parse JSON from {response.url}: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"Given MR21: Expected list response, got {type(data).__name__}")

    context.seed_response = data
    context.seed_request = {'status': status}


@when('a follow-up input is created by adding a new pet with an identifier not present in the seed output and with a status value different from the original filter status, yielding a follow-up output for MR21 by retrieving the list of pets with the original status again.')
def step_mr_MR21_followup_input(context):
    # Determine a pet ID not present in the seed output (if IDs are present and valid)
    existing_ids = set()
    if hasattr(context, "seed_response") and isinstance(context.seed_response, list):
        for pet in context.seed_response:
            if isinstance(pet, dict):
                pet_id = pet.get("id")
                if isinstance(pet_id, int):
                    existing_ids.add(pet_id)

    # Choose a new ID that is not in existing_ids
    new_id = 1
    while new_id in existing_ids:
        new_id += 1

    new_pet = {
        "id": new_id,
        "name": "NewPet",
        "photoUrls": ["http://example.com/photo.jpg"],
        # Use a different valid status than the one used in the Given step ("available")
        "status": "sold"
    }

    add_url = f"{BASE_URL}/pet"
    try:
        add_response = requests.post(add_url, json=new_pet, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"When MR21 (add pet): Request to {add_url} failed: {e}")

    _check_500(add_response, "When MR21 (add pet)")

    try:
        add_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"When MR21 (add pet): Non-success status {add_response.status_code} for {add_response.url}: {e}"
        )

    # Optionally confirm that the created pet matches schema shape (best-effort, type-safe)
    try:
        _ = add_response.json()
    except ValueError as e:
        raise AssertionError(f"When MR21 (add pet): Failed to parse JSON from {add_response.url}: {e}")

    # Retrieve the list of pets with the original status again
    if not hasattr(context, "seed_request") or not isinstance(context.seed_request, dict):
        raise AssertionError("When MR21: seed_request is missing or invalid from Given step")

    original_status = context.seed_request.get("status")
    if not isinstance(original_status, str):
        raise AssertionError("When MR21: original status is missing or not a string")

    followup_url = f"{BASE_URL}/pet/findByStatus"
    try:
        followup_response = requests.get(followup_url, params={'status': original_status}, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"When MR21 (follow-up get): Request to {followup_url} failed: {e}")

    _check_500(followup_response, "When MR21 (follow-up get)")

    try:
        followup_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"When MR21 (follow-up get): Non-success status {followup_response.status_code} "
            f"for {followup_response.url}: {e}"
        )

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"When MR21 (follow-up get): Failed to parse JSON from {followup_response.url}: {e}")

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"When MR21 (follow-up get): Expected list response, got {type(followup_data).__name__}"
        )

    context.followup_response = followup_data
    context.followup_request = new_pet


@then('the follow-up output should be identical to the seed output, as the newly added pet has a different status and therefore does not match the original status filter for MR21.')
def step_mr_MR21_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Then MR21: seed_response is missing from context")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Then MR21: followup_response is missing from context")

    seed = context.seed_response
    followup = context.followup_response

    if not isinstance(seed, list):
        raise AssertionError(f"Then MR21: Seed response is not a list (got {type(seed).__name__})")
    if not isinstance(followup, list):
        raise AssertionError(f"Then MR21: Follow-up response is not a list (got {type(followup).__name__})")

    if seed != followup:
        raise AssertionError("Then MR21: Follow-up output does not match seed output")

# ----




def _check_response_no_500(response, step_name: str) -> None:
    """
    Ensure the API did not return a 500-level error.
    Raises an AssertionError with details if a 500 error is encountered.
    """
    if response is None:
        raise AssertionError(f"{step_name}: No response received from server")

    status_code = getattr(response, "status_code", None)
    if status_code is None:
        raise AssertionError(f"{step_name}: Response object has no status_code attribute")

    if 500 <= status_code <= 599:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"{step_name}: Server returned {status_code} error.\n"
            f"URL: {getattr(response, 'url', '<unknown>')}\n"
            f"Body: {body}"
        )


@given(
    'a seed input that retrieves the list of pets filtered by a specific status value (available, pending, or sold), '
    'producing a seed output with a count of pets for MR23.'
)
def _mr_MR23_seed_input(context):
    # Use a valid enum status as per OpenAPI: available | pending | sold
    status = "available"

    # Build params dict to avoid URL concatenation issues
    params = {"status": status}

    response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params=params,
        timeout=10,
    )

    _check_response_no_500(response, "MR23 Given - findPetsByStatus")
    # raise_for_status after explicit 500 check
    response.raise_for_status()

    # Ensure JSON decoding is safe and type is list
    try:
        data = response.json()
    except json.JSONDecodeError as exc:
        raise AssertionError(f"MR23 Given - Invalid JSON in response: {exc}") from exc

    if not isinstance(data, list):
        raise AssertionError(
            f"MR23 Given - Expected response to be a list, got {type(data).__name__}"
        )

    context.seed_response = response
    context.seed_output = data
    context.seed_count = len(data)
    context.seed_status = status


@when(
    'a follow-up input is created by adding a new pet whose status is set to that same status value, yielding a '
    'follow-up output for MR23 by retrieving the list of pets filtered by that status again.'
)
def _mr_MR23_followup_input(context):
    # Use the same status as in the Given step; default safely if missing
    status = getattr(context, "seed_status", "available")

    new_pet = {
        "name": "New Pet MR23",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": status,
    }

    add_pet_response = requests.post(
        f"{BASE_URL}/pet",
        json=new_pet,
        timeout=10,
    )

    _check_response_no_500(add_pet_response, "MR23 When - addPet")
    add_pet_response.raise_for_status()

    # Optionally capture created pet id for potential cleanup or debugging
    created_pet = None
    try:
        created_pet = add_pet_response.json()
    except json.JSONDecodeError:
        # If server doesn't return JSON, we still proceed with MR logic
        created_pet = None

    if isinstance(created_pet, dict):
        context.created_pet_id = created_pet.get("id")

    # Retrieve the list of pets again with same status
    params = {"status": status}
    followup_response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params=params,
        timeout=10,
    )

    _check_response_no_500(followup_response, "MR23 When - findPetsByStatus follow-up")
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except json.JSONDecodeError as exc:
        raise AssertionError(f"MR23 When - Invalid JSON in follow-up response: {exc}") from exc

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"MR23 When - Expected follow-up response to be a list, got {type(followup_data).__name__}"
        )

    context.followup_response = followup_response
    context.followup_output = followup_data
    context.followup_count = len(followup_data)


@then(
    'the follow-up output should have a count of pets that is exactly one more than the count in the seed output for '
    'MR23, assuming no other changes occur between the two retrievals.'
)
def _mr_MR23_followup_assertion(context):
    seed_count = getattr(context, "seed_count", None)
    followup_count = getattr(context, "followup_count", None)

    if not isinstance(seed_count, int):
        raise AssertionError(
            f"MR23 Then - seed_count should be int, got {type(seed_count).__name__}"
        )
    if not isinstance(followup_count, int):
        raise AssertionError(
            f"MR23 Then - followup_count should be int, got {type(followup_count).__name__}"
        )

    expected = seed_count + 1
    assert followup_count == expected, (
        f"MR23 Then - Expected follow-up count to be {expected}, "
        f"but got {followup_count} (seed_count={seed_count})."
    )

# ----






@given('a seed input that retrieves pets filtered by a specific tag value, producing a seed output with a list of pets for MR24.')
def _mr_MR24_seed_input(context):
    tag_value = "tag1"  # Example tag value, matches /pet/findByTags description
    context.seed_request = {
        "tags": [tag_value]
    }

    response = requests.get(
        f"{BASE_URL}/pet/findByTags",
        params=context.seed_request,
        timeout=10
    )
    _check_response_no_500(response, "Given MR24")
    # Will raise for 4xx as well, which is desired in tests
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Given MR24: Response is not valid JSON. Body: {response.text}") from e

    if not isinstance(data, list):
        raise AssertionError(f"Given MR24: Expected list response, got {type(data).__name__}")

    context.seed_response = data
    context.mr24_tag_value = tag_value


@when('a follow-up input is created by adding a new pet whose tag list includes that same tag value, yielding a follow-up output for MR24 by retrieving pets filtered by that tag again.')
def _mr_MR24_followup_input(context):
    tag_value = getattr(context, "mr24_tag_value", "tag1")

    new_pet = {
        "name": "New Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "tags": [{"id": 1, "name": tag_value}],
        "status": "available"
    }

    add_response = requests.post(
        f"{BASE_URL}/pet",
        json=new_pet,
        timeout=10
    )
    _check_response_no_500(add_response, "When MR24 - add pet")
    add_response.raise_for_status()

    try:
        created_pet = add_response.json()
    except ValueError as e:
        raise AssertionError(
            f"When MR24 - add pet: Response is not valid JSON. Body: {add_response.text}"
        ) from e

    if not isinstance(created_pet, dict):
        raise AssertionError(
            f"When MR24 - add pet: Expected object response, got {type(created_pet).__name__}"
        )

    context.new_pet = created_pet
    context.new_pet_id = created_pet.get("id")

    followup_response = requests.get(
        f"{BASE_URL}/pet/findByTags",
        params={"tags": [tag_value]},
        timeout=10
    )
    _check_response_no_500(followup_response, "When MR24 - followup findByTags")
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(
            f"When MR24 - followup findByTags: Response is not valid JSON. "
            f"Body: {followup_response.text}"
        ) from e

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"When MR24 - followup findByTags: Expected list response, got {type(followup_data).__name__}"
        )

    context.followup_response = followup_data


@then('the follow-up output should include the newly added pet associated with that tag, making it a strict superset of the seed output for MR24, assuming no other changes occur between the two retrievals.')
def _mr_MR24_followup_output(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)
    new_pet = getattr(context, "new_pet", None)

    if not isinstance(seed, list):
        raise AssertionError(f"Then MR24: seed_response is not a list, got {type(seed).__name__}")
    if not isinstance(followup, list):
        raise AssertionError(f"Then MR24: followup_response is not a list, got {type(followup).__name__}")
    if not isinstance(new_pet, dict):
        raise AssertionError(f"Then MR24: new_pet is not an object, got {type(new_pet).__name__}")

    new_pet_name = new_pet.get("name")
    new_pet_id = new_pet.get("id")

    if new_pet_name is None:
        raise AssertionError("Then MR24: new_pet has no 'name' field")
    if new_pet_id is None:
        raise AssertionError("Then MR24: new_pet has no 'id' field")

    # Check if the new pet is in the follow-up response
    new_pet_found = any(
        isinstance(pet, dict) and pet.get("id") == new_pet_id
        for pet in followup
    )
    assert new_pet_found, "Then MR24: Newly added pet is not found in the follow-up output"

    # Compare ID sets to ensure strict superset
    seed_ids = {
        pet.get("id")
        for pet in seed
        if isinstance(pet, dict) and "id" in pet
    }
    followup_ids = {
        pet.get("id")
        for pet in followup
        if isinstance(pet, dict) and "id" in pet
    }

    if None in seed_ids:
        seed_ids.discard(None)
    if None in followup_ids:
        followup_ids.discard(None)

    assert seed_ids.issubset(followup_ids), \
        "Then MR24: Follow-up IDs do not include all seed IDs"
    assert followup_ids != seed_ids, \
        "Then MR24: Follow-up output is not a strict superset of seed output"
