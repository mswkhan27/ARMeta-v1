Feature: Iteration 3 MRs

  Scenario: MR16 Retrieving inventory should reflect changes in pet status
    Given a seed input that retrieves the pet inventory by status, producing a seed output with a map of status codes to quantities for MR16.
    When a follow-up input is created by changing the status of at least one existing pet and then retrieving the inventory again, yielding a follow-up output for MR16.
    Then the follow-up output should reflect the updated quantities for the affected status values compared to the seed output, with counts adjusted for statuses corresponding to the status changes for MR16.

  Scenario: MR17 Logging out a user should complete successfully after login
    Given a seed input that logs a user into the system, producing a seed output with a successful login response for MR17.
    When a follow-up input is created by logging out the user, yielding a follow-up output for MR17.
    Then the follow-up output should indicate a successful logout operation, distinguishing it from the seed output which indicated a successful login for MR17.

  Scenario: MR18 Updating a pet's information should only change the specified fields
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current information for MR18.
    When a follow-up input is created by updating only the pet's name and then retrieving the pet again, yielding a follow-up output for MR18.
    Then the follow-up output should differ from the seed output only in the name field (assuming no other fields were modified in the update request), with all other fields remaining the same for MR18.
