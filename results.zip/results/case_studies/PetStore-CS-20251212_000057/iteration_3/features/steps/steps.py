from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, step_name: str) -> None:
    """Fail fast on HTTP 500s to ensure they are visible in Behave reports."""
    if response is not None and response.status_code == 500:
        raise AssertionError(
            f"Server error (500) in {step_name} step for MR16 at {response.request.method} "
            f"{response.request.url} with body={response.request.body!r}"
        )


@given('a seed input that retrieves the pet inventory by status, producing a seed output with a map of status codes to quantities for MR16.')
def _mr_MR16_seed_input(context):
    # Retrieve the initial inventory
    response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    _check_500(response, "Given")
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in inventory seed response: {e}") from e

    if not isinstance(data, dict):
        raise AssertionError(f"Expected inventory response to be a JSON object (map), got: {type(data)}")

    context.seed_response = data
    context.seed_request = None  # No request body for GET


@when('a follow-up input is created by changing the status of at least one existing pet and then retrieving the inventory again, yielding a follow-up output for MR16.')
def _mr_MR16_followup_input(context):
    # Use a pet ID that should not conflict under normal Petstore usage
    pet_id = 9876543210

    # Create a new pet with status 'available'
    new_pet = {
        "id": pet_id,
        "name": "TestPet-MR16",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    create_response = requests.post(f"{BASE_URL}/pet", json=new_pet, timeout=10)
    _check_500(create_response, "When - create pet")
    # Do not assume 200; allow other non-500 codes to surface via raise_for_status
    create_response.raise_for_status()

    # Update the pet's status to 'sold'
    update_data = {
        "id": pet_id,
        "name": "TestPet-MR16",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "sold"
    }

    update_response = requests.put(f"{BASE_URL}/pet", json=update_data, timeout=10)
    _check_500(update_response, "When - update pet")
    update_response.raise_for_status()

    # Retrieve the inventory again
    response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    _check_500(response, "When - inventory follow-up")
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in inventory follow-up response: {e}") from e

    if not isinstance(data, dict):
        raise AssertionError(f"Expected follow-up inventory response to be a JSON object (map), got: {type(data)}")

    context.followup_response = data
    context.followup_request = None  # No request body for GET


@then('the follow-up output should reflect the updated quantities for the affected status values compared to the seed output, with counts adjusted for statuses corresponding to the status changes for MR16.')
def _mr_MR16_followup_output(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AssertionError("Missing seed or follow-up responses on context for MR16.")

    seed = context.seed_response
    followup = context.followup_response

    if not isinstance(seed, dict):
        raise AssertionError(f"Seed response is not a valid dictionary, got {type(seed)}")
    if not isinstance(followup, dict):
        raise AssertionError(f"Follow-up response is not a valid dictionary, got {type(followup)}")

    # Inventory is a map of status -> count. We changed one pet from available to sold.
    seed_available = seed.get("available", 0)
    seed_sold = seed.get("sold", 0)

    follow_available = followup.get("available", 0)
    follow_sold = followup.get("sold", 0)

    # Only enforce relations where we had numeric counts to begin with.
    if isinstance(seed_available, int) and isinstance(follow_available, int):
        # After moving one pet from available to sold, available should decrease by 1 if it was > 0.
        if seed_available > 0:
            expected_available = seed_available - 1
            assert follow_available == expected_available, (
                f"Expected 'available' count to be {expected_available} "
                f"(seed {seed_available} - 1), got {follow_available}"
            )

    if isinstance(seed_sold, int) and isinstance(follow_sold, int):
        # Sold should increase by 1
        expected_sold = seed_sold + 1
        assert follow_sold == expected_sold, (
            f"Expected 'sold' count to be {expected_sold} "
            f"(seed {seed_sold} + 1), got {follow_sold}"
        )

    # For other statuses, we expect counts to remain unchanged
    for status, seed_count in seed.items():
        if status in ("available", "sold"):
            continue
        follow_count = followup.get(status, 0)
        if isinstance(seed_count, int) and isinstance(follow_count, int):
            assert follow_count == seed_count, (
                f"Expected '{status}' count to remain {seed_count}, got {follow_count}"
            )

# ----




def _check_5xx(response, step_name: str) -> None:
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"{step_name}: Server error {response.status_code} for URL {response.url} with body: {response.text}"
        )


@given('a seed input that logs a user into the system, producing a seed output with a successful login response for MR17.')
def step_mr_MR17_seed_input(context):
    context.seed_request = {
        "username": "testuser",
        "password": "testpassword"
    }

    response = requests.get(
        f"{BASE_URL}/user/login",
        params=context.seed_request,
        timeout=10
    )

    _check_5xx(response, "Given MR17 login")

    # 400 is a valid non-5xx response; treat as test failure for this MR
    if response.status_code != 200:
        raise AssertionError(
            f"Given MR17 login: Expected 200, got {response.status_code} - body: {response.text}"
        )

    # For /user/login, the spec returns a string body for 200
    try:
        # The service may send JSON or plain text; handle both safely
        if response.headers.get("Content-Type", "").startswith("application/json"):
            parsed = response.json()
        else:
            parsed = response.text
    except ValueError:
        # Not JSON; fall back to raw text
        parsed = response.text

    if not isinstance(parsed, str):
        raise AssertionError(
            f"Given MR17 login: Expected string response body, got {type(parsed).__name__}"
        )

    context.seed_response = parsed


@when('a follow-up input is created by logging out the user, yielding a follow-up output for MR17.')
def step_mr_MR17_followup_input(context):
    response = requests.get(
        f"{BASE_URL}/user/logout",
        timeout=10
    )

    _check_5xx(response, "When MR17 logout")

    if response.status_code != 200:
        raise AssertionError(
            f"When MR17 logout: Expected 200, got {response.status_code} - body: {response.text}"
        )

    # /user/logout has 200 with no schema; keep raw text to avoid parsing issues
    context.followup_response_raw = response.text
    context.followup_status_code = response.status_code


@then('the follow-up output should indicate a successful logout operation, distinguishing it from the seed output which indicated a successful login for MR17.')
def step_mr_MR17_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Then MR17: seed_response is missing from context")
    if not hasattr(context, "followup_status_code"):
        raise AssertionError("Then MR17: followup_status_code is missing from context")
    if not hasattr(context, "followup_response_raw"):
        raise AssertionError("Then MR17: followup_response_raw is missing from context")

    # Confirm logout call succeeded
    if context.followup_status_code != 200:
        raise AssertionError(
            f"Then MR17: Expected logout status 200, got {context.followup_status_code}"
        )

    # Metamorphic relation: login response (string token/message) must differ from logout response
    if context.seed_response == context.followup_response_raw:
        raise AssertionError(
            "Then MR17: Logout response should differ from login response, but they are equal"
        )

# ----

from requests import Response



def _check_response_no_500(response: Response, step_name: str) -> None:
    """Ensure no 500-class error is returned; fail the step if it is."""
    if response is None:
        raise AssertionError(f"{step_name}: No response received from server")
    status_code = getattr(response, "status_code", None)
    if status_code is None:
        raise AssertionError(f"{step_name}: Response has no status_code")
    if 500 <= status_code <= 599:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"{step_name}: Server returned {status_code} (5xx).\n"
            f"URL: {getattr(response, 'url', '<unknown>')}\n"
            f"Body: {body}"
        )


def _safe_json(response: Response, step_name: str):
    """Safely parse JSON and provide a clear assertion failure on error."""
    _check_response_no_500(response, step_name)
    try:
        return response.json()
    except ValueError as exc:
        raise AssertionError(f"{step_name}: Failed to parse JSON response: {exc}")


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current information for MR18.")
def _mr_MR18_seed_input(context):
    # Create a pet to ensure it exists (addPet: POST /pet)
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available",
    }

    try:
        create_resp = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    except Exception as exc:
        raise AssertionError(f"Given MR18: Error while creating pet: {exc}")

    _check_response_no_500(create_resp, "Given MR18 (create pet)")

    # Retrieve the pet to get the seed output (getPetById: GET /pet/{{petId}})
    try:
        get_resp = requests.get(f"{BASE_URL}/pet/1", timeout=10)
    except Exception as exc:
        raise AssertionError(f"Given MR18: Error while retrieving pet: {exc}")

    context.seed_request = get_resp
    context.seed_response = _safe_json(get_resp, "Given MR18 (retrieve pet)")

    # Basic structural checks to avoid KeyError / TypeError later
    if not isinstance(context.seed_response, dict):
        raise AssertionError(
            f"Given MR18: Expected JSON object for pet, got {type(context.seed_response)}"
        )

    # Ensure required keys exist with safe defaults for later comparison
    context.seed_response.setdefault("name", None)
    context.seed_response.setdefault("photoUrls", [])
    context.seed_response.setdefault("status", None)


@when("a follow-up input is created by updating only the pet's name and then retrieving the pet again, yielding a follow-up output for MR18.")
def _mr_MR18_followup_input(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("When MR18: seed_response is missing or invalid from Given step")

    # Build updated pet payload based on the seed response (updatePet: PUT /pet)
    updated_pet_data = {
        "id": context.seed_response.get("id", 1),
        "name": "doggie_updated",
        "photoUrls": context.seed_response.get("photoUrls") or [],
        "status": context.seed_response.get("status"),
        "category": context.seed_response.get("category"),
        "tags": context.seed_response.get("tags"),
    }

    try:
        put_resp = requests.put(f"{BASE_URL}/pet", json=updated_pet_data, timeout=10)
    except Exception as exc:
        raise AssertionError(f"When MR18: Error while updating pet: {exc}")

    _check_response_no_500(put_resp, "When MR18 (update pet)")

    # Retrieve the pet again to get the follow-up output (getPetById: GET /pet/{{petId}})
    pet_id = updated_pet_data.get("id", 1)
    try:
        get_resp = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    except Exception as exc:
        raise AssertionError(f"When MR18: Error while retrieving pet after update: {exc}")

    context.followup_request = get_resp
    context.followup_response = _safe_json(get_resp, "When MR18 (retrieve pet after update)")

    if not isinstance(context.followup_response, dict):
        raise AssertionError(
            f"When MR18: Expected JSON object for follow-up pet, got {type(context.followup_response)}"
        )

    # Ensure keys exist with safe defaults
    context.followup_response.setdefault("name", None)
    context.followup_response.setdefault("photoUrls", [])
    context.followup_response.setdefault("status", None)


@then("the follow-up output should differ from the seed output only in the name field (assuming no other fields were modified in the update request), with all other fields remaining the same for MR18.")
def _mr_MR18_followup_output(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AssertionError("Then MR18: Missing seed_response or followup_response on context")

    seed = context.seed_response
    follow = context.followup_response

    if not isinstance(seed, dict) or not isinstance(follow, dict):
        raise AssertionError("Then MR18: Responses must be JSON objects (dicts)")

    # Defensive access
    seed_name = seed.get("name")
    follow_name = follow.get("name")
    seed_photo_urls = seed.get("photoUrls") or []
    follow_photo_urls = follow.get("photoUrls") or []
    seed_status = seed.get("status")
    follow_status = follow.get("status")

    try:
        assert follow_name != seed_name, "Then MR18: Name field should differ after update"
        assert follow_photo_urls == seed_photo_urls, "Then MR18: photoUrls should remain the same"
        assert follow_status == seed_status, "Then MR18: status should remain the same"

        # Optionally ensure all other top-level fields (if present) are unchanged,
        # except for "name" which we intentionally changed.
        excluded_fields = {"name"}
        common_keys = set(seed.keys()).intersection(follow.keys()) - excluded_fields
        for key in common_keys:
            assert follow.get(key) == seed.get(key), (
                f"Then MR18: Field '{key}' should remain the same "
                f"(seed={seed.get(key)!r}, follow-up={follow.get(key)!r})"
            )
    except AssertionError as exc:
        raise AssertionError(str(exc))
