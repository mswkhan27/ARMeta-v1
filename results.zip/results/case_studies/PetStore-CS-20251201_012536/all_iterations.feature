
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet with status available should increase the count of available pets
    Given a seed input that requests pets filtered by the status value 'available', producing a seed output with the number of pets returned for MR1.
    When a follow-up input is created by adding a new pet whose status field is set to 'available', and then requesting pets filtered by status 'available' again, yielding a follow-up output for MR1.
    Then the follow-up output should contain a count of pets with status 'available' that is one more than in the seed output for MR1, assuming no other changes occurred in between.

  Scenario: MR2 Updating a pet's status should reflect in the status-based results
    Given a seed input that requests pets filtered by the status value 'pending', producing a seed output with a list of pending pets for MR2.
    When a follow-up input is created by updating one pet from the seed output so that its status changes from 'pending' to 'sold', and then requesting pets filtered by status 'pending' again, yielding a follow-up output for MR2.
    Then the follow-up output should no longer include the updated pet in the list of pending pets, in contrast to the seed output for MR2.

  Scenario: MR3 Deleting a pet with a given status should decrease that status quantity in the inventory
    Given a seed input that retrieves the pet inventory as quantities grouped by status, producing a seed output with the quantity for a chosen status value (for example, 'available') for MR3, and a pet with that chosen status is identified for deletion.
    When a follow-up input is created by deleting the identified pet and then retrieving the pet inventory again, yielding a follow-up output for MR3.
    Then for the chosen status value used in the seed input, the quantity in the follow-up output should be one less than in the seed output for MR3, assuming no other changes occurred in between.

  Scenario: MR5 Updating a user's information should only change the explicitly updated fields
    Given a seed input that retrieves a user's details by username, producing a seed output with the user's information for MR5.
    When a follow-up input is created by sending an update for that user which changes only the email field while keeping all other fields the same, and then retrieving the user's details again, yielding a follow-up output for MR5.
    Then the follow-up output should differ from the seed output only in the email field; all other fields should match the seed output for MR5.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR6 Deleting a user should make subsequent retrieval fail
    Given a seed input that retrieves a user by username, producing a seed output with the user's details for MR6.
    When a follow-up input is created by deleting the user with the same username and then attempting to retrieve the user again, yielding a follow-up output for MR6.
    Then the follow-up output should indicate that the user is not found (for example, with an appropriate error status), contrasting with the successful seed output for MR6.

  Scenario: MR8 Uploading an image for a pet should not alter the pet's stored details
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR8.
    When a follow-up input is created by uploading an image for the pet and then retrieving the pet's details again, yielding a follow-up output for MR8.
    Then the follow-up output should match the seed output for MR8 in all fields defined for the pet's representation, since uploading an image does not modify the pet's other stored details.

  Scenario: MR10 Repeated logins with the same credentials should yield structurally similar responses
    Given a seed input that attempts to log in with valid credentials, producing a seed output with a successful login response for MR10.
    When a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR10.
    Then the follow-up output should indicate a successful login like the seed output for MR10, including a non-empty response body of the expected type and corresponding rate limit and expiration headers, although specific header values may differ.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR11 Deleting an order should make subsequent retrieval fail
    Given a seed input that retrieves an existing order by a valid identifier, producing a seed output with that order's details for MR11.
    When a follow-up input is created by deleting the order with the same identifier and then attempting to retrieve the order again, yielding a follow-up output for MR11.
    Then the follow-up output should indicate that the order is not found (for example, with an appropriate error status), contrasting with the successful seed output for MR11.

  Scenario: MR12 Finding pets by tags should return a superset when additional tags are included
    Given a seed input that requests pets filtered by a specific set of tags (provided as a comma-separated list), producing a seed output with a list of pets for MR12.
    When a follow-up input is created by adding additional tags to the seed input and requesting pets again, yielding a follow-up output for MR12.
    Then the follow-up output should include all pets from the seed output for MR12, and may contain additional pets that match any of the newly added tags, so that the follow-up result set is a superset of the seed result set.

  Scenario: MR15 Creating users with a list should result in all users being retrievable
    Given a seed input that creates a list of users in a single request, producing a seed output confirming successful creation for MR15.
    When a follow-up input is created by retrieving each user by username from the list using individual user-retrieval operations, yielding a follow-up output for MR15.
    Then the follow-up output should successfully retrieve details for each user created in the seed input, and each retrieved user should match the corresponding user data from the seed input for MR15.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR17 Updating a pet's name should reflect in the pet's details
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR17.
    When a follow-up input is created by calling the operation that updates a pet using its identifier and a new name value, and then retrieving the pet's details again with the same identifier, yielding a follow-up output for MR17.
    Then the follow-up output should show the updated name value provided in the follow-up input, and all other pet details should remain unchanged except for any fields explicitly modified in the update request or automatically managed by the system for MR17.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR18 Logging out a user should return a successful logout response
    Given a seed input that logs a user into the system, producing a seed output with a successful login response for MR18.
    When a follow-up input is created by invoking the logout operation for the currently logged-in user, yielding a follow-up output for MR18.
    Then the follow-up output should indicate a successful logout according to the operation definition (e.g., a successful status response), consistent with the expected behavior described for MR18.

