from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR17.")
def _mr_MR17_seed_input(context):
    # Create a pet to ensure it exists, then retrieve it by id as the seed output
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }
    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    response.raise_for_status()

    seed_response_json = response.json()
    pet_id = seed_response_json.get("id")
    if pet_id is None:
        raise ValueError("Response from POST /pet does not contain 'id' field")

    # Retrieve pet by id to get the current details as seed output
    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    get_response.raise_for_status()
    pet_details = get_response.json()

    if not isinstance(pet_details, dict):
        raise TypeError("GET /pet/{petId} did not return a JSON object as expected")

    context.seed_request = pet_data
    context.seed_response = pet_details
    context.pet_id = pet_id


@when("a follow-up input is created by calling the operation that updates a pet using its identifier and a new name value, and then retrieving the pet's details again with the same identifier, yielding a follow-up output for MR17.")
def _mr_MR17_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AttributeError("context.pet_id is not set in Given step")

    pet_id = context.pet_id
    new_name = "doggie_updated"

    # Use the updatePetWithForm operation: POST /pet/{petId} with name in query
    update_response = requests.post(
        f"{BASE_URL}/pet/{pet_id}",
        params={"name": new_name},
        timeout=10
    )
    update_response.raise_for_status()

    # Retrieve the pet's details again using getPetById: GET /pet/{petId}
    followup_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    followup_response.raise_for_status()

    followup_json = followup_response.json()
    if not isinstance(followup_json, dict):
        raise TypeError("GET /pet/{petId} follow-up did not return a JSON object as expected")

    context.followup_response = followup_json
    context.new_name = new_name


@then("the follow-up output should show the updated name value provided in the follow-up input, and all other pet details should remain unchanged except for any fields explicitly modified in the update request or automatically managed by the system for MR17.")
def _mr_MR17_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AttributeError("context.followup_response is not set in When step")
    if not hasattr(context, "seed_response"):
        raise AttributeError("context.seed_response is not set in Given step")
    if not hasattr(context, "new_name"):
        raise AttributeError("context.new_name is not set in When step")

    followup = context.followup_response
    seed = context.seed_response
    new_name = context.new_name

    # Basic existence checks to avoid KeyError
    for key in ["id", "name", "photoUrls", "status"]:
        if key not in followup:
            raise KeyError(f"Key '{key}' missing in follow-up response")
        if key not in seed:
            raise KeyError(f"Key '{key}' missing in seed response")

    # Name should be updated
    assert followup["name"] == new_name, "The pet's name was not updated correctly."

    # ID should remain the same
    assert followup["id"] == seed["id"], "The pet ID should remain the same."

    # Fields not explicitly updated via updatePetWithForm (name, status) should remain unchanged.
    # We only updated 'name', so photoUrls should remain unchanged.
    assert followup["photoUrls"] == seed["photoUrls"], "The photoUrls should remain unchanged."

    # We did not send 'status' in the form update, so status is expected to remain unchanged.
    assert followup["status"] == seed["status"], "The status should remain unchanged."
