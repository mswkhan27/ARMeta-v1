Feature: Iteration 3 MRs

  Scenario: MR17 Updating a pet's name should reflect in the pet's details
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR17.
    When a follow-up input is created by calling the operation that updates a pet using its identifier and a new name value, and then retrieving the pet's details again with the same identifier, yielding a follow-up output for MR17.
    Then the follow-up output should show the updated name value provided in the follow-up input, and all other pet details should remain unchanged except for any fields explicitly modified in the update request or automatically managed by the system for MR17.
