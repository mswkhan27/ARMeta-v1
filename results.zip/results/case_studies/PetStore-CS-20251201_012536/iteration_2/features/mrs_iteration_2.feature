Feature: Iteration 2 MRs

  Scenario: MR11 Deleting an order should make subsequent retrieval fail
    Given a seed input that retrieves an existing order by a valid identifier, producing a seed output with that order's details for MR11.
    When a follow-up input is created by deleting the order with the same identifier and then attempting to retrieve the order again, yielding a follow-up output for MR11.
    Then the follow-up output should indicate that the order is not found (for example, with an appropriate error status), contrasting with the successful seed output for MR11.

  Scenario: MR12 Finding pets by tags should return a superset when additional tags are included
    Given a seed input that requests pets filtered by a specific set of tags (provided as a comma-separated list), producing a seed output with a list of pets for MR12.
    When a follow-up input is created by adding additional tags to the seed input and requesting pets again, yielding a follow-up output for MR12.
    Then the follow-up output should include all pets from the seed output for MR12, and may contain additional pets that match any of the newly added tags, so that the follow-up result set is a superset of the seed result set.

  Scenario: MR15 Creating users with a list should result in all users being retrievable
    Given a seed input that creates a list of users in a single request, producing a seed output confirming successful creation for MR15.
    When a follow-up input is created by retrieving each user by username from the list using individual user-retrieval operations, yielding a follow-up output for MR15.
    Then the follow-up output should successfully retrieve details for each user created in the seed input, and each retrieved user should match the corresponding user data from the seed input for MR15.
