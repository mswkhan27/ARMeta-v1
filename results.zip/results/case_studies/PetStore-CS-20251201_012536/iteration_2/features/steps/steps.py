from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that retrieves an existing order by a valid identifier, producing a seed output with that order's details for MR11.")
def _mr_MR11_seed_input(context):
    # Create an order to ensure it exists (POST /store/order)
    order_data = {
        "petId": 198772,
        "quantity": 1,
        "status": "placed",
        "complete": False
    }

    response = requests.post(f"{BASE_URL}/store/order", json=order_data, timeout=10)
    context.seed_request = response

    # Safely parse JSON, defaulting to {} on failure to avoid TypeError
    try:
        context.seed_response = response.json() if response.content else {}
    except ValueError:
        context.seed_response = {}

    assert response.status_code == 200, (
        f"Failed to create order: status={response.status_code}, body={context.seed_response}"
    )

    # Ensure the created order has an id to prevent later TypeErrors
    order_id = context.seed_response.get("id")
    assert isinstance(order_id, int), f"Created order does not contain a valid 'id': {context.seed_response}"


@when("a follow-up input is created by deleting the order with the same identifier and then attempting to retrieve the order again, yielding a follow-up output for MR11.")
def _mr_MR11_followup_input(context):
    # Safely get order_id from seed_response
    order_id = None
    if hasattr(context, "seed_response") and isinstance(context.seed_response, dict):
        order_id = context.seed_response.get("id")

    assert isinstance(order_id, int), f"'order_id' is not a valid integer: {order_id}"

    # Delete the order (DELETE /store/order/\{orderId\})
    delete_response = requests.delete(f"{BASE_URL}/store/order/{order_id}", timeout=10)

    # Safely parse delete response JSON, though spec doesn't define a body
    try:
        delete_body = delete_response.json() if delete_response.content else {}
    except ValueError:
        delete_body = {}

    context.delete_request = delete_response
    context.delete_response = delete_body

    assert delete_response.status_code == 200, (
        f"Failed to delete order: status={delete_response.status_code}, body={delete_body}"
    )

    # Attempt to retrieve the deleted order (GET /store/order/\{orderId\})
    followup_request = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    context.followup_request = followup_request

    # Safely parse follow-up JSON, default to {} if not JSON
    try:
        context.followup_response = followup_request.json() if followup_request.content else {}
    except ValueError:
        context.followup_response = {}


@then("the follow-up output should indicate that the order is not found (for example, with an appropriate error status), contrasting with the successful seed output for MR11.")
def _mr_MR11_followup_output(context):
    assert hasattr(context, "followup_request"), "followup_request is missing from context"
    status_code = context.followup_request.status_code

    # Ensure followup_response is at least a dict to avoid TypeError in formatting
    followup_body = context.followup_response if isinstance(context.followup_response, (dict, list, str)) else {}
    try:
        body_str = json.dumps(followup_body)
    except (TypeError, ValueError):
        body_str = str(followup_body)

    assert status_code == 404, f"Expected 404 for deleted order, got {status_code}: {body_str}"

# ----

import time
from typing import Any, Dict, List



def _safe_get_pet_ids(pets: Any) -> List[int]:
    """
    Safely extract pet IDs from a list-like JSON response.
    Returns a list of integer IDs, skipping any entries without a valid numeric id.
    """
    safe_ids: List[int] = []
    if not isinstance(pets, list):
        return safe_ids

    for pet in pets:
        if not isinstance(pet, dict):
            continue
        pet_id = pet.get("id")
        try:
            # Accept int-like values only; skip others instead of raising
            if isinstance(pet_id, bool):
                # exclude booleans which are int subclasses
                continue
            if isinstance(pet_id, (int, float)) and not isinstance(pet_id, bool):
                safe_ids.append(int(pet_id))
            elif isinstance(pet_id, str) and pet_id.strip() != "":
                safe_ids.append(int(pet_id))
        except (TypeError, ValueError):
            # Skip invalid id values without failing the scenario
            continue
    return safe_ids


@given('a seed input that requests pets filtered by a specific set of tags (provided as a comma-separated list), producing a seed output with a list of pets for MR12.')
def _mr_MR12_seed_input(context):
    tags = "tag1,tag2"  # Example tags for the seed input

    # Build request params according to OpenAPI: tags is a required query array of strings
    seed_tags = [t for t in (tag.strip() for tag in tags.split(',')) if t]
    context.seed_request: Dict[str, Any] = {"tags": seed_tags}

    response = requests.get(
        f"{BASE_URL}/pet/findByTags",
        params=context.seed_request,
        timeout=10,
    )
    response.raise_for_status()

    try:
        context.seed_response = response.json()
    except ValueError:
        # Ensure context attributes are always present to avoid AttributeError later
        context.seed_response = []


@when('a follow-up input is created by adding additional tags to the seed input and requesting pets again, yielding a follow-up output for MR12.')
def _mr_MR12_followup_input(context):
    # Ensure seed_request exists and is a dict with "tags" as list
    base_tags: List[str] = []
    if isinstance(getattr(context, "seed_request", None), dict):
        tags_val = context.seed_request.get("tags", [])
        if isinstance(tags_val, list):
            base_tags = [t for t in tags_val if isinstance(t, str)]
        elif isinstance(tags_val, str):
            base_tags = [t.strip() for t in tags_val.split(",") if t.strip()]

    additional_tags_str = "tag3,tag4"
    additional_tags = [t for t in (tag.strip() for tag in additional_tags_str.split(',')) if t]

    combined_tags = base_tags + additional_tags
    context.followup_request: Dict[str, Any] = {"tags": combined_tags}

    response = requests.get(
        f"{BASE_URL}/pet/findByTags",
        params=context.followup_request,
        timeout=10,
    )
    response.raise_for_status()

    try:
        context.followup_response = response.json()
    except ValueError:
        context.followup_response = []


@then('the follow-up output should include all pets from the seed output for MR12, and may contain additional pets that match any of the newly added tags, so that the follow-up result set is a superset of the seed result set.')
def _mr_MR12_followup_output(context):
    seed_pets = getattr(context, "seed_response", [])
    followup_pets = getattr(context, "followup_response", [])

    seed_ids_set = set(_safe_get_pet_ids(seed_pets))
    followup_ids_set = set(_safe_get_pet_ids(followup_pets))

    assert seed_ids_set.issubset(followup_ids_set), (
        f"Follow-up output does not include all pets from the seed output. "
        f"Missing IDs: {sorted(seed_ids_set - followup_ids_set)}"
    )

# ----




@given('a seed input that creates a list of users in a single request, producing a seed output confirming successful creation for MR15.')
def _mr_MR15_create_users(context):
    users = [
        {
            "id": 1001,
            "username": "user1",
            "firstName": "John",
            "lastName": "Doe",
            "email": "john.doe@example.com",
            "password": "password1",
            "phone": "1234567890",
            "userStatus": 1
        },
        {
            "id": 1002,
            "username": "user2",
            "firstName": "Jane",
            "lastName": "Doe",
            "email": "jane.doe@example.com",
            "password": "password2",
            "phone": "0987654321",
            "userStatus": 1
        }
    ]

    context.seed_request = users

    try:
        response = requests.post(
            f"{BASE_URL}/user/createWithList",
            json=users,
            timeout=10
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in Given step for MR15: {e}") from e

    # Expect 200 according to OpenAPI spec
    if response.status_code != 200:
        raise AssertionError(
            f"Unexpected status code in Given step for MR15: "
            f"{response.status_code}, body: {response.text}"
        )

    # Response should be a single User object per spec; may or may not be JSON
    try:
        seed_resp_json = response.json()
    except ValueError:
        # Non‑JSON response is tolerated; just record raw text
        seed_resp_json = None

    context.seed_response = seed_resp_json


@when('a follow-up input is created by retrieving each user by username from the list using individual user-retrieval operations, yielding a follow-up output for MR15.')
def _mr_MR15_retrieve_users(context):
    followups = []

    for user in context.seed_request:
        username = user.get("username")
        if not isinstance(username, str) or not username:
            raise AssertionError(f"Invalid username in seed_request entry: {user!r}")

        try:
            response = requests.get(
                f"{BASE_URL}/user/{username}",
                timeout=10
            )
        except requests.RequestException as e:
            raise AssertionError(f"HTTP error in When step for MR15 for user '{username}': {e}") from e

        if response.status_code != 200:
            raise AssertionError(
                f"Unexpected status code retrieving user '{username}' in When step for MR15: "
                f"{response.status_code}, body: {response.text}"
            )

        try:
            followup_json = response.json()
        except ValueError as e:
            raise AssertionError(
                f"Non‑JSON response retrieving user '{username}' in When step for MR15: {response.text}"
            ) from e

        followups.append(followup_json)

    context.followup_response = followups


@then('the follow-up output should successfully retrieve details for each user created in the seed input, and each retrieved user should match the corresponding user data from the seed input for MR15.')
def _mr_MR15_verify_users(context):
    if not hasattr(context, "seed_request"):
        raise AssertionError("seed_request is missing from context in Then step for MR15.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("followup_response is missing from context in Then step for MR15.")

    seed_users = context.seed_request
    followup_users = context.followup_response

    if not isinstance(seed_users, list):
        raise AssertionError(f"seed_request must be a list, got {type(seed_users).__name__}")
    if not isinstance(followup_users, list):
        raise AssertionError(f"followup_response must be a list, got {type(followup_users).__name__}")

    if len(followup_users) != len(seed_users):
        raise AssertionError(
            f"Mismatch in number of users retrieved: expected {len(seed_users)}, "
            f"got {len(followup_users)}"
        )

    # Compare by username mapping to avoid order‑related issues
    followup_by_username = {}
    for fu in followup_users:
        if not isinstance(fu, dict):
            raise AssertionError(f"Each followup user must be a dict, got {type(fu).__name__}")
        username = fu.get("username")
        if username:
            followup_by_username[username] = fu

    for seed_user in seed_users:
        if not isinstance(seed_user, dict):
            raise AssertionError(f"Each seed user must be a dict, got {type(seed_user).__name__}")
        username = seed_user.get("username")
        if not username:
            raise AssertionError(f"Seed user missing username field: {json.dumps(seed_user)}")

        followup_user = followup_by_username.get(username)
        if followup_user is None:
            raise AssertionError(f"No followup user found for username '{username}'")

        # Compare selected fields that should remain stable
        for field in ["username", "firstName", "lastName", "email", "phone", "userStatus"]:
            seed_val = seed_user.get(field)
            follow_val = followup_user.get(field)
            if seed_val != follow_val:
                raise AssertionError(
                    f"Field '{field}' mismatch for user '{username}': "
                    f"seed='{seed_val}' followup='{follow_val}'"
                )
