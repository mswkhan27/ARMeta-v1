Feature: Iteration 1 MRs

  Scenario: MR6 Deleting a user should make subsequent retrieval fail
    Given a seed input that retrieves a user by username, producing a seed output with the user's details for MR6.
    When a follow-up input is created by deleting the user with the same username and then attempting to retrieve the user again, yielding a follow-up output for MR6.
    Then the follow-up output should indicate that the user is not found (for example, with an appropriate error status), contrasting with the successful seed output for MR6.

  Scenario: MR8 Uploading an image for a pet should not alter the pet's stored details
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR8.
    When a follow-up input is created by uploading an image for the pet and then retrieving the pet's details again, yielding a follow-up output for MR8.
    Then the follow-up output should match the seed output for MR8 in all fields defined for the pet's representation, since uploading an image does not modify the pet's other stored details.

  Scenario: MR10 Repeated logins with the same credentials should yield structurally similar responses
    Given a seed input that attempts to log in with valid credentials, producing a seed output with a successful login response for MR10.
    When a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR10.
    Then the follow-up output should indicate a successful login like the seed output for MR10, including a non-empty response body of the expected type and corresponding rate limit and expiration headers, although specific header values may differ.
