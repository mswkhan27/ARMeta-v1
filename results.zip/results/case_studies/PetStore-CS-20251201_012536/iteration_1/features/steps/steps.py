from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _safe_json(response):
    try:
        return response.json()
    except (ValueError, TypeError):
        return None


@given("a seed input that retrieves a user by username, producing a seed output with the user's details for MR6.")
def step_mr_MR6_seed_input(context):
    # Create a user to ensure it exists
    user_data = {
        "id": 1,
        "username": "testuser",
        "firstName": "Test",
        "lastName": "User",
        "email": "testuser@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1
    }

    create_resp = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    context.seed_create_response = create_resp
    context.seed_create_body = _safe_json(create_resp)

    assert create_resp.status_code == 200, (
        f"Failed to create user: status={create_resp.status_code}, "
        f"body={context.seed_create_body}"
    )

    # Retrieve the user to confirm creation (this is the seed output)
    get_resp = requests.get(f"{BASE_URL}/user/testuser", timeout=10)
    context.seed_get_response = get_resp
    context.seed_get_body = _safe_json(get_resp)

    assert get_resp.status_code == 200, (
        f"Failed to retrieve user: status={get_resp.status_code}, "
        f"body={context.seed_get_body}"
    )


@when("a follow-up input is created by deleting the user with the same username and then attempting to retrieve the user again, yielding a follow-up output for MR6.")
def step_mr_MR6_followup_input(context):
    # Delete the user
    delete_resp = requests.delete(f"{BASE_URL}/user/testuser", timeout=10)
    context.delete_response = delete_resp
    context.delete_body = _safe_json(delete_resp)

    assert delete_resp.status_code == 200, (
        f"Failed to delete user: status={delete_resp.status_code}, "
        f"body={context.delete_body}"
    )

    # Attempt to retrieve the user again (follow-up output)
    followup_resp = requests.get(f"{BASE_URL}/user/testuser", timeout=10)
    context.followup_response = followup_resp
    context.followup_body = _safe_json(followup_resp)


@then("the follow-up output should indicate that the user is not found (for example, with an appropriate error status), contrasting with the successful seed output for MR6.")
def step_mr_MR6_followup_output(context):
    assert hasattr(context, "seed_get_response"), "Seed get response is missing from context."
    assert context.seed_get_response.status_code == 200, (
        f"Seed retrieval was not successful as expected: "
        f"status={context.seed_get_response.status_code}, "
        f"body={context.seed_get_body}"
    )

    assert hasattr(context, "followup_response"), "Follow-up response is missing from context."
    assert context.followup_response.status_code == 404, (
        f"Expected 404 after deletion, got {context.followup_response.status_code}: "
        f"{context.followup_body}"
    )

# ----

import tempfile



@given("a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR8.")
def _mr_MR8_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }
    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    response.raise_for_status()

    seed_created = response.json()
    if not isinstance(seed_created, dict):
        raise TypeError(f"Unexpected response type when creating pet: {type(seed_created)}")

    pet_id = seed_created.get("id")
    if pet_id is None:
        raise ValueError("Created pet response does not contain 'id'")

    context.seed_request = pet_data
    context.pet_id = pet_id

    # Retrieve the pet by ID
    response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    response.raise_for_status()
    seed_retrieved = response.json()
    if not isinstance(seed_retrieved, dict):
        raise TypeError(f"Unexpected response type when retrieving pet: {type(seed_retrieved)}")

    context.seed_response = seed_retrieved


@when("a follow-up input is created by uploading an image for the pet and then retrieving the pet's details again, yielding a follow-up output for MR8.")
def _mr_MR8_followup_input(context):
    pet_id = getattr(context, "pet_id", None)
    if pet_id is None:
        raise ValueError("pet_id is not available in context")

    # Create a temporary dummy image file to avoid file path issues
    with tempfile.NamedTemporaryFile(suffix=".jpg") as tmp_file:
        tmp_file.write(b"\xff\xd8\xff\xd9")  # minimal JPEG header/footer bytes
        tmp_file.flush()

        with open(tmp_file.name, "rb") as image_file:
            files = {"file": image_file}
            response = requests.post(
                f"{BASE_URL}/pet/{pet_id}/uploadImage",
                files=files,
                timeout=10,
            )
            response.raise_for_status()

    # Retrieve the pet's details again
    response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    response.raise_for_status()
    followup = response.json()
    if not isinstance(followup, dict):
        raise TypeError(f"Unexpected response type when retrieving pet after upload: {type(followup)}")

    context.followup_response = followup


@then("the follow-up output should match the seed output for MR8 in all fields defined for the pet's representation, since uploading an image does not modify the pet's other stored details.")
def _mr_MR8_followup_output(context):
    if not isinstance(getattr(context, "seed_response", None), dict):
        raise TypeError("seed_response is missing or not a dict")
    if not isinstance(getattr(context, "followup_response", None), dict):
        raise TypeError("followup_response is missing or not a dict")

    # Compare all fields defined in the Pet schema that are present in the responses
    pet_fields = ["id", "name", "category", "photoUrls", "tags", "status"]

    for field in pet_fields:
        if field in context.seed_response:
            assert field in context.followup_response, f"Field '{field}' missing in follow-up response"
            seed_value = context.seed_response[field]
            followup_value = context.followup_response[field]
            assert followup_value == seed_value, (
                f"Field '{field}' does not match: {followup_value} != {seed_value}"
            )

# ----




@given('a seed input that attempts to log in with valid credentials, producing a seed output with a successful login response for MR10.')
def _mr_MR10_seed_login(context):
    context.seed_request = {
        'username': 'validUser',
        'password': 'validPassword'
    }
    response = requests.get(f"{BASE_URL}/user/login", params=context.seed_request, timeout=10)
    # Ensure we got a 2xx/3xx response; this will raise for 4xx/5xx
    response.raise_for_status()
    context.seed_status_code = response.status_code
    context.seed_headers = response.headers

    # /user/login returns a string (per OpenAPI), not necessarily JSON
    # Guard against JSON decoding issues by using text
    context.seed_response_body = response.text

    # Basic safety checks
    assert isinstance(context.seed_response_body, str), "Seed response body is not a string."
    assert context.seed_response_body.strip() != "", "Seed response body is empty."

    # Store expected header names for later comparison
    context.expected_header_keys = ['X-Rate-Limit', 'X-Expires-After']


@when('a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR10.')
def _mr_MR10_followup_login(context):
    # Reuse the same credentials from the seed step
    followup_request = {
        'username': context.seed_request.get('username'),
        'password': context.seed_request.get('password')
    }
    response = requests.get(f"{BASE_URL}/user/login", params=followup_request, timeout=10)
    response.raise_for_status()
    context.followup_status_code = response.status_code
    context.followup_headers = response.headers
    context.followup_response_body = response.text

    assert isinstance(context.followup_response_body, str), "Follow-up response body is not a string."
    assert context.followup_response_body.strip() != "", "Follow-up response body is empty."


@then('the follow-up output should indicate a successful login like the seed output for MR10, including a non-empty response body of the expected type and corresponding rate limit and expiration headers, although specific header values may differ.')
def _mr_MR10_assert_followup(context):
    # Both responses should indicate success (same 2xx code is a reasonable structural similarity)
    assert str(context.followup_status_code).startswith("2"), "Follow-up login did not succeed."
    assert str(context.seed_status_code).startswith("2"), "Seed login did not succeed."
    assert context.followup_status_code == context.seed_status_code, \
        "Seed and follow-up status codes differ, violating structural similarity."

    # Response bodies should both be non-empty strings (expected type from OpenAPI)
    assert isinstance(context.seed_response_body, str), "Seed response body is not a string."
    assert isinstance(context.followup_response_body, str), "Follow-up response body is not a string."
    assert context.seed_response_body.strip() != "", "Seed response body is empty."
    assert context.followup_response_body.strip() != "", "Follow-up response body is empty."

    # They should be structurally similar: here both being non-empty strings satisfies this.
    # Optionally, ensure they both contain or both do not contain a delimiter like space.
    assert bool(" " in context.seed_response_body) == bool(" " in context.followup_response_body), \
        "Seed and follow-up response bodies differ structurally."

    # Check presence of rate limit and expiration headers in both responses
    for header_name in getattr(context, 'expected_header_keys', ['X-Rate-Limit', 'X-Expires-After']):
        assert header_name in context.seed_headers, f"Missing {header_name} header in seed response."
        assert header_name in context.followup_headers, f"Missing {header_name} header in follow-up response."

    # Header values may differ, but they should be non-empty where present
    seed_rate_limit = context.seed_headers.get('X-Rate-Limit')
    follow_rate_limit = context.followup_headers.get('X-Rate-Limit')
    seed_expires = context.seed_headers.get('X-Expires-After')
    follow_expires = context.followup_headers.get('X-Expires-After')

    assert seed_rate_limit is not None and str(seed_rate_limit).strip() != "", \
        "Seed X-Rate-Limit header is empty."
    assert follow_rate_limit is not None and str(follow_rate_limit).strip() != "", \
        "Follow-up X-Rate-Limit header is empty."
    assert seed_expires is not None and str(seed_expires).strip() != "", \
        "Seed X-Expires-After header is empty."
    assert follow_expires is not None and str(follow_expires).strip() != "", \
        "Follow-up X-Expires-After header is empty."
