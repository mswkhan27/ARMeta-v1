Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet with status available should increase the count of available pets
    Given a seed input that requests pets filtered by the status value 'available', producing a seed output with the number of pets returned for MR1.
    When a follow-up input is created by adding a new pet whose status field is set to 'available', and then requesting pets filtered by status 'available' again, yielding a follow-up output for MR1.
    Then the follow-up output should contain a count of pets with status 'available' that is one more than in the seed output for MR1, assuming no other changes occurred in between.

  Scenario: MR2 Updating a pet's status should reflect in the status-based results
    Given a seed input that requests pets filtered by the status value 'pending', producing a seed output with a list of pending pets for MR2.
    When a follow-up input is created by updating one pet from the seed output so that its status changes from 'pending' to 'sold', and then requesting pets filtered by status 'pending' again, yielding a follow-up output for MR2.
    Then the follow-up output should no longer include the updated pet in the list of pending pets, in contrast to the seed output for MR2.

  Scenario: MR3 Deleting a pet with a given status should decrease that status quantity in the inventory
    Given a seed input that retrieves the pet inventory as quantities grouped by status, producing a seed output with the quantity for a chosen status value (for example, 'available') for MR3, and a pet with that chosen status is identified for deletion.
    When a follow-up input is created by deleting the identified pet and then retrieving the pet inventory again, yielding a follow-up output for MR3.
    Then for the chosen status value used in the seed input, the quantity in the follow-up output should be one less than in the seed output for MR3, assuming no other changes occurred in between.

  Scenario: MR5 Updating a user's information should only change the explicitly updated fields
    Given a seed input that retrieves a user's details by username, producing a seed output with the user's information for MR5.
    When a follow-up input is created by sending an update for that user which changes only the email field while keeping all other fields the same, and then retrieving the user's details again, yielding a follow-up output for MR5.
    Then the follow-up output should differ from the seed output only in the email field; all other fields should match the seed output for MR5.
