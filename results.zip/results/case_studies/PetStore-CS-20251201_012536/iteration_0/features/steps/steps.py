from behave import given, when, then
import os
import json
import requests
from typing import Any, List, Dict

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _safe_get_json_list(response: requests.Response) -> List[Dict[str, Any]]:
    """
    Safely parse a JSON response that is expected to be a list.
    Returns an empty list on any parsing/type issue instead of raising TypeError/ValueError.
    """
    try:
        data = response.json()
    except ValueError:
        return []
    if isinstance(data, list):
        return data
    return []


@given("a seed input that requests pets filtered by the status value 'available', producing a seed output with the number of pets returned for MR1.")
def _mr_MR1_seed_input(context):
    url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        pets = _safe_get_json_list(response)

        context.seed_response = pets
        context.seed_request = params
        context.misc = len(pets)
    except Exception as e:
        print(f"Error in GIVEN step for MR1: {e}")
        raise


@when("a follow-up input is created by adding a new pet whose status field is set to 'available', and then requesting pets filtered by status 'available' again, yielding a follow-up output for MR1.")
def _mr_MR1_followup_input(context):
    add_url = f"{BASE_URL}/pet"
    list_url = f"{BASE_URL}/pet/findByStatus"
    new_pet = {
        "name": "New Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    try:
        add_response = requests.post(add_url, json=new_pet, timeout=10)
        add_response.raise_for_status()

        params = {"status": "available"}
        followup_response = requests.get(list_url, params=params, timeout=10)
        followup_response.raise_for_status()

        pets = _safe_get_json_list(followup_response)
        context.followup_response = pets
        context.followup_request = params
    except Exception as e:
        print(f"Error in WHEN step for MR1: {e}")
        raise


@then("the follow-up output should contain a count of pets with status 'available' that is one more than in the seed output for MR1, assuming no other changes occurred in between.")
def _mr_MR1_followup_assertion(context):
    try:
        seed_count = int(getattr(context, "misc", 0))
        followup_list = getattr(context, "followup_response", []) or []
        followup_count = len(followup_list)

        assert followup_count == seed_count + 1, (
            f"Expected {seed_count + 1} pets, but got {followup_count}"
        )
    except (TypeError, ValueError) as e:
        print(f"Type conversion error in THEN step for MR1: {e}")
        raise
    except AssertionError as e:
        print(f"Assertion error in THEN step for MR1: {e}")
        raise

# ----

from typing import Any, Dict, List



def _safe_get_json(response: requests.Response) -> Any:
    try:
        return response.json()
    except ValueError:
        raise AssertionError("Response body is not valid JSON")


def _ensure_pet_list(pets: Any) -> List[Dict[str, Any]]:
    if not isinstance(pets, list):
        raise AssertionError("Expected a list of pets")
    return pets


def _ensure_pet_has_id(pet: Dict[str, Any]) -> int:
    if not isinstance(pet, dict):
        raise AssertionError("Pet item is not an object")
    pet_id = pet.get("id")
    if not isinstance(pet_id, int):
        raise AssertionError("Pet 'id' is missing or not an integer")
    return pet_id


def _build_update_payload(original_pet: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build a safe payload for PUT /pet based on the Pet schema.
    Avoid KeyError / TypeError by using .get and default values.
    """
    pet_id = _ensure_pet_has_id(original_pet)

    name = original_pet.get("name") or "pet-" + str(pet_id)
    photo_urls = original_pet.get("photoUrls") or ["http://example.com/photo.png"]

    if not isinstance(photo_urls, list):
        photo_urls = [str(photo_urls)]

    category = original_pet.get("category") or {}
    tags = original_pet.get("tags") or []

    if not isinstance(tags, list):
        tags = [tags]

    payload: Dict[str, Any] = {
        "id": pet_id,
        "name": name,
        "status": "sold",
        "photoUrls": photo_urls,
    }

    # Only include category if it is a dict
    if isinstance(category, dict):
        payload["category"] = category

    # Only include tags if it is a list
    if isinstance(tags, list):
        payload["tags"] = tags

    return payload


@given("a seed input that requests pets filtered by the status value 'pending', producing a seed output with a list of pending pets for MR2.")
def _mr_MR2_seed_input(context):
    context.seed_request = {"status": "pending"}

    response = requests.get(
        f"{BASE_URL}/pet/findByStatus", params=context.seed_request, timeout=10
    )
    response.raise_for_status()

    data = _safe_get_json(response)
    context.seed_response = _ensure_pet_list(data)

    if len(context.seed_response) == 0:
        raise AssertionError("Seed response is empty, cannot perform MR2 reliably.")


@when("a follow-up input is created by updating one pet from the seed output so that its status changes from 'pending' to 'sold', and then requesting pets filtered by status 'pending' again, yielding a follow-up output for MR2.")
def _mr_MR2_followup_input(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is not available in context.")

    seed_pets = _ensure_pet_list(context.seed_response)
    if not seed_pets:
        raise AssertionError("Seed response is empty, cannot update pet.")

    pet_to_update = seed_pets[0]
    _ensure_pet_has_id(pet_to_update)

    update_payload = _build_update_payload(pet_to_update)

    update_response = requests.put(
        f"{BASE_URL}/pet", json=update_payload, timeout=10
    )
    update_response.raise_for_status()
    _safe_get_json(update_response)  # Validate JSON, even if not used later

    context.followup_request = {"status": "pending"}
    followup_response = requests.get(
        f"{BASE_URL}/pet/findByStatus", params=context.followup_request, timeout=10
    )
    followup_response.raise_for_status()

    followup_data = _safe_get_json(followup_response)
    context.followup_response = _ensure_pet_list(followup_data)


@then("the follow-up output should no longer include the updated pet in the list of pending pets, in contrast to the seed output for MR2.")
def _mr_MR2_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is not available in context.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response is not available in context.")

    seed_pets = _ensure_pet_list(context.seed_response)
    followup_pets = _ensure_pet_list(context.followup_response)

    updated_pet_id = _ensure_pet_has_id(seed_pets[0])

    for pet in followup_pets:
        pet_id = pet.get("id")
        if pet_id == updated_pet_id:
            raise AssertionError(
                "The updated pet is still present in the list of pending pets."
            )

# ----




@given("a seed input that retrieves the pet inventory as quantities grouped by status, producing a seed output with the quantity for a chosen status value (for example, 'available') for MR3, and a pet with that chosen status is identified for deletion.")
def _mr_MR3_seed_input(context):
    # Retrieve the inventory safely
    inventory_response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    inventory_response.raise_for_status()

    try:
        seed_response = inventory_response.json()
    except ValueError as exc:
        raise AssertionError(f"Inventory response is not valid JSON: {exc}") from exc

    if not isinstance(seed_response, dict):
        raise AssertionError(f"Inventory response JSON is not an object: {seed_response!r}")

    context.seed_response = seed_response
    context.chosen_status = 'available'

    seed_quantity_raw = context.seed_response.get(context.chosen_status, 0)
    try:
        context.seed_quantity = int(seed_quantity_raw)
    except (TypeError, ValueError) as exc:
        raise AssertionError(
            f"Seed quantity for status '{context.chosen_status}' is not an integer: {seed_quantity_raw!r}"
        ) from exc

    # Ensure we have at least one pet with the chosen status
    context.pet_id = None

    if context.seed_quantity <= 0:
        # Create a pet with the chosen status
        pet_data = {
            "name": "Test Pet MR3",
            "photoUrls": ["http://example.com/photo.jpg"],
            "status": context.chosen_status,
        }
        add_pet_response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        add_pet_response.raise_for_status()

        try:
            pet_body = add_pet_response.json()
        except ValueError as exc:
            raise AssertionError(f"Add pet response is not valid JSON: {exc}") from exc

        if not isinstance(pet_body, dict):
            raise AssertionError(f"Add pet response JSON is not an object: {pet_body!r}")

        pet_id = pet_body.get("id")
        try:
            context.pet_id = int(pet_id)
        except (TypeError, ValueError) as exc:
            raise AssertionError(f"Created pet id is not an integer: {pet_id!r}") from exc

        # Re-read inventory to update seed_quantity after creating the pet
        inventory_response_2 = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
        inventory_response_2.raise_for_status()

        try:
            seed_response_2 = inventory_response_2.json()
        except ValueError as exc:
            raise AssertionError(f"Inventory response after pet creation is not valid JSON: {exc}") from exc

        if not isinstance(seed_response_2, dict):
            raise AssertionError(f"Inventory response JSON after creation is not an object: {seed_response_2!r}")

        context.seed_response = seed_response_2
        seed_quantity_raw_2 = context.seed_response.get(context.chosen_status, 0)
        try:
            context.seed_quantity = int(seed_quantity_raw_2)
        except (TypeError, ValueError) as exc:
            raise AssertionError(
                f"Seed quantity (after creation) for status '{context.chosen_status}' is not an integer: {seed_quantity_raw_2!r}"
            ) from exc
    else:
        # Seed inventory shows at least one pet with chosen status.
        # Use GET /pet/findByStatus to locate a concrete pet id.
        find_response = requests.get(
            f"{BASE_URL}/pet/findByStatus",
            params={"status": context.chosen_status},
            timeout=10,
        )
        find_response.raise_for_status()

        try:
            pets = find_response.json()
        except ValueError as exc:
            raise AssertionError(f"findByStatus response is not valid JSON: {exc}") from exc

        if not isinstance(pets, list):
            raise AssertionError(f"findByStatus response JSON is not a list: {pets!r}")

        # Pick the first pet with an integer id
        for pet in pets:
            if isinstance(pet, dict) and "id" in pet:
                try:
                    context.pet_id = int(pet["id"])
                    break
                except (TypeError, ValueError):
                    continue

        if context.pet_id is None:
            raise AssertionError("Could not find any pet with a valid integer 'id' in findByStatus response.")

    # Final safety check
    if context.pet_id is None:
        raise AssertionError("pet_id was not set; cannot proceed with MR3.")


@when("a follow-up input is created by deleting the identified pet and then retrieving the pet inventory again, yielding a follow-up output for MR3.")
def _mr_MR3_followup_input(context):
    if not hasattr(context, "pet_id") or context.pet_id is None:
        raise AssertionError("pet_id is missing on context in When step.")

    # Delete the identified pet using DELETE /pet/\{petId\}
    delete_response = requests.delete(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
    delete_response.raise_for_status()

    # Retrieve the inventory again
    followup_request = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    followup_request.raise_for_status()

    try:
        followup_response = followup_request.json()
    except ValueError as exc:
        raise AssertionError(f"Follow-up inventory response is not valid JSON: {exc}") from exc

    if not isinstance(followup_response, dict):
        raise AssertionError(f"Follow-up inventory response JSON is not an object: {followup_response!r}")

    context.followup_response = followup_response


@then("for the chosen status value used in the seed input, the quantity in the follow-up output should be one less than in the seed output for MR3, assuming no other changes occurred in between.")
def _mr_MR3_assert_quantity(context):
    if not hasattr(context, "chosen_status"):
        raise AssertionError("chosen_status is missing on context in Then step.")
    if not hasattr(context, "seed_quantity"):
        raise AssertionError("seed_quantity is missing on context in Then step.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("followup_response is missing on context in Then step.")

    followup_quantity_raw = context.followup_response.get(context.chosen_status, 0)
    try:
        followup_quantity = int(followup_quantity_raw)
    except (TypeError, ValueError) as exc:
        raise AssertionError(
            f"Follow-up quantity for status '{context.chosen_status}' is not an integer: {followup_quantity_raw!r}"
        ) from exc

    expected = context.seed_quantity - 1
    assert followup_quantity == expected, (
        f"Expected follow-up quantity for status '{context.chosen_status}' to be {expected}, "
        f"but got {followup_quantity}. Seed quantity was {context.seed_quantity}."
    )

# ----






@given("a seed input that retrieves a user's details by username, producing a seed output with the user's information for MR5.")
def step_mr_MR5_seed_input(context):
    # Prepare deterministic seed user data
    user_data = {
        "id": 10,
        "username": "testuser",
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1,
    }

    # Create user (POST /user)
    create_resp = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    context.seed_create_status = create_resp.status_code
    context.seed_create_response = _safe_get_json(create_resp)

    # Retrieve the user details (GET /user/\{username\})
    get_resp = requests.get(f"{BASE_URL}/user/testuser", timeout=10)
    context.seed_get_status = get_resp.status_code
    context.seed_response = _safe_get_json(get_resp)


@when("a follow-up input is created by sending an update for that user which changes only the email field while keeping all other fields the same, and then retrieving the user's details again, yielding a follow-up output for MR5.")
def step_mr_MR5_followup_input(context):
    seed = context.seed_response if isinstance(context.seed_response, dict) else {}

    updated_user_data = {
        "id": seed.get("id"),
        "username": seed.get("username"),
        "firstName": seed.get("firstName"),
        "lastName": seed.get("lastName"),
        "email": "new.email@example.com",
        "password": seed.get("password"),
        "phone": seed.get("phone"),
        "userStatus": seed.get("userStatus"),
    }

    username = seed.get("username") or "testuser"

    # Update user (PUT /user/\{username\})
    update_resp = requests.put(
        f"{BASE_URL}/user/{username}",
        json=updated_user_data,
        timeout=10,
    )
    context.followup_update_status = update_resp.status_code
    context.followup_update_response = _safe_get_json(update_resp)

    # Retrieve updated user details (GET /user/\{username\})
    get_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    context.followup_get_status = get_resp.status_code
    context.followup_response = _safe_get_json(get_resp)


@then("the follow-up output should differ from the seed output only in the email field; all other fields should match the seed output for MR5.")
def step_mr_MR5_followup_output(context):
    seed = context.seed_response if isinstance(context.seed_response, dict) else {}
    followup = context.followup_response if isinstance(context.followup_response, dict) else {}

    # Basic sanity: ensure we have dictionaries
    assert isinstance(seed, dict), f"Seed response is not a JSON object: {seed!r}"
    assert isinstance(followup, dict), f"Follow-up response is not a JSON object: {followup!r}"

    # Email must be updated
    assert followup.get("email") == "new.email@example.com", (
        f"Email did not update correctly. Got {followup.get('email')!r}"
    )

    # Fields that must remain equal
    fields_to_match = ["id", "username", "firstName", "lastName", "password", "phone", "userStatus"]
    for field in fields_to_match:
        assert followup.get(field) == seed.get(field), (
            f"Field '{field}' mismatch: seed={seed.get(field)!r}, followup={followup.get(field)!r}"
        )

    # Optionally ensure no unexpected extra differences in known schema fields
    known_fields = set(fields_to_match + ["email"])
    seed_filtered = {k: v for k, v in seed.items() if k in known_fields}
    followup_filtered = {k: v for k, v in followup.items() if k in known_fields}
    assert seed_filtered != followup_filtered, "Filtered seed and follow-up are identical; email change not reflected."
