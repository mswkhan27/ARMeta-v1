Feature: Iteration 4 MRs

  Scenario: MR18 Logging out a user should return a successful logout response
    Given a seed input that logs a user into the system, producing a seed output with a successful login response for MR18.
    When a follow-up input is created by invoking the logout operation for the currently logged-in user, yielding a follow-up output for MR18.
    Then the follow-up output should indicate a successful logout according to the operation definition (e.g., a successful status response), consistent with the expected behavior described for MR18.
