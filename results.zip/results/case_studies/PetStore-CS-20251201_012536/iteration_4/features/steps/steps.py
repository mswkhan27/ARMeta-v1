from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that logs a user into the system, producing a seed output with a successful login response for MR18.')
def _mr_MR18_seed_login(context):
    user_data = {
        "id": 123456,
        "username": "testuser_mr18",
        "firstName": "Test",
        "lastName": "User",
        "email": "testuser_mr18@example.com",
        "password": "testpassword",
        "phone": "1234567890",
        "userStatus": 1
    }

    create_user_resp = requests.post(
        f"{BASE_URL}/user",
        json=user_data,
        timeout=10
    )

    # Ensure we only call .json() on 200 responses that are expected to have a body
    create_user_body = None
    if create_user_resp.headers.get("Content-Type", "").startswith("application/json"):
        try:
            create_user_body = create_user_resp.json()
        except ValueError:
            create_user_body = None

    assert create_user_resp.status_code == 200, f"Failed to create user: {create_user_body}"

    login_resp = requests.get(
        f"{BASE_URL}/user/login",
        params={"username": user_data["username"], "password": user_data["password"]},
        timeout=10
    )

    login_body = None
    if login_resp.headers.get("Content-Type", "").startswith("application/json"):
        try:
            login_body = login_resp.json()
        except ValueError:
            login_body = None

    context.seed_response = {
        "status_code": login_resp.status_code,
        "body": login_body,
        "raw_text": login_resp.text
    }

    assert login_resp.status_code == 200, f"Login failed: {login_body or login_resp.text}"


@when('a follow-up input is created by invoking the logout operation for the currently logged-in user, yielding a follow-up output for MR18.')
def _mr_MR18_logout(context):
    logout_resp = requests.get(
        f"{BASE_URL}/user/logout",
        timeout=10
    )

    logout_body = None
    # /user/logout 200 response does not define a body, but be robust if server sends JSON
    content_type = logout_resp.headers.get("Content-Type", "")
    if content_type.startswith("application/json"):
        try:
            logout_body = logout_resp.json()
        except ValueError:
            logout_body = None

    context.followup_response = {
        "status_code": logout_resp.status_code,
        "body": logout_body,
        "raw_text": logout_resp.text
    }


@then('the follow-up output should indicate a successful logout according to the operation definition (e.g., a successful status response), consistent with the expected behavior described for MR18.')
def _mr_MR18_assert_logout(context):
    followup = getattr(context, "followup_response", None)
    assert followup is not None, "Follow-up response is None"

    status_code = followup.get("status_code")
    assert status_code == 200, f"Unexpected logout status code: {status_code}, body: {followup.get('body') or followup.get('raw_text')!r}"

    # The OpenAPI spec for /user/logout does not define a response body.
    # We only assert on status code; body, if any, is ignored to avoid brittle or erroneous checks.
