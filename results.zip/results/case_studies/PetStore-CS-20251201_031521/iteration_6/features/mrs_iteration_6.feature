Feature: Iteration 6 MRs

  Scenario: MR25 Adding a new pet with a specific ID should make it retrievable by that ID
    Given a seed input that adds a new pet to the store with a specific ID, producing a seed output that includes the created pet with its identifier for MR25.
    When a follow-up input is created by retrieving the pet using the identifier returned in the seed output, yielding a follow-up output for MR25.
    Then the follow-up output should contain the pet details matching the seed output, confirming that the pet is retrievable by its identifier for MR25.

  Scenario: MR26 Updating a pet's name while keeping other details the same should only change the name
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current details including its name for MR26.
    When a follow-up input is created by updating the pet using the same identifier and sending the same values for all fields except a changed name, and then retrieving the pet again by the same ID, yielding a follow-up output for MR26.
    Then the follow-up output should reflect the updated name while all other pet details remain unchanged compared to the corresponding fields in the seed output, given that the update request preserved those other field values for MR26.

  Scenario: MR27 Deleting a pet should make it inaccessible by its ID
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's details for MR27.
    When a follow-up input is created by deleting the pet with the same ID and then attempting to retrieve the pet again by the same ID, yielding a follow-up output for MR27.
    Then the follow-up output should indicate that the pet is not found, differing from the seed output which contains the pet's details for MR27.

  Scenario: MR28 Uploading an image should not affect the pet's retrievable status
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current status for MR28.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR28.
    Then the follow-up output should have the same pet status as the seed output for MR28, since uploading an image does not modify the pet's status in the store.

  Scenario: MR29 Creating a pet with a specific status should increase the count of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a single allowed status value (available, pending, or sold), producing a seed output with the list and its count for that status for MR29.
    When a follow-up input is created by adding a new pet with that same status value and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR29.
    Then the follow-up output should have a count of pets with that status that is one more than the count in the seed output for MR29, assuming no other changes to pets with that status occur between the two retrievals.
