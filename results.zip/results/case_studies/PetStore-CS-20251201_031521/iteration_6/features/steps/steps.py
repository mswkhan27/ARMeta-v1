from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that adds a new pet to the store with a specific ID, producing a seed output that includes the created pet with its identifier for MR25.')
def _mr_MR25_add_pet(context):
    pet_data = {
        "id": 25,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    context.seed_request = pet_data

    try:
        response = requests.post(f"{BASE_URL}/pet", json=context.seed_request, timeout=10)
        response.raise_for_status()
        try:
            context.seed_response = response.json()
            if not isinstance(context.seed_response, dict):
                context.seed_response = {}
        except (ValueError, TypeError):
            context.seed_response = {}
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in Given step for MR25: {e}") from e


@when('a follow-up input is created by retrieving the pet using the identifier returned in the seed output, yielding a follow-up output for MR25.')
def _mr_MR25_get_pet(context):
    seed_response = getattr(context, "seed_response", {}) or {}
    pet_id = seed_response.get('id')

    if pet_id is None:
        raise AssertionError("Seed response does not contain 'id' for MR25 follow-up step")

    try:
        response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        response.raise_for_status()
        try:
            context.followup_response = response.json()
            if not isinstance(context.followup_response, dict):
                context.followup_response = {}
        except (ValueError, TypeError):
            context.followup_response = {}
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in When step for MR25: {e}") from e


@then('the follow-up output should contain the pet details matching the seed output, confirming that the pet is retrievable by its identifier for MR25.')
def _mr_MR25_verify_pet(context):
    seed_response = getattr(context, "seed_response", {}) or {}
    followup_response = getattr(context, "followup_response", {}) or {}

    for key in ["id", "name", "status", "photoUrls"]:
        assert key in seed_response, f"Seed response missing expected key '{key}'"
        assert key in followup_response, f"Follow-up response missing expected key '{key}'"
        assert followup_response.get(key) == seed_response.get(key), f"Pet {key} does not match between seed and follow-up responses"

# ----

from copy import deepcopy

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


@given("a seed input that retrieves a pet by its ID, producing a seed output with the pet's current details including its name for MR26.")
def step_mr_MR26_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available",
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    response.raise_for_status()

    # Seed response from creation (includes generated id, maybe other defaults)
    created_pet = response.json()
    if not isinstance(created_pet, dict):
        raise TypeError("Expected JSON object for created pet")

    pet_id = created_pet.get("id")
    if pet_id is None:
        raise ValueError("Created pet response does not contain 'id'")

    context.pet_id = pet_id
    context.seed_request = deepcopy(pet_data)

    # Retrieve the pet by ID to get the seed output (as per MR description)
    response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    response.raise_for_status()

    seed_response = response.json()
    if not isinstance(seed_response, dict):
        raise TypeError("Expected JSON object for seed pet retrieval")

    context.seed_response = seed_response


@when("a follow-up input is created by updating the pet using the same identifier and sending the same values for all fields except a changed name, and then retrieving the pet again by the same ID, yielding a follow-up output for MR26.")
def step_mr_MR26_followup_input(context):
    if not hasattr(context, "seed_response"):
        raise AttributeError("seed_response not found in context")
    if not hasattr(context, "pet_id"):
        raise AttributeError("pet_id not found in context")

    # Copy all fields from the seed response to keep them the same,
    # then only modify the name field
    if not isinstance(context.seed_response, dict):
        raise TypeError("seed_response must be a dict")

    updated_pet_data = deepcopy(context.seed_response)
    updated_pet_data["name"] = "doggie_updated"

    # Ensure the id is preserved and is of the correct type (int64 → Python int)
    pet_id = updated_pet_data.get("id")
    if pet_id is None:
        raise ValueError("Updated pet payload must contain 'id'")
    try:
        updated_pet_data["id"] = int(pet_id)
    except (TypeError, ValueError) as exc:
        raise ValueError("Pet id must be convertible to int") from exc

    response = requests.put(f"{BASE_URL}/pet", json=updated_pet_data, timeout=10)
    response.raise_for_status()

    # Retrieve the pet again to get the follow-up output
    response = requests.get(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
    response.raise_for_status()

    followup_response = response.json()
    if not isinstance(followup_response, dict):
        raise TypeError("Expected JSON object for follow-up pet retrieval")

    context.followup_response = followup_response


@then("the follow-up output should reflect the updated name while all other pet details remain unchanged compared to the corresponding fields in the seed output, given that the update request preserved those other field values for MR26.")
def step_mr_MR26_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AttributeError("seed_response not found in context")
    if not hasattr(context, "followup_response"):
        raise AttributeError("followup_response not found in context")

    seed = context.seed_response
    followup = context.followup_response

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise TypeError("seed_response and followup_response must be dicts")

    # Name should be updated
    assert followup.get("name") == "doggie_updated", "Name was not updated correctly."

    # ID and other fields should remain unchanged
    assert followup.get("id") == seed.get("id"), "ID should remain the same."
    assert followup.get("photoUrls") == seed.get("photoUrls"), "Photo URLs should remain unchanged."
    assert followup.get("status") == seed.get("status"), "Status should remain unchanged."
    # Optional: compare category and tags if present in the seed output
    if "category" in seed:
        assert followup.get("category") == seed.get("category"), "Category should remain unchanged."
    if "tags" in seed:
        assert followup.get("tags") == seed.get("tags"), "Tags should remain unchanged."

# ----

import time



@given("a seed input that retrieves a pet by its ID, producing a seed output with the pet's details for MR27.")
def _mr_MR27_seed_input(context):
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }
    try:
        context.seed_request = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        # Ensure we can safely parse JSON (or default to empty dict)
        try:
            context.seed_response = context.seed_request.json()
        except ValueError:
            context.seed_response = {}

        assert context.seed_request.status_code == 200, (
            f"Failed to create pet: {json.dumps(context.seed_response, ensure_ascii=False)}"
        )
        # Safely get pet id from response, fall back to the one we sent
        context.seed_pet_id = context.seed_response.get("id", pet_data["id"])
    except Exception as e:
        raise AssertionError(f"Error in Given step for MR27: {e}") from e


@when("a follow-up input is created by deleting the pet with the same ID and then attempting to retrieve the pet again by the same ID, yielding a follow-up output for MR27.")
def _mr_MR27_followup_input(context):
    try:
        pet_id = getattr(context, "seed_pet_id", None)
        if pet_id is None:
            raise AssertionError("seed_pet_id is not set in context")

        delete_response = requests.delete(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        # Accept 200 as successful deletion; capture body safely
        try:
            delete_body = delete_response.json()
        except ValueError:
            delete_body = {}

        assert delete_response.status_code == 200, (
            f"Failed to delete pet: status={delete_response.status_code}, "
            f"body={json.dumps(delete_body, ensure_ascii=False)}"
        )

        context.followup_request = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        try:
            context.followup_response = context.followup_request.json()
        except ValueError:
            context.followup_response = {}
    except Exception as e:
        raise AssertionError(f"Error in When step for MR27: {e}") from e


@then("the follow-up output should indicate that the pet is not found, differing from the seed output which contains the pet's details for MR27.")
def _mr_MR27_followup_output(context):
    followup_status = getattr(context.followup_request, "status_code", None)
    assert followup_status == 404, (
        f"Expected 404, got {followup_status} with response: "
        f"{json.dumps(getattr(context, 'followup_response', {}), ensure_ascii=False)}"
    )

    seed_response = getattr(context, "seed_response", {})
    seed_id = seed_response.get("id")
    assert seed_id == 1, f"Seed output should contain the pet's details with id 1, got {seed_id!r}."

# ----




@given("a seed input that retrieves a pet by its ID, producing a seed output with the pet's current status for MR28.")
def _mr_MR28_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1"],
        "status": "available"
    }

    resp = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    try:
        body = resp.json()
    except ValueError:
        body = None
    assert resp.status_code == 200, f"Failed to create pet: status={resp.status_code}, body={body}"

    # Retrieve the pet to get the seed output
    resp = requests.get(f"{BASE_URL}/pet/1", timeout=10)
    try:
        body = resp.json()
    except ValueError:
        body = None
    assert resp.status_code == 200, f"Failed to retrieve pet: status={resp.status_code}, body={body}"

    context.seed_response = body if isinstance(body, dict) else {}
    context.seed_status = context.seed_response.get("status")


@when("a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR28.")
def _mr_MR28_followup_input(context):
    # Prepare a small dummy "image" in memory; API only requires octet-stream
    files = {
        "file": ("dummy.jpg", b"dummy-bytes", "application/octet-stream")
    }

    resp = requests.post(f"{BASE_URL}/pet/1/uploadImage", files=files, timeout=10)
    try:
        body = resp.json()
    except ValueError:
        body = None
    assert resp.status_code == 200, f"Failed to upload image: status={resp.status_code}, body={body}"

    # Retrieve the pet again to get the follow-up output
    resp = requests.get(f"{BASE_URL}/pet/1", timeout=10)
    try:
        body = resp.json()
    except ValueError:
        body = None
    assert resp.status_code == 200, f"Failed to retrieve pet: status={resp.status_code}, body={body}"

    context.followup_response = body if isinstance(body, dict) else {}
    context.followup_status = context.followup_response.get("status")


@then("the follow-up output should have the same pet status as the seed output for MR28, since uploading an image does not modify the pet's status in the store.")
def _mr_MR28_followup_output(context):
    assert hasattr(context, "seed_status"), "Seed status not set in context"
    assert hasattr(context, "followup_status"), "Follow-up status not set in context"
    assert context.seed_status is not None, "Seed response does not contain a 'status' field"
    assert context.followup_status is not None, "Follow-up response does not contain a 'status' field"
    assert context.followup_status == context.seed_status, (
        f"Pet status has changed after image upload: seed={context.seed_status}, "
        f"followup={context.followup_status}"
    )

# ----

from typing import Any, Dict, List



def _safe_get_json(response: requests.Response) -> Any:
    try:
        return response.json()
    except ValueError:
        return None


@given('a seed input that retrieves the list of pets filtered by a single allowed status value (available, pending, or sold), producing a seed output with the list and its count for that status for MR29.')
def step_mr_MR29_seed_input(context):
    status = 'available'  # Allowed status value per spec: available | pending | sold
    url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": status}

    response = requests.get(url, params=params, timeout=10)
    response.raise_for_status()

    data = _safe_get_json(response)
    if not isinstance(data, list):
        raise TypeError(f"Expected list from /pet/findByStatus, got {type(data).__name__}: {data}")

    context.seed_response = data
    context.seed_request = {'status': status}
    context.seed_count = len(data)


@when('a follow-up input is created by adding a new pet with that same status value and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR29.')
def step_mr_MR29_followup_input(context):
    status = context.seed_request.get('status') if isinstance(getattr(context, 'seed_request', None), dict) else 'available'

    new_pet: Dict[str, Any] = {
        "name": "New Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": status,
    }

    add_url = f"{BASE_URL}/pet"
    add_response = requests.post(add_url, json=new_pet, timeout=10)
    add_response.raise_for_status()

    list_url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": status}

    followup_response = requests.get(list_url, params=params, timeout=10)
    followup_response.raise_for_status()

    data = _safe_get_json(followup_response)
    if not isinstance(data, list):
        raise TypeError(f"Expected list from /pet/findByStatus, got {type(data).__name__}: {data}")

    context.followup_response = data
    context.followup_count = len(data)


@then('the follow-up output should have a count of pets with that status that is one more than the count in the seed output for MR29, assuming no other changes to pets with that status occur between the two retrievals.')
def step_mr_MR29_followup_output(context):
    seed_count = getattr(context, 'seed_count', None)
    followup_count = getattr(context, 'followup_count', None)

    if not isinstance(seed_count, int):
        raise TypeError(f"seed_count is not an int: {seed_count!r}")
    if not isinstance(followup_count, int):
        raise TypeError(f"followup_count is not an int: {followup_count!r}")

    assert followup_count == seed_count + 1, (
        f"Expected follow-up count to be {seed_count + 1}, but got {followup_count}."
    )
