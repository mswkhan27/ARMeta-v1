Feature: Iteration 2 MRs

  Scenario: MR10 Deleting an order should make the order inaccessible
    Given a seed input that successfully retrieves an order by its ID, producing a seed output with the order's details for MR10.
    When a follow-up input is created by deleting the order with the same ID and then attempting to retrieve the order again by the same ID, yielding a follow-up output for MR10.
    Then the follow-up output should indicate that the order is not found, differing from the seed output which contains the order's details for MR10.

  Scenario: MR11 Uploading an image should not affect pet details
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's details for MR11.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR11.
    Then the follow-up output should have identical pet details to the seed output for MR11, as uploading an image should not alter the pet's details.

  Scenario: MR12 Creating users with a list should result in all users being accessible
    Given a seed input that creates a list of users in a single request, producing a seed output confirming successful creation for MR12.
    When a follow-up input is created by retrieving each user by their username from the initially provided list, yielding a follow-up output for MR12.
    Then the follow-up output should include details for each user corresponding to the usernames in the seed input for MR12, confirming that all users were successfully created and are accessible.
