from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that successfully retrieves an order by its ID, producing a seed output with the order's details for MR10.")
def _mr_MR10_seed_input(context):
    # Create an order to ensure it exists
    order_data = {
        "petId": 198772,
        "quantity": 7,
        "status": "placed",
        "complete": True
    }

    response = requests.post(f"{BASE_URL}/store/order", json=order_data, timeout=10)
    context.seed_request = response

    try:
        context.seed_response = response.json() if response.content else {}
    except ValueError:
        context.seed_response = {}

    assert response.status_code == 200, f"Failed to create order: {context.seed_response}"

    order_id = context.seed_response.get("id")
    assert order_id is not None, f"No 'id' in created order response: {context.seed_response}"

    # Retrieve the order by ID to align with MR wording
    get_response = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    try:
        context.seed_get_response = get_response.json() if get_response.content else {}
    except ValueError:
        context.seed_get_response = {}

    assert get_response.status_code == 200, f"Failed to retrieve order by ID: {context.seed_get_response}"


@when("a follow-up input is created by deleting the order with the same ID and then attempting to retrieve the order again by the same ID, yielding a follow-up output for MR10.")
def _mr_MR10_followup_input(context):
    seed_body = getattr(context, "seed_response", {}) or {}
    order_id = seed_body.get("id")
    assert order_id is not None, f"Seed order id is missing or invalid: {seed_body}"

    # Delete the order
    delete_response = requests.delete(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    context.delete_response = delete_response

    # Do not blindly call .json(); delete 200 may have empty body
    if delete_response.content:
        try:
            context.delete_response_body = delete_response.json()
        except ValueError:
            context.delete_response_body = delete_response.text
    else:
        context.delete_response_body = None

    assert delete_response.status_code == 200, (
        f"Failed to delete order: {context.delete_response_body}"
    )

    # Attempt to retrieve the deleted order
    followup_request = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    context.followup_request = followup_request
    try:
        context.followup_response = followup_request.json() if followup_request.content else {}
    except ValueError:
        context.followup_response = {}


@then("the follow-up output should indicate that the order is not found, differing from the seed output which contains the order's details for MR10.")
def _mr_MR10_followup_output(context):
    seed_body = getattr(context, "seed_get_response", {}) or {}
    followup_body = getattr(context, "followup_response", {}) or {}

    assert context.followup_request.status_code == 404, (
        f"Expected 404, got {context.followup_request.status_code}: {followup_body}"
    )
    assert seed_body != followup_body, "Follow-up output should differ from seed output."

# ----




@given("a seed input that retrieves a pet by its ID, producing a seed output with the pet's details for MR11.")
def _mr_MR11_seed_input(context):
    pet_id = 1  # Using pet ID 1 for the test
    url = f"{BASE_URL}/pet/{pet_id}"
    try:
        response = requests.get(url, timeout=10)
    except requests.RequestException as e:
        assert False, f"HTTP error when retrieving pet in Given step for MR11: {e}"

    context.seed_request = response

    # Safely parse JSON
    try:
        context.seed_response = response.json()
    except ValueError:
        assert False, f"Non-JSON response when retrieving pet in Given step for MR11: status={response.status_code}, text={response.text!r}"

    assert response.status_code == 200, (
        f"Failed to retrieve pet in Given step for MR11: "
        f"status={response.status_code}, body={json.dumps(context.seed_response, ensure_ascii=False)}"
    )

    # Ensure response contains minimal required fields to avoid KeyError/TypeError later
    for key in ["id", "name", "photoUrls", "status"]:
        assert key in context.seed_response, f"Missing key '{key}' in seed_response: {context.seed_response}"


@when("a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR11.")
def _mr_MR11_followup_input(context):
    pet_id = context.seed_response.get("id") or 1
    upload_url = f"{BASE_URL}/pet/{pet_id}/uploadImage"
    get_url = f"{BASE_URL}/pet/{pet_id}"

    # Use a small in-memory dummy binary as "image" to avoid filesystem errors
    files = {"file": ("dummy.jpg", b"\x89PNG\r\n\x1a\n", "image/png")}

    try:
        upload_response = requests.post(upload_url, files=files, timeout=10)
    except requests.RequestException as e:
        assert False, f"HTTP error when uploading image in When step for MR11: {e}"

    # Try to parse upload response as JSON for debugging; tolerate non-JSON
    try:
        upload_body = upload_response.json()
    except ValueError:
        upload_body = upload_response.text

    assert upload_response.status_code == 200, (
        f"Failed to upload image in When step for MR11: "
        f"status={upload_response.status_code}, body={upload_body!r}"
    )

    try:
        followup_request = requests.get(get_url, timeout=10)
    except requests.RequestException as e:
        assert False, f"HTTP error when retrieving pet after upload in When step for MR11: {e}"

    context.followup_request = followup_request

    try:
        context.followup_response = followup_request.json()
    except ValueError:
        assert False, (
            f"Non-JSON response when retrieving pet after upload in When step for MR11: "
            f"status={followup_request.status_code}, text={followup_request.text!r}"
        )

    assert followup_request.status_code == 200, (
        f"Failed to retrieve pet after upload in When step for MR11: "
        f"status={followup_request.status_code}, body={json.dumps(context.followup_response, ensure_ascii=False)}"
    )

    # Ensure follow-up response has same minimal structure for safe comparison
    for key in ["id", "name", "photoUrls", "status"]:
        assert key in context.followup_response, f"Missing key '{key}' in followup_response: {context.followup_response}"


@then("the follow-up output should have identical pet details to the seed output for MR11, as uploading an image should not alter the pet's details.")
def _mr_MR11_followup_output(context):
    seed = context.seed_response or {}
    follow = context.followup_response or {}

    # Use dict.get with defaults to avoid KeyError/TypeError
    assert follow.get("id") == seed.get("id"), f"Pet ID does not match: seed={seed.get('id')}, follow={follow.get('id')}"
    assert follow.get("name") == seed.get("name"), f"Pet name does not match: seed={seed.get('name')}, follow={follow.get('name')}"
    assert follow.get("category") == seed.get("category"), f"Pet category does not match: seed={seed.get('category')}, follow={follow.get('category')}"
    assert follow.get("photoUrls") == seed.get("photoUrls"), f"Pet photoUrls do not match: seed={seed.get('photoUrls')}, follow={follow.get('photoUrls')}"
    assert follow.get("tags") == seed.get("tags"), f"Pet tags do not match: seed={seed.get('tags')}, follow={follow.get('tags')}"
    assert follow.get("status") == seed.get("status"), f"Pet status does not match: seed={seed.get('status')}, follow={follow.get('status')}"

# ----

from typing import Any, Dict, List



def _safe_get_json(response: requests.Response) -> Any:
    """
    Safely parse JSON response. If parsing fails, return None instead of raising an error.
    """
    try:
        if response.content is None or len(response.content) == 0:
            return None
        return response.json()
    except ValueError:
        return None


def _safe_get_str(mapping: Dict[str, Any], key: str, default: str = "") -> str:
    """
    Safely get a string value from a mapping, avoiding KeyError/TypeError.
    """
    value = mapping.get(key, default) if isinstance(mapping, dict) else default
    return value if isinstance(value, str) else default


def _safe_get_int(mapping: Dict[str, Any], key: str, default: int = 0) -> int:
    """
    Safely get an integer value from a mapping, avoiding KeyError/TypeError/ValueError.
    """
    if not isinstance(mapping, dict):
        return default
    value = mapping.get(key, default)
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


@given('a seed input that creates a list of users in a single request, producing a seed output confirming successful creation for MR12.')
def _mr_MR12_create_users(context):
    users: List[Dict[str, Any]] = [
        {
            "username": "user1",
            "firstName": "John",
            "lastName": "Doe",
            "email": "john.doe@example.com",
            "password": "password1",
            "phone": "1234567890",
            "userStatus": 1,
        },
        {
            "username": "user2",
            "firstName": "Jane",
            "lastName": "Doe",
            "email": "jane.doe@example.com",
            "password": "password2",
            "phone": "0987654321",
            "userStatus": 1,
        },
    ]

    context.seed_request = users

    try:
        response = requests.post(
            f"{BASE_URL}/user/createWithList",
            json=users,
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error during user list creation (MR12): {e}") from e

    # Expecting 200 as per OpenAPI spec for /user/createWithList
    if response.status_code != 200:
        raise AssertionError(
            f"Unexpected status code for user list creation (MR12): "
            f"{response.status_code}, body: {response.text}"
        )

    context.seed_response = _safe_get_json(response)


@when('a follow-up input is created by retrieving each user by their username from the initially provided list, yielding a follow-up output for MR12.')
def _mr_MR12_retrieve_users(context):
    seed_request = getattr(context, "seed_request", None)
    if not isinstance(seed_request, list):
        raise AssertionError("seed_request is not available or not a list in MR12 When step.")

    followup_responses: List[Dict[str, Any]] = []
    for user in seed_request:
        if not isinstance(user, dict):
            raise AssertionError(f"Invalid user entry in seed_request (MR12): {user!r}")

        username = _safe_get_str(user, "username")
        if not username:
            raise AssertionError(f"User in seed_request is missing a valid 'username' (MR12): {user!r}")

        try:
            response = requests.get(
                f"{BASE_URL}/user/{username}",
                timeout=10,
            )
        except requests.RequestException as e:
            raise AssertionError(f"HTTP error during user retrieval for username '{username}' (MR12): {e}") from e

        if response.status_code != 200:
            raise AssertionError(
                f"Unexpected status code when retrieving user '{username}' (MR12): "
                f"{response.status_code}, body: {response.text}"
            )

        json_body = _safe_get_json(response)
        if not isinstance(json_body, dict):
            raise AssertionError(
                f"Response body for user '{username}' is not a JSON object (MR12): {json_body!r}"
            )

        followup_responses.append(json_body)

    context.followup_response = followup_responses


@then('the follow-up output should include details for each user corresponding to the usernames in the seed input for MR12, confirming that all users were successfully created and are accessible.')
def _mr_MR12_verify_users(context):
    seed_request = getattr(context, "seed_request", None)
    followup_response = getattr(context, "followup_response", None)

    if not isinstance(seed_request, list):
        raise AssertionError("seed_request is not available or not a list in MR12 Then step.")
    if not isinstance(followup_response, list):
        raise AssertionError("followup_response is not available or not a list in MR12 Then step.")

    if len(followup_response) != len(seed_request):
        raise AssertionError(
            f"Mismatch in number of users retrieved (MR12): "
            f"expected {len(seed_request)}, got {len(followup_response)}"
        )

    for original_user, retrieved_user in zip(seed_request, followup_response):
        if not isinstance(original_user, dict):
            raise AssertionError(f"Invalid original user in seed_request (MR12): {original_user!r}")
        if not isinstance(retrieved_user, dict):
            raise AssertionError(f"Invalid retrieved user in followup_response (MR12): {retrieved_user!r}")

        orig_username = _safe_get_str(original_user, "username")
        recv_username = _safe_get_str(retrieved_user, "username")

        if orig_username != recv_username:
            raise AssertionError(
                f"Username mismatch (MR12): expected '{orig_username}', got '{recv_username}'"
            )

        orig_first = _safe_get_str(original_user, "firstName")
        recv_first = _safe_get_str(retrieved_user, "firstName")
        if orig_first != recv_first:
            raise AssertionError(
                f"First name mismatch for user '{orig_username}' (MR12): "
                f"expected '{orig_first}', got '{recv_first}'"
            )

        orig_last = _safe_get_str(original_user, "lastName")
        recv_last = _safe_get_str(retrieved_user, "lastName")
        if orig_last != recv_last:
            raise AssertionError(
                f"Last name mismatch for user '{orig_username}' (MR12): "
                f"expected '{orig_last}', got '{recv_last}'"
            )

        orig_email = _safe_get_str(original_user, "email")
        recv_email = _safe_get_str(retrieved_user, "email")
        if orig_email != recv_email:
            raise AssertionError(
                f"Email mismatch for user '{orig_username}' (MR12): "
                f"expected '{orig_email}', got '{recv_email}'"
            )

        orig_phone = _safe_get_str(original_user, "phone")
        recv_phone = _safe_get_str(retrieved_user, "phone")
        if orig_phone != recv_phone:
            raise AssertionError(
                f"Phone mismatch for user '{orig_username}' (MR12): "
                f"expected '{orig_phone}', got '{recv_phone}'"
            )

        orig_status = _safe_get_int(original_user, "userStatus", default=None)
        recv_status = _safe_get_int(retrieved_user, "userStatus", default=None)
        if orig_status != recv_status:
            raise AssertionError(
                f"User status mismatch for user '{orig_username}' (MR12): "
                f"expected '{orig_status}', got '{recv_status}'"
            )
