Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet should increase the count of pets with a given status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR1.
    When a follow-up input is created by adding a new pet with status 'available' and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR1.
    Then the follow-up output should have a count of pets with status 'available' that is one more than the seed output for MR1, assuming no other changes occur between the two retrievals.

  Scenario: MR2 Updating a pet's status should reflect in that pet's details
    Given a seed input that retrieves a pet by its identifier, producing a seed output with that pet's current status for MR2.
    When a follow-up input is created by updating the same pet's status to 'sold' and then retrieving that pet again by the same identifier, yielding a follow-up output for MR2.
    Then the follow-up output should reflect the updated status 'sold' for that pet while all other pet details remain identical to the corresponding fields in the seed output for MR2.

  Scenario: MR3 Deleting a pet should reduce the count of pets with the same status
    Given a seed input that retrieves the list of pets filtered by a specific status value (for example, 'available'), producing a seed output with a count of pets for that status for MR3.
    When a follow-up input is created by deleting one pet (identified in the seed output) that currently has that same status, and then retrieving again the list of pets filtered by that status, yielding a follow-up output for MR3.
    Then the follow-up output should have a count of pets with that status that is one less than the seed output for MR3, assuming no other changes occur between the two retrievals.

  Scenario: MR4 Finding pets by multiple tags should be consistent with results from individual tags
    Given a seed input that retrieves pets by a single tag 'tag1', producing a seed output with a list of pets for MR4.
    When a follow-up input is created by retrieving pets by multiple tags 'tag1, tag2', yielding a follow-up output for MR4.
    Then the follow-up output should include all pets from the seed output, and every pet in the follow-up output should have at least one of the tags used in the request ('tag1' or 'tag2') for MR4.
