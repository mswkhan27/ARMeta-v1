from behave import given, when, then
import os
import json
import requests
import time

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR1.")
def _mr_MR1_seed_input(context):
    # Retrieve the list of pets with status 'available'
    url = f"{BASE_URL}/pet/findByStatus"
    try:
        response = requests.get(url, params={"status": "available"}, timeout=10)
        response.raise_for_status()
        data = response.json()

        if not isinstance(data, list):
            raise ValueError(f"Expected list response for {url}, got {type(data).__name__}")

        context.seed_response = data
        context.seed_request = response.request
        context.seed_count = len(data)
    except (requests.RequestException, ValueError, TypeError) as e:
        # Make sure any error is visible and fail the step cleanly
        raise AssertionError(f"Error in Given step for MR1 while calling {url}: {e}") from e


@when("a follow-up input is created by adding a new pet with status 'available' and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR1.")
def _mr_MR1_followup_input(context):
    # Create a new pet with status 'available' and then retrieve list again
    create_url = f"{BASE_URL}/pet"
    list_url = f"{BASE_URL}/pet/findByStatus"

    new_pet = {
        "name": "New Available Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    try:
        add_response = requests.post(create_url, json=new_pet, timeout=10)
        add_response.raise_for_status()

        # Retrieve the list of pets with status 'available' again
        followup_response = requests.get(list_url, params={"status": "available"}, timeout=10)
        followup_response.raise_for_status()
        followup_data = followup_response.json()

        if not isinstance(followup_data, list):
            raise ValueError(f"Expected list response for {list_url}, got {type(followup_data).__name__}")

        context.followup_response = followup_data
        context.followup_request = followup_response.request
        context.followup_count = len(followup_data)
    except (requests.RequestException, ValueError, TypeError) as e:
        raise AssertionError(f"Error in When step for MR1 while calling {create_url} or {list_url}: {e}") from e


@then("the follow-up output should have a count of pets with status 'available' that is one more than the seed output for MR1, assuming no other changes occur between the two retrievals.")
def _mr_MR1_assert_followup_output(context):
    if not hasattr(context, "seed_count") or not hasattr(context, "followup_count"):
        raise AssertionError("Seed or follow-up counts are not available in context for MR1 assertion.")

    try:
        expected = context.seed_count + 1
        actual = context.followup_count
        assert actual == expected, (
            f"Expected follow-up count to be {expected}, but got {actual}."
        )
    except TypeError as e:
        raise AssertionError(f"Type error while comparing counts in Then step for MR1: {e}") from e

# ----




@given("a seed input that retrieves a pet by its identifier, producing a seed output with that pet's current status for MR2.")
def step_mr_MR2_seed_input(context):
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1"],
        "status": "available"
    }

    # Create or update the pet so it exists with known data
    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    try:
        response_json = response.json()
    except ValueError:
        response_json = None

    if response.status_code != 200:
        raise AssertionError(f"Failed to create pet. Status: {response.status_code}, Body: {response_json}")

    # Retrieve the pet by ID as per MR description
    get_response = requests.get(f"{BASE_URL}/pet/1", timeout=10)
    try:
        seed_response_json = get_response.json()
    except ValueError as e:
        raise AssertionError(f"Failed to parse JSON when retrieving pet: {e}, Status: {get_response.status_code}, Body: {get_response.text}")

    if get_response.status_code != 200:
        raise AssertionError(f"Failed to retrieve pet. Status: {get_response.status_code}, Body: {seed_response_json}")

    context.seed_request = get_response
    context.seed_response = seed_response_json


@when("a follow-up input is created by updating the same pet's status to 'sold' and then retrieving that pet again by the same identifier, yielding a follow-up output for MR2.")
def step_mr_MR2_followup_input(context):
    # Ensure seed_response exists to avoid AttributeError/KeyError later
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is missing in context. Ensure the Given step ran successfully.")

    # Build update payload based on existing seed response to keep other fields identical
    seed = context.seed_response
    update_data = {
        "id": seed.get("id", 1),
        "name": seed.get("name", "doggie"),
        "photoUrls": seed.get("photoUrls", ["url1"]),
        "status": "sold",
    }

    # Preserve optional fields if present
    if "category" in seed:
        update_data["category"] = seed["category"]
    if "tags" in seed:
        update_data["tags"] = seed["tags"]

    put_response = requests.put(f"{BASE_URL}/pet", json=update_data, timeout=10)
    try:
        put_response_json = put_response.json()
    except ValueError:
        put_response_json = None

    if put_response.status_code != 200:
        raise AssertionError(f"Failed to update pet. Status: {put_response.status_code}, Body: {put_response_json}")

    # Retrieve the pet again by the same identifier
    pet_id = update_data["id"]
    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    try:
        followup_response_json = get_response.json()
    except ValueError as e:
        raise AssertionError(f"Failed to parse JSON when retrieving updated pet: {e}, Status: {get_response.status_code}, Body: {get_response.text}")

    if get_response.status_code != 200:
        raise AssertionError(f"Failed to retrieve updated pet. Status: {get_response.status_code}, Body: {followup_response_json}")

    context.followup_request = get_response
    context.followup_response = followup_response_json


@then("the follow-up output should reflect the updated status 'sold' for that pet while all other pet details remain identical to the corresponding fields in the seed output for MR2.")
def step_mr_MR2_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is missing in context. Ensure the Given step ran successfully.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response is missing in context. Ensure the When step ran successfully.")

    seed = context.seed_response
    followup = context.followup_response

    # Verify updated status
    followup_status = followup.get("status")
    if followup_status != "sold":
        raise AssertionError(f"Expected status 'sold', got {followup_status!r}")

    # Compare other fields for equality while ignoring status
    # Only compare keys that appear in the seed output, except 'status'
    for key, seed_value in seed.items():
        if key == "status":
            continue
        followup_value = followup.get(key, None)
        if followup_value != seed_value:
            raise AssertionError(
                f"Field '{key}' changed between seed and follow-up.\n"
                f"Seed: {json.dumps(seed_value, sort_keys=True)}\n"
                f"Follow-up: {json.dumps(followup_value, sort_keys=True)}"
            )

# ----

from typing import Any, Dict, List



def _safe_get_json(response: requests.Response) -> Any:
    """
    Safely parse JSON from a response, returning an empty list or dict on failure
    instead of raising a ValueError.
    """
    try:
        return response.json()
    except ValueError:
        # Fallbacks based on expected content type in this MR
        content_type = response.headers.get('Content-Type', '')
        if 'application/json' in content_type:
            # If declared JSON but parsing failed, re-raise
            raise
        # If not JSON, return an empty list as this MR expects a list of pets
        return []


def _safe_len(obj: Any) -> int:
    """
    Safely compute length; returns 0 if obj is not sized.
    Prevents TypeError from len() on non-sized objects.
    """
    try:
        return len(obj)  # type: ignore[arg-type]
    except TypeError:
        return 0


def _extract_pets_list(data: Any) -> List[Dict[str, Any]]:
    """
    Ensure we always work with a list of pet dicts.
    The /pet/findByStatus endpoint returns an array of Pet objects.
    """
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    if isinstance(data, dict):
        # Unexpected but handle gracefully: single pet as dict
        return [data]
    # Any other type: treat as empty
    return []


@given(
    "a seed input that retrieves the list of pets filtered by a specific status value (for example, 'available'), "
    "producing a seed output with a count of pets for that status for MR3."
)
def _mr_MR3_seed_input(context):
    # According to OpenAPI: GET /pet/findByStatus (summary: Finds Pets by status.)
    # Required query parameter: status (enum: available, pending, sold)
    status_value = "available"

    response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params={"status": status_value},
        timeout=10,
    )
    response.raise_for_status()

    raw_data = _safe_get_json(response)
    pets_list = _extract_pets_list(raw_data)

    context.seed_status = status_value
    context.seed_response = pets_list
    context.seed_request = {"status": status_value}
    context.seed_count = _safe_len(pets_list)


@when(
    "a follow-up input is created by deleting one pet (identified in the seed output) that currently has that same "
    "status, and then retrieving again the list of pets filtered by that status, yielding a follow-up output for MR3."
)
def _mr_MR3_followup_input(context):
    # According to OpenAPI: DELETE /pet/\{petId\} (summary: Deletes a pet.)
    # Path parameter petId: integer (int64)
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, list):
        raise AssertionError("Seed response is missing or invalid; GIVEN step may have failed.")

    pets_list: List[Dict[str, Any]] = context.seed_response
    seed_count = _safe_len(pets_list)

    if seed_count <= 0:
        raise AssertionError("No pets available to delete for the specified status.")

    # Choose the first pet that has an 'id' suitable for the DELETE /pet/\{petId\} endpoint
    pet_to_delete_id = None
    for pet in pets_list:
        if not isinstance(pet, dict):
            continue
        pet_id = pet.get("id")
        # Ensure pet_id is an integer-like value to avoid TypeError/ValueError in path formatting
        if isinstance(pet_id, int):
            pet_to_delete_id = pet_id
            break
        # Try to coerce string digits to int safely
        if isinstance(pet_id, str) and pet_id.isdigit():
            pet_to_delete_id = int(pet_id)
            break

    if pet_to_delete_id is None:
        raise AssertionError("No valid pet id found in seed response to delete.")

    context.deleted_pet_id = pet_to_delete_id

    delete_response = requests.delete(
        f"{BASE_URL}/pet/{pet_to_delete_id}",
        timeout=10,
    )
    delete_response.raise_for_status()

    # Retrieve the list of pets again with the same status using GET /pet/findByStatus
    status_value = getattr(context, "seed_status", "available")
    followup_response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params={"status": status_value},
        timeout=10,
    )
    followup_response.raise_for_status()

    followup_raw = _safe_get_json(followup_response)
    followup_pets_list = _extract_pets_list(followup_raw)

    context.followup_response = followup_pets_list
    context.followup_count = _safe_len(followup_pets_list)


@then(
    "the follow-up output should have a count of pets with that status that is one less than the seed output for MR3, "
    "assuming no other changes occur between the two retrievals."
)
def _mr_MR3_followup_output(context):
    if not hasattr(context, "seed_count"):
        raise AssertionError("seed_count is missing on context.")
    if not hasattr(context, "followup_count"):
        raise AssertionError("followup_count is missing on context.")

    seed_count = int(context.seed_count)
    followup_count = int(context.followup_count)

    expected = seed_count - 1
    assert followup_count == expected, (
        f"Expected follow-up count to be {expected}, but got {followup_count}."
    )

# ----

from typing import Any, Dict, List





@given("a seed input that retrieves pets by a single tag 'tag1', producing a seed output with a list of pets for MR4.")
def _mr_MR4_seed_input(context):
    try:
        pet_data: Dict[str, Any] = {
            "name": "Pet1",
            "photoUrls": ["http://example.com/photo1.jpg"],
            "tags": [{"id": 1, "name": "tag1"}],
            "status": "available",
        }
        response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        response_json = _safe_get_json(response)

        assert response.status_code == 200, f"Failed to create pet: {response.status_code} {response_json}"

        # Ensure the created pet has an 'id'
        if not isinstance(response_json, dict) or "id" not in response_json:
            assert False, f"Response JSON does not contain 'id': {response_json}"

        # Seed output should be a list of pets; normalize to a list
        context.seed_pets: List[Dict[str, Any]] = [response_json]
    except Exception as e:
        print(f"Error in Given step: MR4 - {e}")
        assert False


@when("a follow-up input is created by retrieving pets by multiple tags 'tag1, tag2', yielding a follow-up output for MR4.")
def _mr_MR4_followup_input(context):
    try:
        # Create a pet with tag 'tag2'
        pet_data: Dict[str, Any] = {
            "name": "Pet2",
            "photoUrls": ["http://example.com/photo2.jpg"],
            "tags": [{"id": 2, "name": "tag2"}],
            "status": "available",
        }
        create_response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        create_json = _safe_get_json(create_response)
        assert create_response.status_code == 200, f"Failed to create pet2: {create_response.status_code} {create_json}"

        # Retrieve pets by multiple tags using /pet/findByTags (GET, query param 'tags')
        followup_response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params={"tags": ["tag1", "tag2"]},
            timeout=10,
        )
        followup_json = _safe_get_json(followup_response)

        assert followup_response.status_code == 200, f"Failed to retrieve pets: {followup_response.status_code} {followup_json}"
        assert isinstance(followup_json, list), f"Expected list of pets in follow-up response, got: {type(followup_json).__name__}"

        context.followup_pets: List[Dict[str, Any]] = followup_json
    except Exception as e:
        print(f"Error in When step: MR4 - {e}")
        assert False


@then("the follow-up output should include all pets from the seed output, and every pet in the follow-up output should have at least one of the tags used in the request ('tag1' or 'tag2') for MR4.")
def _mr_MR4_followup_output(context):
    try:
        seed_pets = getattr(context, "seed_pets", None)
        followup_pets = getattr(context, "followup_pets", None)

        assert isinstance(seed_pets, list), f"seed_pets is not a list: {type(seed_pets).__name__}"
        assert isinstance(followup_pets, list), f"followup_pets is not a list: {type(followup_pets).__name__}"

        seed_pet_ids = {
            pet.get("id")
            for pet in seed_pets
            if isinstance(pet, dict) and "id" in pet
        }
        followup_pet_ids = {
            pet.get("id")
            for pet in followup_pets
            if isinstance(pet, dict) and "id" in pet
        }

        assert seed_pet_ids, "No valid pet IDs found in seed_pets."
        assert followup_pet_ids, "No valid pet IDs found in followup_pets."

        # All seed pets must be included in follow-up output
        assert seed_pet_ids.issubset(followup_pet_ids), (
            f"Not all seed pets are included in the follow-up output. "
            f"Missing: {seed_pet_ids - followup_pet_ids}"
        )

        # Every pet in follow-up must have at least one of the tags 'tag1' or 'tag2'
        required_tags = {"tag1", "tag2"}
        for pet in followup_pets:
            if not isinstance(pet, dict):
                continue
            tags_field = pet.get("tags") or []
            if not isinstance(tags_field, list):
                tags_field = []

            tag_names = {
                tag.get("name")
                for tag in tags_field
                if isinstance(tag, dict) and "name" in tag
            }

            assert tag_names & required_tags, (
                f"Pet {pet.get('id')} does not have required tags 'tag1' or 'tag2'. "
                f"Tags found: {sorted(t for t in tag_names if t is not None)}"
            )
    except Exception as e:
        print(f"Error in Then step: MR4 - {e}")
        assert False
