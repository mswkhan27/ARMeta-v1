
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet should increase the count of pets with a given status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR1.
    When a follow-up input is created by adding a new pet with status 'available' and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR1.
    Then the follow-up output should have a count of pets with status 'available' that is one more than the seed output for MR1, assuming no other changes occur between the two retrievals.

  Scenario: MR2 Updating a pet's status should reflect in that pet's details
    Given a seed input that retrieves a pet by its identifier, producing a seed output with that pet's current status for MR2.
    When a follow-up input is created by updating the same pet's status to 'sold' and then retrieving that pet again by the same identifier, yielding a follow-up output for MR2.
    Then the follow-up output should reflect the updated status 'sold' for that pet while all other pet details remain identical to the corresponding fields in the seed output for MR2.

  Scenario: MR3 Deleting a pet should reduce the count of pets with the same status
    Given a seed input that retrieves the list of pets filtered by a specific status value (for example, 'available'), producing a seed output with a count of pets for that status for MR3.
    When a follow-up input is created by deleting one pet (identified in the seed output) that currently has that same status, and then retrieving again the list of pets filtered by that status, yielding a follow-up output for MR3.
    Then the follow-up output should have a count of pets with that status that is one less than the seed output for MR3, assuming no other changes occur between the two retrievals.

  Scenario: MR4 Finding pets by multiple tags should be consistent with results from individual tags
    Given a seed input that retrieves pets by a single tag 'tag1', producing a seed output with a list of pets for MR4.
    When a follow-up input is created by retrieving pets by multiple tags 'tag1, tag2', yielding a follow-up output for MR4.
    Then the follow-up output should include all pets from the seed output, and every pet in the follow-up output should have at least one of the tags used in the request ('tag1' or 'tag2') for MR4.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR5 Deleting a user should make the user inaccessible
    Given a seed input that retrieves a user by username, producing a seed output with the user's details for MR5.
    When a follow-up input is created by deleting the user with the same username and then attempting to retrieve the user again by the same username, yielding a follow-up output for MR5.
    Then the follow-up output should indicate that the user is not found (for example, by returning a corresponding error status), differing from the seed output which contains the user's details for MR5.

  Scenario: MR7 Logging in should return a consistent login response structure
    Given a seed input that attempts to log in with valid credentials, producing a seed output that includes a success status, a response body string, and any login-related headers (such as rate limit and expiry information) for MR7.
    When a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR7.
    Then the follow-up output should also indicate a successful login and provide a response body of the same type along with the same set of login-related headers as in the seed output for MR7.

  Scenario: MR8 Updating a user's details should reflect in the user's profile
    Given a seed input that retrieves a user's profile by username, producing a seed output with the user's current details for MR8.
    When a follow-up input is created by updating the user's details and then retrieving the user's profile again by the same username, yielding a follow-up output for MR8.
    Then the follow-up output should reflect the updated details for the fields that were modified, while fields that were not part of the update request should remain identical to the corresponding fields in the seed output for MR8.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR10 Deleting an order should make the order inaccessible
    Given a seed input that successfully retrieves an order by its ID, producing a seed output with the order's details for MR10.
    When a follow-up input is created by deleting the order with the same ID and then attempting to retrieve the order again by the same ID, yielding a follow-up output for MR10.
    Then the follow-up output should indicate that the order is not found, differing from the seed output which contains the order's details for MR10.

  Scenario: MR11 Uploading an image should not affect pet details
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's details for MR11.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR11.
    Then the follow-up output should have identical pet details to the seed output for MR11, as uploading an image should not alter the pet's details.

  Scenario: MR12 Creating users with a list should result in all users being accessible
    Given a seed input that creates a list of users in a single request, producing a seed output confirming successful creation for MR12.
    When a follow-up input is created by retrieving each user by their username from the initially provided list, yielding a follow-up output for MR12.
    Then the follow-up output should include details for each user corresponding to the usernames in the seed input for MR12, confirming that all users were successfully created and are accessible.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR13 Retrieving inventory should be stable without intervening changes
    Given a seed input that retrieves the inventory of pets by status, producing a seed output with a map of status codes to quantities for MR13.
    When a follow-up input is created by retrieving the inventory again under the same conditions, with no changes made to pets or orders between the two retrievals, yielding a follow-up output for MR13.
    Then the follow-up output should contain the same set of status codes with the same corresponding quantities as the seed output for MR13.

  Scenario: MR14 Logging in multiple times with the same credentials should behave consistently
    Given a seed input that logs a user into the system with valid credentials, producing a seed output that indicates a successful operation and includes response headers for MR14.
    When a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR14.
    Then the follow-up output should also indicate a successful operation and include the same header fields (such as rate limit and expiry information) as the seed output for MR14, though the specific header values and body content may differ.

  Scenario: MR16 Uploading an image should not affect pet's status
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's status for MR16.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR16.
    Then the follow-up output should have the same pet status as the seed output for MR16, as uploading an image is defined to upload additional data but does not modify the pet's stored attributes.

  Scenario: MR17 Updating a pet's details should reflect only the updated fields
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's details for MR17.
    When a follow-up input is created by updating the pet's name while leaving other updatable fields unchanged, and then retrieving the pet again by the same ID, yielding a follow-up output for MR17.
    Then the follow-up output should reflect the updated name while all other pet details remain identical to the corresponding fields in the seed output for MR17.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR18 Logging out should report a successful termination of the current session
    Given a seed input that logs a user into the system, producing a seed output indicating a successful login with any returned login details for MR18.
    When a follow-up input is created by logging out the user, yielding a follow-up output for MR18.
    Then the follow-up output should indicate a successful logout operation, regardless of the specific login details present in the seed output for MR18.

  Scenario: MR19 Updating a pet's name should reflect only the updated name
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current details including its name for MR19.
    When a follow-up input is created by updating the pet's name and then retrieving the pet again by the same ID, yielding a follow-up output for MR19.
    Then the follow-up output should reflect the updated name while all other pet details remain unchanged compared to the corresponding fields in the seed output for MR19.


# --- From iteration_5\features\mrs_iteration_5.feature ---

Feature: Iteration 5 MRs

  Scenario: MR20 Adding a new pet and using its returned ID should make it retrievable by that ID
    Given a seed input that adds a new pet to the store, producing a seed output that includes the created pet with its identifier for MR20.
    When a follow-up input is created by retrieving the pet using the identifier returned in the seed output, yielding a follow-up output for MR20.
    Then the follow-up output should contain the pet details matching the seed output, confirming that the pet is retrievable by its identifier for MR20.

  Scenario: MR21 Updating a pet's status should reflect in the pet's retrievable details
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current status and other details for MR21.
    When a follow-up input is created by updating only the pet's status to a new valid value and then retrieving the pet again by the same ID, yielding a follow-up output for MR21.
    Then the follow-up output should reflect the updated status, and no other pet details should change except for fields explicitly modified by the update in MR21.

  Scenario: MR22 Deleting a pet should make it inaccessible by its ID
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's details for MR22.
    When a follow-up input is created by deleting the pet with the same ID and then attempting to retrieve the pet again by the same ID, yielding a follow-up output for MR22.
    Then the follow-up output should indicate that the pet is not found, differing from the seed output which contains the pet's details for MR22.

  Scenario: MR23 Uploading an image should not affect the pet's retrievable status
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current status for MR23.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR23.
    Then the follow-up output should have the same pet status as the seed output for MR23, since uploading an image does not modify the pet's status in the store.

  Scenario: MR24 Creating a pet with a specific status should increase the count of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a specific status, producing a seed output with the list and its count for that status for MR24.
    When a follow-up input is created by adding a new pet with the same status and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR24.
    Then the follow-up output should have a count of pets with that status that is one more than the count in the seed output for MR24, assuming no other changes to pets with that status occur between the two retrievals.


# --- From iteration_6\features\mrs_iteration_6.feature ---

Feature: Iteration 6 MRs

  Scenario: MR25 Adding a new pet with a specific ID should make it retrievable by that ID
    Given a seed input that adds a new pet to the store with a specific ID, producing a seed output that includes the created pet with its identifier for MR25.
    When a follow-up input is created by retrieving the pet using the identifier returned in the seed output, yielding a follow-up output for MR25.
    Then the follow-up output should contain the pet details matching the seed output, confirming that the pet is retrievable by its identifier for MR25.

  Scenario: MR26 Updating a pet's name while keeping other details the same should only change the name
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current details including its name for MR26.
    When a follow-up input is created by updating the pet using the same identifier and sending the same values for all fields except a changed name, and then retrieving the pet again by the same ID, yielding a follow-up output for MR26.
    Then the follow-up output should reflect the updated name while all other pet details remain unchanged compared to the corresponding fields in the seed output, given that the update request preserved those other field values for MR26.

  Scenario: MR27 Deleting a pet should make it inaccessible by its ID
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's details for MR27.
    When a follow-up input is created by deleting the pet with the same ID and then attempting to retrieve the pet again by the same ID, yielding a follow-up output for MR27.
    Then the follow-up output should indicate that the pet is not found, differing from the seed output which contains the pet's details for MR27.

  Scenario: MR28 Uploading an image should not affect the pet's retrievable status
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current status for MR28.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR28.
    Then the follow-up output should have the same pet status as the seed output for MR28, since uploading an image does not modify the pet's status in the store.

  Scenario: MR29 Creating a pet with a specific status should increase the count of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a single allowed status value (available, pending, or sold), producing a seed output with the list and its count for that status for MR29.
    When a follow-up input is created by adding a new pet with that same status value and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR29.
    Then the follow-up output should have a count of pets with that status that is one more than the count in the seed output for MR29, assuming no other changes to pets with that status occur between the two retrievals.


# --- From iteration_7\features\mrs_iteration_7.feature ---

Feature: Iteration 7 MRs

  Scenario: MR30 Adding a new pet and using its returned identifier should make it retrievable by that identifier
    Given a seed input that adds a new pet to the store, producing a seed output that includes the created pet with its identifier assigned by the system for MR30.
    When a follow-up input is created by retrieving the pet using the identifier returned in the seed output, yielding a follow-up output for MR30.
    Then the follow-up output should contain the pet details matching the seed output, confirming that the pet is retrievable by its identifier for MR30.

  Scenario: MR31 Updating a pet's name while keeping other fields the same in the request should reflect only the updated name
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details including its name for MR31.
    When a follow-up input is created by updating the pet using a representation where only the name field is changed and all other fields are kept identical to the seed output, and then retrieving the pet again by the same identifier, yielding a follow-up output for MR31.
    Then the follow-up output should reflect the updated name while all other pet details remain unchanged compared to the corresponding fields in the seed output for MR31.

  Scenario: MR32 Deleting a pet should make it inaccessible by its identifier
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's details for MR32.
    When a follow-up input is created by deleting the pet with the same identifier and then attempting to retrieve the pet again by that identifier, yielding a follow-up output for MR32.
    Then the follow-up output should indicate that the pet is not found, differing from the seed output which contains the pet's details for MR32.

  Scenario: MR33 Uploading an image should not affect the pet's status when retrieved
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR33.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same identifier, yielding a follow-up output for MR33.
    Then the follow-up output should have the same pet status as the seed output for MR33, since uploading an image does not modify the pet's status in the store.

  Scenario: MR34 Creating a pet with a specific status should increase the count of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a single allowed status value (available, pending, or sold), producing a seed output with the list and its count for that status for MR34.
    When a follow-up input is created by adding a new pet whose status field is set to that same status value and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR34.
    Then the follow-up output should have a count of pets with that status that is one more than the count in the seed output for MR34, assuming no other changes to pets with that status occur between the two retrievals.


# --- From iteration_8\features\mrs_iteration_8.feature ---

Feature: Iteration 8 MRs

  Scenario: MR35 Adding a new pet and obtaining its identifier should make it retrievable by that identifier
    Given a seed input that adds a new pet to the store, optionally including an identifier, producing a seed output that includes the created pet with the identifier assigned by the system for MR35.
    When a follow-up input is created by retrieving the pet using the identifier returned in the seed output, yielding a follow-up output for MR35.
    Then the follow-up output should contain pet details that are consistent with the seed output (including the same identifier), confirming that the pet is retrievable by its identifier for MR35.

  Scenario: MR36 Updating a pet's name while keeping other details the same should only change the name in the stored representation
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current details including its name for MR36.
    When a follow-up input is created by updating the pet using the same identifier and sending the same values for all modifiable fields except a changed name, and then retrieving the pet again by the same ID, yielding a follow-up output for MR36.
    Then the follow-up output should reflect the updated name while all other explicitly preserved pet fields remain unchanged compared to the corresponding fields in the seed output, given that the update request provided the same values for those fields for MR36.

  Scenario: MR37 Deleting a pet should make it inaccessible by its ID
    Given a seed input that retrieves an existing pet by its ID, producing a seed output with the pet's details for MR37.
    When a follow-up input is created by deleting the pet with the same ID and then attempting to retrieve the pet again by the same ID, yielding a follow-up output for MR37.
    Then the follow-up output should indicate that the pet is not found according to the API's error semantics, differing from the seed output which contains the pet's details for MR37.

  Scenario: MR38 Uploading an image should not affect the pet's retrievable status field
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current status value for MR38.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR38.
    Then the follow-up output should have the same pet status value as the seed output for MR38, since uploading an image only sends binary content and additional metadata and does not modify the pet's status in the store.

  Scenario: MR39 Creating a pet with a specific status should increase the count of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a single allowed status value (available, pending, or sold), producing a seed output with the list and its count for that status for MR39.
    When a follow-up input is created by adding a new pet whose status field is set to that same allowed status value and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR39.
    Then the follow-up output should have a count of pets with that status that is at least one more than the count in the seed output for MR39, under the assumption that no other operations modify pets with that status between the two retrievals.

