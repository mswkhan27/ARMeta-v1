Feature: Iteration 3 MRs

  Scenario: MR13 Retrieving inventory should be stable without intervening changes
    Given a seed input that retrieves the inventory of pets by status, producing a seed output with a map of status codes to quantities for MR13.
    When a follow-up input is created by retrieving the inventory again under the same conditions, with no changes made to pets or orders between the two retrievals, yielding a follow-up output for MR13.
    Then the follow-up output should contain the same set of status codes with the same corresponding quantities as the seed output for MR13.

  Scenario: MR14 Logging in multiple times with the same credentials should behave consistently
    Given a seed input that logs a user into the system with valid credentials, producing a seed output that indicates a successful operation and includes response headers for MR14.
    When a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR14.
    Then the follow-up output should also indicate a successful operation and include the same header fields (such as rate limit and expiry information) as the seed output for MR14, though the specific header values and body content may differ.

  Scenario: MR16 Uploading an image should not affect pet's status
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's status for MR16.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR16.
    Then the follow-up output should have the same pet status as the seed output for MR16, as uploading an image is defined to upload additional data but does not modify the pet's stored attributes.

  Scenario: MR17 Updating a pet's details should reflect only the updated fields
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's details for MR17.
    When a follow-up input is created by updating the pet's name while leaving other updatable fields unchanged, and then retrieving the pet again by the same ID, yielding a follow-up output for MR17.
    Then the follow-up output should reflect the updated name while all other pet details remain identical to the corresponding fields in the seed output for MR17.
