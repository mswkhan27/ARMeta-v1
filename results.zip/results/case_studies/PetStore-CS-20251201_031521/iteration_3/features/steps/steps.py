from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that retrieves the inventory of pets by status, producing a seed output with a map of status codes to quantities for MR13.')
def _mr_MR13_seed_input(context):
    response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Response is not valid JSON for MR13 seed step: {e}")

    if not isinstance(data, dict):
        raise AssertionError(f"Expected inventory as JSON object (map), got {type(data).__name__}")

    # Ensure all values are integers as per OpenAPI (additionalProperties: integer)
    for k, v in data.items():
        if not isinstance(v, int):
            raise AssertionError(f"Inventory value for status '{k}' is not an integer: {v} (type={type(v).__name__})")

    context.seed_response = data
    context.seed_request = {"method": "GET", "url": f"{BASE_URL}/store/inventory"}


@when('a follow-up input is created by retrieving the inventory again under the same conditions, with no changes made to pets or orders between the two retrievals, yielding a follow-up output for MR13.')
def _mr_MR13_followup_input(context):
    response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Response is not valid JSON for MR13 follow-up step: {e}")

    if not isinstance(data, dict):
        raise AssertionError(f"Expected inventory as JSON object (map), got {type(data).__name__}")

    for k, v in data.items():
        if not isinstance(v, int):
            raise AssertionError(f"Inventory value for status '{k}' is not an integer: {v} (type={type(v).__name__})")

    context.followup_response = data
    context.followup_request = {"method": "GET", "url": f"{BASE_URL}/store/inventory"}


@then('the follow-up output should contain the same set of status codes with the same corresponding quantities as the seed output for MR13.')
def _mr_MR13_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is missing in context for MR13.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response is missing in context for MR13.")

    seed = context.seed_response
    follow = context.followup_response

    if not isinstance(seed, dict) or not isinstance(follow, dict):
        raise AssertionError(
            f"Both seed and follow-up responses must be dicts. "
            f"Got seed={type(seed).__name__}, followup={type(follow).__name__}"
        )

    # Compare keys and values explicitly to avoid surprises with ordering or types
    if seed.keys() != follow.keys():
        raise AssertionError(
            f"Status code sets differ between seed and follow-up.\n"
            f"Seed keys: {list(seed.keys())}\nFollow-up keys: {list(follow.keys())}"
        )

    for status, seed_qty in seed.items():
        follow_qty = follow.get(status)
        if seed_qty != follow_qty:
            raise AssertionError(
                f"Quantity mismatch for status '{status}': seed={seed_qty}, follow-up={follow_qty}"
            )

# ----




@given('a seed input that logs a user into the system with valid credentials, producing a seed output that indicates a successful operation and includes response headers for MR14.')
def step_mr_MR14_seed_input(context):
    username = "testuser"
    password = "testpassword"

    context.seed_request = {
        "username": username,
        "password": password,
    }

    response = requests.get(
        f"{BASE_URL}/user/login",
        params=context.seed_request,
        timeout=10,
    )
    response.raise_for_status()

    # Response body is defined as a string in the OpenAPI spec
    context.seed_response_body = response.text
    context.seed_status_code = response.status_code
    context.seed_headers = response.headers


@when('a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR14.')
def step_mr_MR14_followup_input(context):
    if not hasattr(context, "seed_request"):
        raise RuntimeError("Seed request data is missing in context.")

    response = requests.get(
        f"{BASE_URL}/user/login",
        params=context.seed_request,
        timeout=10,
    )
    response.raise_for_status()

    context.followup_response_body = response.text
    context.followup_status_code = response.status_code
    context.followup_headers = response.headers


@then('the follow-up output should also indicate a successful operation and include the same header fields (such as rate limit and expiry information) as the seed output for MR14, though the specific header values and body content may differ.')
def step_mr_MR14_followup_output(context):
    if not hasattr(context, "seed_status_code") or not hasattr(context, "followup_status_code"):
        raise RuntimeError("Status codes for seed or follow-up responses are missing in context.")
    if not hasattr(context, "seed_headers") or not hasattr(context, "followup_headers"):
        raise RuntimeError("Headers for seed or follow-up responses are missing in context.")

    # Both responses should indicate successful operation (HTTP 200)
    assert context.seed_status_code == 200, f"Expected seed status code 200, got {context.seed_status_code}"
    assert context.followup_status_code == 200, f"Expected follow-up status code 200, got {context.followup_status_code}"

    # Both responses should be non-empty bodies (string per OpenAPI)
    assert isinstance(context.seed_response_body, str), "Seed response body is not a string."
    assert isinstance(context.followup_response_body, str), "Follow-up response body is not a string."
    assert context.seed_response_body != "", "Seed response body is empty."
    assert context.followup_response_body != "", "Follow-up response body is empty."

    # MR requirement: same header FIELDS (presence), values may differ
    # OpenAPI defines these response headers for /user/login
    for header_name in ("X-Rate-Limit", "X-Expires-After"):
        assert header_name in context.seed_headers, f"{header_name} header is missing in seed response."
        assert header_name in context.followup_headers, f"{header_name} header is missing in follow-up response."

# ----




@given("a seed input that retrieves a pet by its ID, producing a seed output with the pet's status for MR16.")
def _mr_MR16_seed_input(context):
    # Create a pet to ensure it exists (POST /pet)
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    response.raise_for_status()

    # Ensure JSON body and required fields exist
    try:
        seed_json = response.json()
    except ValueError as exc:  # JSON decode error
        raise AssertionError(f"Seed response is not valid JSON: {exc}; body={response.text!r}")

    if not isinstance(seed_json, dict):
        raise AssertionError(f"Seed response JSON is not an object: {seed_json!r}")

    pet_id = seed_json.get("id")
    if not isinstance(pet_id, int):
        raise AssertionError(f"Seed response 'id' is missing or not an integer: {seed_json!r}")

    status = seed_json.get("status")
    if status is None:
        raise AssertionError(f"Seed response 'status' is missing: {seed_json!r}")

    context.seed_request = pet_data
    context.seed_response = seed_json
    context.pet_id = pet_id


@when("a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR16.")
def _mr_MR16_followup_input(context):
    # Use a small in-memory dummy "image" instead of relying on filesystem paths
    fake_image_content = b"\x89PNG\r\n\x1a\n"  # minimal PNG-like header bytes
    files = {
        "file": ("image.png", fake_image_content, "image/png")
    }

    # POST /pet/\{petId\}/uploadImage
    response_upload = requests.post(
        f"{BASE_URL}/pet/{context.pet_id}/uploadImage",
        files=files,
        timeout=10,
    )
    response_upload.raise_for_status()

    # GET /pet/\{petId\}
    response_get = requests.get(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
    response_get.raise_for_status()

    try:
        followup_json = response_get.json()
    except ValueError as exc:
        raise AssertionError(f"Follow-up response is not valid JSON: {exc}; body={response_get.text!r}")

    if not isinstance(followup_json, dict):
        raise AssertionError(f"Follow-up response JSON is not an object: {followup_json!r}")

    if "status" not in followup_json:
        raise AssertionError(f"Follow-up response 'status' is missing: {followup_json!r}")

    context.followup_response = followup_json


@then("the follow-up output should have the same pet status as the seed output for MR16, as uploading an image is defined to upload additional data but does not modify the pet's stored attributes.")
def _mr_MR16_followup_output(context):
    seed_status = context.seed_response.get("status")
    follow_status = context.followup_response.get("status")

    if seed_status is None:
        raise AssertionError(f"Seed status is missing in context.seed_response: {json.dumps(context.seed_response)}")

    if follow_status is None:
        raise AssertionError(f"Follow-up status is missing in context.followup_response: {json.dumps(context.followup_response)}")

    if seed_status != follow_status:
        raise AssertionError(
            f"Expected status '{seed_status}' to remain unchanged after image upload, "
            f"but got '{follow_status}'."
        )

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


@given("a seed input that retrieves a pet by its ID, producing a seed output with the pet's details for MR17.")
def _mr_MR17_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available",
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    try:
        response_json = response.json()
    except ValueError:
        response_json = None

    if response.status_code != 200:
        raise AssertionError(f"Failed to create pet: status={response.status_code}, body={response.text}")

    created_id = response_json.get("id") if isinstance(response_json, dict) else None
    if created_id is None:
        raise AssertionError(f"Create pet response missing 'id': {response.text}")

    get_response = requests.get(f"{BASE_URL}/pet/{created_id}", timeout=10)
    try:
        get_response_json = get_response.json()
    except ValueError:
        get_response_json = None

    if get_response.status_code != 200:
        raise AssertionError(f"Failed to retrieve pet: status={get_response.status_code}, body={get_response.text}")

    if not isinstance(get_response_json, dict):
        raise AssertionError(f"Retrieve pet response is not a JSON object: {get_response.text}")

    context.seed_response = get_response_json


@when(
    "a follow-up input is created by updating the pet's name while leaving other updatable fields unchanged, and then retrieving the pet again by the same ID, yielding a follow-up output for MR17."
)
def _mr_MR17_followup_input(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("Seed response is missing or invalid in context.")

    seed = context.seed_response
    seed_id = seed.get("id")
    if seed_id is None:
        raise AssertionError(f"Seed response missing 'id': {json.dumps(seed, ensure_ascii=False)}")

    updated_pet_data = {
        "id": seed_id,
        "name": "doggie_updated",
        "photoUrls": seed.get("photoUrls") or [],
        "status": seed.get("status"),
        "category": seed.get("category"),
        "tags": seed.get("tags"),
    }

    put_response = requests.put(f"{BASE_URL}/pet", json=updated_pet_data, timeout=10)
    try:
        put_response_json = put_response.json()
    except ValueError:
        put_response_json = None

    if put_response.status_code != 200:
        raise AssertionError(f"Failed to update pet: status={put_response.status_code}, body={put_response.text}")

    updated_id = None
    if isinstance(put_response_json, dict):
        updated_id = put_response_json.get("id", seed_id)
    if updated_id is None:
        raise AssertionError(f"Update pet response missing 'id': {put_response.text}")

    get_response = requests.get(f"{BASE_URL}/pet/{updated_id}", timeout=10)
    try:
        get_response_json = get_response.json()
    except ValueError:
        get_response_json = None

    if get_response.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve updated pet: status={get_response.status_code}, body={get_response.text}"
        )

    if not isinstance(get_response_json, dict):
        raise AssertionError(f"Retrieve updated pet response is not a JSON object: {get_response.text}")

    context.followup_response = get_response_json


@then(
    "the follow-up output should reflect the updated name while all other pet details remain identical to the corresponding fields in the seed output for MR17."
)
def _mr_MR17_followup_output(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("Seed response is missing or invalid in context.")
    if not hasattr(context, "followup_response") or not isinstance(context.followup_response, dict):
        raise AssertionError("Follow-up response is missing or invalid in context.")

    seed = context.seed_response
    followup = context.followup_response

    if followup.get("name") != "doggie_updated":
        raise AssertionError(
            f"The pet name was not updated correctly. Expected 'doggie_updated', got {followup.get('name')!r}"
        )

    seed_photo_urls = seed.get("photoUrls") or []
    followup_photo_urls = followup.get("photoUrls") or []
    if seed_photo_urls != followup_photo_urls:
        raise AssertionError(
            f"Photo URLs should remain unchanged. Seed={seed_photo_urls!r}, Follow-up={followup_photo_urls!r}"
        )

    if seed.get("status") != followup.get("status"):
        raise AssertionError(
            f"Status should remain unchanged. Seed={seed.get('status')!r}, Follow-up={followup.get('status')!r}"
        )

    if seed.get("category") != followup.get("category"):
        raise AssertionError(
            f"Category should remain unchanged. Seed={seed.get('category')!r}, Follow-up={followup.get('category')!r}"
        )

    if (seed.get("tags") or []) != (followup.get("tags") or []):
        raise AssertionError(
            f"Tags should remain unchanged. Seed={seed.get('tags')!r}, Follow-up={followup.get('tags')!r}"
        )
