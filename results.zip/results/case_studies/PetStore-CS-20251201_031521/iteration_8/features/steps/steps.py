from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that adds a new pet to the store, optionally including an identifier, producing a seed output that includes the created pet with the identifier assigned by the system for MR35.')
def _mr_MR35_add_pet(context):
    context.seed_request = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }
    try:
        response = requests.post(f"{BASE_URL}/pet", json=context.seed_request, timeout=10)
        response.raise_for_status()
        try:
            context.seed_response = response.json()
        except ValueError:
            raise AssertionError("Seed response is not valid JSON for MR35.")
        if not isinstance(context.seed_response, dict):
            raise AssertionError("Seed response JSON is not an object for MR35.")
        if 'id' not in context.seed_response:
            raise AssertionError("Seed response does not contain 'id' field for MR35.")
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in GIVEN step for MR35: {e}") from e


@when('a follow-up input is created by retrieving the pet using the identifier returned in the seed output, yielding a follow-up output for MR35.')
def _mr_MR35_retrieve_pet(context):
    seed_response = getattr(context, 'seed_response', None)
    if not isinstance(seed_response, dict):
        raise AssertionError("Seed response is missing or invalid in context for MR35.")
    pet_id = seed_response.get('id')
    if pet_id is None:
        raise AssertionError("Pet ID is missing in seed response for MR35.")
    try:
        response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        response.raise_for_status()
        try:
            context.followup_response = response.json()
        except ValueError:
            raise AssertionError("Follow-up response is not valid JSON for MR35.")
        if not isinstance(context.followup_response, dict):
            raise AssertionError("Follow-up response JSON is not an object for MR35.")
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in WHEN step for MR35: {e}") from e


@then('the follow-up output should contain pet details that are consistent with the seed output (including the same identifier), confirming that the pet is retrievable by its identifier for MR35.')
def _mr_MR35_verify_pet(context):
    seed_response = getattr(context, 'seed_response', None)
    followup_response = getattr(context, 'followup_response', None)

    if not isinstance(seed_response, dict):
        raise AssertionError("Seed response is missing or invalid in context for MR35.")
    if not isinstance(followup_response, dict):
        raise AssertionError("Follow-up response is missing or invalid in context for MR35.")

    seed_id = seed_response.get('id')
    follow_id = followup_response.get('id')
    assert seed_id is not None, "Seed response 'id' is missing for MR35."
    assert follow_id is not None, "Follow-up response 'id' is missing for MR35."

    assert follow_id == seed_id, "Pet ID does not match between seed and follow-up for MR35."
    assert followup_response.get('name') == seed_response.get('name'), "Pet name does not match between seed and follow-up for MR35."
    assert followup_response.get('status') == seed_response.get('status'), "Pet status does not match between seed and follow-up for MR35."
    assert followup_response.get('photoUrls') == seed_response.get('photoUrls'), "Pet photoUrls do not match between seed and follow-up for MR35."

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


@given(
    "a seed input that retrieves a pet by its ID, producing a seed output with the pet's current details including its name for MR36."
)
def step_mr_MR36_seed_input(context):
    pet_id = 1  # Using a fixed existing pet ID for the test
    context.pet_id = pet_id
    context.seed_request = {
        "method": "GET",
        "url": f"{BASE_URL}/pet/{pet_id}",
    }
    try:
        response = requests.get(context.seed_request["url"], timeout=10)
        response.raise_for_status()
        # Ensure JSON decoding is safe
        try:
            context.seed_response = response.json()
        except ValueError as e:
            raise AssertionError(f"Seed response is not valid JSON: {e}") from e
        if not isinstance(context.seed_response, dict):
            raise AssertionError(
                f"Expected seed response to be an object, got {type(context.seed_response)}"
            )
        if "name" not in context.seed_response:
            raise AssertionError("Seed response does not contain 'name' field")
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in GIVEN step for MR36: {e}") from e


@when(
    "a follow-up input is created by updating the pet using the same identifier and sending the same values for all modifiable fields except a changed name, and then retrieving the pet again by the same ID, yielding a follow-up output for MR36."
)
def step_mr_MR36_followup_input(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("Seed response not available or invalid in context")

    pet_id = getattr(context, "pet_id", 1)
    updated_name = "UpdatedPetName"

    category = context.seed_response.get("category")
    photo_urls = context.seed_response.get("photoUrls")
    tags = context.seed_response.get("tags")
    status = context.seed_response.get("status")

    updated_pet_data = {
        "id": pet_id,
        "name": updated_name,
        "category": category,
        "photoUrls": photo_urls if isinstance(photo_urls, list) else [],
        "tags": tags if isinstance(tags, list) else [],
        "status": status,
    }

    context.followup_request = {
        "method": "PUT",
        "url": f"{BASE_URL}/pet",
        "data": json.dumps(updated_pet_data),
        "headers": {"Content-Type": "application/json"},
    }

    try:
        update_response = requests.put(
            context.followup_request["url"],
            data=context.followup_request["data"],
            headers=context.followup_request["headers"],
            timeout=10,
        )
        update_response.raise_for_status()

        followup_get_response = requests.get(context.seed_request["url"], timeout=10)
        followup_get_response.raise_for_status()
        try:
            context.followup_response = followup_get_response.json()
        except ValueError as e:
            raise AssertionError(f"Follow-up response is not valid JSON: {e}") from e
        if not isinstance(context.followup_response, dict):
            raise AssertionError(
                f"Expected follow-up response to be an object, got {type(context.followup_response)}"
            )
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in WHEN step for MR36: {e}") from e


@then(
    "the follow-up output should reflect the updated name while all other explicitly preserved pet fields remain unchanged compared to the corresponding fields in the seed output, given that the update request provided the same values for those fields for MR36."
)
def step_mr_MR36_followup_output(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AssertionError("Seed or follow-up response missing from context")

    seed = context.seed_response
    followup = context.followup_response

    followup_name = followup.get("name")
    assert (
        followup_name == "UpdatedPetName"
    ), f"Expected name to be 'UpdatedPetName', but got {followup_name!r}"

    for key in ["category", "photoUrls", "tags", "status"]:
        seed_value = seed.get(key)
        followup_value = followup.get(key)
        assert (
            followup_value == seed_value
        ), f"Expected field {key!r} to remain unchanged. Seed: {seed_value!r}, Follow-up: {followup_value!r}"

# ----




@given("a seed input that retrieves an existing pet by its ID, producing a seed output with the pet's details for MR37.")
def step_mr_MR37_seed_input(context):
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)

    # Safely parse JSON, avoid TypeError/ValueError
    try:
        response_json = response.json()
    except ValueError:
        response_json = None

    assert response.status_code == 200, f"Failed to create pet: {response_json}"
    assert isinstance(response_json, dict), f"Unexpected response type: {type(response_json)}"

    context.seed_request = response
    context.seed_response = response_json

    # Safely extract pet id
    pet_id = response_json.get("id")
    assert pet_id is not None, f"No 'id' field in seed response: {response_json}"
    context.pet_id = pet_id


@when("a follow-up input is created by deleting the pet with the same ID and then attempting to retrieve the pet again by the same ID, yielding a follow-up output for MR37.")
def step_mr_MR37_followup_input(context):
    assert hasattr(context, "pet_id"), "pet_id not set in context"
    pet_id = context.pet_id

    delete_response = requests.delete(f"{BASE_URL}/pet/{pet_id}", timeout=10)

    # Delete operation: spec says 200 on success, but be tolerant and just ensure not 400.
    assert delete_response.status_code != 400, (
        f"Invalid pet value when deleting: status={delete_response.status_code}, "
        f"body={safe_json(delete_response)}"
    )

    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)

    try:
        followup_json = get_response.json()
    except ValueError:
        followup_json = None

    context.followup_request = get_response
    context.followup_response = followup_json


@then("the follow-up output should indicate that the pet is not found according to the API's error semantics, differing from the seed output which contains the pet's details for MR37.")
def step_mr_MR37_followup_output(context):
    assert hasattr(context, "seed_response"), "seed_response not set in context"
    assert hasattr(context, "followup_request"), "followup_request not set in context"

    # Seed output must contain pet details (200 with a Pet object)
    assert context.seed_request.status_code == 200, (
        f"Seed request did not return 200: {context.seed_request.status_code}, "
        f"body={context.seed_response}"
    )
    assert isinstance(context.seed_response, dict), (
        f"Seed response is not an object: {type(context.seed_response)}"
    )
    assert context.seed_response.get("id") == context.pet_id, (
        f"Seed response id mismatch. Expected {context.pet_id}, got {context.seed_response.get('id')}"
    )

    # Follow-up output should indicate not found: HTTP 404 per spec
    status_code = context.followup_request.status_code
    assert status_code == 404, (
        f"Expected 404 after deletion, got {status_code}: {context.followup_response}"
    )

    # Ensure follow-up output differs from seed output
    try:
        seed_str = json.dumps(context.seed_response, sort_keys=True)
    except (TypeError, ValueError):
        seed_str = str(context.seed_response)

    try:
        followup_str = json.dumps(context.followup_response, sort_keys=True)
    except (TypeError, ValueError):
        followup_str = str(context.followup_response)

    assert seed_str != followup_str, (
        "Follow-up output should differ from seed output, but they appear equal"
    )


def safe_json(response):
    try:
        return response.json()
    except ValueError:
        return response.text

# ----




@given("a seed input that retrieves a pet by its ID, producing a seed output with the pet's current status value for MR38.")
def _mr_MR38_seed_input(context):
    pet_id = 1  # Using a pet ID that is expected to exist
    try:
        response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    except requests.RequestException as exc:
        raise AssertionError(f"Request to retrieve pet failed: {exc}")

    context.seed_request = response

    if response.status_code != 200:
        raise AssertionError(f"Failed to retrieve pet: {response.status_code} - {response.text}")

    try:
        context.seed_response = response.json()
    except (ValueError, json.JSONDecodeError) as exc:
        raise AssertionError(f"Failed to decode seed response as JSON: {exc}")


@given("the pet's current status value is stored")
def _mr_MR38_store_status(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("Seed response is missing or not a JSON object.")

    seed_status = context.seed_response.get("status", None)
    if seed_status is None:
        raise AssertionError("Pet status not found in seed response.")
    context.seed_status = seed_status


@when("a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR38.")
def _mr_MR38_followup_input(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("Seed response is missing or not a JSON object.")

    pet_id = context.seed_response.get("id", None)
    if pet_id is None:
        raise AssertionError("Pet ID not found in seed response.")

    image_path = os.environ.get("MR38_IMAGE_PATH", "path/to/image.jpg")
    if not os.path.isfile(image_path):
        raise AssertionError(f"Image file does not exist at path: {image_path}")

    try:
        with open(image_path, "rb") as image_file:
            files = {"file": image_file}
            upload_url = f"{BASE_URL}/pet/{pet_id}/uploadImage"
            upload_response = requests.post(upload_url, files=files, timeout=10)
    except OSError as exc:
        raise AssertionError(f"Failed to open image file: {exc}")
    except requests.RequestException as exc:
        raise AssertionError(f"Request to upload image failed: {exc}")

    if upload_response.status_code != 200:
        raise AssertionError(
            f"Failed to upload image: {upload_response.status_code} - {upload_response.text}"
        )

    try:
        followup_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    except requests.RequestException as exc:
        raise AssertionError(f"Request to retrieve pet after upload failed: {exc}")

    context.followup_request = followup_response

    if followup_response.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve pet after upload: {followup_response.status_code} - {followup_response.text}"
        )

    try:
        context.followup_response = followup_response.json()
    except (ValueError, json.JSONDecodeError) as exc:
        raise AssertionError(f"Failed to decode follow-up response as JSON: {exc}")


@then("the follow-up output should have the same pet status value as the seed output for MR38, since uploading an image only sends binary content and additional metadata and does not modify the pet's status in the store.")
def _mr_MR38_assert_status(context):
    if not hasattr(context, "seed_status"):
        raise AssertionError("Seed status is not stored in context.")

    if not hasattr(context, "followup_response") or not isinstance(context.followup_response, dict):
        raise AssertionError("Follow-up response is missing or not a JSON object.")

    followup_status = context.followup_response.get("status", None)
    if followup_status is None:
        raise AssertionError("Pet status not found in follow-up response.")

    if followup_status != context.seed_status:
        raise AssertionError(
            f"Expected status '{context.seed_status}', but got '{followup_status}'."
        )

# ----

import time



@given('a seed input that retrieves the list of pets filtered by a single allowed status value (available, pending, or sold), producing a seed output with the list and its count for that status for MR39.')
def _mr_MR39_seed_input(context):
    status = 'available'  # Using 'available' as the allowed status value
    context.seed_request = {'status': status}

    response = requests.get(f"{BASE_URL}/pet/findByStatus", params=context.seed_request, timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as exc:
        raise AssertionError(f"Seed response is not valid JSON: {exc}") from exc

    if not isinstance(data, list):
        raise AssertionError(f"Expected seed response to be a list, got {type(data).__name__}")

    context.seed_response = data
    context.seed_count = len(data)


@when('a follow-up input is created by adding a new pet whose status field is set to that same allowed status value and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR39.')
def _mr_MR39_followup_input(context):
    new_pet = {
        "name": "New Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    add_response = requests.post(f"{BASE_URL}/pet", json=new_pet, timeout=10)
    add_response.raise_for_status()

    # Optional small delay to allow the store to be updated, avoiding flakiness
    time.sleep(0.2)

    followup_response = requests.get(f"{BASE_URL}/pet/findByStatus", params={'status': 'available'}, timeout=10)
    followup_response.raise_for_status()

    try:
        data = followup_response.json()
    except ValueError as exc:
        raise AssertionError(f"Follow-up response is not valid JSON: {exc}") from exc

    if not isinstance(data, list):
        raise AssertionError(f"Expected follow-up response to be a list, got {type(data).__name__}")

    context.followup_response = data
    context.followup_count = len(data)


@then('the follow-up output should have a count of pets with that status that is at least one more than the count in the seed output for MR39, under the assumption that no other operations modify pets with that status between the two retrievals.')
def _mr_MR39_followup_output(context):
    if not hasattr(context, "seed_count"):
        raise AssertionError("seed_count is missing from context.")
    if not hasattr(context, "followup_count"):
        raise AssertionError("followup_count is missing from context.")

    if not isinstance(context.seed_count, int):
        raise AssertionError(f"seed_count must be int, got {type(context.seed_count).__name__}")
    if not isinstance(context.followup_count, int):
        raise AssertionError(f"followup_count must be int, got {type(context.followup_count).__name__}")

    expected_min = context.seed_count + 1
    assert context.followup_count >= expected_min, (
        f"Expected follow-up count to be at least {expected_min}, but got {context.followup_count}."
    )
