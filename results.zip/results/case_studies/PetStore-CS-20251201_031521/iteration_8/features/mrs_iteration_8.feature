Feature: Iteration 8 MRs

  Scenario: MR35 Adding a new pet and obtaining its identifier should make it retrievable by that identifier
    Given a seed input that adds a new pet to the store, optionally including an identifier, producing a seed output that includes the created pet with the identifier assigned by the system for MR35.
    When a follow-up input is created by retrieving the pet using the identifier returned in the seed output, yielding a follow-up output for MR35.
    Then the follow-up output should contain pet details that are consistent with the seed output (including the same identifier), confirming that the pet is retrievable by its identifier for MR35.

  Scenario: MR36 Updating a pet's name while keeping other details the same should only change the name in the stored representation
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current details including its name for MR36.
    When a follow-up input is created by updating the pet using the same identifier and sending the same values for all modifiable fields except a changed name, and then retrieving the pet again by the same ID, yielding a follow-up output for MR36.
    Then the follow-up output should reflect the updated name while all other explicitly preserved pet fields remain unchanged compared to the corresponding fields in the seed output, given that the update request provided the same values for those fields for MR36.

  Scenario: MR37 Deleting a pet should make it inaccessible by its ID
    Given a seed input that retrieves an existing pet by its ID, producing a seed output with the pet's details for MR37.
    When a follow-up input is created by deleting the pet with the same ID and then attempting to retrieve the pet again by the same ID, yielding a follow-up output for MR37.
    Then the follow-up output should indicate that the pet is not found according to the API's error semantics, differing from the seed output which contains the pet's details for MR37.

  Scenario: MR38 Uploading an image should not affect the pet's retrievable status field
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current status value for MR38.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR38.
    Then the follow-up output should have the same pet status value as the seed output for MR38, since uploading an image only sends binary content and additional metadata and does not modify the pet's status in the store.

  Scenario: MR39 Creating a pet with a specific status should increase the count of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a single allowed status value (available, pending, or sold), producing a seed output with the list and its count for that status for MR39.
    When a follow-up input is created by adding a new pet whose status field is set to that same allowed status value and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR39.
    Then the follow-up output should have a count of pets with that status that is at least one more than the count in the seed output for MR39, under the assumption that no other operations modify pets with that status between the two retrievals.
