Feature: Iteration 4 MRs

  Scenario: MR18 Logging out should report a successful termination of the current session
    Given a seed input that logs a user into the system, producing a seed output indicating a successful login with any returned login details for MR18.
    When a follow-up input is created by logging out the user, yielding a follow-up output for MR18.
    Then the follow-up output should indicate a successful logout operation, regardless of the specific login details present in the seed output for MR18.

  Scenario: MR19 Updating a pet's name should reflect only the updated name
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current details including its name for MR19.
    When a follow-up input is created by updating the pet's name and then retrieving the pet again by the same ID, yielding a follow-up output for MR19.
    Then the follow-up output should reflect the updated name while all other pet details remain unchanged compared to the corresponding fields in the seed output for MR19.
