from behave import given, when, then
import os
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that logs a user into the system, producing a seed output indicating a successful login with any returned login details for MR18.')
def step_mr_MR18_seed_input(context):
    try:
        # Create a user for login using the correct schema
        user_data = {
            "id": 1,
            "username": "testuser_mr18",
            "firstName": "Test",
            "lastName": "User",
            "email": "testuser_mr18@example.com",
            "password": "testpassword",
            "phone": "1234567890",
            "userStatus": 1
        }

        create_user_resp = requests.post(
            f"{BASE_URL}/user",
            json=user_data,
            timeout=10
        )

        # Creation may or may not strictly be required for login, but ensure no client error occurred
        assert create_user_resp.status_code < 500, (
            f"User creation failed with server error: {create_user_resp.status_code}, "
            f"body: {create_user_resp.text}"
        )

        # Log in the user using the documented login endpoint
        login_params = {
            "username": user_data["username"],
            "password": user_data["password"]
        }
        login_response = requests.get(
            f"{BASE_URL}/user/login",
            params=login_params,
            timeout=10
        )

        context.login_status_code = login_response.status_code
        context.login_raw_text = login_response.text

        # Only attempt to parse JSON if content-type is JSON
        content_type = login_response.headers.get("Content-Type", "")
        if "application/json" in content_type:
            try:
                context.login_response = login_response.json()
            except ValueError:
                context.login_response = None
        else:
            context.login_response = None

        assert context.login_status_code == 200, (
            f"Login failed: status={context.login_status_code}, body={context.login_raw_text}"
        )
    except Exception as e:
        raise AssertionError(f"Error in Given step for MR18: {e}") from e


@when('a follow-up input is created by logging out the user, yielding a follow-up output for MR18.')
def step_mr_MR18_followup_input(context):
    try:
        logout_response = requests.get(
            f"{BASE_URL}/user/logout",
            timeout=10
        )

        context.logout_status_code = logout_response.status_code
        context.logout_raw_text = logout_response.text

        # Only attempt to parse JSON if content-type is JSON
        content_type = logout_response.headers.get("Content-Type", "")
        if "application/json" in content_type:
            try:
                context.followup_response = logout_response.json()
            except ValueError:
                context.followup_response = None
        else:
            context.followup_response = None
    except Exception as e:
        raise AssertionError(f"Error in When step for MR18: {e}") from e


@then('the follow-up output should indicate a successful logout operation, regardless of the specific login details present in the seed output for MR18.')
def step_mr_MR18_followup_output(context):
    try:
        assert hasattr(context, "logout_status_code"), "Logout response is not available in context."
        assert context.logout_status_code == 200, (
            f"Expected logout status code 200, got {context.logout_status_code}, "
            f"body={getattr(context, 'logout_raw_text', '')}"
        )
        # MR is about successful logout; no strict shape requirement on body,
        # so we only assert the HTTP success status.
    except Exception as e:
        raise AssertionError(f"Error in Then step for MR18: {e}") from e

# ----

import json



@given("a seed input that retrieves a pet by its ID, producing a seed output with the pet's current details including its name for MR19.")
def _mr_MR19_seed_input(context):
    try:
        pet_data = {
            "name": "doggie",
            "photoUrls": ["url1", "url2"],
            "status": "available"
        }
        response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        response.raise_for_status()

        seed_response_json = response.json()
        if not isinstance(seed_response_json, dict):
            raise ValueError("Seed creation response is not a JSON object")

        pet_id = seed_response_json.get("id")
        if pet_id is None:
            raise ValueError("Created pet has no 'id' field")

        get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        get_response.raise_for_status()

        seed_get_json = get_response.json()
        if not isinstance(seed_get_json, dict):
            raise ValueError("Seed GET response is not a JSON object")

        context.seed_pet = seed_get_json
        context.seed_pet_id = pet_id
    except (requests.RequestException, ValueError, TypeError) as e:
        print(f"Error in Given step for MR19: {e}")
        raise


@when("a follow-up input is created by updating the pet's name and then retrieving the pet again by the same ID, yielding a follow-up output for MR19.")
def _mr_MR19_followup_input(context):
    try:
        if not hasattr(context, "seed_pet") or not isinstance(context.seed_pet, dict):
            raise ValueError("Seed pet data is not available or invalid in context")

        pet_id = context.seed_pet.get("id")
        if pet_id is None:
            raise ValueError("Seed pet does not contain 'id'")

        original_name = context.seed_pet.get("name", "")
        updated_name = f"{original_name}_updated" if isinstance(original_name, str) else "doggie_updated"

        update_data = {
            "id": pet_id,
            "name": updated_name,
            "photoUrls": context.seed_pet.get("photoUrls", []),
            "status": context.seed_pet.get("status"),
        }

        if "category" in context.seed_pet:
            update_data["category"] = context.seed_pet["category"]
        if "tags" in context.seed_pet:
            update_data["tags"] = context.seed_pet["tags"]

        put_response = requests.put(f"{BASE_URL}/pet", json=update_data, timeout=10)
        put_response.raise_for_status()

        get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        get_response.raise_for_status()

        followup_json = get_response.json()
        if not isinstance(followup_json, dict):
            raise ValueError("Follow-up GET response is not a JSON object")

        context.followup_pet = followup_json
        context.updated_name = updated_name
    except (requests.RequestException, ValueError, TypeError) as e:
        print(f"Error in When step for MR19: {e}")
        raise


@then("the follow-up output should reflect the updated name while all other pet details remain unchanged compared to the corresponding fields in the seed output for MR19.")
def _mr_MR19_followup_assertion(context):
    try:
        if not hasattr(context, "seed_pet") or not isinstance(context.seed_pet, dict):
            raise ValueError("Seed pet data is not available or invalid in context")
        if not hasattr(context, "followup_pet") or not isinstance(context.followup_pet, dict):
            raise ValueError("Follow-up pet data is not available or invalid in context")

        seed_pet = context.seed_pet
        followup_pet = context.followup_pet
        updated_name = getattr(context, "updated_name", "doggie_updated")

        assert followup_pet.get("name") == updated_name, "The pet's name was not updated correctly."
        assert followup_pet.get("id") == seed_pet.get("id"), "The pet ID should remain the same."
        assert followup_pet.get("photoUrls") == seed_pet.get("photoUrls"), "The photo URLs should remain unchanged."
        assert followup_pet.get("status") == seed_pet.get("status"), "The pet status should remain unchanged."

        for field in ("category", "tags"):
            if field in seed_pet:
                assert followup_pet.get(field) == seed_pet.get(field), f"The field '{field}' should remain unchanged."
    except AssertionError as e:
        print(f"Assertion error in Then step for MR19: {e}")
        raise
    except (ValueError, TypeError) as e:
        print(f"Error in Then step for MR19: {e}")
        raise
