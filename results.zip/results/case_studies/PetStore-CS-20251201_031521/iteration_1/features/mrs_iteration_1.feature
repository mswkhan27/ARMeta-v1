Feature: Iteration 1 MRs

  Scenario: MR5 Deleting a user should make the user inaccessible
    Given a seed input that retrieves a user by username, producing a seed output with the user's details for MR5.
    When a follow-up input is created by deleting the user with the same username and then attempting to retrieve the user again by the same username, yielding a follow-up output for MR5.
    Then the follow-up output should indicate that the user is not found (for example, by returning a corresponding error status), differing from the seed output which contains the user's details for MR5.

  Scenario: MR7 Logging in should return a consistent login response structure
    Given a seed input that attempts to log in with valid credentials, producing a seed output that includes a success status, a response body string, and any login-related headers (such as rate limit and expiry information) for MR7.
    When a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR7.
    Then the follow-up output should also indicate a successful login and provide a response body of the same type along with the same set of login-related headers as in the seed output for MR7.

  Scenario: MR8 Updating a user's details should reflect in the user's profile
    Given a seed input that retrieves a user's profile by username, producing a seed output with the user's current details for MR8.
    When a follow-up input is created by updating the user's details and then retrieving the user's profile again by the same username, yielding a follow-up output for MR8.
    Then the follow-up output should reflect the updated details for the fields that were modified, while fields that were not part of the update request should remain identical to the corresponding fields in the seed output for MR8.
