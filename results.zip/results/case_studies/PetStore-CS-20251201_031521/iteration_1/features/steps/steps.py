from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that retrieves a user by username, producing a seed output with the user's details for MR5.")
def _mr_MR5_seed_input(context):
    context.username = "testuser"
    context.seed_request = {
        "username": context.username,
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password123",
        "phone": "1234567890",
        "userStatus": 1
    }

    try:
        # Create the user
        create_response = requests.post(
            f"{BASE_URL}/user",
            json=context.seed_request,
            timeout=10
        )
        create_response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error creating user in Given step: {e}") from e

    try:
        # Retrieve the user by username (seed output)
        seed_response = requests.get(
            f"{BASE_URL}/user/{context.username}",
            timeout=10
        )
        # We expect this to succeed; if not, fail explicitly but avoid TypeError
        if seed_response.status_code != 200:
            raise AssertionError(
                f"Expected 200 when retrieving seed user, got {seed_response.status_code}"
            )
        # Safely parse JSON
        try:
            context.seed_response = seed_response.json()
        except ValueError as e:
            raise AssertionError(f"Seed response is not valid JSON: {e}") from e

        if not isinstance(context.seed_response, dict):
            raise AssertionError(
                f"Seed response JSON is not an object: {context.seed_response!r}"
            )
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error retrieving user in Given step: {e}") from e


@when("a follow-up input is created by deleting the user with the same username and then attempting to retrieve the user again by the same username, yielding a follow-up output for MR5.")
def _mr_MR5_followup_input(context):
    if not hasattr(context, "username"):
        raise AssertionError("Context is missing 'username' from Given step")

    try:
        # Delete the user
        delete_response = requests.delete(
            f"{BASE_URL}/user/{context.username}",
            timeout=10
        )
        # Even if delete fails with a 4xx/5xx, we keep the response for assertion,
        # but raise_for_status would turn it into an exception; avoid that here.
        context.delete_status_code = delete_response.status_code
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error deleting user in When step: {e}") from e

    try:
        # Attempt to retrieve the user again
        followup_response = requests.get(
            f"{BASE_URL}/user/{context.username}",
            timeout=10
        )
        context.followup_response = followup_response
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error retrieving user in When step: {e}") from e


@then("the follow-up output should indicate that the user is not found (for example, by returning a corresponding error status), differing from the seed output which contains the user's details for MR5.")
def _mr_MR5_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AssertionError("Context is missing 'followup_response' from When step")
    if not hasattr(context, "seed_response"):
        raise AssertionError("Context is missing 'seed_response' from Given step")
    if not hasattr(context, "username"):
        raise AssertionError("Context is missing 'username' from Given step")

    status_code = getattr(context.followup_response, "status_code", None)
    if status_code is None:
        raise AssertionError("Follow-up response has no status_code")

    # According to /user/\{username\} spec, 404 indicates user not found
    assert status_code == 404, (
        f"Expected user not found status code 404 after deletion, got {status_code}"
    )

    username_in_seed = None
    if isinstance(context.seed_response, dict):
        username_in_seed = context.seed_response.get("username")

    assert username_in_seed == context.username, (
        f"Seed output should contain the username '{context.username}', "
        f"but got {username_in_seed!r}"
    )

# ----

from requests import Response



def _safe_get_json(response: Response):
    """
    Safely get JSON from response.
    Login endpoint returns a string body; if JSON parsing fails, fall back to text.
    """
    if response is None:
        return None
    try:
        return response.json()
    except (ValueError, TypeError):
        # Not JSON; return text instead
        return response.text


def _get_header(headers, name, default=None):
    """
    Safely get a header value without raising KeyError or TypeError.
    """
    if not hasattr(headers, 'get'):
        return default
    return headers.get(name, default)


@given('a seed input that attempts to log in with valid credentials, producing a seed output that includes a success status, a response body string, and any login-related headers (such as rate limit and expiry information) for MR7.')
def step_mr_MR7_seed_login(context):
    context.seed_request = {
        'username': 'validUser',
        'password': 'validPassword',
    }

    url = f"{BASE_URL}/user/login"
    response = requests.get(url, params=context.seed_request, timeout=10)
    # Will raise HTTPError if not 2xx; this is desired for "success status"
    response.raise_for_status()

    context.seed_status_code = response.status_code
    context.seed_body = response.text if isinstance(response.text, str) else str(response.text)
    context.seed_body_type = type(context.seed_body)
    context.seed_headers = dict(response.headers)

    # Store only the login-related headers we care about, safely
    context.seed_rate_limit = _get_header(context.seed_headers, 'X-Rate-Limit')
    context.seed_expires_after = _get_header(context.seed_headers, 'X-Expires-After')


@when('a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR7.')
def step_mr_MR7_followup_login(context):
    url = f"{BASE_URL}/user/login"
    response = requests.get(url, params=context.seed_request, timeout=10)
    response.raise_for_status()

    context.followup_status_code = response.status_code
    context.followup_body = response.text if isinstance(response.text, str) else str(response.text)
    context.followup_body_type = type(context.followup_body)
    context.followup_headers = dict(response.headers)

    context.followup_rate_limit = _get_header(context.followup_headers, 'X-Rate-Limit')
    context.followup_expires_after = _get_header(context.followup_headers, 'X-Expires-After')


@then('the follow-up output should also indicate a successful login and provide a response body of the same type along with the same set of login-related headers as in the seed output for MR7.')
def step_mr_MR7_verify_followup(context):
    # Both should be successful (2xx). Behave steps already raised on non-2xx.
    assert 200 <= context.seed_status_code < 300, "Seed login did not return a success status."
    assert 200 <= context.followup_status_code < 300, "Follow-up login did not return a success status."

    # Body should have the same type (string according to OpenAPI)
    assert context.seed_body_type is str, "Seed response body is not a string."
    assert context.followup_body_type is str, "Follow-up response body is not a string."
    assert context.followup_body_type is context.seed_body_type, "Body types between seed and follow-up do not match."

    # Header presence consistency: if a login-related header exists in seed, it must also exist in follow-up
    if context.seed_rate_limit is not None:
        assert context.followup_rate_limit is not None, "Follow-up missing X-Rate-Limit header present in seed."
    if context.seed_expires_after is not None:
        assert context.followup_expires_after is not None, "Follow-up missing X-Expires-After header present in seed."

    # If both present, sets of login-related headers should be the same (by presence) and types comparable
    seed_login_headers = {
        'X-Rate-Limit': context.seed_rate_limit,
        'X-Expires-After': context.seed_expires_after,
    }
    followup_login_headers = {
        'X-Rate-Limit': context.followup_rate_limit,
        'X-Expires-After': context.followup_expires_after,
    }

    seed_present = {k for k, v in seed_login_headers.items() if v is not None}
    followup_present = {k for k, v in followup_login_headers.items() if v is not None}
    assert seed_present == followup_present, (
        f"Login-related header presence differs between seed ({seed_present}) "
        f"and follow-up ({followup_present})."
    )

# ----




@given("a seed input that retrieves a user's profile by username, producing a seed output with the user's current details for MR8.")
def _mr_MR8_seed_input(context):
    username = "testuser"

    user_data = {
        "id": 1,
        "username": username,
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1
    }

    create_resp = requests.post(
        f"{BASE_URL}/user",
        json=user_data,
        timeout=10,
    )

    try:
        seed_response_json = create_resp.json()
    except ValueError:
        seed_response_json = {}

    if not isinstance(seed_response_json, dict):
        seed_response_json = {}

    context.seed_request = create_resp
    context.seed_response = seed_response_json

    get_resp = requests.get(
        f"{BASE_URL}/user/{username}",
        timeout=10,
    )

    try:
        seed_output_json = get_resp.json()
    except ValueError:
        seed_output_json = {}

    if not isinstance(seed_output_json, dict):
        seed_output_json = {}

    context.user_profile_request = get_resp
    context.seed_output = seed_output_json
    context.username = username


@when("a follow-up input is created by updating the user's details and then retrieving the user's profile again by the same username, yielding a follow-up output for MR8.")
def _mr_MR8_followup_input(context):
    username = getattr(context, "username", None)
    if not isinstance(username, str) or not username:
        username = "testuser"

    updated_user_data = {
        "id": context.seed_output.get("id", 1),
        "username": username,
        "firstName": "Jane",
        "lastName": "Doe",
        "email": "jane.doe@example.com",
        "password": "newpassword",
        "phone": "0987654321",
        "userStatus": context.seed_output.get("userStatus", 1),
    }

    put_resp = requests.put(
        f"{BASE_URL}/user/{username}",
        json=updated_user_data,
        timeout=10,
    )

    context.followup_request = put_resp

    get_resp = requests.get(
        f"{BASE_URL}/user/{username}",
        timeout=10,
    )

    try:
        followup_output_json = get_resp.json()
    except ValueError:
        followup_output_json = {}

    if not isinstance(followup_output_json, dict):
        followup_output_json = {}

    context.followup_response = get_resp
    context.followup_output = followup_output_json


@then("the follow-up output should reflect the updated details for the fields that were modified, while fields that were not part of the update request should remain identical to the corresponding fields in the seed output for MR8.")
def _mr_MR8_followup_output(context):
    follow = getattr(context, "followup_output", {}) or {}
    seed = getattr(context, "seed_output", {}) or {}

    assert follow.get("firstName") == "Jane", "First name did not update correctly."
    assert follow.get("lastName") == "Doe", "Last name should remain unchanged."
    assert follow.get("email") == "jane.doe@example.com", "Email did not update correctly."
    assert follow.get("phone") == "0987654321", "Phone did not update correctly."

    assert follow.get("userStatus") == seed.get(
        "userStatus"
    ), "User status should remain unchanged."
