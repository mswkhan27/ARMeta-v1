Feature: Iteration 5 MRs

  Scenario: MR20 Adding a new pet and using its returned ID should make it retrievable by that ID
    Given a seed input that adds a new pet to the store, producing a seed output that includes the created pet with its identifier for MR20.
    When a follow-up input is created by retrieving the pet using the identifier returned in the seed output, yielding a follow-up output for MR20.
    Then the follow-up output should contain the pet details matching the seed output, confirming that the pet is retrievable by its identifier for MR20.

  Scenario: MR21 Updating a pet's status should reflect in the pet's retrievable details
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current status and other details for MR21.
    When a follow-up input is created by updating only the pet's status to a new valid value and then retrieving the pet again by the same ID, yielding a follow-up output for MR21.
    Then the follow-up output should reflect the updated status, and no other pet details should change except for fields explicitly modified by the update in MR21.

  Scenario: MR22 Deleting a pet should make it inaccessible by its ID
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's details for MR22.
    When a follow-up input is created by deleting the pet with the same ID and then attempting to retrieve the pet again by the same ID, yielding a follow-up output for MR22.
    Then the follow-up output should indicate that the pet is not found, differing from the seed output which contains the pet's details for MR22.

  Scenario: MR23 Uploading an image should not affect the pet's retrievable status
    Given a seed input that retrieves a pet by its ID, producing a seed output with the pet's current status for MR23.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR23.
    Then the follow-up output should have the same pet status as the seed output for MR23, since uploading an image does not modify the pet's status in the store.

  Scenario: MR24 Creating a pet with a specific status should increase the count of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a specific status, producing a seed output with the list and its count for that status for MR24.
    When a follow-up input is created by adding a new pet with the same status and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR24.
    Then the follow-up output should have a count of pets with that status that is one more than the count in the seed output for MR24, assuming no other changes to pets with that status occur between the two retrievals.
