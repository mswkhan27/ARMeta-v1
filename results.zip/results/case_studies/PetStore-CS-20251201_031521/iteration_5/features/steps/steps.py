from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that adds a new pet to the store, producing a seed output that includes the created pet with its identifier for MR20.')
def _mr_MR20_add_pet(context):
    context.seed_request = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    try:
        response = requests.post(f"{BASE_URL}/pet", json=context.seed_request, timeout=10)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"HTTP error in Given step for MR20: {e}") from e

    try:
        context.seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Non-JSON response in Given step for MR20: {e}") from e

    if not isinstance(context.seed_response, dict):
        raise AssertionError("Seed response is not a JSON object for MR20")

    pet_id = context.seed_response.get('id')
    if pet_id is None:
        raise AssertionError("Seed response does not contain 'id' for MR20")
    try:
        # Ensure pet_id can be used as an integer path parameter as per OpenAPI
        int(pet_id)
    except (TypeError, ValueError) as e:
        raise AssertionError(f"Seed response 'id' is not a valid integer for MR20: {e}") from e


@when('a follow-up input is created by retrieving the pet using the identifier returned in the seed output, yielding a follow-up output for MR20.')
def _mr_MR20_get_pet(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("Missing or invalid seed_response in context for MR20")

    pet_id = context.seed_response.get('id')
    if pet_id is None:
        raise AssertionError("Seed response does not contain 'id' for MR20")

    try:
        pet_id_int = int(pet_id)
    except (TypeError, ValueError) as e:
        raise AssertionError(f"'id' in seed response is not a valid integer for MR20: {e}") from e

    try:
        response = requests.get(f"{BASE_URL}/pet/{pet_id_int}", timeout=10)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"HTTP error in When step for MR20: {e}") from e

    try:
        context.followup_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Non-JSON response in When step for MR20: {e}") from e

    if not isinstance(context.followup_response, dict):
        raise AssertionError("Follow-up response is not a JSON object for MR20")


@then('the follow-up output should contain the pet details matching the seed output, confirming that the pet is retrievable by its identifier for MR20.')
def _mr_MR20_verify_pet(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("Missing or invalid seed_response in context for MR20")
    if not hasattr(context, "followup_response") or not isinstance(context.followup_response, dict):
        raise AssertionError("Missing or invalid followup_response in context for MR20")

    seed = context.seed_response
    follow = context.followup_response

    seed_id = seed.get('id')
    follow_id = follow.get('id')
    if seed_id is None or follow_id is None:
        raise AssertionError("One of the responses does not contain 'id' for MR20")
    try:
        if int(seed_id) != int(follow_id):
            raise AssertionError("Pet ID does not match between seed and follow-up for MR20")
    except (TypeError, ValueError) as e:
        raise AssertionError(f"Invalid ID type when comparing seed and follow-up for MR20: {e}") from e

    if follow.get('name') != seed.get('name'):
        raise AssertionError("Pet name does not match between seed and follow-up for MR20")

    if follow.get('status') != seed.get('status'):
        raise AssertionError("Pet status does not match between seed and follow-up for MR20")

    seed_photos = seed.get('photoUrls') or []
    follow_photos = follow.get('photoUrls') or []
    if seed_photos != follow_photos:
        raise AssertionError("Pet photoUrls do not match between seed and follow-up for MR20")

# ----




@given("a seed input that retrieves a pet by its ID, producing a seed output with the pet's current status and other details for MR21.")
def step_mr_MR21_seed_input(context):
    try:
        # Create a pet to ensure it exists
        pet_data = {
            "id": 1,
            "name": "doggie",
            "photoUrls": ["url1"],
            "status": "available"
        }
        create_resp = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        try:
            create_json = create_resp.json()
        except ValueError:
            create_json = None

        assert create_resp.status_code == 200, f"Failed to create pet: {create_resp.text}"

        if not isinstance(create_json, dict):
            raise AssertionError("Create pet response is not a JSON object")

        pet_id = create_json.get("id")
        assert pet_id is not None, "Create pet response does not contain 'id'"

        # Retrieve the pet by ID
        get_resp = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        try:
            get_json = get_resp.json()
        except ValueError:
            get_json = None

        assert get_resp.status_code == 200, f"Failed to retrieve pet: {get_resp.text}"
        if not isinstance(get_json, dict):
            raise AssertionError("Get pet response is not a JSON object")

        context.seed_request = get_resp
        context.seed_response = get_json
        context.pet_id = pet_id
    except Exception as e:
        print(f"Error in Given step for MR21: {str(e)}")
        assert False


@when("a follow-up input is created by updating only the pet's status to a new valid value and then retrieving the pet again by the same ID, yielding a follow-up output for MR21.")
def step_mr_MR21_followup_input(context):
    try:
        if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
            raise AssertionError("Seed response is missing or invalid")

        pet_id = context.pet_id if hasattr(context, "pet_id") else context.seed_response.get("id")
        assert pet_id is not None, "Pet ID is missing from context"

        name = context.seed_response.get("name")
        photo_urls = context.seed_response.get("photoUrls")
        status = context.seed_response.get("status")

        assert name is not None, "Seed response missing 'name'"
        assert photo_urls is not None, "Seed response missing 'photoUrls'"
        # status may be None initially, so we don't assert on it

        # Update the pet's status
        updated_pet_data = {
            "id": pet_id,
            "name": name,
            "photoUrls": photo_urls,
            "status": "sold"  # New valid status
        }
        update_resp = requests.put(f"{BASE_URL}/pet", json=updated_pet_data, timeout=10)
        try:
            update_json = update_resp.json()
        except ValueError:
            update_json = None

        assert update_resp.status_code == 200, f"Failed to update pet: {update_resp.text}"
        if not isinstance(update_json, dict):
            raise AssertionError("Update pet response is not a JSON object")

        updated_id = update_json.get("id")
        if updated_id is None:
            updated_id = pet_id

        # Retrieve the pet again
        get_resp = requests.get(f"{BASE_URL}/pet/{updated_id}", timeout=10)
        try:
            get_json = get_resp.json()
        except ValueError:
            get_json = None

        assert get_resp.status_code == 200, f"Failed to retrieve updated pet: {get_resp.text}"
        if not isinstance(get_json, dict):
            raise AssertionError("Get updated pet response is not a JSON object")

        context.followup_request = get_resp
        context.followup_response = get_json
    except Exception as e:
        print(f"Error in When step for MR21: {str(e)}")
        assert False


@then("the follow-up output should reflect the updated status, and no other pet details should change except for fields explicitly modified by the update in MR21.")
def step_mr_MR21_followup_output(context):
    try:
        if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
            raise AssertionError("Seed or follow-up response missing from context")

        if not isinstance(context.seed_response, dict) or not isinstance(context.followup_response, dict):
            raise AssertionError("Seed or follow-up response is not a JSON object")

        follow = context.followup_response
        seed = context.seed_response

        assert follow.get("status") == "sold", "Status was not updated correctly."

        assert follow.get("name") == seed.get("name"), "Name should not have changed."
        assert follow.get("photoUrls") == seed.get("photoUrls"), "Photo URLs should not have changed."

        # Optional: ensure id stayed the same
        assert follow.get("id") == seed.get("id"), "Pet ID should not have changed."
    except AssertionError as e:
        print(f"Assertion error in Then step for MR21: {str(e)}")
        assert False
    except Exception as e:
        print(f"Error in Then step for MR21: {str(e)}")
        assert False

# ----




@given("a seed input that retrieves a pet by its ID, producing a seed output with the pet's details for MR22.")
def _mr_MR22_seed_input(context):
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }
    url = f"{BASE_URL}/pet"
    response = requests.post(url, json=pet_data, timeout=10)

    context.seed_request = response

    try:
        context.seed_response = response.json()
    except ValueError:
        context.seed_response = {}

    if response.status_code != 200:
        raise AssertionError(
            f"Failed to create pet, status={response.status_code}, body={json.dumps(context.seed_response)}"
        )

    # Retrieve by ID as the MR states: "retrieves a pet by its ID"
    pet_id = context.seed_response.get("id")
    if pet_id is None:
        raise AssertionError(f"Seed response does not contain 'id': {json.dumps(context.seed_response)}")

    get_url = f"{BASE_URL}/pet/{pet_id}"
    get_response = requests.get(get_url, timeout=10)

    context.seed_get_request = get_response
    try:
        context.seed_get_response = get_response.json()
    except ValueError:
        context.seed_get_response = {}

    if get_response.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve pet by ID, status={get_response.status_code}, "
            f"body={json.dumps(context.seed_get_response)}"
        )


@when("a follow-up input is created by deleting the pet with the same ID and then attempting to retrieve the pet again by the same ID, yielding a follow-up output for MR22.")
def _mr_MR22_followup_input(context):
    pet_id = None
    if isinstance(context.seed_get_response, dict):
        pet_id = context.seed_get_response.get("id")
    if pet_id is None and isinstance(context.seed_response, dict):
        pet_id = context.seed_response.get("id")
    if pet_id is None:
        raise AssertionError(
            f"Cannot determine pet id from seed responses: "
            f"seed_response={json.dumps(context.seed_response)}, "
            f"seed_get_response={json.dumps(context.seed_get_response)}"
        )

    delete_url = f"{BASE_URL}/pet/{pet_id}"
    delete_response = requests.delete(delete_url, timeout=10)

    context.delete_request = delete_response
    try:
        context.delete_response = delete_response.json()
    except ValueError:
        context.delete_response = {}

    if delete_response.status_code != 200:
        raise AssertionError(
            f"Failed to delete pet, status={delete_response.status_code}, "
            f"body={json.dumps(context.delete_response)}"
        )

    followup_url = f"{BASE_URL}/pet/{pet_id}"
    followup_request = requests.get(followup_url, timeout=10)

    context.followup_request = followup_request
    try:
        context.followup_response = followup_request.json()
    except ValueError:
        context.followup_response = {}


@then("the follow-up output should indicate that the pet is not found, differing from the seed output which contains the pet's details for MR22.")
def _mr_MR22_followup_output(context):
    if context.seed_get_request.status_code != 200:
        raise AssertionError(
            f"Seed GET did not return 200 as expected, "
            f"status={context.seed_get_request.status_code}, "
            f"body={json.dumps(context.seed_get_response)}"
        )

    if context.followup_request.status_code != 404:
        raise AssertionError(
            f"Expected 404 after deleting pet, got {context.followup_request.status_code}, "
            f"body={json.dumps(context.followup_response)}"
        )

    if not isinstance(context.seed_get_response, dict):
        raise AssertionError(
            f"Seed GET response is not an object: {json.dumps(context.seed_get_response)}"
        )

    seed_id = context.seed_get_response.get("id")
    if seed_id is None:
        raise AssertionError(
            f"Seed GET response does not contain 'id': {json.dumps(context.seed_get_response)}"
        )

    if seed_id != 1:
        raise AssertionError(
            f"Seed output ID does not match expected value 1, got {seed_id}"
        )

# ----




@given("a seed input that retrieves a pet by its ID, producing a seed output with the pet's current status for MR23.")
def step_mr_MR23_seed_input(context):
    # Create a pet to ensure it exists, matching /pet POST: Pet schema (id optional)
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    try:
        response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to create pet failed: {e}") from e

    if response is None:
        raise AssertionError("No response received when creating pet")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"Creating pet failed with status {response.status_code}: {response.text}") from e

    try:
        seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Creating pet returned non-JSON response: {response.text}") from e

    if not isinstance(seed_response, dict):
        raise AssertionError(f"Expected JSON object for pet, got: {seed_response!r}")

    pet_id = seed_response.get("id")
    if pet_id is None:
        raise AssertionError(f"Created pet response does not contain 'id': {seed_response}")
    if not isinstance(pet_id, int):
        raise AssertionError(f"Created pet id is not an integer: {pet_id!r}")

    context.seed_request = pet_data
    context.seed_response = seed_response
    context.pet_id = pet_id

    # Retrieve the pet by ID to align with the MR wording ("retrieves a pet by its ID")
    try:
        get_response = requests.get(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to retrieve pet by ID failed: {e}") from e

    if get_response is None:
        raise AssertionError("No response received when retrieving pet by ID")

    try:
        get_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"Retrieving pet by ID failed with status {get_response.status_code}: {get_response.text}"
        ) from e

    try:
        pet_by_id = get_response.json()
    except ValueError as e:
        raise AssertionError(f"Retrieving pet by ID returned non-JSON response: {get_response.text}") from e

    if not isinstance(pet_by_id, dict):
        raise AssertionError(f"Expected JSON object for pet when retrieved by ID, got: {pet_by_id!r}")

    # Use the status from the retrieval as the seed output per MR description
    context.seed_response = pet_by_id


@when("a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same ID, yielding a follow-up output for MR23.")
def step_mr_MR23_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AssertionError("Context is missing 'pet_id' from Given step")

    pet_id = context.pet_id
    if not isinstance(pet_id, int):
        raise AssertionError(f"'pet_id' must be an integer, got: {pet_id!r}")

    # Upload an image for the pet using /pet/\{petId\}/uploadImage with application/octet-stream
    image_data = b"fake_image_data"

    try:
        upload_response = requests.post(
            f"{BASE_URL}/pet/{pet_id}/uploadImage",
            data=image_data,
            headers={"Content-Type": "application/octet-stream"},
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"Request to upload image failed: {e}") from e

    if upload_response is None:
        raise AssertionError("No response received when uploading image")

    try:
        upload_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"Uploading image failed with status {upload_response.status_code}: {upload_response.text}"
        ) from e

    # Retrieve the pet again using /pet/\{petId\}
    try:
        followup_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to retrieve pet after upload failed: {e}") from e

    if followup_response is None:
        raise AssertionError("No response received when retrieving pet after upload")

    try:
        followup_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"Retrieving pet after upload failed with status {followup_response.status_code}: {followup_response.text}"
        ) from e

    try:
        followup_json = followup_response.json()
    except ValueError as e:
        raise AssertionError(
            f"Retrieving pet after upload returned non-JSON response: {followup_response.text}"
        ) from e

    if not isinstance(followup_json, dict):
        raise AssertionError(f"Expected JSON object for follow-up pet, got: {followup_json!r}")

    context.followup_response = followup_json


@then("the follow-up output should have the same pet status as the seed output for MR23, since uploading an image does not modify the pet's status in the store.")
def step_mr_MR23_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Context is missing 'seed_response' from Given step")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Context is missing 'followup_response' from When step")

    seed = context.seed_response
    followup = context.followup_response

    if not isinstance(seed, dict):
        raise AssertionError(f"'seed_response' must be a dict, got: {type(seed).__name__}")
    if not isinstance(followup, dict):
        raise AssertionError(f"'followup_response' must be a dict, got: {type(followup).__name__}")

    seed_status = seed.get("status")
    followup_status = followup.get("status")

    if seed_status is None:
        raise AssertionError(f"'status' missing in seed_response: {json.dumps(seed, indent=2)}")
    if followup_status is None:
        raise AssertionError(f"'status' missing in followup_response: {json.dumps(followup, indent=2)}")

    assert followup_status == seed_status, (
        f"Expected status {seed_status!r} but got {followup_status!r}"
    )

# ----

import time
from typing import Any, Dict, List



@given('a seed input that retrieves the list of pets filtered by a specific status, producing a seed output with the list and its count for that status for MR24.')
def _mr_MR24_seed_input(context) -> None:
    status = 'available'
    context.seed_status = status
    context.seed_request = {'status': status}

    response = requests.get(f"{BASE_URL}/pet/findByStatus", params=context.seed_request, timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as exc:
        raise AssertionError(f"Response from /pet/findByStatus is not valid JSON: {response.text}") from exc

    if not isinstance(data, list):
        raise AssertionError(f"Expected list from /pet/findByStatus, got {type(data).__name__}")

    context.seed_response = data
    context.seed_count = len(data)


@when('a follow-up input is created by adding a new pet with the same status and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR24.')
def _mr_MR24_followup_input(context) -> None:
    status = getattr(context, "seed_status", "available")

    new_pet: Dict[str, Any] = {
        "name": "New Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": status,
    }

    add_response = requests.post(f"{BASE_URL}/pet", json=new_pet, timeout=10)
    add_response.raise_for_status()

    # Optional small delay to allow the system to persist the new pet, if needed
    time.sleep(0.1)

    followup_response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params={'status': status},
        timeout=10,
    )
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except ValueError as exc:
        raise AssertionError(f"Response from /pet/findByStatus (follow-up) is not valid JSON: {followup_response.text}") from exc

    if not isinstance(followup_data, list):
        raise AssertionError(f"Expected list from follow-up /pet/findByStatus, got {type(followup_data).__name__}")

    context.followup_response = followup_data
    context.followup_count = len(followup_data)


@then('the follow-up output should have a count of pets with that status that is one more than the count in the seed output for MR24, assuming no other changes to pets with that status occur between the two retrievals.')
def _mr_MR24_followup_assertion(context) -> None:
    seed_count = getattr(context, "seed_count", None)
    followup_count = getattr(context, "followup_count", None)

    if not isinstance(seed_count, int):
        raise AssertionError(f"seed_count is not an int or not set; got {repr(seed_count)}")
    if not isinstance(followup_count, int):
        raise AssertionError(f"followup_count is not an int or not set; got {repr(followup_count)}")

    expected = seed_count + 1
    assert followup_count == expected, (
        f"Expected follow-up count to be {expected}, but got {followup_count}."
    )
