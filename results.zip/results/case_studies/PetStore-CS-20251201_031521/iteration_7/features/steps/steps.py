from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that adds a new pet to the store, producing a seed output that includes the created pet with its identifier assigned by the system for MR30.')
def _mr_MR30_add_pet(context):
    context.seed_request = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }
    try:
        response = requests.post(f"{BASE_URL}/pet", json=context.seed_request, timeout=10)
        response.raise_for_status()
        try:
            context.seed_response = response.json()
        except ValueError as e:
            raise AssertionError(f"Seed response is not valid JSON for MR30: {e}")
        if not isinstance(context.seed_response, dict):
            raise AssertionError(f"Seed response is not a JSON object for MR30: {context.seed_response!r}")
        if "id" not in context.seed_response:
            raise AssertionError(f"Seed response does not contain 'id' field for MR30: {json.dumps(context.seed_response, indent=2)}")
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in GIVEN step for MR30: {e}")


@when('a follow-up input is created by retrieving the pet using the identifier returned in the seed output, yielding a follow-up output for MR30.')
def _mr_MR30_retrieve_pet(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response is missing in context for MR30 WHEN step")
    pet_id = context.seed_response.get("id")
    if pet_id is None:
        raise AssertionError(f"'id' is missing in seed_response for MR30: {json.dumps(context.seed_response, indent=2)}")
    try:
        response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        response.raise_for_status()
        try:
            context.followup_response = response.json()
        except ValueError as e:
            raise AssertionError(f"Follow-up response is not valid JSON for MR30: {e}")
        if not isinstance(context.followup_response, dict):
            raise AssertionError(f"Follow-up response is not a JSON object for MR30: {context.followup_response!r}")
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in WHEN step for MR30: {e}")


@then('the follow-up output should contain the pet details matching the seed output, confirming that the pet is retrievable by its identifier for MR30.')
def _mr_MR30_verify_pet(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response is missing in context for MR30 THEN step")
    if not hasattr(context, "followup_response"):
        raise AssertionError("followup_response is missing in context for MR30 THEN step")

    seed = context.seed_response
    followup = context.followup_response

    seed_id = seed.get("id")
    followup_id = followup.get("id")
    if seed_id is None or followup_id is None:
        raise AssertionError(
            f"Missing 'id' in responses for MR30.\nSeed: {json.dumps(seed, indent=2)}\nFollow-up: {json.dumps(followup, indent=2)}"
        )
    assert followup_id == seed_id, f"Pet ID does not match for MR30: seed={seed_id}, follow-up={followup_id}"

    for field in ("name", "status", "photoUrls"):
        seed_val = seed.get(field)
        followup_val = followup.get(field)
        assert followup_val == seed_val, (
            f"Pet field '{field}' does not match for MR30:\n"
            f"  seed: {json.dumps(seed_val, indent=2)}\n"
            f"  follow-up: {json.dumps(followup_val, indent=2)}"
        )

# ----

import time



@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details including its name for MR31.")
def _mr_MR31_seed_input(context):
    try:
        pet_data = {
            "name": "doggie",
            "photoUrls": ["url1", "url2"],
            "status": "available"
        }
        response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        response.raise_for_status()

        try:
            seed_response = response.json()
        except ValueError:
            raise RuntimeError("Seed response is not valid JSON")

        if not isinstance(seed_response, dict):
            raise RuntimeError("Seed response JSON is not an object")

        pet_id = seed_response.get("id")
        if pet_id is None:
            raise RuntimeError("Seed response does not contain 'id' field")

        context.seed_response = seed_response
        context.seed_request = pet_data
        context.pet_id = pet_id
    except Exception as e:
        print(f"Error in Given step for MR31: {e}")
        raise


@when("a follow-up input is created by updating the pet using a representation where only the name field is changed and all other fields are kept identical to the seed output, and then retrieving the pet again by the same identifier, yielding a follow-up output for MR31.")
def _mr_MR31_followup_input(context):
    try:
        if not hasattr(context, "seed_response") or not hasattr(context, "pet_id"):
            raise RuntimeError("Seed data is missing from context")

        seed_response = context.seed_response
        if not isinstance(seed_response, dict):
            raise RuntimeError("Seed response in context is not a dict")

        updated_pet_data = seed_response.copy()
        # Ensure required fields are present
        updated_pet_data["id"] = context.pet_id
        updated_pet_data["name"] = "doggie_updated"
        if "photoUrls" not in updated_pet_data or not isinstance(updated_pet_data["photoUrls"], list):
            updated_pet_data["photoUrls"] = context.seed_request.get("photoUrls", [])

        response = requests.put(f"{BASE_URL}/pet", json=updated_pet_data, timeout=10)
        response.raise_for_status()

        followup_response = requests.get(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
        followup_response.raise_for_status()

        try:
            followup_json = followup_response.json()
        except ValueError:
            raise RuntimeError("Follow-up response is not valid JSON")

        if not isinstance(followup_json, dict):
            raise RuntimeError("Follow-up response JSON is not an object")

        context.followup_response = followup_json
    except Exception as e:
        print(f"Error in When step for MR31: {e}")
        raise


@then("the follow-up output should reflect the updated name while all other pet details remain unchanged compared to the corresponding fields in the seed output for MR31.")
def _mr_MR31_followup_assertion(context):
    try:
        if not hasattr(context, "followup_response") or not hasattr(context, "seed_response"):
            raise RuntimeError("Required responses are missing from context")

        followup = context.followup_response
        seed = context.seed_response

        if not isinstance(followup, dict) or not isinstance(seed, dict):
            raise RuntimeError("Responses in context are not dictionaries")

        assert followup.get("name") == "doggie_updated", "Name was not updated correctly."

        seed_photo_urls = seed.get("photoUrls", [])
        followup_photo_urls = followup.get("photoUrls", [])
        assert followup_photo_urls == seed_photo_urls, "Photo URLs should remain unchanged."

        seed_status = seed.get("status")
        followup_status = followup.get("status")
        assert followup_status == seed_status, "Status should remain unchanged."
    except AssertionError as e:
        print(f"Assertion error in Then step for MR31: {e}")
        raise
    except Exception as e:
        print(f"Error in Then step for MR31: {e}")
        raise

# ----




@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's details for MR32.")
def step_mr_MR32_seed_input(context):
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    try:
        response_json = response.json()
    except ValueError:
        raise AssertionError(f"Failed to parse JSON from create-pet response, status={response.status_code}, text={response.text}")

    if response.status_code != 200:
        raise AssertionError(f"Failed to create pet: status={response.status_code}, body={response_json}")

    context.seed_request = response
    context.seed_response = response_json

    pet_id = context.seed_response.get("id")
    if pet_id is None:
        raise AssertionError(f"Create-pet response does not contain 'id': {context.seed_response}")
    context.pet_id = pet_id


@when("a follow-up input is created by deleting the pet with the same identifier and then attempting to retrieve the pet again by that identifier, yielding a follow-up output for MR32.")
def step_mr_MR32_followup_input(context):
    pet_id = getattr(context, "pet_id", None)
    if pet_id is None:
        raise AssertionError("Pet ID is missing in context; Given step may have failed.")

    delete_response = requests.delete(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    # /pet/\{petId\} delete returns 200 on successful deletion per spec
    try:
        delete_body = delete_response.text
    except Exception:
        delete_body = "<unreadable body>"

    if delete_response.status_code != 200:
        # Do not try delete_response.json() here; it may not be JSON
        raise AssertionError(f"Failed to delete pet: status={delete_response.status_code}, body={delete_body}")

    followup_request = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    try:
        followup_json = followup_request.json()
    except ValueError:
        # For 404, server might not return JSON; keep raw text for diagnostics
        followup_json = followup_request.text

    context.followup_request = followup_request
    context.followup_response = followup_json


@then("the follow-up output should indicate that the pet is not found, differing from the seed output which contains the pet's details for MR32.")
def step_mr_MR32_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response missing from context; Given step may not have run correctly.")
    if not hasattr(context, "followup_request"):
        raise AssertionError("Follow-up request missing from context; When step may not have run correctly.")

    seed_id = context.seed_response.get("id")
    if seed_id is None:
        raise AssertionError(f"Seed output does not contain 'id': {context.seed_response}")

    if context.followup_request.status_code != 404:
        raise AssertionError(
            f"Expected 404 when retrieving deleted pet, got {context.followup_request.status_code}: "
            f"{context.followup_response}"
        )

    # Ensure that the follow-up output is different from the seed output
    seed_serialized = json.dumps(context.seed_response, sort_keys=True)
    followup_serialized = json.dumps(context.followup_response, sort_keys=True) if isinstance(context.followup_response, (dict, list)) else str(context.followup_response)
    if seed_serialized == followup_serialized:
        raise AssertionError(
            "Follow-up output should differ from seed output, but they are the same."
        )

# ----




@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR33.")
def step_mr_MR33_seed_input(context):
    try:
        pet_data = {
            "name": "doggie",
            "photoUrls": ["url1", "url2"],
            "status": "available"
        }
        response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
        response.raise_for_status()

        response_json = response.json()
        if not isinstance(response_json, dict):
            raise ValueError("Seed response is not a JSON object")

        pet_id = response_json.get("id")
        if pet_id is None:
            raise ValueError("Created pet response does not contain 'id'")

        # Ensure status is present in response; if not, fall back to request data
        seed_status = response_json.get("status", pet_data["status"])

        context.seed_request = pet_data
        context.seed_response = {
            "id": pet_id,
            "status": seed_status
        }
    except requests.RequestException as e:
        raise RuntimeError(f"HTTP error in Given step for MR33: {e}") from e
    except (TypeError, ValueError, KeyError) as e:
        raise RuntimeError(f"Data handling error in Given step for MR33: {e}") from e


@when("a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same identifier, yielding a follow-up output for MR33.")
def step_mr_MR33_followup_input(context):
    try:
        seed_response = getattr(context, "seed_response", None)
        if not isinstance(seed_response, dict):
            raise ValueError("seed_response is missing or not a dictionary")

        pet_id = seed_response.get("id")
        if pet_id is None:
            raise ValueError("seed_response does not contain 'id'")

        image_data = b"fake_image_data"

        upload_url = f"{BASE_URL}/pet/{pet_id}/uploadImage"
        upload_response = requests.post(upload_url, data=image_data, timeout=10)
        upload_response.raise_for_status()

        get_url = f"{BASE_URL}/pet/{pet_id}"
        followup_response = requests.get(get_url, timeout=10)
        followup_response.raise_for_status()

        followup_json = followup_response.json()
        if not isinstance(followup_json, dict):
            raise ValueError("Follow-up response is not a JSON object")

        followup_status = followup_json.get("status")
        if followup_status is None:
            raise ValueError("Follow-up response does not contain 'status'")

        context.followup_response = {
            "id": followup_json.get("id"),
            "status": followup_status
        }
    except requests.RequestException as e:
        raise RuntimeError(f"HTTP error in When step for MR33: {e}") from e
    except (TypeError, ValueError, KeyError) as e:
        raise RuntimeError(f"Data handling error in When step for MR33: {e}") from e


@then("the follow-up output should have the same pet status as the seed output for MR33, since uploading an image does not modify the pet's status in the store.")
def step_mr_MR33_followup_output(context):
    try:
        seed_response = getattr(context, "seed_response", None)
        followup_response = getattr(context, "followup_response", None)

        if not isinstance(seed_response, dict):
            raise ValueError("seed_response is missing or not a dictionary")
        if not isinstance(followup_response, dict):
            raise ValueError("followup_response is missing or not a dictionary")

        seed_status = seed_response.get("status")
        followup_status = followup_response.get("status")

        if seed_status is None:
            raise ValueError("seed_response does not contain 'status'")
        if followup_status is None:
            raise ValueError("followup_response does not contain 'status'")

        assert followup_status == seed_status, (
            f"Expected status {seed_status} but got {followup_status}"
        )
    except AssertionError:
        raise
    except (TypeError, ValueError, KeyError) as e:
        raise RuntimeError(f"Data handling error in Then step for MR33: {e}") from e

# ----




@given('a seed input that retrieves the list of pets filtered by a single allowed status value (available, pending, or sold), producing a seed output with the list and its count for that status for MR34.')
def _mr_MR34_seed_input(context):
    status = 'available'  # Using 'available' as the status for the seed input
    context.seed_request = {'status': status}

    response = requests.get(f"{BASE_URL}/pet/findByStatus", params=context.seed_request, timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Response from /pet/findByStatus is not valid JSON: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"Expected a list of pets from /pet/findByStatus, got {type(data).__name__}")

    context.seed_response = data
    context.seed_count = len(context.seed_response)


@when('a follow-up input is created by adding a new pet whose status field is set to that same status value and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR34.')
def _mr_MR34_followup_input(context):
    status = context.seed_request.get('status')
    if status not in ('available', 'pending', 'sold'):
        raise AssertionError(f"Seed status must be one of 'available', 'pending', or 'sold', got {status!r}")

    new_pet = {
        "name": "New Pet MR34",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": status
    }

    add_response = requests.post(f"{BASE_URL}/pet", json=new_pet, timeout=10)
    add_response.raise_for_status()

    try:
        _ = add_response.json()
    except ValueError:
        # The API spec says 200 returns a Pet object; if not JSON, fail clearly
        raise AssertionError("Response from POST /pet is not valid JSON")

    followup_response = requests.get(f"{BASE_URL}/pet/findByStatus", params=context.seed_request, timeout=10)
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Response from /pet/findByStatus (follow-up) is not valid JSON: {e}")

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"Expected a list of pets from follow-up /pet/findByStatus, got {type(followup_data).__name__}"
        )

    context.followup_response = followup_data
    context.followup_count = len(context.followup_response)


@then('the follow-up output should have a count of pets with that status that is one more than the count in the seed output for MR34, assuming no other changes to pets with that status occur between the two retrievals.')
def _mr_MR34_followup_output(context):
    if not isinstance(context.seed_count, int):
        raise AssertionError(f"seed_count should be int, got {type(context.seed_count).__name__}")
    if not isinstance(context.followup_count, int):
        raise AssertionError(f"followup_count should be int, got {type(context.followup_count).__name__}")

    expected = context.seed_count + 1
    actual = context.followup_count

    assert actual == expected, (
        f"Expected follow-up count to be {expected}, but got {actual}."
    )
