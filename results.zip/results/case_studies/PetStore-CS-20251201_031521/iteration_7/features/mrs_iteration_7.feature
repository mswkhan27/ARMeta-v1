Feature: Iteration 7 MRs

  Scenario: MR30 Adding a new pet and using its returned identifier should make it retrievable by that identifier
    Given a seed input that adds a new pet to the store, producing a seed output that includes the created pet with its identifier assigned by the system for MR30.
    When a follow-up input is created by retrieving the pet using the identifier returned in the seed output, yielding a follow-up output for MR30.
    Then the follow-up output should contain the pet details matching the seed output, confirming that the pet is retrievable by its identifier for MR30.

  Scenario: MR31 Updating a pet's name while keeping other fields the same in the request should reflect only the updated name
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details including its name for MR31.
    When a follow-up input is created by updating the pet using a representation where only the name field is changed and all other fields are kept identical to the seed output, and then retrieving the pet again by the same identifier, yielding a follow-up output for MR31.
    Then the follow-up output should reflect the updated name while all other pet details remain unchanged compared to the corresponding fields in the seed output for MR31.

  Scenario: MR32 Deleting a pet should make it inaccessible by its identifier
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's details for MR32.
    When a follow-up input is created by deleting the pet with the same identifier and then attempting to retrieve the pet again by that identifier, yielding a follow-up output for MR32.
    Then the follow-up output should indicate that the pet is not found, differing from the seed output which contains the pet's details for MR32.

  Scenario: MR33 Uploading an image should not affect the pet's status when retrieved
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR33.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by the same identifier, yielding a follow-up output for MR33.
    Then the follow-up output should have the same pet status as the seed output for MR33, since uploading an image does not modify the pet's status in the store.

  Scenario: MR34 Creating a pet with a specific status should increase the count of pets returned for that status
    Given a seed input that retrieves the list of pets filtered by a single allowed status value (available, pending, or sold), producing a seed output with the list and its count for that status for MR34.
    When a follow-up input is created by adding a new pet whose status field is set to that same status value and then retrieving the list of pets filtered by that status again, yielding a follow-up output for MR34.
    Then the follow-up output should have a count of pets with that status that is one more than the count in the seed output for MR34, assuming no other changes to pets with that status occur between the two retrievals.
