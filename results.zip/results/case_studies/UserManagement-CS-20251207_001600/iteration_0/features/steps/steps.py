from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


def _safe_get_user_list_count(payload):
    """
    Safely extract user list count from the /users GET response.
    According to the OpenAPI spec, /users GET returns UserListDTO:
      { "userList": [ UserDTO, ... ] }
    """
    if not isinstance(payload, dict):
        return 0
    user_list = payload.get('userList')
    if isinstance(user_list, list):
        return len(user_list)
    return 0


@given('a seed input that retrieves the list of users, producing a seed output with a count of users for MR1.')
def _mr_MR1_seed_input(context):
    response = requests.get(f"{BASE_URL}/users", timeout=10)
    response.raise_for_status()

    # Safely parse JSON
    try:
        payload = response.json()
    except ValueError:
        payload = {}

    context.seed_response = payload
    context.seed_request = response.request
    context.seed_user_count = _safe_get_user_list_count(payload)


@when('a follow-up input is created by first adding a new user using the user creation operation and then retrieving the list of users again, yielding a follow-up output for MR1.')
def _mr_MR1_followup_input(context):
    # According to OpenAPI, /users POST expects CreateOrUpdateUserDTO
    new_user_data = {
        "username": "new_user_mr1",
        "password": "password123",
        "name": "New",
        "surname": "User",
        "email": "newuser@example.com",
        "gender": "other",
        "enabled": True,
        "secured": False
    }

    # Create a new user
    create_response = requests.post(
        f"{BASE_URL}/users",
        json=new_user_data,
        timeout=10
    )
    create_response.raise_for_status()

    # Retrieve the updated list of users
    followup_response = requests.get(f"{BASE_URL}/users", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_payload = followup_response.json()
    except ValueError:
        followup_payload = {}

    context.followup_response = followup_payload
    context.followup_request = followup_response.request
    context.followup_user_count = _safe_get_user_list_count(followup_payload)


@then('the follow-up output should have a user list size that is exactly one more than the seed output for MR1, assuming the creation operation completed successfully.')
def _mr_MR1_followup_output(context):
    expected = context.seed_user_count + 1
    actual = context.followup_user_count
    assert actual == expected, (
        f"Expected user count to be {expected}, but got {actual}."
    )

# ----




def _safe_get_user_list():
    response = requests.get(f"{BASE_URL}/users", timeout=10)
    if response.status_code != 200:
        raise AssertionError(f"Failed to retrieve users: {response.status_code} {response.text}")
    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in user list response: {e}\nBody: {response.text}")
    if not isinstance(data, dict):
        raise AssertionError(f"User list response is not a JSON object: {data}")
    user_list = data.get('userList')
    if user_list is None:
        # treat missing list as empty but keep type safety
        user_list = []
    if not isinstance(user_list, list):
        raise AssertionError(f"'userList' is not a list: {type(user_list).__name__}")
    return response, data, user_list


def _safe_create_user():
    # Use only defined fields from CreateOrUpdateUserDTO to avoid server-side errors
    new_user = {
        "username": "testuser_mr2",
        "password": "password",
        "name": "Test",
        "surname": "User",
        "email": "testuser_mr2@example.com",
        "enabled": True
    }
    response = requests.post(f"{BASE_URL}/users", json=new_user, timeout=10)
    if response.status_code not in (200, 201):
        raise AssertionError(f"Failed to create user: {response.status_code} {response.text}")
    try:
        data = response.json()
    except ValueError:
        # creation may return empty body on 201, so just ignore JSON error
        data = None
    # If server returns a UserDTO, try to capture the id
    user_id = None
    if isinstance(data, dict):
        user_id = data.get("id")
    return response, user_id


def _safe_delete_user(user_id):
    # Path parameter {id} is integer (int64) per spec, ensure correct type
    try:
        int_id = int(user_id)
    except (TypeError, ValueError):
        raise AssertionError(f"User id is not a valid integer: {user_id}")
    response = requests.delete(f"{BASE_URL}/users/{int_id}", timeout=10)
    if response.status_code not in (200, 204):
        raise AssertionError(f"Failed to delete user {int_id}: {response.status_code} {response.text}")
    return response


@given('a seed input that retrieves the list of users, producing a seed output with a count of users for MR2.')
def step_mr_MR2_seed_input(context):
    response, data, user_list = _safe_get_user_list()
    context.seed_request = response
    context.seed_response = data
    context.user_count = len(user_list)


@when('a follow-up input is created by first deleting an existing user using the user deletion operation and then retrieving the list of users again, yielding a follow-up output for MR2.')
def step_mr_MR2_followup_input(context):
    # Ensure there is at least one user to delete
    _, _, user_list = _safe_get_user_list()

    if not user_list:
        # Create a user if none exists
        _, created_id = _safe_create_user()
        # Refresh the list after creation
        _, _, user_list = _safe_get_user_list()
        if not user_list and created_id is None:
            raise AssertionError("No users available to delete even after creation.")

    # Choose a user id safely
    first_user = user_list[0]
    if not isinstance(first_user, dict):
        raise AssertionError(f"User entry is not an object: {first_user}")
    user_id = first_user.get("id")
    if user_id is None:
        raise AssertionError(f"User entry does not contain 'id': {first_user}")

    _safe_delete_user(user_id)

    # Retrieve the user list again after deletion
    followup_response, followup_data, followup_user_list = _safe_get_user_list()
    context.followup_request = followup_response
    context.followup_response = followup_data
    context.followup_user_count = len(followup_user_list)


@then('the follow-up output should have a user list size that is exactly one less than the seed output for MR2, assuming the deletion operation completed successfully and the deleted user was present in the seed list.')
def step_mr_MR2_followup_output(context):
    if not hasattr(context, "user_count"):
        raise AssertionError("Seed user count is not available on context.")
    if not hasattr(context, "followup_user_count"):
        # Fallback if When step did not set it for some reason
        _, _, followup_user_list = _safe_get_user_list()
        context.followup_user_count = len(followup_user_list)

    expected = context.user_count - 1
    actual = context.followup_user_count
    assert actual == expected, f"Expected user count to be {expected}, but got {actual}."

# ----




def _safe_get(d, key, default=None):
    if isinstance(d, dict):
        return d.get(key, default)
    return default


@given("a seed input that retrieves a user's details by ID, producing a seed output with user information for MR3.")
def step_mr_MR3_seed_input(context):
    # Create a user to ensure we have a valid ID to retrieve
    user_data = {
        "username": "testuser_mr3",
        "password": "password123",
        "email": "testuser_mr3@example.com",
        "name": "Test",
        "surname": "User",
        "gender": "male",
        "enabled": True,
        "secured": False
    }

    create_resp = requests.post(f"{BASE_URL}/users", json=user_data, timeout=10)
    create_resp.raise_for_status()

    created_user = create_resp.json()
    if not isinstance(created_user, dict):
        raise TypeError("Expected JSON object for created user")

    user_id = _safe_get(created_user, "id")
    if user_id is None:
        raise ValueError("Created user response does not contain 'id'")

    context.user_id = user_id

    # Retrieve the user details to set as seed output
    get_resp = requests.get(f"{BASE_URL}/users/{context.user_id}", timeout=10)
    get_resp.raise_for_status()

    seed_user = get_resp.json()
    if not isinstance(seed_user, dict):
        raise TypeError("Expected JSON object for seed user")

    context.seed_response = seed_user


@when("a follow-up input is created by updating the user's information using the user update operation, yielding a follow-up output for MR3.")
def step_mr_MR3_followup_input(context):
    if not hasattr(context, "user_id"):
        raise ValueError("user_id not set on context in When step")

    seed = getattr(context, "seed_response", None)
    if not isinstance(seed, dict):
        raise TypeError("seed_response must be a dict before update")

    # Build update payload by starting from existing values so we do not
    # trigger server-side validation issues due to missing required fields.
    update_payload = {
        "username": "updateduser_mr3",
        "email": "updateduser_mr3@example.com",
        "name": _safe_get(seed, "name"),
        "surname": _safe_get(seed, "surname"),
        "gender": _safe_get(seed, "gender"),
        "enabled": _safe_get(seed, "enabled"),
        "secured": _safe_get(seed, "secured"),
        "address": _safe_get(seed.get("addressDTO", {}), "address") if isinstance(seed.get("addressDTO"), dict) else None,
        "address2": _safe_get(seed.get("addressDTO", {}), "address2") if isinstance(seed.get("addressDTO"), dict) else None,
        "city": _safe_get(seed.get("addressDTO", {}), "city") if isinstance(seed.get("addressDTO"), dict) else None,
        "country": _safe_get(seed.get("addressDTO", {}), "country") if isinstance(seed.get("addressDTO"), dict) else None,
        "zipCode": _safe_get(seed.get("addressDTO", {}), "zipCode") if isinstance(seed.get("addressDTO"), dict) else None,
        "contactNote": _safe_get(seed.get("contactDTO", {}), "contactNote") if isinstance(seed.get("contactDTO"), dict) else None,
        "phone": _safe_get(seed.get("contactDTO", {}), "phone") if isinstance(seed.get("contactDTO"), dict) else None,
        "skype": _safe_get(seed.get("contactDTO", {}), "skype") if isinstance(seed.get("contactDTO"), dict) else None,
        "facebook": _safe_get(seed.get("contactDTO", {}), "facebook") if isinstance(seed.get("contactDTO"), dict) else None,
        "linkedin": _safe_get(seed.get("contactDTO", {}), "linkedin") if isinstance(seed.get("contactDTO"), dict) else None,
        "website": _safe_get(seed.get("contactDTO", {}), "website") if isinstance(seed.get("contactDTO"), dict) else None,
        "note": _safe_get(seed, "note"),
        "birthDate": _safe_get(seed, "birthDate"),
        "password": None
    }

    # Remove None values to avoid sending explicit nulls if not desired
    safe_update_payload = {k: v for k, v in update_payload.items() if v is not None or k in ["username", "email"]}

    put_resp = requests.put(
        f"{BASE_URL}/users/{context.user_id}",
        json=safe_update_payload,
        timeout=10
    )
    put_resp.raise_for_status()

    followup_user = put_resp.json()
    if not isinstance(followup_user, dict):
        raise TypeError("Expected JSON object for updated user")

    context.followup_response = followup_user


@then("the follow-up output should differ from the seed output only in the fields that were updated for MR3 and in any system-managed metadata fields (such as timestamps or audit information) that are expected to change as a consequence of the update.")
def step_mr_MR3_followup_output(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise TypeError("seed_response and followup_response must be dicts")

    # Explicitly updated fields
    assert _safe_get(followup, "username") == "updateduser_mr3"
    assert _safe_get(followup, "username") != _safe_get(seed, "username")

    assert _safe_get(followup, "email") == "updateduser_mr3@example.com"
    # email may not exist in UserDTO, so only check inequality if seed had it
    if "email" in seed:
        assert _safe_get(followup, "email") != _safe_get(seed, "email")

    # Fields that should remain unchanged (core identity fields)
    assert _safe_get(followup, "id") == _safe_get(seed, "id")
    assert _safe_get(followup, "surname") == _safe_get(seed, "surname")
    assert _safe_get(followup, "gender") == _safe_get(seed, "gender")
    assert _safe_get(followup, "enabled") == _safe_get(seed, "enabled")

    # System-managed metadata: updatedDt may or may not be present
    seed_updated = _safe_get(seed, "updatedDt")
    follow_updated = _safe_get(followup, "updatedDt")

    if seed_updated is not None and follow_updated is not None:
        assert follow_updated != seed_updated  # expect metadata change

    # Ensure no unexpected changes for a selected set of other fields
    for field in ["name", "note", "secured", "birthDate", "username"  # username already validated
                  ]:
        if field in ["username"]:
            continue
        if field in seed:
            assert _safe_get(followup, field) == _safe_get(seed, field)

# ----




@given("a seed input that retrieves a role's details including its permissions, producing a seed output with a list of permissions for MR4.")
def _mr_MR4_seed_input(context):
    # Create a role first to ensure it exists
    role_data = {"role": "test_role_MR4"}
    try:
        response = requests.post(
            f"{BASE_URL}/users/rbac/roles",
            data=json.dumps(role_data),
            headers={"Content-Type": "application/json"},
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error while creating role: {e}")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"Failed to create role, status code: {response.status_code}, error: {e}")

    try:
        body = response.json() if response.content else {}
    except ValueError as e:
        raise AssertionError(f"Failed to parse JSON when creating role: {e}")

    if not isinstance(body, dict):
        raise AssertionError(f"Unexpected role creation response type: {type(body)}")

    role_id = body.get("id")
    if role_id is None:
        raise AssertionError("Role creation response does not contain 'id' field")
    context.role_id = role_id

    # Now retrieve the role details
    try:
        seed_request = requests.get(
            f"{BASE_URL}/users/rbac/roles/{context.role_id}",
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error while retrieving role: {e}")

    try:
        seed_request.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"Failed to retrieve role, status code: {seed_request.status_code}, error: {e}")

    try:
        seed_response = seed_request.json() if seed_request.content else {}
    except ValueError as e:
        raise AssertionError(f"Failed to parse JSON when retrieving role: {e}")

    if not isinstance(seed_response, dict):
        raise AssertionError(f"Unexpected role retrieval response type: {type(seed_response)}")

    permissions = seed_response.get("permissions", [])
    if permissions is None:
        permissions = []
    if not isinstance(permissions, list):
        raise AssertionError(f"'permissions' field is not a list: {type(permissions)}")

    context.seed_response = seed_response
    context.initial_permissions_count = len(permissions)


@when("a follow-up input is created by adding a permission to the role using the role-permission association creation operation, yielding a follow-up output for MR4.")
def _mr_MR4_followup_input(context):
    # Create a permission to add
    permission_data = {"permission": "test_permission_MR4", "enabled": True}
    try:
        permission_response = requests.post(
            f"{BASE_URL}/users/rbac/permissions",
            data=json.dumps(permission_data),
            headers={"Content-Type": "application/json"},
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error while creating permission: {e}")

    try:
        permission_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"Failed to create permission, status code: {permission_response.status_code}, error: {e}"
        )

    try:
        permission_body = permission_response.json() if permission_response.content else {}
    except ValueError as e:
        raise AssertionError(f"Failed to parse JSON when creating permission: {e}")

    if not isinstance(permission_body, dict):
        raise AssertionError(f"Unexpected permission creation response type: {type(permission_body)}")

    permission_key = permission_body.get("permission")
    if not permission_key:
        raise AssertionError("Permission creation response does not contain 'permission' field or it is empty")

    context.permission_key = permission_key

    # Add the permission to the role using the role-permission association creation operation
    try:
        followup_request = requests.post(
            f"{BASE_URL}/users/rbac/roles/{context.role_id}/permissions/{context.permission_key}",
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error while adding permission to role: {e}")

    try:
        followup_request.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"Failed to add permission to role, status code: {followup_request.status_code}, error: {e}"
        )

    try:
        followup_response = followup_request.json() if followup_request.content else {}
    except ValueError as e:
        raise AssertionError(f"Failed to parse JSON when adding permission to role: {e}")

    if not isinstance(followup_response, dict):
        raise AssertionError(f"Unexpected follow-up response type: {type(followup_response)}")

    context.followup_response = followup_response


@then("the follow-up output should have a permission list size that is exactly one more than the seed output for MR4, assuming the added permission was not already present on the role.")
def _mr_MR4_followup_output(context):
    followup_body = getattr(context, "followup_response", None)
    if not isinstance(followup_body, dict):
        raise AssertionError(f"Missing or invalid follow-up response on context: {type(followup_body)}")

    permissions = followup_body.get("permissions", [])
    if permissions is None:
        permissions = []
    if not isinstance(permissions, list):
        raise AssertionError(f"'permissions' field in follow-up response is not a list: {type(permissions)}")

    updated_permissions_count = len(permissions)

    initial_count = getattr(context, "initial_permissions_count", None)
    if not isinstance(initial_count, int):
        raise AssertionError(
            f"Initial permissions count is missing or not an int: {initial_count} (type={type(initial_count)})"
        )

    expected_count = initial_count + 1
    assert (
        updated_permissions_count == expected_count
    ), f"Expected {expected_count} permissions, but got {updated_permissions_count}."

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


@given("a seed input that retrieves a role's details including its permissions, producing a seed output with a list of permissions for MR5.")
def step_mr_MR5_seed_input(context):
    # Create a role to ensure it exists (role body must be a string per OpenAPI)
    try:
        role_body = "test_role"
        role_create_resp = requests.post(
            f"{BASE_URL}/users/rbac/roles",
            json=role_body,
            timeout=10,
        )
    except Exception as e:
        raise RuntimeError(f"Request to create role failed: {e}")

    if role_create_resp is None:
        raise RuntimeError("No response received when creating role.")
    try:
        role_create_resp.raise_for_status()
    except Exception as e:
        raise RuntimeError(f"Creating role failed with status {role_create_resp.status_code}: {e}")

    try:
        role_json = role_create_resp.json()
    except ValueError as e:
        raise RuntimeError(f"Failed to decode role creation response as JSON: {e}")

    if not isinstance(role_json, dict):
        raise TypeError(f"Expected role creation response JSON to be an object, got {type(role_json)}")

    role_id = role_json.get("id")
    if role_id is None:
        raise RuntimeError("Created role response does not contain 'id'.")
    try:
        context.role_id = int(role_id)
    except (TypeError, ValueError) as e:
        raise RuntimeError(f"Role 'id' is not a valid integer: {e}")

    # Retrieve the role's details
    try:
        seed_req = requests.get(
            f"{BASE_URL}/users/rbac/roles/{context.role_id}",
            timeout=10,
        )
    except Exception as e:
        raise RuntimeError(f"Request to get role details failed: {e}")

    if seed_req is None:
        raise RuntimeError("No response received when retrieving role details.")
    try:
        seed_req.raise_for_status()
    except Exception as e:
        raise RuntimeError(f"Retrieving role details failed with status {seed_req.status_code}: {e}")

    try:
        seed_json = seed_req.json()
    except ValueError as e:
        raise RuntimeError(f"Failed to decode role details response as JSON: {e}")

    if not isinstance(seed_json, dict):
        raise TypeError(f"Expected role details JSON to be an object, got {type(seed_json)}")

    permissions = seed_json.get("permissions", [])
    if permissions is None:
        permissions = []
    if not isinstance(permissions, list):
        raise TypeError(f"Expected 'permissions' to be a list, got {type(permissions)}")

    context.seed_response = seed_json
    context.seed_permissions = permissions


@when("a follow-up input is created by removing an existing permission from the role using the role-permission association removal operation, yielding a follow-up output for MR5.")
def step_mr_MR5_followup_input(context):
    if not hasattr(context, "role_id"):
        raise RuntimeError("Context is missing 'role_id'. Ensure the Given step ran successfully.")
    if not hasattr(context, "seed_permissions"):
        raise RuntimeError("Context is missing 'seed_permissions'. Ensure the Given step ran successfully.")

    if not context.seed_permissions:
        raise AssertionError("No permissions available to remove for MR5.")

    first_perm = context.seed_permissions[0]
    if not isinstance(first_perm, dict):
        raise TypeError(f"Expected permission item to be an object, got {type(first_perm)}")

    permission_key = first_perm.get("permission")
    if not permission_key:
        raise RuntimeError("Permission object does not contain a non-empty 'permission' key to remove.")

    # Remove the permission from the role
    try:
        delete_resp = requests.delete(
            f"{BASE_URL}/users/rbac/roles/{context.role_id}/permissions/{permission_key}",
            timeout=10,
        )
    except Exception as e:
        raise RuntimeError(f"Request to remove permission from role failed: {e}")

    if delete_resp is None:
        raise RuntimeError("No response received when removing permission from role.")
    try:
        delete_resp.raise_for_status()
    except Exception as e:
        raise RuntimeError(f"Removing permission from role failed with status {delete_resp.status_code}: {e}")

    # Retrieve the updated role details
    try:
        followup_req = requests.get(
            f"{BASE_URL}/users/rbac/roles/{context.role_id}",
            timeout=10,
        )
    except Exception as e:
        raise RuntimeError(f"Request to get updated role details failed: {e}")

    if followup_req is None:
        raise RuntimeError("No response received when retrieving updated role details.")
    try:
        followup_req.raise_for_status()
    except Exception as e:
        raise RuntimeError(f"Retrieving updated role details failed with status {followup_req.status_code}: {e}")

    context.followup_response = followup_req


@then("the follow-up output should have a permission list size that is exactly one less than the seed output for MR5, assuming the removed permission was present in the seed list.")
def step_mr_MR5_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise RuntimeError("Context is missing 'followup_response'. Ensure the When step ran successfully.")
    if not hasattr(context, "seed_permissions"):
        raise RuntimeError("Context is missing 'seed_permissions'. Ensure the Given step ran successfully.")

    resp = context.followup_response
    if resp is None:
        raise RuntimeError("Follow-up response is None.")

    try:
        followup_json = resp.json()
    except ValueError as e:
        raise RuntimeError(f"Failed to decode follow-up response as JSON: {e}")

    if not isinstance(followup_json, dict):
        raise TypeError(f"Expected follow-up JSON to be an object, got {type(followup_json)}")

    followup_permissions = followup_json.get("permissions", [])
    if followup_permissions is None:
        followup_permissions = []
    if not isinstance(followup_permissions, list):
        raise TypeError(f"Expected follow-up 'permissions' to be a list, got {type(followup_permissions)}")

    expected_size = len(context.seed_permissions) - 1
    actual_size = len(followup_permissions)
    if actual_size != expected_size:
        raise AssertionError(
            f"Expected {expected_size} permissions after removal, but got {actual_size}."
        )
