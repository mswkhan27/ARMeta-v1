
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new user should increase the user list size by one
    Given a seed input that retrieves the list of users, producing a seed output with a count of users for MR1.
    When a follow-up input is created by first adding a new user using the user creation operation and then retrieving the list of users again, yielding a follow-up output for MR1.
    Then the follow-up output should have a user list size that is exactly one more than the seed output for MR1, assuming the creation operation completed successfully.

  Scenario: MR2 Deleting a user should decrease the user list size by one
    Given a seed input that retrieves the list of users, producing a seed output with a count of users for MR2.
    When a follow-up input is created by first deleting an existing user using the user deletion operation and then retrieving the list of users again, yielding a follow-up output for MR2.
    Then the follow-up output should have a user list size that is exactly one less than the seed output for MR2, assuming the deletion operation completed successfully and the deleted user was present in the seed list.

  Scenario: MR3 Updating a user's information should only change the updated fields and related metadata
    Given a seed input that retrieves a user's details by ID, producing a seed output with user information for MR3.
    When a follow-up input is created by updating the user's information using the user update operation, yielding a follow-up output for MR3.
    Then the follow-up output should differ from the seed output only in the fields that were updated for MR3 and in any system-managed metadata fields (such as timestamps or audit information) that are expected to change as a consequence of the update.

  Scenario: MR4 Adding a permission to a role should increase the role's permission list by one
    Given a seed input that retrieves a role's details including its permissions, producing a seed output with a list of permissions for MR4.
    When a follow-up input is created by adding a permission to the role using the role-permission association creation operation, yielding a follow-up output for MR4.
    Then the follow-up output should have a permission list size that is exactly one more than the seed output for MR4, assuming the added permission was not already present on the role.

  Scenario: MR5 Removing a permission from a role should decrease the role's permission list by one
    Given a seed input that retrieves a role's details including its permissions, producing a seed output with a list of permissions for MR5.
    When a follow-up input is created by removing an existing permission from the role using the role-permission association removal operation, yielding a follow-up output for MR5.
    Then the follow-up output should have a permission list size that is exactly one less than the seed output for MR5, assuming the removed permission was present in the seed list.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR6 Retrieving permissions should return the same list if no changes are made
    Given a seed input that invokes the operation to retrieve the list of permissions, producing a seed output with a list of permissions for MR6.
    When a follow-up input is created by invoking the same permissions retrieval operation again without performing any permission or role creation, update, or deletion operations in between, yielding a follow-up output for MR6.
    Then the follow-up output should be identical to the seed output for MR6, assuming no permissions have been added, updated, or removed in the system between the two retrievals.

  Scenario: MR7 Adding a role should increase the role list size by one
    Given a seed input that invokes the operation to retrieve the list of roles, producing a seed output with a count of roles for MR7.
    When a follow-up input is created by successfully adding a new role using the role creation operation and then invoking the role list retrieval operation again, yielding a follow-up output for MR7.
    Then the follow-up output should have a role list size that is exactly one more than the seed output for MR7, assuming the role creation completed successfully and no other role additions or deletions occurred between the two retrievals.

  Scenario: MR8 Deleting a role should decrease the role list size by one
    Given a seed input that invokes the operation to retrieve the list of roles, producing a seed output with a count of roles for MR8.
    When a follow-up input is created by successfully deleting an existing role using the role deletion operation and then invoking the role list retrieval operation again, yielding a follow-up output for MR8.
    Then the follow-up output should have a role list size that is exactly one less than the seed output for MR8, assuming the deletion operation completed successfully, the deleted role was present in the seed list, and no other role additions or deletions occurred between the two retrievals.

  Scenario: MR9 Updating a role's permissions should only change the updated permissions
    Given a seed input that invokes the operation to retrieve a role's details, including its permissions, producing a seed output with that role's permissions for MR9.
    When a follow-up input is created by modifying the role's permissions using the operations that add or remove a specific permission from the role, and then retrieving the same role's details again, yielding a follow-up output for MR9.
    Then the follow-up output should differ from the seed output only in the role's permissions that were added or removed for MR9, while the other attributes of the role remain unchanged.

  Scenario: MR10 Generating a salt should produce a unique value each time
    Given a seed input that invokes the salt generation operation, producing a seed output with a salt value for MR10.
    When a follow-up input is created by invoking the salt generation operation again, yielding a follow-up output for MR10.
    Then the follow-up output should be different from the seed output for MR10, reflecting that each salt generation call is expected to return a new salt string under normal operation.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR11 Deleting a permission should decrease the permission list size by one
    Given a seed input that retrieves the list of permissions, producing a seed output with a count of permissions for MR11.
    When a follow-up input is created by successfully deleting an existing permission using the permission deletion operation and then retrieving the list of permissions again, yielding a follow-up output for MR11.
    Then the follow-up output should have a permission list size that is exactly one less than the seed output for MR11, assuming the deletion operation completed successfully and the deleted permission was present in the seed list and no other permission changes occurred between the two retrievals.

  Scenario: MR12 Deleting a role should decrease the role list size by one
    Given a seed input that retrieves the list of roles, producing a seed output with a count of roles for MR12.
    When a follow-up input is created by successfully deleting an existing role using the role deletion operation and then retrieving the list of roles again, yielding a follow-up output for MR12.
    Then the follow-up output should have a role list size that is exactly one less than the seed output for MR12, assuming the deletion operation completed successfully and the deleted role was present in the seed list and no other role changes occurred between the two retrievals.

  Scenario: MR14 Logging in with the same credentials should return consistent core user details
    Given a seed input that invokes the login operation with valid credentials, producing a seed output with user details for MR14.
    When a follow-up input is created by invoking the login operation again with the same credentials, yielding a follow-up output for MR14.
    Then the follow-up output should contain the same stable user attributes (such as id, username, name, surname, enabled, secured, roles, and permissions) as the seed output for MR14, while time-related fields (such as login timestamps) may differ, assuming the underlying user record has not been modified between the two logins.

  Scenario: MR15 Registering a new user should increase the user list size by one
    Given a seed input that retrieves the list of users, producing a seed output with a count of users for MR15.
    When a follow-up input is created by successfully registering a new user using the user registration operation and then retrieving the list of users again, yielding a follow-up output for MR15.
    Then the follow-up output should have a user list size that is exactly one more than the seed output for MR15, assuming the registration operation completed successfully and no other user creations or deletions occurred between the two retrievals.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR17 Deleting a permission by key should decrease the permission list size by one
    Given a seed input that retrieves the current list of permissions, producing a seed output with a count of permissions for MR17.
    When a follow-up input is created by successfully deleting an existing permission using the permission-deletion operation and then retrieving the list of permissions again, yielding a follow-up output for MR17.
    Then the follow-up output should have a permission list size that is exactly one less than the seed output for MR17, assuming the deletion operation completed successfully and the deleted permission was present in the seed list.

  Scenario: MR18 Deleting a role by ID should decrease the role list size by one
    Given a seed input that retrieves the current list of roles, producing a seed output with a count of roles for MR18.
    When a follow-up input is created by successfully deleting an existing role using the role-deletion operation and then retrieving the list of roles again, yielding a follow-up output for MR18.
    Then the follow-up output should have a role list size that is exactly one less than the seed output for MR18, assuming the deletion operation completed successfully and the deleted role was present in the seed list.

  Scenario: MR20 Adding a role to a user should update the user's role list
    Given a seed input that retrieves a user's details including their roles, producing a seed output with a list of roles for MR20.
    When a follow-up input is created by adding a role to the user using the role-assignment operation and then retrieving the user's details again, yielding a follow-up output for MR20.
    Then the follow-up output should have a role list that includes the newly added role, differing from the seed output for MR20.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR21 Deleting an error should be able to result in no content
    Given a seed input that retrieves the current error state, producing a seed output with error details for MR21.
    When a follow-up input is created by deleting the current error state using the delete operation for the error resource, yielding a follow-up output for MR21.
    Then the follow-up output may be a 'No Content' response, indicating the error state has been removed and its body is empty, differing from the seed output for MR21 that contained error details.

  Scenario: MR22 Retrieving a permission by key should return consistent details
    Given a seed input that retrieves a permission by its key, producing a seed output with permission details for MR22.
    When a follow-up input is created by retrieving the same permission by key again using the corresponding read operation on that permission resource, yielding a follow-up output for MR22.
    Then the follow-up output should be identical to the seed output for MR22, assuming no changes have been made to the permission in the system between the two retrievals.

  Scenario: MR23 Deleting a permission by key should be able to result in no content
    Given a seed input that retrieves a permission by its key, producing a seed output with permission details for MR23.
    When a follow-up input is created by deleting this permission using the corresponding delete operation on that permission resource, yielding a follow-up output for MR23.
    Then the follow-up output may be a 'No Content' response, indicating the permission has been successfully deleted and the response body is empty, differing from the seed output for MR23 that contained permission details.

  Scenario: MR24 Deleting a role by ID should be able to result in no content
    Given a seed input that retrieves a role by its ID, producing a seed output with role details for MR24.
    When a follow-up input is created by deleting this role using the corresponding delete operation on that role resource, yielding a follow-up output for MR24.
    Then the follow-up output may be a 'No Content' response, indicating the role has been successfully deleted and the response body is empty, differing from the seed output for MR24 that contained role details.

  Scenario: MR25 Updating a permission should only change the updated fields
    Given a seed input that retrieves a permission's details, producing a seed output with permission information for MR25.
    When a follow-up input is created by updating this permission using the corresponding update operation on the permission resource, yielding a follow-up output for MR25.
    Then the follow-up output should differ from the seed output only in the fields that were updated for MR25, while other attributes of the permission remain unchanged.

