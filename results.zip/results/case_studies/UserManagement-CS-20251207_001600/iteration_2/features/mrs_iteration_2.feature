Feature: Iteration 2 MRs

  Scenario: MR11 Deleting a permission should decrease the permission list size by one
    Given a seed input that retrieves the list of permissions, producing a seed output with a count of permissions for MR11.
    When a follow-up input is created by successfully deleting an existing permission using the permission deletion operation and then retrieving the list of permissions again, yielding a follow-up output for MR11.
    Then the follow-up output should have a permission list size that is exactly one less than the seed output for MR11, assuming the deletion operation completed successfully and the deleted permission was present in the seed list and no other permission changes occurred between the two retrievals.

  Scenario: MR12 Deleting a role should decrease the role list size by one
    Given a seed input that retrieves the list of roles, producing a seed output with a count of roles for MR12.
    When a follow-up input is created by successfully deleting an existing role using the role deletion operation and then retrieving the list of roles again, yielding a follow-up output for MR12.
    Then the follow-up output should have a role list size that is exactly one less than the seed output for MR12, assuming the deletion operation completed successfully and the deleted role was present in the seed list and no other role changes occurred between the two retrievals.

  Scenario: MR14 Logging in with the same credentials should return consistent core user details
    Given a seed input that invokes the login operation with valid credentials, producing a seed output with user details for MR14.
    When a follow-up input is created by invoking the login operation again with the same credentials, yielding a follow-up output for MR14.
    Then the follow-up output should contain the same stable user attributes (such as id, username, name, surname, enabled, secured, roles, and permissions) as the seed output for MR14, while time-related fields (such as login timestamps) may differ, assuming the underlying user record has not been modified between the two logins.

  Scenario: MR15 Registering a new user should increase the user list size by one
    Given a seed input that retrieves the list of users, producing a seed output with a count of users for MR15.
    When a follow-up input is created by successfully registering a new user using the user registration operation and then retrieving the list of users again, yielding a follow-up output for MR15.
    Then the follow-up output should have a user list size that is exactly one more than the seed output for MR15, assuming the registration operation completed successfully and no other user creations or deletions occurred between the two retrievals.
