from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the list of permissions, producing a seed output with a count of permissions for MR11.')
def _mr_MR11_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Response is not valid JSON: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"Expected permissions list (JSON array), got: {type(data).__name__}")

    context.seed_response = data
    context.seed_request = response.request
    context.seed_count = len(data)


@when('a follow-up input is created by successfully deleting an existing permission using the permission deletion operation and then retrieving the list of permissions again, yielding a follow-up output for MR11.')
def _mr_MR11_followup_input(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, list):
        raise AssertionError("Seed response is not available or not a list.")

    if not hasattr(context, "seed_count") or not isinstance(context.seed_count, int):
        raise AssertionError("Seed count is not available or not an integer.")

    if context.seed_count == 0:
        raise AssertionError("No permissions available to delete.")

    first_perm = context.seed_response[0]
    if not isinstance(first_perm, dict):
        raise AssertionError(f"Expected first permission to be an object, got: {type(first_perm).__name__}")

    permission_key = first_perm.get("permission")
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError(f"Permission key is missing or invalid in first permission object: {first_perm}")

    delete_url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"
    delete_response = requests.delete(delete_url, timeout=10)
    delete_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response is not valid JSON: {e}")

    if not isinstance(followup_data, list):
        raise AssertionError(f"Expected follow-up permissions list (JSON array), got: {type(followup_data).__name__}")

    context.followup_response = followup_data
    context.followup_count = len(followup_data)


@then('the follow-up output should have a permission list size that is exactly one less than the seed output for MR11, assuming the deletion operation completed successfully and the deleted permission was present in the seed list and no other permission changes occurred between the two retrievals.')
def _mr_MR11_followup_output(context):
    if not hasattr(context, "seed_count") or not isinstance(context.seed_count, int):
        raise AssertionError("Seed count is not available or not an integer.")

    if not hasattr(context, "followup_count") or not isinstance(context.followup_count, int):
        raise AssertionError("Follow-up count is not available or not an integer.")

    expected_count = context.seed_count - 1
    actual_count = context.followup_count

    assert actual_count == expected_count, (
        f"Expected follow-up count to be {expected_count}, but got {actual_count}."
    )

# ----




@given('a seed input that retrieves the list of roles, producing a seed output with a count of roles for MR12.')
def _mr_MR12_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    response.raise_for_status()

    # Response schema: array of RoleDTO
    data = response.json()
    if not isinstance(data, list):
        raise TypeError(f"Expected list for roles, got {type(data).__name__}")

    context.seed_response = data
    context.seed_request = response.request
    context.seed_count = len(data)


@when('a follow-up input is created by successfully deleting an existing role using the role deletion operation and then retrieving the list of roles again, yielding a follow-up output for MR12.')
def _mr_MR12_followup_input(context):
    # Ensure there is at least one role to delete
    seed_roles = getattr(context, "seed_response", None)
    seed_count = getattr(context, "seed_count", None)

    if seed_roles is None or seed_count is None:
        raise ValueError("Seed roles or seed count not initialized in Given step.")

    role_id_to_delete = None

    if seed_count == 0:
        # Create a role to ensure we have something to delete
        # According to OpenAPI, POST /users/rbac/roles takes a string body "role"
        new_role_body = "TestRole"
        create_response = requests.post(
            f"{BASE_URL}/users/rbac/roles",
            data=json.dumps(new_role_body),
            headers={"Content-Type": "application/json"},
            timeout=10,
        )
        create_response.raise_for_status()
        created_role = create_response.json()
        if not isinstance(created_role, dict):
            raise TypeError(f"Expected created role to be dict, got {type(created_role).__name__}")
        role_id_to_delete = created_role.get("id")
        if role_id_to_delete is None:
            raise ValueError("Created role does not contain 'id' field.")
    else:
        first_role = seed_roles[0]
        if not isinstance(first_role, dict):
            raise TypeError(f"Expected role item to be dict, got {type(first_role).__name__}")
        role_id_to_delete = first_role.get("id")
        if role_id_to_delete is None:
            raise ValueError("Seed role does not contain 'id' field.")

    # Delete the role using DELETE /users/rbac/roles/{roleId}
    delete_response = requests.delete(
        f"{BASE_URL}/users/rbac/roles/{role_id_to_delete}",
        timeout=10,
    )
    delete_response.raise_for_status()

    # Retrieve the list of roles again
    followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    followup_response.raise_for_status()

    followup_data = followup_response.json()
    if not isinstance(followup_data, list):
        raise TypeError(f"Expected list for roles in follow-up, got {type(followup_data).__name__}")

    context.followup_response = followup_data
    context.followup_request = followup_response.request
    context.followup_count = len(followup_data)


@then('the follow-up output should have a role list size that is exactly one less than the seed output for MR12, assuming the deletion operation completed successfully and the deleted role was present in the seed list and no other role changes occurred between the two retrievals.')
def _mr_MR12_followup_assertion(context):
    if not hasattr(context, "followup_count") or not hasattr(context, "seed_count"):
        raise ValueError("Counts not available on context for MR12 assertion.")
    assert context.followup_count == context.seed_count - 1, (
        f"Expected follow-up count to be {context.seed_count - 1}, "
        f"but got {context.followup_count}."
    )

# ----




@given('a seed input that invokes the login operation with valid credentials, producing a seed output with user details for MR14.')
def step_mr_MR14_seed_input(context):
    login_request = {
        "username": "testuser",
        "password": "testpassword"
    }
    context.seed_request = login_request

    response = requests.post(f"{BASE_URL}/login", json=login_request, timeout=10)
    response.raise_for_status()

    try:
        context.seed_response = response.json()
    except ValueError:
        raise AssertionError("Seed login response is not valid JSON")


@when('a follow-up input is created by invoking the login operation again with the same credentials, yielding a follow-up output for MR14.')
def step_mr_MR14_followup_input(context):
    if not hasattr(context, "seed_request") or not isinstance(context.seed_request, dict):
        raise AssertionError("Seed request is missing or invalid in context")

    response = requests.post(f"{BASE_URL}/login", json=context.seed_request, timeout=10)
    response.raise_for_status()

    try:
        context.followup_response = response.json()
    except ValueError:
        raise AssertionError("Follow-up login response is not valid JSON")


@then('the follow-up output should contain the same stable user attributes (such as id, username, name, surname, enabled, secured, roles, and permissions) as the seed output for MR14, while time-related fields (such as login timestamps) may differ, assuming the underlying user record has not been modified between the two logins.')
def step_mr_MR14_assert_stable_attributes(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("Seed response is missing or invalid in context")
    if not hasattr(context, "followup_response") or not isinstance(context.followup_response, dict):
        raise AssertionError("Follow-up response is missing or invalid in context")

    seed = context.seed_response
    followup = context.followup_response

    stable_attributes = ['id', 'username', 'name', 'surname', 'enabled', 'secured', 'roles', 'permissions']

    for attr in stable_attributes:
        seed_value = seed.get(attr, None)
        follow_value = followup.get(attr, None)
        assert seed_value == follow_value, f"Attribute {attr} does not match: seed={seed_value}, follow-up={follow_value}"

    # Time-related fields may differ or may be absent; only assert they are not both present and identical if they exist.
    seed_login_dt = seed.get('loginDt')
    follow_login_dt = followup.get('loginDt')
    if seed_login_dt is not None and follow_login_dt is not None:
        assert seed_login_dt != follow_login_dt, "Login timestamps should differ when both are present"

# ----

import time



@given('a seed input that retrieves the list of users, producing a seed output with a count of users for MR15.')
def step_mr_MR15_seed_input(context):
    # Retrieve the initial list of users
    response = requests.get(f"{BASE_URL}/users", timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Seed /users response is not valid JSON: {e}")

    if not isinstance(data, dict):
        raise AssertionError(f"Seed /users response JSON is not an object: {data!r}")

    user_list = data.get('userList', [])
    if user_list is None:
        user_list = []
    if not isinstance(user_list, list):
        raise AssertionError(f"'userList' field is not a list in seed response: {type(user_list)}")

    context.seed_response = data
    context.seed_request = response.request
    context.user_count = len(user_list)


@when('a follow-up input is created by successfully registering a new user using the user registration operation and then retrieving the list of users again, yielding a follow-up output for MR15.')
def step_mr_MR15_followup_input(context):
    # Register a new user using the registration endpoint /users/register
    timestamp = int(time.time() * 1000)
    new_user_data = {
        "username": f"mr15_user_{timestamp}",
        "password": "password123",
        "name": "New",
        "surname": "User",
        "email": f"mr15_user_{timestamp}@example.com",
        "gender": "other"
    }

    register_response = requests.post(
        f"{BASE_URL}/users/register",
        json=new_user_data,
        timeout=10
    )
    register_response.raise_for_status()

    # Optional: validate registration response JSON shape
    try:
        _ = register_response.json()
    except ValueError as e:
        raise AssertionError(f"/users/register response is not valid JSON: {e}")

    # Retrieve the updated list of users from the same /users endpoint
    followup_response = requests.get(f"{BASE_URL}/users", timeout=10)
    followup_response.raise_for_status()

    try:
        data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up /users response is not valid JSON: {e}")

    if not isinstance(data, dict):
        raise AssertionError(f"Follow-up /users response JSON is not an object: {data!r}")

    context.followup_response = data
    context.followup_request = followup_response.request


@then('the follow-up output should have a user list size that is exactly one more than the seed output for MR15, assuming the registration operation completed successfully and no other user creations or deletions occurred between the two retrievals.')
def step_mr_MR15_followup_output(context):
    data = getattr(context, 'followup_response', None)
    if data is None:
        raise AssertionError("Follow-up response is missing on context.")

    if not isinstance(data, dict):
        raise AssertionError(f"Follow-up response JSON is not an object: {data!r}")

    user_list = data.get('userList', [])
    if user_list is None:
        user_list = []
    if not isinstance(user_list, list):
        raise AssertionError(f"'userList' field is not a list in follow-up response: {type(user_list)}")

    if not hasattr(context, 'user_count'):
        raise AssertionError("Seed user_count is not available on context.")

    followup_user_count = len(user_list)
    expected_count = context.user_count + 1

    if followup_user_count != expected_count:
        raise AssertionError(
            f"Expected user count to be {expected_count}, but got {followup_user_count}."
        )
