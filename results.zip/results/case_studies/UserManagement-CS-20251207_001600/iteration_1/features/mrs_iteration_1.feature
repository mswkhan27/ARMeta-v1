Feature: Iteration 1 MRs

  Scenario: MR6 Retrieving permissions should return the same list if no changes are made
    Given a seed input that invokes the operation to retrieve the list of permissions, producing a seed output with a list of permissions for MR6.
    When a follow-up input is created by invoking the same permissions retrieval operation again without performing any permission or role creation, update, or deletion operations in between, yielding a follow-up output for MR6.
    Then the follow-up output should be identical to the seed output for MR6, assuming no permissions have been added, updated, or removed in the system between the two retrievals.

  Scenario: MR7 Adding a role should increase the role list size by one
    Given a seed input that invokes the operation to retrieve the list of roles, producing a seed output with a count of roles for MR7.
    When a follow-up input is created by successfully adding a new role using the role creation operation and then invoking the role list retrieval operation again, yielding a follow-up output for MR7.
    Then the follow-up output should have a role list size that is exactly one more than the seed output for MR7, assuming the role creation completed successfully and no other role additions or deletions occurred between the two retrievals.

  Scenario: MR8 Deleting a role should decrease the role list size by one
    Given a seed input that invokes the operation to retrieve the list of roles, producing a seed output with a count of roles for MR8.
    When a follow-up input is created by successfully deleting an existing role using the role deletion operation and then invoking the role list retrieval operation again, yielding a follow-up output for MR8.
    Then the follow-up output should have a role list size that is exactly one less than the seed output for MR8, assuming the deletion operation completed successfully, the deleted role was present in the seed list, and no other role additions or deletions occurred between the two retrievals.

  Scenario: MR9 Updating a role's permissions should only change the updated permissions
    Given a seed input that invokes the operation to retrieve a role's details, including its permissions, producing a seed output with that role's permissions for MR9.
    When a follow-up input is created by modifying the role's permissions using the operations that add or remove a specific permission from the role, and then retrieving the same role's details again, yielding a follow-up output for MR9.
    Then the follow-up output should differ from the seed output only in the role's permissions that were added or removed for MR9, while the other attributes of the role remain unchanged.

  Scenario: MR10 Generating a salt should produce a unique value each time
    Given a seed input that invokes the salt generation operation, producing a seed output with a salt value for MR10.
    When a follow-up input is created by invoking the salt generation operation again, yielding a follow-up output for MR10.
    Then the follow-up output should be different from the seed output for MR10, reflecting that each salt generation call is expected to return a new salt string under normal operation.
