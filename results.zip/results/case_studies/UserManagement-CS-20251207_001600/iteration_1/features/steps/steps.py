from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that invokes the operation to retrieve the list of permissions, producing a seed output with a list of permissions for MR6.')
def _mr_MR6_seed_input(context):
    url = f"{BASE_URL}/users/rbac/permissions"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        try:
            context.seed_response = response.json()
        except ValueError:
            context.seed_response = response.text
        context.seed_request = {
            "method": response.request.method,
            "url": response.request.url,
            "headers": dict(response.request.headers),
        }
    except requests.RequestException as e:
        raise AssertionError(f"Error in Given step: MR6 while calling {url} - {e}") from e


@when('a follow-up input is created by invoking the same permissions retrieval operation again without performing any permission or role creation, update, or deletion operations in between, yielding a follow-up output for MR6.')
def _mr_MR6_followup_input(context):
    url = f"{BASE_URL}/users/rbac/permissions"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        try:
            context.followup_response = response.json()
        except ValueError:
            context.followup_response = response.text
        context.followup_request = {
            "method": response.request.method,
            "url": response.request.url,
            "headers": dict(response.request.headers),
        }
    except requests.RequestException as e:
        raise AssertionError(f"Error in When step: MR6 while calling {url} - {e}") from e


@then('the follow-up output should be identical to the seed output for MR6, assuming no permissions have been added, updated, or removed in the system between the two retrievals.')
def _mr_MR6_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is missing in context for MR6.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response is missing in context for MR6.")

    try:
        seed_serialized = json.dumps(context.seed_response, sort_keys=True)
    except (TypeError, ValueError):
        seed_serialized = str(context.seed_response)

    try:
        followup_serialized = json.dumps(context.followup_response, sort_keys=True)
    except (TypeError, ValueError):
        followup_serialized = str(context.followup_response)

    assert followup_serialized == seed_serialized, (
        "Follow-up output does not match seed output for MR6."
    )

# ----




@given('a seed input that invokes the operation to retrieve the list of roles, producing a seed output with a count of roles for MR7.')
def _mr_MR7_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    response.raise_for_status()

    # According to OpenAPI, this is an array of RoleDTO
    data = response.json()
    if not isinstance(data, list):
        raise TypeError(f"Expected list for role list, got {type(data).__name__}")

    context.seed_response = data
    context.seed_request = response.request
    context.seed_role_count = len(data)


@when('a follow-up input is created by successfully adding a new role using the role creation operation and then invoking the role list retrieval operation again, yielding a follow-up output for MR7.')
def _mr_MR7_followup_input(context):
    # OpenAPI: POST /users/rbac/roles with body: string "role"
    new_role = "NewRoleForMR7"

    headers = {"Content-Type": "application/json"}
    create_response = requests.post(
        f"{BASE_URL}/users/rbac/roles",
        data=json.dumps(new_role),
        headers=headers,
        timeout=10,
    )
    create_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    followup_response.raise_for_status()

    followup_data = followup_response.json()
    if not isinstance(followup_data, list):
        raise TypeError(f"Expected list for role list, got {type(followup_data).__name__}")

    context.followup_response = followup_data
    context.followup_request = followup_response.request
    context.followup_role_count = len(followup_data)


@then('the follow-up output should have a role list size that is exactly one more than the seed output for MR7, assuming the role creation completed successfully and no other role additions or deletions occurred between the two retrievals.')
def _mr_MR7_followup_assertion(context):
    expected_count = context.seed_role_count + 1
    actual_count = context.followup_role_count
    assert actual_count == expected_count, (
        f"Expected role count to be {expected_count}, but got {actual_count}."
    )

# ----

import time



@given('a seed input that invokes the operation to retrieve the list of roles, producing a seed output with a count of roles for MR8.')
def step_mr_MR8_seed_input(context):
    try:
        response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
        response.raise_for_status()
        data = response.json()

        if not isinstance(data, list):
            raise TypeError(f"Expected list for role list, got {type(data).__name__}")

        context.seed_response = data
        context.seed_request = response.request
        context.seed_count = len(data)
    except Exception as e:
        print(f"Error in Given step for MR8: {e}")
        raise


@when('a follow-up input is created by successfully deleting an existing role using the role deletion operation and then invoking the role list retrieval operation again, yielding a follow-up output for MR8.')
def step_mr_MR8_followup_input(context):
    try:
        if not hasattr(context, "seed_response"):
            raise AttributeError("seed_response is not available in context")

        if not isinstance(context.seed_response, list):
            raise TypeError(f"seed_response must be a list, got {type(context.seed_response).__name__}")

        if not context.seed_response:
            raise ValueError("No roles available to delete in seed_response")

        first_role = context.seed_response[0]
        if not isinstance(first_role, dict):
            raise TypeError(f"Expected role item to be dict, got {type(first_role).__name__}")

        role_id = first_role.get("id")
        if role_id is None:
            raise ValueError("Role item does not contain 'id' field")

        try:
            role_id_int = int(role_id)
        except (TypeError, ValueError):
            raise ValueError(f"Role id must be convertible to int, got {role_id!r}")

        delete_response = requests.delete(f"{BASE_URL}/users/rbac/roles/{role_id_int}", timeout=10)
        delete_response.raise_for_status()

        followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
        followup_response.raise_for_status()
        followup_data = followup_response.json()

        if not isinstance(followup_data, list):
            raise TypeError(f"Expected list for follow-up role list, got {type(followup_data).__name__}")

        context.followup_response = followup_data
        context.followup_request = followup_response.request
        context.followup_count = len(followup_data)
    except Exception as e:
        print(f"Error in When step for MR8: {e}")
        raise


@then('the follow-up output should have a role list size that is exactly one less than the seed output for MR8, assuming the deletion operation completed successfully, the deleted role was present in the seed list, and no other role additions or deletions occurred between the two retrievals.')
def step_mr_MR8_followup_output(context):
    try:
        if not hasattr(context, "seed_count"):
            raise AttributeError("seed_count is not available in context")
        if not hasattr(context, "followup_count"):
            raise AttributeError("followup_count is not available in context")

        if not isinstance(context.seed_count, int):
            raise TypeError(f"seed_count must be int, got {type(context.seed_count).__name__}")
        if not isinstance(context.followup_count, int):
            raise TypeError(f"followup_count must be int, got {type(context.followup_count).__name__}")

        expected = context.seed_count - 1
        assert context.followup_count == expected, (
            f"Expected follow-up count to be {expected}, but got {context.followup_count}."
        )
    except AssertionError as e:
        print(f"Assertion error in Then step for MR8: {e}")
        raise
    except Exception as e:
        print(f"Error in Then step for MR8: {e}")
        raise

# ----




@given("a seed input that invokes the operation to retrieve a role's details, including its permissions, producing a seed output with that role's permissions for MR9.")
def _mr_MR9_seed_input(context):
    # Create a role to ensure it exists
    role_data = "test_role"
    response = requests.post(
        f"{BASE_URL}/users/rbac/roles",
        json=role_data,
        timeout=10,
    )
    response.raise_for_status()

    role_json = response.json()
    if not isinstance(role_json, dict):
        raise TypeError(f"Expected role response to be a dict, got {type(role_json)}")

    role_id = role_json.get("id")
    if role_id is None:
        raise ValueError("Role ID is missing in role creation response")

    # Retrieve the role's details
    role_details_response = requests.get(
        f"{BASE_URL}/users/rbac/roles/{role_id}",
        timeout=10,
    )
    role_details_response.raise_for_status()

    role_details_json = role_details_response.json()
    if not isinstance(role_details_json, dict):
        raise TypeError(f"Expected role details response to be a dict, got {type(role_details_json)}")

    context.role_id = role_id
    context.seed_response = role_details_json


@when("a follow-up input is created by modifying the role's permissions using the operations that add or remove a specific permission from the role, and then retrieving the same role's details again, yielding a follow-up output for MR9.")
def _mr_MR9_followup_input(context):
    if not hasattr(context, "role_id"):
        raise AttributeError("role_id is not set in context from the Given step")

    role_id = context.role_id

    # Create a permission first, as the API expects an existing permissionKey
    permission_payload = {
        "permission": "test_permission_MR9",
        "note": "permission for MR9",
        "enabled": True,
    }
    perm_create_response = requests.post(
        f"{BASE_URL}/users/rbac/permissions",
        json=permission_payload,
        timeout=10,
    )
    perm_create_response.raise_for_status()

    perm_json = perm_create_response.json()
    if not isinstance(perm_json, dict):
        raise TypeError(f"Expected permission response to be a dict, got {type(perm_json)}")

    permission_key = perm_json.get("permission")
    if not permission_key:
        raise ValueError("Permission key is missing in permission creation response")

    context.permission_key = permission_key

    # Add the created permission to the role (no body defined in OpenAPI, so no json param)
    add_perm_response = requests.post(
        f"{BASE_URL}/users/rbac/roles/{role_id}/permissions/{permission_key}",
        timeout=10,
    )
    add_perm_response.raise_for_status()

    # Retrieve the role's details again
    followup_response = requests.get(
        f"{BASE_URL}/users/rbac/roles/{role_id}",
        timeout=10,
    )
    followup_response.raise_for_status()

    followup_json = followup_response.json()
    if not isinstance(followup_json, dict):
        raise TypeError(f"Expected follow-up role response to be a dict, got {type(followup_json)}")

    context.followup_response = followup_json


@then("the follow-up output should differ from the seed output only in the role's permissions that were added or removed for MR9, while the other attributes of the role remain unchanged.")
def _mr_MR9_assertion(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AttributeError("Seed or follow-up response is missing from context")

    seed = context.seed_response
    followup = context.followup_response

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise TypeError("Seed and follow-up responses must both be dicts")

    # Check that non-permission attributes are unchanged
    for key in ("id", "role"):
        if key not in seed or key not in followup:
            raise KeyError(f"Key '{key}' missing in seed or follow-up response")
        assert seed[key] == followup[key], f"Field '{key}' changed between seed and follow-up"

    # Extract permissions as sets of permission strings, guarding against bad types
    def extract_permissions(role_obj):
        permissions_raw = role_obj.get("permissions") or []
        if not isinstance(permissions_raw, list):
            raise TypeError(f"'permissions' field must be a list, got {type(permissions_raw)}")
        result = set()
        for item in permissions_raw:
            if isinstance(item, dict):
                perm_value = item.get("permission")
                if isinstance(perm_value, str):
                    result.add(perm_value)
            elif isinstance(item, str):
                # If API ever returns plain strings, also support that safely
                result.add(item)
        return result

    seed_permissions = extract_permissions(seed)
    followup_permissions = extract_permissions(followup)

    expected_added = {getattr(context, "permission_key", "test_permission_MR9")}
    assert followup_permissions == seed_permissions.union(expected_added), (
        f"Permissions did not change as expected; "
        f"seed={seed_permissions}, followup={followup_permissions}, expected_added={expected_added}"
    )

# ----




@given('a seed input that invokes the salt generation operation, producing a seed output with a salt value for MR10.')
def step_mr_MR10_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/salt", timeout=10)
    response.raise_for_status()
    context.seed_response = response.text
    context.seed_request = None  # No request body for GET


@when('a follow-up input is created by invoking the salt generation operation again, yielding a follow-up output for MR10.')
def step_mr_MR10_followup_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/salt", timeout=10)
    response.raise_for_status()
    context.followup_response = response.text
    context.followup_request = None  # No request body for GET


@then('the follow-up output should be different from the seed output for MR10, reflecting that each salt generation call is expected to return a new salt string under normal operation.')
def step_mr_MR10_assert_different(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    if seed is None or followup is None:
        raise AssertionError("Seed or follow-up response is missing in context.")

    if not isinstance(seed, str) or not isinstance(followup, str):
        raise AssertionError("Seed or follow-up response is not a string as expected for salt values.")

    assert seed != followup, "The follow-up output is not different from the seed output."
