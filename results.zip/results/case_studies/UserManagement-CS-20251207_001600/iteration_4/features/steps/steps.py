from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given("a seed input that retrieves the current error state, producing a seed output with error details for MR21.")
def step_mr_MR21_seed_input(context):
    url = f"{BASE_URL}/error"
    try:
        response = requests.get(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to {url} failed in Given step for MR21: {e}") from e

    # /error returns 200 on success
    if response.status_code != 200:
        raise AssertionError(
            f"Expected status code 200 from GET /error, got {response.status_code}. "
            f"Response text: {response.text}"
        )

    # Safely parse JSON; /error may return non-JSON content
    try:
        seed_body = response.json()
    except ValueError:
        # If body is not JSON, store raw text instead to avoid TypeError later
        seed_body = {"raw_body": response.text}

    context.seed_response = seed_body
    context.seed_request = response.request


@when("a follow-up input is created by deleting the current error state using the delete operation for the error resource, yielding a follow-up output for MR21.")
def step_mr_MR21_followup_input(context):
    url = f"{BASE_URL}/error"
    try:
        response = requests.delete(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to {url} failed in When step for MR21: {e}") from e

    context.followup_response = response
    context.followup_request = response.request


@then("the follow-up output may be a 'No Content' response, indicating the error state has been removed and its body is empty, differing from the seed output for MR21 that contained error details.")
def step_mr_MR21_followup_output(context):
    response = getattr(context, "followup_response", None)
    if response is None:
        raise AssertionError("followup_response is not set in context.")

    # DELETE /error defines both 200 and 204 as possible success codes.
    # The MR focuses on the 'may be 204 No Content' behavior.
    if response.status_code != 204:
        raise AssertionError(
            f"Expected No Content (204) response from DELETE /error, got {response.status_code}. "
            f"Response text: {response.text}"
        )

    # For 204, response body should be empty (no JSON parsing to avoid ValueError)
    body_text = response.text.strip()
    if body_text:
        raise AssertionError(
            f"Expected empty body for 204 No Content, but received: {body_text}"
        )

    # Ensure the seed output contained some content (non-empty dict)
    seed = getattr(context, "seed_response", None)
    if seed is None:
        raise AssertionError("seed_response is not set in context.")

    if isinstance(seed, dict):
        if not seed:
            raise AssertionError("Seed output should contain error details, but dict is empty.")
    elif isinstance(seed, str):
        if not seed.strip():
            raise AssertionError("Seed output should contain error details, but string is empty.")
    else:
        # For any other type, just ensure it's not "empty" by Python truthiness
        if not seed:
            raise AssertionError("Seed output should contain error details, but is empty.")

# ----




@given('a seed input that retrieves a permission by its key, producing a seed output with permission details for MR22.')
def step_mr_MR22_seed_input(context):
    # Create a permission first to ensure the key exists for retrieval
    permission_data = {
        "enabled": True,
        "note": "Test permission",
        "permission": "test_permission_mr22"
    }

    response = requests.post(
        f"{BASE_URL}/users/rbac/permissions",
        json=permission_data,
        timeout=10
    )

    # Ensure we got a successful response and valid JSON
    if response.status_code not in (200, 201):
        raise AssertionError(
            f"Failed to create permission for MR22, "
            f"status code: {response.status_code}, body: {response.text}"
        )

    try:
        seed_json = response.json()
    except ValueError as e:
        raise AssertionError(f"Response is not valid JSON for MR22 seed step: {e}")

    # Safely extract the permission key
    permission_key = seed_json.get("permission")
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError(
            f"Missing or invalid 'permission' field in seed response for MR22: {json.dumps(seed_json)}"
        )

    context.seed_response = seed_json
    context.permission_key = permission_key


@when('a follow-up input is created by retrieving the same permission by key again using the corresponding read operation on that permission resource, yielding a follow-up output for MR22.')
def step_mr_MR22_followup_input(context):
    # Ensure the Given step has set the necessary attributes
    if not hasattr(context, "permission_key"):
        raise AssertionError("permission_key is not set in context for MR22 follow-up step")

    permission_key = context.permission_key
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError(f"Invalid permission_key in context for MR22: {permission_key!r}")

    response = requests.get(
        f"{BASE_URL}/users/rbac/permissions/{permission_key}",
        timeout=10
    )

    if response.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve permission by key for MR22, "
            f"status code: {response.status_code}, body: {response.text}"
        )

    try:
        followup_json = response.json()
    except ValueError as e:
        raise AssertionError(f"Response is not valid JSON for MR22 follow-up step: {e}")

    context.followup_response = followup_json


@then('the follow-up output should be identical to the seed output for MR22, assuming no changes have been made to the permission in the system between the two retrievals.')
def step_mr_MR22_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response is not set in context for MR22 then step")
    if not hasattr(context, "followup_response"):
        raise AssertionError("followup_response is not set in context for MR22 then step")

    seed = context.seed_response
    followup = context.followup_response

    # Ensure both are dictionaries before comparison
    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise AssertionError(
            f"Seed or follow-up response is not a JSON object for MR22.\n"
            f"Seed type: {type(seed)}, value: {seed}\n"
            f"Follow-up type: {type(followup)}, value: {followup}"
        )

    assert seed == followup, (
        "Follow-up output does not match seed output for MR22.\n"
        f"Seed: {json.dumps(seed, sort_keys=True)}\n"
        f"Follow-up: {json.dumps(followup, sort_keys=True)}"
    )

# ----




@given('a seed input that retrieves a permission by its key, producing a seed output with permission details for MR23.')
def step_mr_MR23_seed_input(context):
    permission_key = "example_permission_key"  # Replace with actual, existing key if needed
    url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"
    try:
        response = requests.get(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to retrieve permission failed: {e}")

    context.seed_request = response
    # Safely parse JSON if possible; otherwise store None
    try:
        context.seed_response = response.json()
    except ValueError:
        context.seed_response = None

    assert response.status_code == 200, (
        f"Failed to retrieve permission, expected 200, got {response.status_code}. "
        f"Response text: {response.text}"
    )


@when('a follow-up input is created by deleting this permission using the corresponding delete operation on that permission resource, yielding a follow-up output for MR23.')
def step_mr_MR23_followup_input(context):
    # Ensure seed step has run
    assert hasattr(context, "seed_request"), "Seed request not found in context; Given step may not have executed."

    permission_key = "example_permission_key"  # Must correspond to the key used in the Given step
    url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"
    try:
        response = requests.delete(url, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Request to delete permission failed: {e}")

    context.followup_request = response
    context.followup_response = response

    assert response.status_code in (200, 204), (
        f"Failed to delete permission, expected 200 or 204, got {response.status_code}. "
        f"Response text: {response.text}"
    )


@then("the follow-up output may be a 'No Content' response, indicating the permission has been successfully deleted and the response body is empty, differing from the seed output for MR23 that contained permission details.")
def step_mr_MR23_followup_output(context):
    assert hasattr(context, "followup_response"), "Follow-up response not found in context; When step may not have executed."

    status_code = context.followup_response.status_code
    # For MR23 we specifically check the possibility of 204 No Content
    assert status_code == 204, f"Expected status code 204 (No Content), got {status_code}."

    # Verify that the body is empty (robustly)
    body_text = context.followup_response.text or ""
    assert body_text.strip() == "", (
        f"Expected empty response body for 204 No Content, but got: {body_text!r}"
    )

    # Optionally ensure the seed response contained details (if it was JSON)
    if getattr(context, "seed_response", None) is not None:
        assert context.seed_response != {}, "Seed response unexpectedly empty; MR23 requires permission details in seed output."

# ----




@given('a seed input that retrieves a role by its ID, producing a seed output with role details for MR24.')
def _mr_MR24_seed_input(context):
    # Create a role to ensure it exists (POST /users/rbac/roles)
    role_data = {"role": "TestRole"}
    response = requests.post(f"{BASE_URL}/users/rbac/roles", json=role_data, timeout=10)

    # Safely parse JSON and extract id
    try:
        response_json = response.json() if response.content else {}
    except ValueError:
        response_json = {}

    role_id = response_json.get('id')
    if not isinstance(role_id, int):
        raise AssertionError(f"Expected created role to have integer 'id', got: {role_id!r}")

    context.role_id = role_id

    # Retrieve the created role by ID (GET /users/rbac/roles/\{roleId\})
    seed_request = requests.get(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)

    # Ensure we received role details
    try:
        seed_response_json = seed_request.json() if seed_request.content else {}
    except ValueError:
        seed_response_json = {}

    if not isinstance(seed_response_json, dict) or seed_response_json.get('id') != context.role_id:
        raise AssertionError(
            f"Expected to retrieve role details for id {context.role_id}, "
            f"got status {seed_request.status_code} and body {seed_response_json!r}"
        )

    context.seed_request = seed_request
    context.seed_response = seed_response_json


@when('a follow-up input is created by deleting this role using the corresponding delete operation on that role resource, yielding a follow-up output for MR24.')
def _mr_MR24_followup_input(context):
    if not hasattr(context, 'role_id'):
        raise AssertionError("role_id not set in context; Given step may have failed.")

    # Delete the role by ID (DELETE /users/rbac/roles/\{roleId\})
    followup_request = requests.delete(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
    context.followup_request = followup_request
    context.followup_response = followup_request  # kept for compatibility


@then("the follow-up output may be a 'No Content' response, indicating the role has been successfully deleted and the response body is empty, differing from the seed output for MR24 that contained role details.")
def _mr_MR24_followup_output(context):
    if not hasattr(context, 'followup_response'):
        raise AssertionError("followup_response not set in context; When step may have failed.")
    if not hasattr(context, 'role_id'):
        raise AssertionError("role_id not set in context; Given step may have failed.")

    # The MR states the follow-up output may be a 'No Content' response.
    # Accept 204 as the primary expected outcome.
    status_code = context.followup_response.status_code
    assert status_code == 204, f"Expected status code 204 (No Content), got {status_code}"

    # Verify that the role no longer exists (GET /users/rbac/roles/\{roleId\} should return 404)
    verify_request = requests.get(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
    verify_status = verify_request.status_code

    # Do not parse JSON for 404 to avoid ValueError
    assert verify_status == 404, f"Expected status code 404 after deletion, got {verify_status}"

    context.verify_request = verify_request

# ----




@given("a seed input that retrieves a permission's details, producing a seed output with permission information for MR25.")
def step_mr_MR25_seed_input(context):
    # Create a permission to ensure it exists (POST /users/rbac/permissions)
    permission_data = {
        "enabled": True,
        "note": "Test permission",
        "permission": "test.permission"
    }

    response = requests.post(
        f"{BASE_URL}/users/rbac/permissions",
        json=permission_data,
        timeout=10
    )

    # Safely capture status and body
    context.seed_status_code = getattr(response, "status_code", None)
    try:
        context.seed_response = response.json()
    except (ValueError, TypeError):
        context.seed_response = {}

    assert context.seed_status_code == 200, (
        f"Failed to create permission, status={context.seed_status_code}, "
        f"body={getattr(response, 'text', '')}"
    )

    # Ensure required fields exist before proceeding
    assert isinstance(context.seed_response, dict), "Seed response is not a JSON object"
    for field in ["enabled", "note", "permission"]:
        assert field in context.seed_response, f"Seed response missing '{field}' field"


@when("a follow-up input is created by updating this permission using the corresponding update operation on the permission resource, yielding a follow-up output for MR25.")
def step_mr_MR25_followup_input(context):
    # Construct updated permission payload using existing values
    seed = getattr(context, "seed_response", {}) or {}

    updated_permission_data = {
        "enabled": not bool(seed.get("enabled", True)),  # Toggle enabled safely
        "note": seed.get("note", "Test permission"),
        "permission": seed.get("permission", "test.permission")
    }

    # Update the permission (PUT /users/rbac/permissions)
    response = requests.put(
        f"{BASE_URL}/users/rbac/permissions",
        json=updated_permission_data,
        timeout=10
    )

    context.followup_status_code = getattr(response, "status_code", None)
    try:
        context.followup_response = response.json()
    except (ValueError, TypeError):
        context.followup_response = {}

    assert context.followup_status_code == 200, (
        f"Failed to update permission, status={context.followup_status_code}, "
        f"body={getattr(response, 'text', '')}"
    )

    assert isinstance(context.followup_response, dict), "Follow-up response is not a JSON object"
    for field in ["enabled", "note", "permission"]:
        assert field in context.followup_response, f"Follow-up response missing '{field}' field"


@then("the follow-up output should differ from the seed output only in the fields that were updated for MR25, while other attributes of the permission remain unchanged.")
def step_mr_MR25_followup_output(context):
    seed = getattr(context, "seed_response", {}) or {}
    followup = getattr(context, "followup_response", {}) or {}

    # Ensure both responses have the required keys
    for field in ["enabled", "note", "permission"]:
        assert field in seed, f"Seed response missing '{field}' field"
        assert field in followup, f"Follow-up response missing '{field}' field"

    # MR25: enabled should change, note and permission should remain the same
    assert followup["enabled"] != seed["enabled"], "Enabled field should differ between seed and follow-up"
    assert followup["note"] == seed["note"], "Note field should remain unchanged between seed and follow-up"
    assert followup["permission"] == seed["permission"], "Permission field should remain unchanged between seed and follow-up"
