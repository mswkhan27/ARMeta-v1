Feature: Iteration 4 MRs

  Scenario: MR21 Deleting an error should be able to result in no content
    Given a seed input that retrieves the current error state, producing a seed output with error details for MR21.
    When a follow-up input is created by deleting the current error state using the delete operation for the error resource, yielding a follow-up output for MR21.
    Then the follow-up output may be a 'No Content' response, indicating the error state has been removed and its body is empty, differing from the seed output for MR21 that contained error details.

  Scenario: MR22 Retrieving a permission by key should return consistent details
    Given a seed input that retrieves a permission by its key, producing a seed output with permission details for MR22.
    When a follow-up input is created by retrieving the same permission by key again using the corresponding read operation on that permission resource, yielding a follow-up output for MR22.
    Then the follow-up output should be identical to the seed output for MR22, assuming no changes have been made to the permission in the system between the two retrievals.

  Scenario: MR23 Deleting a permission by key should be able to result in no content
    Given a seed input that retrieves a permission by its key, producing a seed output with permission details for MR23.
    When a follow-up input is created by deleting this permission using the corresponding delete operation on that permission resource, yielding a follow-up output for MR23.
    Then the follow-up output may be a 'No Content' response, indicating the permission has been successfully deleted and the response body is empty, differing from the seed output for MR23 that contained permission details.

  Scenario: MR24 Deleting a role by ID should be able to result in no content
    Given a seed input that retrieves a role by its ID, producing a seed output with role details for MR24.
    When a follow-up input is created by deleting this role using the corresponding delete operation on that role resource, yielding a follow-up output for MR24.
    Then the follow-up output may be a 'No Content' response, indicating the role has been successfully deleted and the response body is empty, differing from the seed output for MR24 that contained role details.

  Scenario: MR25 Updating a permission should only change the updated fields
    Given a seed input that retrieves a permission's details, producing a seed output with permission information for MR25.
    When a follow-up input is created by updating this permission using the corresponding update operation on the permission resource, yielding a follow-up output for MR25.
    Then the follow-up output should differ from the seed output only in the fields that were updated for MR25, while other attributes of the permission remain unchanged.
