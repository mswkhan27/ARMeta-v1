Feature: Iteration 3 MRs

  Scenario: MR17 Deleting a permission by key should decrease the permission list size by one
    Given a seed input that retrieves the current list of permissions, producing a seed output with a count of permissions for MR17.
    When a follow-up input is created by successfully deleting an existing permission using the permission-deletion operation and then retrieving the list of permissions again, yielding a follow-up output for MR17.
    Then the follow-up output should have a permission list size that is exactly one less than the seed output for MR17, assuming the deletion operation completed successfully and the deleted permission was present in the seed list.

  Scenario: MR18 Deleting a role by ID should decrease the role list size by one
    Given a seed input that retrieves the current list of roles, producing a seed output with a count of roles for MR18.
    When a follow-up input is created by successfully deleting an existing role using the role-deletion operation and then retrieving the list of roles again, yielding a follow-up output for MR18.
    Then the follow-up output should have a role list size that is exactly one less than the seed output for MR18, assuming the deletion operation completed successfully and the deleted role was present in the seed list.

  Scenario: MR20 Adding a role to a user should update the user's role list
    Given a seed input that retrieves a user's details including their roles, producing a seed output with a list of roles for MR20.
    When a follow-up input is created by adding a role to the user using the role-assignment operation and then retrieving the user's details again, yielding a follow-up output for MR20.
    Then the follow-up output should have a role list that includes the newly added role, differing from the seed output for MR20.
