from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the current list of permissions, producing a seed output with a count of permissions for MR17.')
def _mr_MR17_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Response from /users/rbac/permissions is not valid JSON: {e}")

    if not isinstance(data, list):
        raise AssertionError(
            f"Expected permissions endpoint to return a list, got {type(data).__name__}: {json.dumps(data, default=str)}"
        )

    context.seed_response = data
    context.seed_request = response.request
    context.seed_count = len(data)


@when('a follow-up input is created by successfully deleting an existing permission using the permission-deletion operation and then retrieving the list of permissions again, yielding a follow-up output for MR17.')
def _mr_MR17_followup_input(context):
    if not hasattr(context, 'seed_response'):
        raise AssertionError("seed_response is not available in context. Ensure the Given step executed successfully.")

    if not isinstance(context.seed_response, list):
        raise AssertionError(
            f"seed_response is not a list as expected, got {type(context.seed_response).__name__}"
        )

    if not context.seed_response:
        raise AssertionError("No permissions available to delete in seed_response; cannot perform MR17 deletion.")

    first_permission = context.seed_response[0]
    if not isinstance(first_permission, dict):
        raise AssertionError(
            f"Expected each permission to be a dict, got {type(first_permission).__name__}: {first_permission!r}"
        )

    permission_key = first_permission.get('permission')
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError(
            f"Permission object does not contain a valid 'permission' key: {json.dumps(first_permission, default=str)}"
        )

    delete_url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"
    delete_response = requests.delete(delete_url, timeout=10)
    delete_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response from /users/rbac/permissions is not valid JSON: {e}")

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"Expected follow-up permissions endpoint to return a list, got {type(followup_data).__name__}: "
            f"{json.dumps(followup_data, default=str)}"
        )

    context.followup_response = followup_data
    context.followup_count = len(followup_data)


@then('the follow-up output should have a permission list size that is exactly one less than the seed output for MR17, assuming the deletion operation completed successfully and the deleted permission was present in the seed list.')
def _mr_MR17_assert_followup_output(context):
    if not hasattr(context, 'seed_count'):
        raise AssertionError("seed_count is not available in context. Ensure the Given step executed successfully.")
    if not hasattr(context, 'followup_count'):
        raise AssertionError("followup_count is not available in context. Ensure the When step executed successfully.")

    if not isinstance(context.seed_count, int):
        raise AssertionError(f"seed_count is not an int, got {type(context.seed_count).__name__}")
    if not isinstance(context.followup_count, int):
        raise AssertionError(f"followup_count is not an int, got {type(context.followup_count).__name__}")

    expected = context.seed_count - 1
    actual = context.followup_count

    assert actual == expected, (
        f"Expected follow-up permission count to be {expected} after deletion, but got {actual}. "
        f"Seed list length was {context.seed_count}."
    )

# ----




@given('a seed input that retrieves the current list of roles, producing a seed output with a count of roles for MR18.')
def step_mr_MR18_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    response.raise_for_status()

    data = response.json()
    if not isinstance(data, list):
        raise TypeError(f"Expected list of roles, got {type(data).__name__}: {json.dumps(data, default=str)}")

    context.seed_roles = data
    context.seed_request = response.request
    context.seed_count = len(context.seed_roles)


@when('a follow-up input is created by successfully deleting an existing role using the role-deletion operation and then retrieving the list of roles again, yielding a follow-up output for MR18.')
def step_mr_MR18_followup_input(context):
    if not hasattr(context, "seed_roles") or not isinstance(context.seed_roles, list):
        raise AttributeError("seed_roles not found on context or not a list. Ensure Given step ran successfully.")

    if len(context.seed_roles) == 0:
        raise ValueError("No roles available to delete for MR18.")

    first_role = context.seed_roles[0]
    if not isinstance(first_role, dict) or "id" not in first_role:
        raise KeyError(f"Role object does not contain 'id' field: {json.dumps(first_role, default=str)}")

    role_id = first_role["id"]
    try:
        role_id_int = int(role_id)
    except (TypeError, ValueError):
        raise ValueError(f"Role id is not an integer-compatible value: {role_id}")

    delete_response = requests.delete(f"{BASE_URL}/users/rbac/roles/{role_id_int}", timeout=10)
    delete_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    followup_response.raise_for_status()

    followup_data = followup_response.json()
    if not isinstance(followup_data, list):
        raise TypeError(f"Expected list of roles in follow-up, got {type(followup_data).__name__}: {json.dumps(followup_data, default=str)}")

    context.followup_roles = followup_data
    context.followup_request = followup_response.request
    context.followup_count = len(context.followup_roles)


@then('the follow-up output should have a role list size that is exactly one less than the seed output for MR18, assuming the deletion operation completed successfully and the deleted role was present in the seed list.')
def step_mr_MR18_followup_output(context):
    if not hasattr(context, "seed_count") or not hasattr(context, "followup_count"):
        raise AttributeError("seed_count or followup_count not found on context. Ensure Given and When steps ran successfully.")

    expected_count = context.seed_count - 1
    actual_count = context.followup_count

    if expected_count < 0:
        raise ValueError(f"Computed expected_count is negative ({expected_count}). Seed count was {context.seed_count}.")

    assert actual_count == expected_count, (
        f"Expected role count to be {expected_count}, but got {actual_count}."
    )

# ----




@given("a seed input that retrieves a user's details including their roles, producing a seed output with a list of roles for MR20.")
def step_mr_MR20_seed_input(context):
    # Create a user for testing via /users POST (createUser)
    user_data = {
        "username": "testuser_mr20",
        "password": "password123",
        "name": "Test",
        "surname": "User",
        "email": "testuser_mr20@example.com",
        "gender": "male"
    }

    response = requests.post(f"{BASE_URL}/users", json=user_data, timeout=10)
    context.seed_create_user_response = response

    # The API spec allows 200 or 201; treat both as successful creation
    if response.status_code not in (200, 201):
        raise AssertionError(
            f"Failed to create user for MR20. "
            f"Status: {response.status_code}, Body: {response.text}"
        )

    try:
        user_body = response.json()
    except ValueError:
        raise AssertionError(f"Create user did not return valid JSON: {response.text}")

    user_id = user_body.get("id")
    if not isinstance(user_id, int):
        raise AssertionError(f"User 'id' missing or not int in response: {json.dumps(user_body)}")

    context.user_id = user_id

    # Retrieve the user's details via /users/{id} GET (getUserById)
    details_resp = requests.get(f"{BASE_URL}/users/{user_id}", timeout=10)
    context.seed_get_user_response = details_resp

    if details_resp.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve user details for MR20. "
            f"Status: {details_resp.status_code}, Body: {details_resp.text}"
        )

    try:
        details_body = details_resp.json()
    except ValueError:
        raise AssertionError(f"Get user did not return valid JSON: {details_resp.text}")

    # Store the initial roles safely as a list
    initial_roles = details_body.get("roles", [])
    if initial_roles is None:
        initial_roles = []
    if not isinstance(initial_roles, list):
        raise AssertionError(f"'roles' is not a list in user details: {json.dumps(details_body)}")

    context.seed_response = details_body
    context.initial_roles = list(initial_roles)


@when("a follow-up input is created by adding a role to the user using the role-assignment operation and then retrieving the user's details again, yielding a follow-up output for MR20.")
def step_mr_MR20_followup_input(context):
    if not hasattr(context, "user_id"):
        raise AssertionError("user_id not set in context from Given step.")

    user_id = context.user_id

    # Create a role for testing via /users/rbac/roles POST (createRole)
    role_name = "mr20_new_role"
    role_payload = role_name  # Spec: body is a string

    role_resp = requests.post(f"{BASE_URL}/users/rbac/roles", json=role_payload, timeout=10)
    context.role_create_response = role_resp

    if role_resp.status_code not in (200, 201):
        raise AssertionError(
            f"Failed to create role for MR20. "
            f"Status: {role_resp.status_code}, Body: {role_resp.text}"
        )

    try:
        role_body = role_resp.json()
    except ValueError:
        raise AssertionError(f"Create role did not return valid JSON: {role_resp.text}")

    role_id = role_body.get("id")
    if not isinstance(role_id, int):
        raise AssertionError(f"Role 'id' missing or not int in response: {json.dumps(role_body)}")

    context.role_response = role_body
    context.role_id = role_id

    # Add the role to the user via /users/{id}/roles/{roleId} POST (addRole)
    add_role_resp = requests.post(
        f"{BASE_URL}/users/{user_id}/roles/{role_id}", timeout=10
    )
    context.add_role_response = add_role_resp

    if add_role_resp.status_code not in (200, 201):
        raise AssertionError(
            f"Failed to add role to user for MR20. "
            f"Status: {add_role_resp.status_code}, Body: {add_role_resp.text}"
        )

    # Retrieve the user's details again via /users/{id} GET
    followup_resp = requests.get(f"{BASE_URL}/users/{user_id}", timeout=10)
    context.followup_get_user_response = followup_resp

    if followup_resp.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve user details after adding role for MR20. "
            f"Status: {followup_resp.status_code}, Body: {followup_resp.text}"
        )

    try:
        followup_body = followup_resp.json()
    except ValueError:
        raise AssertionError(f"Follow-up get user did not return valid JSON: {followup_resp.text}")

    roles_after = followup_body.get("roles", [])
    if roles_after is None:
        roles_after = []
    if not isinstance(roles_after, list):
        raise AssertionError(f"'roles' is not a list in follow-up user details: {json.dumps(followup_body)}")

    context.followup_response = followup_body
    context.followup_roles = list(roles_after)


@then("the follow-up output should have a role list that includes the newly added role, differing from the seed output for MR20.")
def step_mr_MR20_followup_output(context):
    if not hasattr(context, "initial_roles"):
        raise AssertionError("initial_roles not set in context from Given step.")
    if not hasattr(context, "followup_roles"):
        raise AssertionError("followup_roles not set in context from When step.")
    if not hasattr(context, "role_response"):
        raise AssertionError("role_response not set in context from When step.")

    initial_roles = context.initial_roles
    followup_roles = context.followup_roles

    if not isinstance(initial_roles, list) or not isinstance(followup_roles, list):
        raise AssertionError(
            f"Roles must be lists. initial_roles type: {type(initial_roles)}, "
            f"followup_roles type: {type(followup_roles)}"
        )

    # MR20: role list should grow after assignment
    if len(followup_roles) <= len(initial_roles):
        raise AssertionError(
            "The role list did not increase after adding a new role."
            f" Initial size: {len(initial_roles)}, Follow-up size: {len(followup_roles)}"
        )

    new_role_name = context.role_response.get("role")
    if not isinstance(new_role_name, str):
        raise AssertionError(
            f"Created role does not contain a valid 'role' field: "
            f"{json.dumps(context.role_response)}"
        )

    if new_role_name not in followup_roles:
        raise AssertionError(
            f"The new role '{new_role_name}' was not found in the follow-up roles: "
            f"{json.dumps(followup_roles)}"
        )
