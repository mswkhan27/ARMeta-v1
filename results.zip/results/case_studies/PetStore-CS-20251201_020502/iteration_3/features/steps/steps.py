from behave import given, when, then
import os
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that logs a user into the system, producing a seed output that indicates a successful login for MR12.')
def step_mr_MR12_seed_input(context):
    # Create a user for testing
    user_data = {
        "username": "testuser_mr12",
        "firstName": "Test",
        "lastName": "User",
        "email": "testuser_mr12@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1
    }

    response = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    context.seed_create_user_response = response
    try:
        seed_create_body = response.json()
    except ValueError:
        seed_create_body = None
    context.seed_create_user_body = seed_create_body

    assert response.status_code == 200, f"Failed to create user: {response.text}"

    # Log in the user
    login_response = requests.get(
        f"{BASE_URL}/user/login",
        params={"username": "testuser_mr12", "password": "password"},
        timeout=10,
    )
    context.seed_login_response = login_response
    try:
        login_body = login_response.json()
    except ValueError:
        login_body = login_response.text
    context.seed_login_body = login_body

    assert login_response.status_code == 200, f"Login failed: {login_response.text}"


@when('a follow-up input is created by logging out the same user, yielding a follow-up output for MR12.')
def step_mr_MR12_followup_input(context):
    logout_response = requests.get(f"{BASE_URL}/user/logout", timeout=10)
    context.followup_logout_response = logout_response
    try:
        logout_body = logout_response.json()
    except ValueError:
        logout_body = None
    context.followup_logout_body = logout_body

    assert logout_response.status_code == 200, f"Logout failed: {logout_response.text}"


@then('the follow-up output should indicate a successful logout as defined by the API specification for MR12.')
def step_mr_MR12_followup_output(context):
    assert hasattr(context, "followup_logout_response"), "Missing logout response in context"
    response = context.followup_logout_response

    # Per OpenAPI, /user/logout returns 200 with no defined body; just verify status code
    assert response.status_code == 200, f"Expected status code 200 for logout, got {response.status_code}"

# ----

import json



@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR13.")
def step_mr_MR13_seed_input(context):
    pet_id = 1  # Using a fixed valid pet ID for this example
    url = f"{BASE_URL}/pet/{pet_id}"

    response = requests.get(url, timeout=10)
    context.seed_request = response

    try:
        context.seed_response = response.json()
    except json.JSONDecodeError:
        assert False, f"Failed to decode JSON response from {url}: {response.text}"

    assert response.status_code == 200, (
        f"Expected status code 200 when retrieving pet, got {response.status_code}. "
        f"Response body: {context.seed_response}"
    )

    # Defensive access to pet id to avoid KeyError / TypeError
    pet_id_in_response = context.seed_response.get("id")
    assert isinstance(pet_id_in_response, int), (
        f"Pet 'id' is missing or not an integer in seed response: {context.seed_response}"
    )


@when("a follow-up input is created by uploading an image for the same pet using its identifier, yielding a follow-up output for MR13.")
def step_mr_MR13_followup_input(context):
    pet_id = context.seed_response.get("id")
    assert isinstance(pet_id, int), f"Pet 'id' in context is invalid: {pet_id}"

    url = f"{BASE_URL}/pet/{pet_id}/uploadImage"

    # Ensure image path exists and is readable to avoid FileNotFoundError
    image_path = os.environ.get("TEST_IMAGE_PATH", "path/to/image.jpg")
    assert os.path.isfile(image_path), f"Image file does not exist at path: {image_path}"

    with open(image_path, "rb") as image_file:
        files = {"file": image_file}
        response = requests.post(url, files=files, timeout=10)

    context.followup_request = response

    try:
        context.followup_response = response.json()
    except json.JSONDecodeError:
        assert False, f"Failed to decode JSON response from {url}: {response.text}"

    # Ensure we did not get a 404 (pet not found) as per MR
    assert response.status_code != 404, (
        f"Image upload returned 404 (pet not found) despite existing pet. "
        f"Response body: {context.followup_response}"
    )

    # Per API spec: 200 is "successful operation"
    assert response.status_code == 200, (
        f"Expected status code 200 for image upload, got {response.status_code}. "
        f"Response body: {context.followup_response}"
    )


@then("the follow-up output should indicate a successful image upload according to the API specification, and it should not indicate that the pet is missing (such as a not-found condition), given that the seed output confirmed the pet exists for MR13.")
def step_mr_MR13_followup_output(context):
    # Safety checks to avoid TypeError/KeyError
    assert isinstance(context.followup_response, dict), (
        f"Follow-up response is not a JSON object: {context.followup_response}"
    )

    # According to the spec, /pet/\{petId\}/uploadImage returns ApiResponse
    # with fields: code (int), type (string), message (string)
    api_response = context.followup_response

    # Ensure 'code' exists and is an integer
    assert "code" in api_response, f"'code' field missing in follow-up response: {api_response}"
    assert isinstance(api_response["code"], int), (
        f"'code' field is not an integer: {api_response['code']}"
    )

    # Ensure 'message' exists and is a string
    assert "message" in api_response, f"'message' field missing in follow-up response: {api_response}"
    assert isinstance(api_response["message"], str), (
        f"'message' field is not a string: {api_response['message']}"
    )

    # MR requirement: successful upload and not a not-found condition.
    # 1. HTTP status already checked in @when (200, not 404).
    # 2. Here we just assert that message does not indicate not-found.
    message_lower = api_response["message"].lower()
    assert "not found" not in message_lower, (
        f"Follow-up response indicates pet is missing: {api_response}"
    )

    # Optionally, ensure it's a generally successful operation per spec
    # The spec does not fix an exact message, so we do not hardcode it here,
    # just ensure it's non-empty.
    assert api_response["message"].strip() != "", (
        f"Follow-up response message is empty, response: {api_response}"
    )
