Feature: Iteration 3 MRs

  Scenario: MR12 Logging out should invalidate the current session
    Given a seed input that logs a user into the system, producing a seed output that indicates a successful login for MR12.
    When a follow-up input is created by logging out the same user, yielding a follow-up output for MR12.
    Then the follow-up output should indicate a successful logout as defined by the API specification for MR12.

  Scenario: MR13 Uploading an image should succeed for an existing pet
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR13.
    When a follow-up input is created by uploading an image for the same pet using its identifier, yielding a follow-up output for MR13.
    Then the follow-up output should indicate a successful image upload according to the API specification, and it should not indicate that the pet is missing (such as a not-found condition), given that the seed output confirmed the pet exists for MR13.
