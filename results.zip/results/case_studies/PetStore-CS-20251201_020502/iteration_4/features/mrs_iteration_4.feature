Feature: Iteration 4 MRs

  Scenario: MR14 Creating a list of users should make each user individually retrievable
    Given a seed input that creates a list of new users using the list-based user creation operation, producing a seed output containing the details of the created users for MR14.
    When a follow-up input is created by retrieving each of these users individually by their usernames, yielding a follow-up output for MR14.
    Then the follow-up output should, for each retrieved user, match the corresponding user details from the seed output, ensuring that all users created in the seed input are individually retrievable with consistent data for MR14.

  Scenario: MR15 Uploading an image for a pet should not affect other pet details
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR15.
    When a follow-up input is created by uploading an image for the same pet using its identifier and then retrieving that pet again by the same identifier, yielding a follow-up output for MR15.
    Then the follow-up output should remain identical to the seed output in terms of all stored pet details (such as name, category, photo URLs, tags, and status), as the image upload does not modify these fields for MR15.

  Scenario: MR16 Adding a new pet should increase the inventory count for its status
    Given a seed input that retrieves the current pet inventory by status, producing a seed output with the quantities for each status for MR16.
    When a follow-up input is created by adding a new pet with a specific status and then retrieving the pet inventory by status again, yielding a follow-up output for MR16.
    Then the follow-up output should show that the quantity for the status assigned to the newly added pet has increased by exactly one compared to the seed output, assuming no other changes to pets with that status occurred between the two retrievals for MR16.

  Scenario: MR17 Updating a pet's details should reflect in subsequent retrievals
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR17.
    When a follow-up input is created by updating the pet's details (such as name or status) using its identifier and then retrieving the pet again by the same identifier, yielding a follow-up output for MR17.
    Then the follow-up output should reflect the updated values for the fields included in the update, while any fields that were not changed should remain the same as in the seed output for MR17.

  Scenario: MR18 Deleting a pet should prevent its successful retrieval
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's details for MR18.
    When a follow-up input is created by deleting the pet with that specific identifier and then attempting to retrieve the pet again by the same identifier, yielding a follow-up output for MR18.
    Then the follow-up output should indicate that the pet is not found, confirming that the pet has been removed from the system for MR18.
