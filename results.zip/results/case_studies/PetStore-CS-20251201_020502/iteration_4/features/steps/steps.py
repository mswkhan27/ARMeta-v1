from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that creates a list of new users using the list-based user creation operation, producing a seed output containing the details of the created users for MR14.')
def step_mr_MR14_create_users(context):
    users = [
        {
            "id": 101,
            "username": "mr14_user1",
            "firstName": "John",
            "lastName": "Doe",
            "email": "john.doe@example.com",
            "password": "password1",
            "phone": "1234567890",
            "userStatus": 1
        },
        {
            "id": 102,
            "username": "mr14_user2",
            "firstName": "Jane",
            "lastName": "Doe",
            "email": "jane.doe@example.com",
            "password": "password2",
            "phone": "0987654321",
            "userStatus": 1
        }
    ]

    context.seed_request = users

    try:
        response = requests.post(
            f"{BASE_URL}/user/createWithList",
            json=users,
            timeout=10
        )
    except requests.RequestException as e:
        raise AssertionError(f"Request failed in Given step for MR14: {e}") from e

    # API may or may not return body; handle both safely
    if response.status_code != 200:
        raise AssertionError(
            f"Unexpected status code in Given step for MR14: "
            f"{response.status_code}, body={response.text!r}"
        )

    # If response has JSON, use it; otherwise fall back to the original request as seed output
    try:
        if response.content and response.headers.get("Content-Type", "").startswith("application/json"):
            context.seed_response = response.json()
        else:
            context.seed_response = users
    except (ValueError, TypeError):
        # Invalid/missing JSON, safely fall back
        context.seed_response = users

    # Ensure seed_response is a list for downstream processing
    if not isinstance(context.seed_response, list):
        context.seed_response = users


@when('a follow-up input is created by retrieving each of these users individually by their usernames, yielding a follow-up output for MR14.')
def step_mr_MR14_retrieve_users(context):
    users = getattr(context, "seed_response", None)
    if not isinstance(users, list):
        raise AssertionError("seed_response is not a list in When step for MR14.")

    followup_responses = []

    for user in users:
        if not isinstance(user, dict):
            raise AssertionError(f"User entry is not an object: {user!r}")

        username = user.get("username")
        if not isinstance(username, str) or not username:
            raise AssertionError(f"Invalid or missing username in seed_response entry: {user!r}")

        try:
            response = requests.get(
                f"{BASE_URL}/user/{username}",
                timeout=10
            )
        except requests.RequestException as e:
            raise AssertionError(f"Request failed when retrieving user '{username}' in When step for MR14: {e}") from e

        if response.status_code != 200:
            raise AssertionError(
                f"Unexpected status code when retrieving user '{username}' in When step for MR14: "
                f"{response.status_code}, body={response.text!r}"
            )

        try:
            followup_user = response.json()
        except (ValueError, TypeError) as e:
            raise AssertionError(
                f"Failed to decode JSON when retrieving user '{username}' in When step for MR14: {e}"
            ) from e

        if not isinstance(followup_user, dict):
            raise AssertionError(
                f"Follow-up response for user '{username}' is not a JSON object: {followup_user!r}"
            )

        followup_responses.append(followup_user)

    context.followup_response = followup_responses


@then('the follow-up output should, for each retrieved user, match the corresponding user details from the seed output, ensuring that all users created in the seed input are individually retrievable with consistent data for MR14.')
def step_mr_MR14_assert_users(context):
    seed_users = getattr(context, "seed_response", None)
    followup_users = getattr(context, "followup_response", None)

    if not isinstance(seed_users, list):
        raise AssertionError("seed_response is not a list in Then step for MR14.")
    if not isinstance(followup_users, list):
        raise AssertionError("followup_response is not a list in Then step for MR14.")

    if len(seed_users) != len(followup_users):
        raise AssertionError(
            f"Mismatch in number of users retrieved. "
            f"Expected {len(seed_users)}, got {len(followup_users)}."
        )

    # Compare user by username mapping to be order-agnostic and safer
    def to_user_map(users_list, label):
        user_map = {}
        for u in users_list:
            if not isinstance(u, dict):
                raise AssertionError(f"{label} entry is not an object: {u!r}")
            username = u.get("username")
            if not isinstance(username, str) or not username:
                raise AssertionError(f"Invalid or missing username in {label} entry: {u!r}")
            user_map[username] = u
        return user_map

    seed_map = to_user_map(seed_users, "seed_response")
    followup_map = to_user_map(followup_users, "followup_response")

    if set(seed_map.keys()) != set(followup_map.keys()):
        raise AssertionError(
            f"Usernames in seed and follow-up responses do not match. "
            f"Seed: {set(seed_map.keys())}, Follow-up: {set(followup_map.keys())}"
        )

    fields_to_compare = ["username", "firstName", "lastName", "email", "phone", "userStatus"]

    for username, seed_user in seed_map.items():
        followup_user = followup_map.get(username)
        if followup_user is None:
            raise AssertionError(f"User '{username}' not found in follow-up response.")

        for field in fields_to_compare:
            seed_value = seed_user.get(field)
            followup_value = followup_user.get(field)
            if seed_value != followup_value:
                raise AssertionError(
                    f"Field '{field}' mismatch for user '{username}': "
                    f"seed={seed_value!r}, follow-up={followup_value!r}"
                )

# ----

import pathlib



def _safe_get_json(response):
    try:
        return response.json()
    except json.JSONDecodeError:
        raise AssertionError(f"Failed to decode JSON response: {response.text}")


def _get_pet_by_id(pet_id):
    if not isinstance(pet_id, int):
        raise AssertionError(f"pet_id must be int, got {type(pet_id).__name__}")
    url = f"{BASE_URL}/pet/{pet_id}"
    resp = requests.get(url, timeout=10)
    assert resp.status_code == 200, f"Failed to retrieve pet (GET {url}): {resp.status_code} {resp.text}"
    data = _safe_get_json(resp)
    if not isinstance(data, dict):
        raise AssertionError(f"Expected pet JSON object, got {type(data).__name__}")
    return data


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR15.")
def _mr_MR15_seed_input(context):
    pet_id = 1
    context.pet_id = pet_id
    context.seed_response = _get_pet_by_id(pet_id)


@when("a follow-up input is created by uploading an image for the same pet using its identifier and then retrieving that pet again by the same identifier, yielding a follow-up output for MR15.")
def _mr_MR15_followup_input(context):
    pet_id = getattr(context, "pet_id", None)
    if not isinstance(pet_id, int):
        raise AssertionError(f"Context pet_id must be int, got {type(pet_id).__name__}")

    image_path = os.environ.get("PET_IMAGE_PATH", "testdata/image.jpg")
    image_file_path = pathlib.Path(image_path)

    if not image_file_path.is_file():
        raise AssertionError(f"Image file for upload not found at: {image_file_path}")

    url = f"{BASE_URL}/pet/{pet_id}/uploadImage"
    with image_file_path.open("rb") as image_file:
        upload_response = requests.post(
            url,
            files={"file": image_file},
            timeout=30,
        )

    assert upload_response.status_code == 200, (
        f"Failed to upload image (POST {url}): "
        f"{upload_response.status_code} {upload_response.text}"
    )

    context.followup_response = _get_pet_by_id(pet_id)


@then("the follow-up output should remain identical to the seed output in terms of all stored pet details (such as name, category, photo URLs, tags, and status), as the image upload does not modify these fields for MR15.")
def _mr_MR15_assert_followup(context):
    seed = getattr(context, "seed_response", None)
    follow = getattr(context, "followup_response", None)

    if not isinstance(seed, dict) or not isinstance(follow, dict):
        raise AssertionError(
            f"Seed and follow-up responses must be dicts, got "
            f"{type(seed).__name__} and {type(follow).__name__}"
        )

    for field in ["name", "category", "tags", "status", "photoUrls"]:
        assert field in seed, f"Field '{field}' missing in seed response"
        assert field in follow, f"Field '{field}' missing in follow-up response"
        assert follow[field] == seed[field], f"{field.capitalize()} has changed after image upload"

# ----

import time



@given('a seed input that retrieves the current pet inventory by status, producing a seed output with the quantities for each status for MR16.')
def _mr_MR16_seed_input(context):
    response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    response.raise_for_status()
    data = response.json()
    if not isinstance(data, dict):
        raise AssertionError(f"Expected inventory to be an object/map, got: {type(data)}")
    context.seed_response = data


@when('a follow-up input is created by adding a new pet with a specific status and then retrieving the pet inventory by status again, yielding a follow-up output for MR16.')
def _mr_MR16_followup_input(context):
    # Ensure we have seed data first
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("Seed inventory response is missing or invalid before When step in MR16.")

    status = "available"
    new_pet = {
        "name": "Buddy",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": status
    }

    add_response = requests.post(f"{BASE_URL}/pet", json=new_pet, timeout=10)
    add_response.raise_for_status()

    # Give the system a short time to update inventory if needed
    time.sleep(0.2)

    followup_response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    followup_response.raise_for_status()
    data = followup_response.json()
    if not isinstance(data, dict):
        raise AssertionError(f"Expected follow-up inventory to be an object/map, got: {type(data)}")

    context.followup_response = data
    context._mr16_status = status


@then('the follow-up output should show that the quantity for the status assigned to the newly added pet has increased by exactly one compared to the seed output, assuming no other changes to pets with that status occurred between the two retrievals for MR16.')
def _mr_MR16_followup_output(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("Seed inventory response is missing or invalid in Then step for MR16.")
    if not hasattr(context, "followup_response") or not isinstance(context.followup_response, dict):
        raise AssertionError("Follow-up inventory response is missing or invalid in Then step for MR16.")
    status = getattr(context, "_mr16_status", None)
    if not isinstance(status, str):
        raise AssertionError("MR16 status used for comparison is missing or invalid.")

    seed_count_raw = context.seed_response.get(status, 0)
    followup_count_raw = context.followup_response.get(status, 0)

    if not isinstance(seed_count_raw, int):
        raise AssertionError(f"Seed inventory count for '{status}' is not an integer: {seed_count_raw!r}")
    if not isinstance(followup_count_raw, int):
        raise AssertionError(f"Follow-up inventory count for '{status}' is not an integer: {followup_count_raw!r}")

    expected = seed_count_raw + 1
    assert followup_count_raw == expected, (
        f"Expected inventory count for status '{status}' to be {expected}, "
        f"but got {followup_count_raw}."
    )

# ----




@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR17.")
def step_mr_MR17_seed_input(context):
    # Create a pet to ensure it exists, then retrieve it by id as the seed output
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    response.raise_for_status()
    created_pet = response.json()

    pet_id = created_pet.get("id")
    if pet_id is None:
        raise ValueError("Created pet does not contain an 'id' field")

    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    get_response.raise_for_status()
    seed_pet = get_response.json()

    context.seed_request = pet_data
    context.seed_response = seed_pet
    context.pet_id = pet_id


@when("a follow-up input is created by updating the pet's details (such as name or status) using its identifier and then retrieving the pet again by the same identifier, yielding a follow-up output for MR17.")
def step_mr_MR17_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AttributeError("pet_id is missing from context. Ensure Given step ran successfully.")

    pet_id = context.pet_id

    seed = context.seed_response or {}
    photo_urls = seed.get("photoUrls") or []
    category = seed.get("category")
    tags = seed.get("tags")

    updated_data = {
        "id": pet_id,
        "name": "doggie_updated",
        "photoUrls": photo_urls,
        "status": "pending"
    }

    if category is not None:
        updated_data["category"] = category
    if tags is not None:
        updated_data["tags"] = tags

    update_response = requests.put(f"{BASE_URL}/pet", json=updated_data, timeout=10)
    update_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    followup_response.raise_for_status()
    context.followup_response = followup_response.json()
    context.updated_request = updated_data


@then("the follow-up output should reflect the updated values for the fields included in the update, while any fields that were not changed should remain the same as in the seed output for MR17.")
def step_mr_MR17_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AttributeError("followup_response is missing from context. Ensure When step ran successfully.")
    if not hasattr(context, "seed_response"):
        raise AttributeError("seed_response is missing from context. Ensure Given step ran successfully.")

    followup = context.followup_response or {}
    seed = context.seed_response or {}

    assert followup.get("name") == "doggie_updated", "Name was not updated correctly."
    assert followup.get("status") == "pending", "Status was not updated correctly."

    assert followup.get("photoUrls") == seed.get("photoUrls"), "Photo URLs should remain unchanged."

    if "category" in seed:
        assert followup.get("category") == seed.get("category"), "Category should remain unchanged."
    if "tags" in seed:
        assert followup.get("tags") == seed.get("tags"), "Tags should remain unchanged."

# ----




@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's details for MR18.")
def _mr_MR18_seed_input(context):
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    response.raise_for_status()

    # Safely parse JSON; if no JSON is returned, use an empty dict
    try:
        seed_response = response.json()
    except (ValueError, json.JSONDecodeError):
        seed_response = {}

    # Ensure 'id' exists and is an integer to avoid KeyError/TypeError later
    pet_id = seed_response.get("id")
    if pet_id is None:
        raise AssertionError("Seed response does not contain 'id' field.")
    try:
        pet_id_int = int(pet_id)
    except (TypeError, ValueError) as exc:
        raise AssertionError(f"Seed 'id' is not a valid integer: {pet_id}") from exc

    context.seed_response = seed_response
    context.seed_request = pet_data
    context.seed_pet_id = pet_id_int


@when("a follow-up input is created by deleting the pet with that specific identifier and then attempting to retrieve the pet again by the same identifier, yielding a follow-up output for MR18.")
def _mr_MR18_followup_input(context):
    if not hasattr(context, "seed_pet_id"):
        raise AssertionError("Context is missing 'seed_pet_id' from the Given step.")
    pet_id = context.seed_pet_id

    delete_response = requests.delete(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    delete_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    context.followup_response = followup_response


@then("the follow-up output should indicate that the pet is not found, confirming that the pet has been removed from the system for MR18.")
def _mr_MR18_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AssertionError("Context is missing 'followup_response' from the When step.")
    assert context.followup_response.status_code == 404, (
        f"Expected status code 404 for not found, got {context.followup_response.status_code}"
    )
