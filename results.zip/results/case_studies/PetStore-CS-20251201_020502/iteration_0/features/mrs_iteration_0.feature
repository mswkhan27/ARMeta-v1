Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet with a given status should increase the count of pets with that status
    Given a seed input that retrieves pets filtered by status 'available', producing a seed output whose size is the current count of pets with status 'available' for MR1.
    When a follow-up input is created by adding a new pet with status 'available' and then retrieving pets filtered by status 'available' again, yielding a follow-up output for MR1.
    Then the follow-up output should have a count of pets with status 'available' that is exactly one more than the seed output for MR1, assuming no other pets with that status were added, updated, or deleted between the two retrievals.

  Scenario: MR2 Updating a pet's status should be reflected when retrieving that pet by its identifier
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR2.
    When a follow-up input is created by updating the same pet so that its status field is set to 'sold', and the pet is retrieved again by the same identifier, yielding a follow-up output for MR2.
    Then the follow-up output should show the pet's status as 'sold', and fields that were not changed as part of the update request should remain the same as in the seed output for MR2, subject to any server-generated fields.

  Scenario: MR3 Deleting a pet should remove it from subsequent filtered retrievals
    Given a seed input that retrieves pets using a filter, producing a seed output that includes a specific pet identifier for MR3.
    When a follow-up input is created by deleting the pet with that specific identifier and then performing the same filtered retrieval again, yielding a follow-up output for MR3.
    Then the follow-up output should not include the deleted pet identifier, indicating the pet has been removed from the results for that filter for MR3, and retrieving the pet directly by that identifier should indicate that the pet is no longer found.

  Scenario: MR4 Finding pets by tags should return only pets that match the specified tags
    Given a seed input that retrieves pets by a single tag, producing a seed output with a list of pets for MR4.
    When a follow-up input is created by searching using the original tag together with an additional tag, yielding a follow-up output for MR4.
    Then the follow-up output should contain only pets whose tags include at least one of the tags used in the follow-up search, and any pet from the seed output that still satisfies the combined tag criteria should also appear in the follow-up output for MR4.
