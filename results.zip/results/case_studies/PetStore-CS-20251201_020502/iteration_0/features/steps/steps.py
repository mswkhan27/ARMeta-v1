from behave import given, when, then
import os
import json
import requests
from typing import Any, List

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _safe_get_json(response: requests.Response) -> Any:
    """
    Safely parse JSON from a response.
    Returns parsed JSON or raises a ValueError with a clear message.
    """
    try:
        return response.json()
    except ValueError as exc:
        raise ValueError(
            f"Response from {response.request.method} {response.url} is not valid JSON. "
            f"Status code: {response.status_code}, Content: {response.text}"
        ) from exc


def _ensure_list(value: Any, context_label: str) -> List[Any]:
    """
    Ensure the provided value is a list.
    If it's None, return an empty list.
    If it's not a list, wrap it in a list.
    This prevents TypeError when using len(...) on unexpected types.
    """
    if value is None:
        return []
    if isinstance(value, list):
        return value
    # If it's a dict or other JSON type, we still want len(...) to be valid,
    # but for consistency with expectations (findByStatus returns an array),
    # we coerce non-list responses into a single-element list.
    return [value]


@given(
    "a seed input that retrieves pets filtered by status 'available', producing a seed output whose size is the current count of pets with status 'available' for MR1."
)
def _mr_MR1_seed_input(context) -> None:
    # Retrieve pets with status 'available' using the documented endpoint:
    # GET /pet/findByStatus with query parameter ?status=available
    url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}

    response = requests.get(url, params=params, timeout=10)
    response.raise_for_status()

    data = _safe_get_json(response)
    pets_list = _ensure_list(data, "seed_response")

    context.seed_request = params
    context.seed_response = pets_list
    context.seed_count = len(pets_list)


@when(
    "a follow-up input is created by adding a new pet with status 'available' and then retrieving pets filtered by status 'available' again, yielding a follow-up output for MR1."
)
def _mr_MR1_followup_input(context) -> None:
    # Create a new pet with status 'available' using:
    # POST /pet with a Pet object in the body
    new_pet = {
        "name": "New Available Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }

    add_url = f"{BASE_URL}/pet"
    add_response = requests.post(add_url, json=new_pet, timeout=10)
    add_response.raise_for_status()
    _ = _safe_get_json(add_response)  # Ensure response is valid JSON; not used further

    # Retrieve pets with status 'available' again:
    # GET /pet/findByStatus?status=available
    find_url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}

    followup_response = requests.get(find_url, params=params, timeout=10)
    followup_response.raise_for_status()

    data = _safe_get_json(followup_response)
    pets_list = _ensure_list(data, "followup_response")

    context.followup_response = pets_list
    context.followup_count = len(pets_list)


@then(
    "the follow-up output should have a count of pets with status 'available' that is exactly one more than the seed output for MR1, assuming no other pets with that status were added, updated, or deleted between the two retrievals."
)
def _mr_MR1_followup_assertion(context) -> None:
    expected = context.seed_count + 1
    actual = context.followup_count
    assert actual == expected, (
        f"Expected follow-up count to be {expected}, but got {actual}."
    )

# ----




@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR2.")
def step_mr_MR2_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    context.seed_create_response = response

    try:
        seed_created = response.json()
    except ValueError:
        raise AssertionError(
            f"Expected JSON response when creating pet, got: {response.text}"
        )

    if not isinstance(seed_created, dict):
        raise AssertionError(
            f"Expected JSON object when creating pet, got: {type(seed_created)}"
        )

    pet_id = seed_created.get("id")
    if pet_id is None:
        raise AssertionError(
            f"No 'id' field in create response JSON: {json.dumps(seed_created, ensure_ascii=False)}"
        )

    # Retrieve the pet by its identifier
    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    context.seed_get_response = get_response

    try:
        seed_pet = get_response.json()
    except ValueError:
        raise AssertionError(
            f"Expected JSON response when retrieving pet, got: {get_response.text}"
        )

    if not isinstance(seed_pet, dict):
        raise AssertionError(
            f"Expected JSON object when retrieving pet, got: {type(seed_pet)}"
        )

    # Store seed output safely on context
    context.seed_pet = {
        "id": seed_pet.get("id"),
        "name": seed_pet.get("name"),
        "photoUrls": list(seed_pet.get("photoUrls") or []),
        "status": seed_pet.get("status")
    }


@when("a follow-up input is created by updating the same pet so that its status field is set to 'sold', and the pet is retrieved again by the same identifier, yielding a follow-up output for MR2.")
def step_mr_MR2_followup_input(context):
    if not hasattr(context, "seed_pet") or not isinstance(context.seed_pet, dict):
        raise AssertionError("Seed pet data is not available or invalid on context.")

    pet_id = context.seed_pet.get("id")
    if pet_id is None:
        raise AssertionError("Seed pet 'id' is missing; cannot perform update.")

    # Build update payload using existing values and changing only status
    update_data = {
        "id": pet_id,
        "name": context.seed_pet.get("name"),
        "photoUrls": list(context.seed_pet.get("photoUrls") or []),
        "status": "sold"
    }

    put_response = requests.put(f"{BASE_URL}/pet", json=update_data, timeout=10)
    context.followup_put_response = put_response

    try:
        updated_pet = put_response.json()
    except ValueError:
        raise AssertionError(
            f"Expected JSON response when updating pet, got: {put_response.text}"
        )

    if not isinstance(updated_pet, dict):
        raise AssertionError(
            f"Expected JSON object when updating pet, got: {type(updated_pet)}"
        )

    updated_id = updated_pet.get("id", pet_id)

    # Retrieve the pet again by the same identifier
    get_response = requests.get(f"{BASE_URL}/pet/{updated_id}", timeout=10)
    context.followup_get_response = get_response

    try:
        followup_pet = get_response.json()
    except ValueError:
        raise AssertionError(
            f"Expected JSON response when retrieving updated pet, got: {get_response.text}"
        )

    if not isinstance(followup_pet, dict):
        raise AssertionError(
            f"Expected JSON object when retrieving updated pet, got: {type(followup_pet)}"
        )

    context.followup_pet = {
        "id": followup_pet.get("id"),
        "name": followup_pet.get("name"),
        "photoUrls": list(followup_pet.get("photoUrls") or []),
        "status": followup_pet.get("status")
    }


@then("the follow-up output should show the pet's status as 'sold', and fields that were not changed as part of the update request should remain the same as in the seed output for MR2, subject to any server-generated fields.")
def step_mr_MR2_followup_output(context):
    if not hasattr(context, "seed_pet") or not hasattr(context, "followup_pet"):
        raise AssertionError("Seed or follow-up pet data is missing from context.")

    seed_pet = context.seed_pet
    followup_pet = context.followup_pet

    # Status must be updated to 'sold'
    if followup_pet.get("status") != "sold":
        raise AssertionError(
            f"Expected status 'sold' after update, got: {followup_pet.get('status')}"
        )

    # Fields not changed in the update should remain the same
    # We did not modify 'name' and 'photoUrls' in the MR
    if followup_pet.get("name") != seed_pet.get("name"):
        raise AssertionError(
            f"Name changed unexpectedly: seed={seed_pet.get('name')}, "
            f"followup={followup_pet.get('name')}"
        )

    if list(followup_pet.get("photoUrls") or []) != list(seed_pet.get("photoUrls") or []):
        raise AssertionError(
            "photoUrls changed unexpectedly: "
            f"seed={seed_pet.get('photoUrls')}, "
            f"followup={followup_pet.get('photoUrls')}"
        )

# ----




@given('a seed input that retrieves pets using a filter, producing a seed output that includes a specific pet identifier for MR3.')
def step_mr_MR3_seed_input(context):
    # Create a pet to ensure we have a pet to retrieve
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    context.seed_request = response

    # Safely parse JSON
    try:
        seed_response = response.json()
    except (ValueError, json.JSONDecodeError):
        raise AssertionError("Seed response is not valid JSON")

    if not isinstance(seed_response, dict):
        raise AssertionError("Seed response JSON is not an object")

    context.seed_response = seed_response

    pet_id = seed_response.get("id")
    if not isinstance(pet_id, int):
        raise AssertionError("Seed response does not contain a valid integer 'id' field")

    context.pet_id = pet_id

    # Retrieve pets by status to ensure the created pet is included
    response = requests.get(f"{BASE_URL}/pet/findByStatus", params={"status": "available"}, timeout=10)

    try:
        pets = response.json()
    except (ValueError, json.JSONDecodeError):
        raise AssertionError("findByStatus response is not valid JSON")

    if not isinstance(pets, list):
        raise AssertionError("findByStatus response JSON is not a list")

    context.pets = pets

    # Assert that the created pet is in the retrieved list, safely accessing 'id'
    if not any(isinstance(pet, dict) and pet.get("id") == context.pet_id for pet in pets):
        raise AssertionError("Seed pet not found in the retrieved pets.")


@when('a follow-up input is created by deleting the pet with that specific identifier and then performing the same filtered retrieval again, yielding a follow-up output for MR3.')
def step_mr_MR3_followup_input(context):
    # Delete the pet
    delete_response = requests.delete(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
    context.delete_response = delete_response
    if delete_response.status_code != 200:
        raise AssertionError(f"Failed to delete the pet. Status code: {delete_response.status_code}")

    # Retrieve pets by status again using the same filter as in Given
    followup_response = requests.get(f"{BASE_URL}/pet/findByStatus", params={"status": "available"}, timeout=10)

    try:
        followup_json = followup_response.json()
    except (ValueError, json.JSONDecodeError):
        raise AssertionError("Follow-up findByStatus response is not valid JSON")

    if not isinstance(followup_json, list):
        raise AssertionError("Follow-up findByStatus response JSON is not a list")

    context.followup_response = followup_json


@then('the follow-up output should not include the deleted pet identifier, indicating the pet has been removed from the results for that filter for MR3, and retrieving the pet directly by that identifier should indicate that the pet is no longer found.')
def step_mr_MR3_followup_output(context):
    # Assert that the deleted pet is not in the follow-up output
    if any(isinstance(pet, dict) and pet.get("id") == context.pet_id for pet in context.followup_response):
        raise AssertionError("Deleted pet is still found in the follow-up output.")

    # Attempt to retrieve the deleted pet directly
    direct_retrieve_response = requests.get(f"{BASE_URL}/pet/{context.pet_id}", timeout=10)
    context.direct_retrieve_response = direct_retrieve_response

    if direct_retrieve_response.status_code != 404:
        raise AssertionError(
            f"Deleted pet should not be found. Expected status 404, got {direct_retrieve_response.status_code}"
        )

# ----




@given('a seed input that retrieves pets by a single tag, producing a seed output with a list of pets for MR4.')
def _mr_MR4_seed_input(context):
    tag = "dog"  # Example tag

    context.seed_request = {'tags': tag}

    response = requests.get(
        f"{BASE_URL}/pet/findByTags",
        params=context.seed_request,
        timeout=10
    )
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Seed response is not valid JSON: {e}") from e

    if not isinstance(data, list):
        raise AssertionError(f"Seed response is not a list: {type(data)}")

    context.seed_response = data


@when('a follow-up input is created by searching using the original tag together with an additional tag, yielding a follow-up output for MR4.')
def _mr_MR4_followup_input(context):
    additional_tag = "cute"  # Example additional tag

    original_tag = context.seed_request.get('tags')
    if not isinstance(original_tag, str):
        raise AssertionError(f"Original tag should be a string, got: {type(original_tag)}")

    followup_tags = [original_tag, additional_tag]
    context.followup_request = {'tags': followup_tags}

    response = requests.get(
        f"{BASE_URL}/pet/findByTags",
        params={'tags': followup_tags},
        timeout=10
    )
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response is not valid JSON: {e}") from e

    if not isinstance(data, list):
        raise AssertionError(f"Follow-up response is not a list: {type(data)}")

    context.followup_response = data


@then('the follow-up output should contain only pets whose tags include at least one of the tags used in the follow-up search, and any pet from the seed output that still satisfies the combined tag criteria should also appear in the follow-up output for MR4.')
def _mr_MR4_followup_output(context):
    followup_tags = set(context.followup_request.get('tags') or [])
    if not followup_tags:
        raise AssertionError("Follow-up tags set is empty")

    # 1) Every pet in follow-up must have at least one of the follow-up tags
    for idx, pet in enumerate(context.followup_response):
        if not isinstance(pet, dict):
            raise AssertionError(f"Follow-up pet at index {idx} is not an object: {type(pet)}")

        pet_tags_raw = pet.get('tags') or []
        if not isinstance(pet_tags_raw, list):
            raise AssertionError(f"Pet 'tags' field is not a list at index {idx}: {type(pet_tags_raw)}")

        pet_tag_names = {
            t.get('name')
            for t in pet_tags_raw
            if isinstance(t, dict) and isinstance(t.get('name'), str)
        }

        if not pet_tag_names.intersection(followup_tags):
            raise AssertionError(
                f"Follow-up output contains a pet that does not match any follow-up tags; "
                f"pet id={pet.get('id')}, tags={list(pet_tag_names)}, followup_tags={list(followup_tags)}"
            )

    # 2) Any pet from seed output that still satisfies follow-up tag criteria should appear in follow-up
    followup_ids = {
        pet.get('id')
        for pet in context.followup_response
        if isinstance(pet, dict) and 'id' in pet
    }

    for idx, seed_pet in enumerate(context.seed_response):
        if not isinstance(seed_pet, dict):
            raise AssertionError(f"Seed pet at index {idx} is not an object: {type(seed_pet)}")

        seed_id = seed_pet.get('id')
        if seed_id is None:
            # If no id, we cannot reliably compare membership; skip
            continue

        seed_tags_raw = seed_pet.get('tags') or []
        if not isinstance(seed_tags_raw, list):
            continue

        seed_tag_names = {
            t.get('name')
            for t in seed_tags_raw
            if isinstance(t, dict) and isinstance(t.get('name'), str)
        }

        # Only check pets that satisfy the follow-up tag criteria
        if not seed_tag_names.intersection(followup_tags):
            continue

        if seed_id not in followup_ids:
            raise AssertionError(
                f"Seed pet satisfying follow-up tag criteria not found in follow-up output; "
                f"pet id={seed_id}, tags={list(seed_tag_names)}, followup_tags={list(followup_tags)}"
            )
