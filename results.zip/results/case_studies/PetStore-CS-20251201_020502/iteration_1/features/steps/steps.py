from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that successfully retrieves a user by their username, producing a seed output that includes the user's details for MR5.")
def _mr_MR5_seed_input(context):
    context.username = "testuser"
    context.user_data = {
        "username": context.username,
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password123",
        "phone": "1234567890",
        "userStatus": 1
    }

    try:
        create_response = requests.post(
            f"{BASE_URL}/user",
            json=context.user_data,
            timeout=10,
        )
        create_response.raise_for_status()

        context.seed_response = requests.get(
            f"{BASE_URL}/user/{context.username}",
            timeout=10,
        )
        context.seed_response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Error in Given step for MR5: {e}") from e


@when("a follow-up input is created by deleting the user with that specific username and then attempting to retrieve the user again by the same username, yielding a follow-up output for MR5.")
def _mr_MR5_followup_input(context):
    try:
        delete_response = requests.delete(
            f"{BASE_URL}/user/{context.username}",
            timeout=10,
        )
        delete_response.raise_for_status()

        context.followup_response = requests.get(
            f"{BASE_URL}/user/{context.username}",
            timeout=10,
        )
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Error in When step for MR5: {e}") from e


@then("the follow-up output should indicate that the user is not found (for example, via a 'User not found' response), confirming the user has been removed from the system for MR5.")
def _mr_MR5_followup_output(context):
    if context.followup_response is None:
        raise AssertionError("Follow-up response is missing.")

    status_code = getattr(context.followup_response, "status_code", None)
    if status_code != 404:
        raise AssertionError(
            f"Expected status code 404 for user not found, got {status_code}."
        )

    # Try to parse JSON safely; do not assume presence or type of message field
    message = None
    try:
        body = context.followup_response.json()
        if isinstance(body, dict):
            message = body.get("message")
    except (ValueError, TypeError, json.JSONDecodeError):
        body = context.followup_response.text
        message = None

    if message is not None and message != "User not found":
        raise AssertionError(
            f"Expected 'User not found' message or no message, got: {message!r}. "
            f"Raw body: {body!r}"
        )

# ----




@given("a seed input that successfully retrieves a user by their username, producing a seed output with the user's current details for MR7.")
def _mr_MR7_seed_input(context):
    # Create a user to ensure it exists
    user_data = {
        "id": 10,
        "username": "testuser",
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1
    }

    response = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    response.raise_for_status()
    context.seed_create_response = response

    # Retrieve the user to get the seed output
    seed_response = requests.get(f"{BASE_URL}/user/testuser", timeout=10)
    seed_response.raise_for_status()

    # Ensure we always have dictionaries, not None, to avoid TypeError/KeyError later
    try:
        context.seed_response = seed_response
        context.seed_data = seed_response.json() if seed_response.content else {}
    except ValueError:
        context.seed_data = {}


@when("a follow-up input is created by updating the user's details (e.g., email or phone) and then retrieving the user again by the same username, yielding a follow-up output for MR7.")
def _mr_MR7_followup_input(context):
    # Prepare full user payload based on the seed to comply with the schema
    seed_data = getattr(context, "seed_data", {})
    if not isinstance(seed_data, dict):
        seed_data = {}

    updated_user_data = {
        "id": seed_data.get("id", 10),
        "username": seed_data.get("username", "testuser"),
        "firstName": seed_data.get("firstName", "John"),
        "lastName": seed_data.get("lastName", "Doe"),
        "email": "john.doe.updated@example.com",
        "password": seed_data.get("password", "password"),
        "phone": seed_data.get("phone", "1234567890"),
        "userStatus": seed_data.get("userStatus", 1),
    }

    followup_request = requests.put(
        f"{BASE_URL}/user/testuser",
        json=updated_user_data,
        timeout=10,
    )
    followup_request.raise_for_status()
    context.followup_request = followup_request

    followup_response = requests.get(f"{BASE_URL}/user/testuser", timeout=10)
    followup_response.raise_for_status()
    context.followup_response = followup_response

    try:
        context.followup_data = followup_response.json() if followup_response.content else {}
    except ValueError:
        context.followup_data = {}


@then("the follow-up output should reflect the updated details for the fields included in the update, and any fields that were not changed as part of the update request should remain the same as in the seed output for MR7, provided the update operation completed successfully.")
def _mr_MR7_followup_output(context):
    seed_data = getattr(context, "seed_data", {})
    followup_data = getattr(context, "followup_data", {})

    if not isinstance(seed_data, dict):
        seed_data = {}
    if not isinstance(followup_data, dict):
        followup_data = {}

    # Safely access fields with get to avoid KeyError/TypeError
    assert followup_data.get("email") == "john.doe.updated@example.com", "Email was not updated correctly."

    # Unchanged fields should remain the same
    assert followup_data.get("username") == seed_data.get("username"), "Username should remain unchanged."
    assert followup_data.get("firstName") == seed_data.get("firstName"), "First name should remain unchanged."
    assert followup_data.get("lastName") == seed_data.get("lastName"), "Last name should remain unchanged."
    assert followup_data.get("phone") == seed_data.get("phone"), "Phone should remain unchanged."
    assert followup_data.get("userStatus") == seed_data.get("userStatus"), "User status should remain unchanged."

# ----

from datetime import datetime



def _safe_parse_datetime(value: str):
    """
    Safely parse an RFC 3339 / ISO-8601 datetime string.
    Returns a datetime object or None if parsing fails.
    """
    if not isinstance(value, str) or not value.strip():
        return None
    # Try common formats; OpenAPI uses "date-time" (RFC 3339)
    for fmt in (
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%S.%f",
    ):
        try:
            return datetime.strptime(value, fmt)
        except (ValueError, TypeError):
            continue
    return None


@given('a seed input that logs a user into the system, producing a seed output that includes a response body and expiration details (such as an expiration header with a date-time value) for MR8.')
def step_mr_MR8_seed_input(context):
    try:
        # Create a user for login (POST /user)
        user_data = {
            "id": 10,
            "username": "testuser",
            "firstName": "Test",
            "lastName": "User",
            "email": "testuser@example.com",
            "password": "password",
            "phone": "1234567890",
            "userStatus": 1,
        }
        create_user_resp = requests.post(
            f"{BASE_URL}/user",
            json=user_data,
            timeout=10,
        )
        create_user_resp.raise_for_status()
        context.seed_user = user_data

        # Log in the user (GET /user/login)
        login_resp = requests.get(
            f"{BASE_URL}/user/login",
            params={"username": "testuser", "password": "password"},
            timeout=10,
        )
        login_resp.raise_for_status()

        context.seed_login_response = login_resp
        context.seed_body = login_resp.text  # body is a string per spec
        context.seed_expires_after_raw = login_resp.headers.get("X-Expires-After")
        context.seed_expires_after = _safe_parse_datetime(
            context.seed_expires_after_raw
        )
    except Exception as e:
        # Ensure behave step fails cleanly without raising unexpected exception types
        context.step_exception = e
        assert False, f"Error in Given step for MR8: {e}"


@when('a follow-up input is created by logging in the same user again, yielding a follow-up output for MR8.')
def step_mr_MR8_followup_input(context):
    try:
        login_resp = requests.get(
            f"{BASE_URL}/user/login",
            params={"username": "testuser", "password": "password"},
            timeout=10,
        )
        login_resp.raise_for_status()

        context.followup_login_response = login_resp
        context.followup_body = login_resp.text
        context.followup_expires_after_raw = login_resp.headers.get("X-Expires-After")
        context.followup_expires_after = _safe_parse_datetime(
            context.followup_expires_after_raw
        )
    except Exception as e:
        context.step_exception = e
        assert False, f"Error in When step for MR8: {e}"


@then('the follow-up output should also include expiration details in the response, and, if the service issues a new session on each login, the expiration time in the follow-up output is expected to be greater than or equal to the expiration time in the seed output for MR8.')
def step_mr_MR8_followup_output(context):
    try:
        # Ensure headers are present on both responses
        assert hasattr(context, "seed_login_response"), "Seed login response missing"
        assert hasattr(
            context, "followup_login_response"
        ), "Follow-up login response missing"

        # Both responses should include X-Expires-After header with a date-time value
        assert context.seed_expires_after_raw is not None, (
            "Seed response missing X-Expires-After header"
        )
        assert context.followup_expires_after_raw is not None, (
            "Follow-up response missing X-Expires-After header"
        )

        assert (
            context.seed_expires_after is not None
        ), "Seed X-Expires-After is not a valid date-time"
        assert (
            context.followup_expires_after is not None
        ), "Follow-up X-Expires-After is not a valid date-time"

        # Metamorphic relation: follow-up expiration >= seed expiration
        assert (
            context.followup_expires_after >= context.seed_expires_after
        ), "Follow-up expiration time is earlier than seed expiration time"
    except AssertionError as e:
        context.step_exception = e
        assert False, f"Assertion error in Then step for MR8: {e}"
    except Exception as e:
        context.step_exception = e
        assert False, f"Error in Then step for MR8: {e}"

# ----

import time



@given('a seed input that retrieves the pet inventory by status, producing a seed output with the current stock levels for each status for MR9.')
def _mr_MR9_seed_input(context):
    # Retrieve the initial inventory safely
    response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError as exc:  # JSON decode error
        raise AssertionError(f"Inventory response is not valid JSON: {exc}") from exc

    if not isinstance(data, dict):
        raise AssertionError(f"Inventory response is not a JSON object, got: {type(data)}")

    # Ensure all quantities are integers to avoid TypeError in arithmetic
    safe_seed = {}
    for status, quantity in data.items():
        try:
            safe_seed[str(status)] = int(quantity)
        except (TypeError, ValueError) as exc:
            raise AssertionError(
                f"Inventory value for status '{status}' is not an integer-like value: {quantity}"
            ) from exc

    context.seed_response = safe_seed


@when('a follow-up input is created by adding or removing one or more pets with specific statuses and then retrieving the inventory again, yielding a follow-up output for MR9.')
def _mr_MR9_followup_input(context):
    # Use a unique ID each run to avoid collisions
    unique_id = int(time.time() * 1000)  # milliseconds since epoch

    new_pet = {
        "id": unique_id,
        "name": "Buddy",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    add_response = requests.post(f"{BASE_URL}/pet", json=new_pet, timeout=10)
    add_response.raise_for_status()

    # Retrieve the updated inventory
    followup_response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    followup_response.raise_for_status()

    try:
        data = followup_response.json()
    except ValueError as exc:
        raise AssertionError(f"Follow-up inventory response is not valid JSON: {exc}") from exc

    if not isinstance(data, dict):
        raise AssertionError(f"Follow-up inventory response is not a JSON object, got: {type(data)}")

    safe_followup = {}
    for status, quantity in data.items():
        try:
            safe_followup[str(status)] = int(quantity)
        except (TypeError, ValueError) as exc:
            raise AssertionError(
                f"Follow-up inventory value for status '{status}' is not an integer-like value: {quantity}"
            ) from exc

    context.followup_response = safe_followup


@then('the follow-up output should reflect the updated stock levels by status, such that for each affected status the quantity has changed consistently with the additions or removals made, compared to the seed output for MR9.')
def _mr_MR9_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is missing from context.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response is missing from context.")

    seed = context.seed_response
    followup = context.followup_response

    if not isinstance(seed, dict):
        raise AssertionError(f"Seed response is not a dict, got: {type(seed)}")
    if not isinstance(followup, dict):
        raise AssertionError(f"Follow-up response is not a dict, got: {type(followup)}")

    # We added exactly one 'available' pet; inventory for 'available' should reflect that change.
    seed_available = int(seed.get("available", 0))
    followup_available = int(followup.get("available", 0))

    if followup_available != seed_available + 1:
        raise AssertionError(
            f"Expected 'available' inventory to increase by 1: "
            f"seed={seed_available}, follow-up={followup_available}"
        )

    # For all other statuses, inventory should remain unchanged
    for status, seed_qty in seed.items():
        if status == "available":
            continue
        followup_qty = followup.get(status)
        if followup_qty is None:
            raise AssertionError(
                f"Status '{status}' present in seed inventory is missing in follow-up inventory."
            )
        if int(followup_qty) != int(seed_qty):
            raise AssertionError(
                f"Inventory for status '{status}' changed unexpectedly: "
                f"seed={seed_qty}, follow-up={followup_qty}"
            )
