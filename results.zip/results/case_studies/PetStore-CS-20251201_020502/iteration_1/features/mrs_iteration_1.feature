Feature: Iteration 1 MRs

  Scenario: MR5 Deleting a user should remove them from subsequent retrievals
    Given a seed input that successfully retrieves a user by their username, producing a seed output that includes the user's details for MR5.
    When a follow-up input is created by deleting the user with that specific username and then attempting to retrieve the user again by the same username, yielding a follow-up output for MR5.
    Then the follow-up output should indicate that the user is not found (for example, via a 'User not found' response), confirming the user has been removed from the system for MR5.

  Scenario: MR7 Updating a user's details should reflect in subsequent retrievals
    Given a seed input that successfully retrieves a user by their username, producing a seed output with the user's current details for MR7.
    When a follow-up input is created by updating the user's details (e.g., email or phone) and then retrieving the user again by the same username, yielding a follow-up output for MR7.
    Then the follow-up output should reflect the updated details for the fields included in the update, and any fields that were not changed as part of the update request should remain the same as in the seed output for MR7, provided the update operation completed successfully.

  Scenario: MR8 Logging in should provide session information with expiration
    Given a seed input that logs a user into the system, producing a seed output that includes a response body and expiration details (such as an expiration header with a date-time value) for MR8.
    When a follow-up input is created by logging in the same user again, yielding a follow-up output for MR8.
    Then the follow-up output should also include expiration details in the response, and, if the service issues a new session on each login, the expiration time in the follow-up output is expected to be greater than or equal to the expiration time in the seed output for MR8.

  Scenario: MR9 Retrieving inventory should reflect current stock levels
    Given a seed input that retrieves the pet inventory by status, producing a seed output with the current stock levels for each status for MR9.
    When a follow-up input is created by adding or removing one or more pets with specific statuses and then retrieving the inventory again, yielding a follow-up output for MR9.
    Then the follow-up output should reflect the updated stock levels by status, such that for each affected status the quantity has changed consistently with the additions or removals made, compared to the seed output for MR9.
