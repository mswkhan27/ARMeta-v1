
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet with a given status should increase the count of pets with that status
    Given a seed input that retrieves pets filtered by status 'available', producing a seed output whose size is the current count of pets with status 'available' for MR1.
    When a follow-up input is created by adding a new pet with status 'available' and then retrieving pets filtered by status 'available' again, yielding a follow-up output for MR1.
    Then the follow-up output should have a count of pets with status 'available' that is exactly one more than the seed output for MR1, assuming no other pets with that status were added, updated, or deleted between the two retrievals.

  Scenario: MR2 Updating a pet's status should be reflected when retrieving that pet by its identifier
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR2.
    When a follow-up input is created by updating the same pet so that its status field is set to 'sold', and the pet is retrieved again by the same identifier, yielding a follow-up output for MR2.
    Then the follow-up output should show the pet's status as 'sold', and fields that were not changed as part of the update request should remain the same as in the seed output for MR2, subject to any server-generated fields.

  Scenario: MR3 Deleting a pet should remove it from subsequent filtered retrievals
    Given a seed input that retrieves pets using a filter, producing a seed output that includes a specific pet identifier for MR3.
    When a follow-up input is created by deleting the pet with that specific identifier and then performing the same filtered retrieval again, yielding a follow-up output for MR3.
    Then the follow-up output should not include the deleted pet identifier, indicating the pet has been removed from the results for that filter for MR3, and retrieving the pet directly by that identifier should indicate that the pet is no longer found.

  Scenario: MR4 Finding pets by tags should return only pets that match the specified tags
    Given a seed input that retrieves pets by a single tag, producing a seed output with a list of pets for MR4.
    When a follow-up input is created by searching using the original tag together with an additional tag, yielding a follow-up output for MR4.
    Then the follow-up output should contain only pets whose tags include at least one of the tags used in the follow-up search, and any pet from the seed output that still satisfies the combined tag criteria should also appear in the follow-up output for MR4.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR5 Deleting a user should remove them from subsequent retrievals
    Given a seed input that successfully retrieves a user by their username, producing a seed output that includes the user's details for MR5.
    When a follow-up input is created by deleting the user with that specific username and then attempting to retrieve the user again by the same username, yielding a follow-up output for MR5.
    Then the follow-up output should indicate that the user is not found (for example, via a 'User not found' response), confirming the user has been removed from the system for MR5.

  Scenario: MR7 Updating a user's details should reflect in subsequent retrievals
    Given a seed input that successfully retrieves a user by their username, producing a seed output with the user's current details for MR7.
    When a follow-up input is created by updating the user's details (e.g., email or phone) and then retrieving the user again by the same username, yielding a follow-up output for MR7.
    Then the follow-up output should reflect the updated details for the fields included in the update, and any fields that were not changed as part of the update request should remain the same as in the seed output for MR7, provided the update operation completed successfully.

  Scenario: MR8 Logging in should provide session information with expiration
    Given a seed input that logs a user into the system, producing a seed output that includes a response body and expiration details (such as an expiration header with a date-time value) for MR8.
    When a follow-up input is created by logging in the same user again, yielding a follow-up output for MR8.
    Then the follow-up output should also include expiration details in the response, and, if the service issues a new session on each login, the expiration time in the follow-up output is expected to be greater than or equal to the expiration time in the seed output for MR8.

  Scenario: MR9 Retrieving inventory should reflect current stock levels
    Given a seed input that retrieves the pet inventory by status, producing a seed output with the current stock levels for each status for MR9.
    When a follow-up input is created by adding or removing one or more pets with specific statuses and then retrieving the inventory again, yielding a follow-up output for MR9.
    Then the follow-up output should reflect the updated stock levels by status, such that for each affected status the quantity has changed consistently with the additions or removals made, compared to the seed output for MR9.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR11 Deleting an order should prevent its successful retrieval
    Given a seed input that retrieves an order by its identifier, producing a seed output that includes the order details for MR11.
    When a follow-up input is created by deleting the order with that specific identifier and then attempting to retrieve the order again by the same identifier, yielding a follow-up output for MR11.
    Then the follow-up output should indicate that the order identifier is invalid or that the order is not found, confirming the order can no longer be retrieved from the system for MR11.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR12 Logging out should invalidate the current session
    Given a seed input that logs a user into the system, producing a seed output that indicates a successful login for MR12.
    When a follow-up input is created by logging out the same user, yielding a follow-up output for MR12.
    Then the follow-up output should indicate a successful logout as defined by the API specification for MR12.

  Scenario: MR13 Uploading an image should succeed for an existing pet
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR13.
    When a follow-up input is created by uploading an image for the same pet using its identifier, yielding a follow-up output for MR13.
    Then the follow-up output should indicate a successful image upload according to the API specification, and it should not indicate that the pet is missing (such as a not-found condition), given that the seed output confirmed the pet exists for MR13.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR14 Creating a list of users should make each user individually retrievable
    Given a seed input that creates a list of new users using the list-based user creation operation, producing a seed output containing the details of the created users for MR14.
    When a follow-up input is created by retrieving each of these users individually by their usernames, yielding a follow-up output for MR14.
    Then the follow-up output should, for each retrieved user, match the corresponding user details from the seed output, ensuring that all users created in the seed input are individually retrievable with consistent data for MR14.

  Scenario: MR15 Uploading an image for a pet should not affect other pet details
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR15.
    When a follow-up input is created by uploading an image for the same pet using its identifier and then retrieving that pet again by the same identifier, yielding a follow-up output for MR15.
    Then the follow-up output should remain identical to the seed output in terms of all stored pet details (such as name, category, photo URLs, tags, and status), as the image upload does not modify these fields for MR15.

  Scenario: MR16 Adding a new pet should increase the inventory count for its status
    Given a seed input that retrieves the current pet inventory by status, producing a seed output with the quantities for each status for MR16.
    When a follow-up input is created by adding a new pet with a specific status and then retrieving the pet inventory by status again, yielding a follow-up output for MR16.
    Then the follow-up output should show that the quantity for the status assigned to the newly added pet has increased by exactly one compared to the seed output, assuming no other changes to pets with that status occurred between the two retrievals for MR16.

  Scenario: MR17 Updating a pet's details should reflect in subsequent retrievals
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR17.
    When a follow-up input is created by updating the pet's details (such as name or status) using its identifier and then retrieving the pet again by the same identifier, yielding a follow-up output for MR17.
    Then the follow-up output should reflect the updated values for the fields included in the update, while any fields that were not changed should remain the same as in the seed output for MR17.

  Scenario: MR18 Deleting a pet should prevent its successful retrieval
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's details for MR18.
    When a follow-up input is created by deleting the pet with that specific identifier and then attempting to retrieve the pet again by the same identifier, yielding a follow-up output for MR18.
    Then the follow-up output should indicate that the pet is not found, confirming that the pet has been removed from the system for MR18.


# --- From iteration_5\features\mrs_iteration_5.feature ---

Feature: Iteration 5 MRs

  Scenario: MR19 Uploading an image for a pet should succeed and return a confirmation
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR19.
    When a follow-up input is created by uploading an image for the same pet using its identifier, yielding a follow-up output for MR19.
    Then the follow-up output should indicate a successful image upload according to the API specification by returning a successful operation response for MR19.

  Scenario: MR20 Adding a new pet should make it retrievable by its identifier
    Given a seed input that retrieves a list of pets based on a valid filter, producing a seed output with the current list of matching pets for MR20.
    When a follow-up input is created by adding a new pet and then retrieving that pet by its identifier, yielding a follow-up output for MR20.
    Then the follow-up output should include the newly added pet with its details matching the input data, confirming the pet is retrievable by its identifier for MR20.

  Scenario: MR21 Uploading an image should not alter the pet's status
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR21.
    When a follow-up input is created by uploading an image for the same pet using its identifier and then retrieving that pet again by the same identifier, yielding a follow-up output for MR21.
    Then the follow-up output should show the pet's status remains unchanged from the seed output, confirming that the image upload operation does not modify the stored status of the pet for MR21.

  Scenario: MR22 Adding a pet should not affect previously retrieved pets
    Given a seed input that retrieves a list of pets based on a valid filter, producing a seed output with the current list of matching pets for MR22.
    When a follow-up input is created by adding a new pet, and then retrieving pets using the same filter, yielding a follow-up output for MR22.
    Then the follow-up output should include the new pet in addition to the pets from the seed output, with the previously retrieved pets remaining unchanged, confirming that adding a new pet does not affect existing pets for MR22.

  Scenario: MR23 Uploading an image should return a specific response code
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR23.
    When a follow-up input is created by uploading an image for the same pet using its identifier, yielding a follow-up output for MR23.
    Then the follow-up output should return a response code indicating a successful operation as defined by the API specification, confirming the image upload was processed correctly for MR23.

