Feature: Iteration 5 MRs

  Scenario: MR19 Uploading an image for a pet should succeed and return a confirmation
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR19.
    When a follow-up input is created by uploading an image for the same pet using its identifier, yielding a follow-up output for MR19.
    Then the follow-up output should indicate a successful image upload according to the API specification by returning a successful operation response for MR19.

  Scenario: MR20 Adding a new pet should make it retrievable by its identifier
    Given a seed input that retrieves a list of pets based on a valid filter, producing a seed output with the current list of matching pets for MR20.
    When a follow-up input is created by adding a new pet and then retrieving that pet by its identifier, yielding a follow-up output for MR20.
    Then the follow-up output should include the newly added pet with its details matching the input data, confirming the pet is retrievable by its identifier for MR20.

  Scenario: MR21 Uploading an image should not alter the pet's status
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR21.
    When a follow-up input is created by uploading an image for the same pet using its identifier and then retrieving that pet again by the same identifier, yielding a follow-up output for MR21.
    Then the follow-up output should show the pet's status remains unchanged from the seed output, confirming that the image upload operation does not modify the stored status of the pet for MR21.

  Scenario: MR22 Adding a pet should not affect previously retrieved pets
    Given a seed input that retrieves a list of pets based on a valid filter, producing a seed output with the current list of matching pets for MR22.
    When a follow-up input is created by adding a new pet, and then retrieving pets using the same filter, yielding a follow-up output for MR22.
    Then the follow-up output should include the new pet in addition to the pets from the seed output, with the previously retrieved pets remaining unchanged, confirming that adding a new pet does not affect existing pets for MR22.

  Scenario: MR23 Uploading an image should return a specific response code
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR23.
    When a follow-up input is created by uploading an image for the same pet using its identifier, yielding a follow-up output for MR23.
    Then the follow-up output should return a response code indicating a successful operation as defined by the API specification, confirming the image upload was processed correctly for MR23.
