from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR19.")
def _mr_MR19_seed_input(context):
    # Create a pet to ensure it exists (matches POST /pet)
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    context.seed_request = response

    # Safely parse JSON
    try:
        context.seed_response = response.json()
    except ValueError:
        context.seed_response = {}

    assert response.status_code == 200, f"Failed to create pet: status={response.status_code}, body={context.seed_response}"


@when("a follow-up input is created by uploading an image for the same pet using its identifier, yielding a follow-up output for MR19.")
def _mr_MR19_followup_input(context):
    # Safely get pet_id from previous response
    pet_id = context.seed_response.get("id")
    assert pet_id is not None, f"seed_response missing 'id': {context.seed_response}"

    # Use a small, known-bytes payload as binary content to avoid filesystem errors
    dummy_image_bytes = b"dummy image bytes for testing upload"

    files = {
        # The spec uses application/octet-stream for the body; `requests` will send this as multipart
        "file": ("dummy.jpg", dummy_image_bytes, "application/octet-stream")
    }

    response = requests.post(
        f"{BASE_URL}/pet/{pet_id}/uploadImage",
        files=files,
        timeout=10
    )
    context.followup_request = response

    # Safely parse JSON
    try:
        context.followup_response = response.json()
    except ValueError:
        context.followup_response = {}

    assert response.status_code == 200, f"Failed to upload image: status={response.status_code}, body={context.followup_response}"


@then("the follow-up output should indicate a successful image upload according to the API specification by returning a successful operation response for MR19.")
def _mr_MR19_followup_output(context):
    # According to /pet/{petId}/uploadImage, 200 returns ApiResponse {code:int, type:string, message:string}
    resp = context.followup_response

    assert isinstance(resp, dict), f"Expected JSON object, got: {resp!r}"
    assert "code" in resp, f"Response does not contain 'code': {resp}"
    assert "message" in resp, f"Response does not contain 'message': {resp}"

    code = resp["code"]
    assert isinstance(code, int), f"'code' should be integer, got: {type(code).__name__} ({code!r})"
    assert code == 200, f"Expected success code 200 but got: {code}"

# ----




@given('a seed input that retrieves a list of pets based on a valid filter, producing a seed output with the current list of matching pets for MR20.')
def _mr_MR20_seed_input(context):
    # Retrieve pets with status 'available' as a valid filter using /pet/findByStatus
    try:
        params = {"status": "available"}
        response = requests.get(f"{BASE_URL}/pet/findByStatus", params=params, timeout=10)
        response.raise_for_status()
        try:
            context.seed_response = response.json()
        except ValueError:
            context.seed_response = []
        context.seed_request = params
    except requests.RequestException as e:
        print(f"Error in Given step for MR20 (request error): {e}")
        raise
    except Exception as e:
        print(f"Unexpected error in Given step for MR20: {e}")
        raise


@when('a follow-up input is created by adding a new pet and then retrieving that pet by its identifier, yielding a follow-up output for MR20.')
def _mr_MR20_followup_input(context):
    try:
        # Create a new pet using POST /pet
        new_pet = {
            "name": "Buddy",
            "photoUrls": ["http://example.com/photo.jpg"],
            "status": "available"
        }

        add_response = requests.post(
            f"{BASE_URL}/pet",
            json=new_pet,
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        add_response.raise_for_status()

        try:
            added_pet = add_response.json()
        except ValueError:
            raise RuntimeError("Add pet response is not valid JSON")

        pet_id = added_pet.get("id")
        if pet_id is None:
            raise RuntimeError("Added pet response does not contain 'id'")

        context.followup_request = new_pet
        context.added_pet = added_pet
        context.pet_id = pet_id

        # Retrieve the newly added pet by ID using GET /pet/{petId}
        get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
        get_response.raise_for_status()
        try:
            context.followup_response = get_response.json()
        except ValueError:
            raise RuntimeError("Get pet by ID response is not valid JSON")

    except requests.RequestException as e:
        print(f"Error in When step for MR20 (request error): {e}")
        raise
    except Exception as e:
        print(f"Unexpected error in When step for MR20: {e}")
        raise


@then('the follow-up output should include the newly added pet with its details matching the input data, confirming the pet is retrievable by its identifier for MR20.')
def _mr_MR20_followup_output(context):
    try:
        followup = getattr(context, "followup_response", None)
        request_pet = getattr(context, "followup_request", None)
        pet_id = getattr(context, "pet_id", None)

        assert isinstance(followup, dict), "Follow-up response is not a JSON object"
        assert isinstance(request_pet, dict), "Follow-up request is not a JSON object"
        assert pet_id is not None, "Pet ID is not set on context"

        # Basic field checks
        assert followup.get("id") == pet_id, "Pet ID does not match"
        assert followup.get("name") == request_pet.get("name"), "Pet name does not match"
        assert followup.get("status") == request_pet.get("status"), "Pet status does not match"

        # photoUrls comparison with type safety
        req_photos = request_pet.get("photoUrls") or []
        resp_photos = followup.get("photoUrls") or []

        if not isinstance(req_photos, list):
            raise AssertionError("Request photoUrls is not a list")
        if not isinstance(resp_photos, list):
            raise AssertionError("Response photoUrls is not a list")

        assert resp_photos == req_photos, "Pet photoUrls do not match"

    except AssertionError as e:
        print(f"Assertion error in Then step for MR20: {e}")
        raise
    except Exception as e:
        print(f"Unexpected error in Then step for MR20: {e}")
        raise

# ----




@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status for MR21.")
def _mr_MR21_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    response.raise_for_status()

    # Safely parse JSON
    try:
        seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Response from POST /pet is not valid JSON: {e}\nBody: {response.text}") from e

    if not isinstance(seed_response, dict):
        raise AssertionError(f"Expected JSON object from POST /pet, got: {type(seed_response)}")

    pet_id = seed_response.get("id")
    if pet_id is None:
        raise AssertionError(f"POST /pet response does not contain 'id': {json.dumps(seed_response, indent=2)}")

    # Now retrieve the pet by its identifier to get the seed output (MR text requirement)
    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    get_response.raise_for_status()

    try:
        get_pet = get_response.json()
    except ValueError as e:
        raise AssertionError(f"Response from GET /pet/{{petId}} is not valid JSON: {e}\nBody: {get_response.text}") from e

    if not isinstance(get_pet, dict):
        raise AssertionError(f"Expected JSON object from GET /pet/{{petId}}, got: {type(get_pet)}")

    # Ensure status field exists
    if "status" not in get_pet:
        raise AssertionError(f"GET /pet/{{petId}} response does not contain 'status': {json.dumps(get_pet, indent=2)}")

    context.seed_request = pet_data
    context.seed_response = get_pet
    context.pet_id = pet_id


@when("a follow-up input is created by uploading an image for the same pet using its identifier and then retrieving that pet again by the same identifier, yielding a follow-up output for MR21.")
def _mr_MR21_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AssertionError("Context is missing 'pet_id' from the Given step.")

    pet_id = context.pet_id

    # Upload an image for the pet using /pet/\{petId\}/uploadImage
    image_data = b"fake_image_data"  # Simulated image data; OpenAPI allows application/octet-stream body
    upload_url = f"{BASE_URL}/pet/{pet_id}/uploadImage"
    upload_response = requests.post(upload_url, data=image_data, timeout=10)
    upload_response.raise_for_status()

    # Retrieve the pet again to get the follow-up output
    get_url = f"{BASE_URL}/pet/{pet_id}"
    followup_response = requests.get(get_url, timeout=10)
    followup_response.raise_for_status()

    try:
        followup_pet = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Response from GET /pet/{{petId}} (follow-up) is not valid JSON: {e}\nBody: {followup_response.text}") from e

    if not isinstance(followup_pet, dict):
        raise AssertionError(f"Expected JSON object from follow-up GET /pet/{{petId}}, got: {type(followup_pet)}")

    if "status" not in followup_pet:
        raise AssertionError(f"Follow-up GET /pet/{{petId}} response does not contain 'status': {json.dumps(followup_pet, indent=2)}")

    context.followup_response = followup_pet


@then("the follow-up output should show the pet's status remains unchanged from the seed output, confirming that the image upload operation does not modify the stored status of the pet for MR21.")
def _mr_MR21_followup_assertion(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Context is missing 'seed_response' from the Given step.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Context is missing 'followup_response' from the When step.")

    seed = context.seed_response
    followup = context.followup_response

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise AssertionError(f"'seed_response' and 'followup_response' must be dicts, got {type(seed)} and {type(followup)}")

    if "status" not in seed:
        raise AssertionError(f"'seed_response' does not contain 'status': {json.dumps(seed, indent=2)}")
    if "status" not in followup:
        raise AssertionError(f"'followup_response' does not contain 'status': {json.dumps(followup, indent=2)}")

    seed_status = seed.get("status")
    followup_status = followup.get("status")

    assert seed_status == followup_status, (
        f"Expected status to remain unchanged after image upload, "
        f"but seed status='{seed_status}' and follow-up status='{followup_status}'."
    )

# ----

from requests.exceptions import RequestException, Timeout



@given('a seed input that retrieves a list of pets based on a valid filter, producing a seed output with the current list of matching pets for MR22.')
def _mr_MR22_seed_input(context):
    # Define the filter for retrieving pets using the documented endpoint:
    # GET /pet/findByStatus (summary: "Finds Pets by status.")
    filter_status = 'available'
    seed_url = f'{BASE_URL}/pet/findByStatus'
    params = {'status': filter_status}

    context.seed_request = {
        'method': 'GET',
        'url': seed_url,
        'params': params
    }

    try:
        response = requests.get(seed_url, params=params, timeout=10)
        response.raise_for_status()
        try:
            data = response.json()
        except ValueError:
            raise AssertionError("Seed response is not valid JSON")

        if not isinstance(data, list):
            raise AssertionError("Seed response JSON is not a list as expected for /pet/findByStatus")

        context.seed_response = response
        context.seed_output = data
    except (RequestException, Timeout) as e:
        raise AssertionError(f"HTTP error in Given step for MR22: {e!r}")


@when('a follow-up input is created by adding a new pet, and then retrieving pets using the same filter, yielding a follow-up output for MR22.')
def _mr_MR22_followup_input(context):
    # Create a new pet using POST /pet (summary: "Add a new pet to the store.")
    new_pet = {
        "name": "NewPet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    add_pet_url = f'{BASE_URL}/pet'
    try:
        add_pet_response = requests.post(add_pet_url, json=new_pet, timeout=10)
        add_pet_response.raise_for_status()
        try:
            added_pet = add_pet_response.json()
        except ValueError:
            raise AssertionError("Add-pet response is not valid JSON")

        if not isinstance(added_pet, dict):
            raise AssertionError("Add-pet response JSON is not an object as expected for POST /pet")

        # Store the created pet (to know its id and to later match it)
        context.added_pet = added_pet

        # Retrieve pets again using the same filter via GET /pet/findByStatus
        followup_url = f'{BASE_URL}/pet/findByStatus'
        params = {'status': 'available'}

        context.followup_request = {
            'method': 'GET',
            'url': followup_url,
            'params': params
        }

        followup_response = requests.get(followup_url, params=params, timeout=10)
        followup_response.raise_for_status()
        try:
            followup_data = followup_response.json()
        except ValueError:
            raise AssertionError("Follow-up response is not valid JSON")

        if not isinstance(followup_data, list):
            raise AssertionError("Follow-up response JSON is not a list as expected for /pet/findByStatus")

        context.followup_response = followup_response
        context.followup_output = followup_data
    except (RequestException, Timeout) as e:
        raise AssertionError(f"HTTP error in When step for MR22: {e!r}")


@then('the follow-up output should include the new pet in addition to the pets from the seed output, with the previously retrieved pets remaining unchanged, confirming that adding a new pet does not affect existing pets for MR22.')
def _mr_MR22_followup_output(context):
    # Defensive checks to avoid AttributeError / TypeError
    if not hasattr(context, 'followup_output') or not hasattr(context, 'seed_output'):
        raise AssertionError("Missing outputs on context; Given/When steps may have failed")

    followup_output = context.followup_output
    seed_output = context.seed_output
    added_pet = getattr(context, 'added_pet', None)

    if not isinstance(followup_output, list):
        raise AssertionError("Follow-up output is not a list")
    if not isinstance(seed_output, list):
        raise AssertionError("Seed output is not a list")
    if not isinstance(added_pet, dict):
        raise AssertionError("Added pet information is not available or not a dict")

    # Prefer matching by id when available, fallback to name if id is missing
    added_id = added_pet.get('id')
    added_name = added_pet.get('name')

    try:
        if added_id is not None:
            # Ensure the new pet (by id) is present in the follow-up output
            new_pet_found = any(
                isinstance(p, dict) and p.get('id') == added_id
                for p in followup_output
            )
        else:
            # Fall back to checking by name if id is not provided
            new_pet_found = any(
                isinstance(p, dict) and p.get('name') == added_name
                for p in followup_output
            )

        assert new_pet_found, "New pet not found in follow-up output"

        # Check that all seed pets are still present in the follow-up output.
        # We match them by 'id' when available; if 'id' is missing, we use a
        # tuple of (name, status) as a weaker identity.
        for seed_pet in seed_output:
            if not isinstance(seed_pet, dict):
                raise AssertionError("Seed pet item is not a JSON object")

            seed_id = seed_pet.get('id')
            if seed_id is not None:
                in_followup = any(
                    isinstance(p, dict) and p.get('id') == seed_id
                    for p in followup_output
                )
            else:
                key = (
                    seed_pet.get('name'),
                    seed_pet.get('status')
                )
                in_followup = any(
                    isinstance(p, dict)
                    and (p.get('name'), p.get('status')) == key
                    for p in followup_output
                )

            assert in_followup, "Seed pet not found in follow-up output"
    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"Unexpected error in Then step for MR22: {e!r}")

# ----




@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR23.")
def _mr_MR23_seed_input(context):
    # Create a pet to ensure it exists, then retrieve it by ID as the seed output
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    # Create or update the pet (POST /pet)
    create_resp = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    try:
        create_json = create_resp.json()
    except ValueError:
        create_json = None

    if create_resp.status_code != 200:
        raise AssertionError(f"Failed to create pet, status={create_resp.status_code}, body={create_json}")

    # Retrieve the pet by ID (GET /pet/\{petId\})
    pet_id = pet_data.get("id")
    if pet_id is None:
        raise AssertionError("Pet ID is missing from seed pet data")

    get_resp = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    try:
        get_json = get_resp.json()
    except ValueError:
        get_json = None

    if get_resp.status_code != 200:
        raise AssertionError(f"Failed to retrieve pet by id, status={get_resp.status_code}, body={get_json}")

    # Store responses safely on context
    context.seed_create_response = create_resp
    context.seed_create_json = create_json
    context.seed_request = get_resp
    context.seed_response = get_json

    if not isinstance(context.seed_response, dict):
        raise AssertionError(f"Expected seed response to be a JSON object, got: {type(context.seed_response)}")


@when("a follow-up input is created by uploading an image for the same pet using its identifier, yielding a follow-up output for MR23.")
def _mr_MR23_followup_input(context):
    # Safely obtain pet_id from seed_response
    seed = getattr(context, "seed_response", None)
    if not isinstance(seed, dict):
        raise AssertionError(f"seed_response missing or invalid, got: {type(seed)}")

    pet_id = seed.get("id")
    if pet_id is None:
        raise AssertionError(f"'id' field missing in seed_response: {json.dumps(seed)}")

    # Select a safe image path; use a tiny generated file if not present
    image_path = os.environ.get("TEST_IMAGE_PATH", "test_image.jpg")
    if not os.path.isfile(image_path):
        # Create a small dummy file to avoid FileNotFoundError
        try:
            with open(image_path, "wb") as f:
                f.write(b"\x89PNG\r\n\x1a\n")
        except OSError as e:
            raise AssertionError(f"Unable to create dummy image file at {image_path}: {e}") from e

    try:
        with open(image_path, "rb") as image_file:
            files = {"file": image_file}
            followup_req = requests.post(
                f"{BASE_URL}/pet/{pet_id}/uploadImage",
                files=files,
                timeout=10,
            )
    except OSError as e:
        raise AssertionError(f"Failed to open image file at {image_path}: {e}") from e

    try:
        followup_json = followup_req.json()
    except ValueError:
        followup_json = None

    context.followup_request = followup_req
    context.followup_response = followup_json

    if followup_req.status_code != 200:
        raise AssertionError(
            f"Failed to upload image, status={followup_req.status_code}, body={followup_json}"
        )


@then("the follow-up output should return a response code indicating a successful operation as defined by the API specification, confirming the image upload was processed correctly for MR23.")
def _mr_MR23_followup_output(context):
    resp = getattr(context, "followup_request", None)
    if resp is None:
        raise AssertionError("followup_request is not set on context")

    # According to the OpenAPI spec, 200 indicates successful operation
    if resp.status_code != 200:
        raise AssertionError(f"Expected HTTP status code 200, got {resp.status_code}")

    # Response body should be ApiResponse; validate shape defensively
    body = getattr(context, "followup_response", None)
    if body is not None and not isinstance(body, dict):
        raise AssertionError(f"Expected follow-up response JSON object, got: {type(body)}")

    # If the body contains a 'code' field, check that it matches HTTP status
    if isinstance(body, dict) and "code" in body:
        try:
            code_value = int(body["code"])
        except (TypeError, ValueError):
            raise AssertionError(f"ApiResponse.code is not an integer: {body['code']}")
        if code_value != 200:
            raise AssertionError(f"Expected ApiResponse.code 200 but got: {code_value}")
