from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


@given('a seed input that retrieves an order by its identifier, producing a seed output that includes the order details for MR11.')
def step_mr_MR11_seed_input(context):
    try:
        # Create an order to ensure it exists
        order_data = {
            "petId": 198772,
            "quantity": 1,
            "status": "placed",
            "complete": False
        }
        response = requests.post(f"{BASE_URL}/store/order", json=order_data, timeout=10)
        context.seed_request = response

        # Ensure the response status code is as expected
        assert response is not None, "No response received from order creation request"
        assert response.status_code == 200, f"Failed to create order: {response.text}"

        # Safely parse JSON
        try:
            seed_response_json = response.json()
        except ValueError:
            assert False, f"Order creation response is not valid JSON: {response.text}"

        assert isinstance(seed_response_json, dict), "Order creation response JSON is not an object"
        order_id = seed_response_json.get('id')
        assert order_id is not None, f"Order creation response missing 'id': {seed_response_json}"

        context.seed_response = seed_response_json
        context.order_id = order_id
    except AssertionError:
        raise
    except Exception as e:
        assert False, f"Unexpected error in Given step for MR11: {str(e)}"


@when('a follow-up input is created by deleting the order with that specific identifier and then attempting to retrieve the order again by the same identifier, yielding a follow-up output for MR11.')
def step_mr_MR11_followup_input(context):
    try:
        order_id = getattr(context, 'order_id', None)
        assert order_id is not None, "order_id not found in context from Given step"

        # Delete the order
        delete_response = requests.delete(f"{BASE_URL}/store/order/{order_id}", timeout=10)
        context.delete_response = delete_response
        assert delete_response is not None, "No response received from delete order request"
        assert delete_response.status_code == 200, f"Failed to delete order: {delete_response.text}"

        # Attempt to retrieve the deleted order
        followup_request = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
        context.followup_request = followup_request

        assert followup_request is not None, "No response received from get deleted order request"

        # Safely parse JSON, but allow non-JSON body
        followup_response_json = None
        if followup_request.headers.get("Content-Type", "").startswith("application/json"):
            try:
                followup_response_json = followup_request.json()
            except ValueError:
                followup_response_json = None

        context.followup_response = followup_response_json
    except AssertionError:
        raise
    except Exception as e:
        assert False, f"Unexpected error in When step for MR11: {str(e)}"


@then('the follow-up output should indicate that the order identifier is invalid or that the order is not found, confirming the order can no longer be retrieved from the system for MR11.')
def step_mr_MR11_followup_output(context):
    try:
        followup_request = getattr(context, 'followup_request', None)
        assert followup_request is not None, "followup_request not found in context"

        # As per OpenAPI, after deletion, retrieval should return 404 (Order not found) or 400 (Invalid ID supplied)
        assert followup_request.status_code in (400, 404), (
            f"Expected status 400 or 404 but got {followup_request.status_code}: {followup_request.text}"
        )

        # If JSON body exists and has a message, optionally check it mentions invalid or not found
        followup_response = getattr(context, 'followup_response', None)
        if isinstance(followup_response, dict):
            message = str(followup_response.get('message', '')).lower()
            # Not all implementations guarantee a message string, so this is a soft check
            if message:
                assert ('not found' in message) or ('invalid' in message), (
                    f"Expected error message to indicate invalid or not found, got: {followup_response}"
                )
    except AssertionError:
        raise
    except Exception as e:
        assert False, f"Unexpected error in Then step for MR11: {str(e)}"
