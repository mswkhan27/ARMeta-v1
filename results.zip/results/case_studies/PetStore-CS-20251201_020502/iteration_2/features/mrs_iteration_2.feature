Feature: Iteration 2 MRs

  Scenario: MR11 Deleting an order should prevent its successful retrieval
    Given a seed input that retrieves an order by its identifier, producing a seed output that includes the order details for MR11.
    When a follow-up input is created by deleting the order with that specific identifier and then attempting to retrieve the order again by the same identifier, yielding a follow-up output for MR11.
    Then the follow-up output should indicate that the order identifier is invalid or that the order is not found, confirming the order can no longer be retrieved from the system for MR11.
