Feature: Iteration 2 MRs

  Scenario: MR11 Generating a salt should produce a new random-like string each time
    Given a seed input that requests a salt generation, producing a seed output with a generated salt string for MR11.
    When a follow-up input is created by requesting another salt generation, yielding a follow-up output for MR11.
    Then the follow-up output's salt string is expected to be different from the seed output's salt string, i.e., multiple salt generation requests should typically return distinct string values for MR11.

  Scenario: MR12 Deleting a permission by key should remove it from the permission list
    Given a seed input that retrieves the current list of permissions, producing a seed output that includes a specific permission identified by its key for MR12.
    When a follow-up input is created by deleting that permission using its key and then retrieving the permission list again, yielding a follow-up output for MR12.
    Then the follow-up output's list of permissions should not include the deleted permission, i.e., it should be a strict subset of the seed output's permission list for MR12.

  Scenario: MR13 Deleting a role by ID should remove it from the role list
    Given a seed input that retrieves the current list of roles, producing a seed output that includes a specific role identified by its ID for MR13.
    When a follow-up input is created by deleting that role using its ID and then retrieving the role list again, yielding a follow-up output for MR13.
    Then the follow-up output's list of roles should not include the deleted role, i.e., it should be a strict subset of the seed output's role list for MR13.

  Scenario: MR14 Removing a permission from a role should exclude the permission from the role's permission list
    Given a seed input that retrieves a specific role's current details by its identifier, producing a seed output that includes the role's existing list of permissions and contains the permission to be removed for MR14.
    When a follow-up input is created by removing that existing permission from the same role, yielding a follow-up output that contains the updated details of that role for MR14.
    Then the follow-up output's list of permissions for that role should contain all permissions from the seed output except the removed permission, i.e., it should be a strict subset of the seed output's permission list for MR14.

  Scenario: MR15 Adding a permission to a role should include the new permission in the role's permission list
    Given a seed input that retrieves a specific role's current details by its identifier, producing a seed output that includes the role's existing list of permissions for MR15.
    When a follow-up input is created by assigning an additional existing permission (not already present in the role) to the same role, yielding a follow-up output that contains the updated details of that role for MR15.
    Then the follow-up output's list of permissions for that role should contain all permissions from the seed output plus the newly assigned permission, i.e., it should be a strict superset of the seed output's permission list for MR15.
