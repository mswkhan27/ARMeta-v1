from behave import given, when, then
import os
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given("a seed input that requests a salt generation, producing a seed output with a generated salt string for MR11.")
def step_mr_MR11_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/salt", timeout=10)
    response.raise_for_status()
    context.seed_response = response.text
    context.seed_request = "GET /users/rbac/salt"


@when("a follow-up input is created by requesting another salt generation, yielding a follow-up output for MR11.")
def step_mr_MR11_followup_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/salt", timeout=10)
    response.raise_for_status()
    context.followup_response = response.text
    context.followup_request = "GET /users/rbac/salt"


@then("the follow-up output's salt string is expected to be different from the seed output's salt string, i.e., multiple salt generation requests should typically return distinct string values for MR11.")
def step_mr_MR11_assert_different(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    if seed is None or followup is None:
        raise AssertionError("Missing seed or follow-up response on context for MR11 comparison.")

    # Both responses are expected to be plain strings per OpenAPI ("type": "string")
    assert isinstance(seed, str), f"Seed response is not a string: {type(seed)}"
    assert isinstance(followup, str), f"Follow-up response is not a string: {type(followup)}"

    assert seed != followup, "The salt strings are the same, which violates the expected behavior."

# ----

import json
from typing import Any, Dict, List

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


def _safe_get_permissions_list(data: Any) -> List[Dict[str, Any]]:
    """
    Safely extract a list of permissions from the API response.
    The OpenAPI spec for GET /users/rbac/permissions returns:
      { "type": "array", "items": { "$ref": "#/definitions/PermissionDTO" } }
    so we expect a JSON array of objects.
    """
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    return []


@given(
    "a seed input that retrieves the current list of permissions, producing a seed output that includes a specific permission identified by its key for MR12."
)
def _mr_MR12_seed_input(context):
    url = f"{BASE_URL}/users/rbac/permissions"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except requests.RequestException as exc:
        raise AssertionError(f"Request to {url} failed: {exc}") from exc

    try:
        raw_json = response.json()
    except ValueError as exc:
        raise AssertionError("Response from /users/rbac/permissions is not valid JSON") from exc

    permissions = _safe_get_permissions_list(raw_json)
    context.seed_permissions = permissions

    if not permissions:
        raise AssertionError("Seed permission list is empty or invalid; cannot perform MR12.")

    # Choose a stable existing permission key from the seed list
    permission_keys = [
        p.get("permission")
        for p in permissions
        if isinstance(p, dict) and isinstance(p.get("permission"), str)
    ]
    if not permission_keys:
        raise AssertionError("No valid 'permission' keys found in seed permission list; cannot perform MR12.")

    context.permission_key = permission_keys[0]

    # Store a set of keys for later subset comparison
    context.seed_permission_keys = set(permission_keys)


@when(
    "a follow-up input is created by deleting that permission using its key and then retrieving the permission list again, yielding a follow-up output for MR12."
)
def _mr_MR12_followup_input(context):
    if not hasattr(context, "permission_key") or not isinstance(context.permission_key, str):
        raise AssertionError("permission_key is not set correctly in context before When step.")

    delete_url = f"{BASE_URL}/users/rbac/permissions/{context.permission_key}"
    try:
        delete_response = requests.delete(delete_url, timeout=10)
        delete_response.raise_for_status()
    except requests.RequestException as exc:
        raise AssertionError(f"DELETE {delete_url} failed: {exc}") from exc

    get_url = f"{BASE_URL}/users/rbac/permissions"
    try:
        followup_response = requests.get(get_url, timeout=10)
        followup_response.raise_for_status()
    except requests.RequestException as exc:
        raise AssertionError(f"Request to {get_url} failed: {exc}") from exc

    try:
        raw_followup_json = followup_response.json()
    except ValueError as exc:
        raise AssertionError("Follow-up response from /users/rbac/permissions is not valid JSON") from exc

    context.followup_permissions = _safe_get_permissions_list(raw_followup_json)
    context.followup_permission_keys = {
        p.get("permission")
        for p in context.followup_permissions
        if isinstance(p, dict) and isinstance(p.get("permission"), str)
    }


@then(
    "the follow-up output's list of permissions should not include the deleted permission, i.e., it should be a strict subset of the seed output's permission list for MR12."
)
def _mr_MR12_assertion(context):
    if not hasattr(context, "seed_permission_keys") or not hasattr(context, "followup_permission_keys"):
        raise AssertionError("Seed or follow-up permission keys are missing from context.")

    seed_keys = context.seed_permission_keys
    followup_keys = context.followup_permission_keys

    if not isinstance(seed_keys, set) or not isinstance(followup_keys, set):
        raise AssertionError("Seed or follow-up permission keys are not sets; internal test error.")

    if not hasattr(context, "permission_key") or not isinstance(context.permission_key, str):
        raise AssertionError("permission_key is not set correctly in context before Then step.")

    deleted_key = context.permission_key

    # The deleted permission key must not be present in the follow-up list
    assert deleted_key not in followup_keys, (
        f"Deleted permission '{deleted_key}' is still present in follow-up permission list."
    )

    # Follow-up permission keys must be a strict subset of the seed permission keys
    assert followup_keys.issubset(seed_keys), (
        "Follow-up permission keys are not a subset of the seed permission keys."
    )
    assert followup_keys != seed_keys, (
        "Follow-up permission keys are equal to seed permission keys; expected a strict subset after deletion."
    )

# ----




@given("a seed input that retrieves the current list of roles, producing a seed output that includes a specific role identified by its ID for MR13.")
def _mr_MR13_seed_input(context):
    # Retrieve the current list of roles
    response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    context.seed_request = response

    if response.status_code != 200:
        raise AssertionError(f"Failed to retrieve roles, status code: {response.status_code}")

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Response is not valid JSON: {e}")

    if not isinstance(data, list):
        raise AssertionError(f"Expected a list of roles, got: {type(data).__name__}")

    # Store the seed response safely
    context.seed_response = data

    # Ensure there is at least one role to delete
    if not data:
        raise AssertionError("No roles available to perform MR13 (role list is empty).")

    # Pick a concrete role that has both 'id' and 'role' keys
    role_id = None
    for role in data:
        if not isinstance(role, dict):
            continue
        if "id" in role and role["id"] is not None:
            role_id = role["id"]
            break

    if role_id is None:
        raise AssertionError("No deletable role with an 'id' field found in the seed output.")

    context.role_id = role_id


@when("a follow-up input is created by deleting that role using its ID and then retrieving the role list again, yielding a follow-up output for MR13.")
def _mr_MR13_followup_input(context):
    if not hasattr(context, "role_id"):
        raise AssertionError("role_id is not set in context before deletion step.")

    # Delete the role using its ID
    delete_url = f"{BASE_URL}/users/rbac/roles/{context.role_id}"
    delete_response = requests.delete(delete_url, timeout=10)

    if delete_response.status_code not in (200, 204):
        raise AssertionError(f"Failed to delete the role, status code: {delete_response.status_code}")

    # Retrieve the role list again
    followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    context.followup_request = followup_response

    if followup_response.status_code != 200:
        raise AssertionError(f"Failed to retrieve roles after deletion, status code: {followup_response.status_code}")

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response is not valid JSON: {e}")

    if not isinstance(followup_data, list):
        raise AssertionError(f"Expected a list of roles after deletion, got: {type(followup_data).__name__}")

    context.followup_response = followup_data


@then("the follow-up output's list of roles should not include the deleted role, i.e., it should be a strict subset of the seed output's role list for MR13.")
def _mr_MR13_followup_output(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AssertionError("Seed or follow-up responses are missing from context.")
    if not hasattr(context, "role_id"):
        raise AssertionError("role_id is missing from context in Then step.")

    role_id = context.role_id
    seed_list = context.seed_response
    followup_list = context.followup_response

    # Build sets of role IDs safely
    def extract_ids(roles):
        ids = set()
        for r in roles:
            if isinstance(r, dict) and "id" in r and r["id"] is not None:
                ids.add(r["id"])
        return ids

    seed_role_ids = extract_ids(seed_list)
    followup_role_ids = extract_ids(followup_list)

    # Assert that the deleted role id was present in the seed list
    if role_id not in seed_role_ids:
        raise AssertionError("Deleted role ID was not present in the original seed role list.")

    # Assert that the deleted role is not in the follow-up output
    if role_id in followup_role_ids:
        raise AssertionError("Deleted role is still present in the follow-up role list.")

    # Assert that the follow-up output is a strict subset of the seed output
    if not followup_role_ids.issubset(seed_role_ids):
        raise AssertionError("Follow-up role IDs are not a subset of seed role IDs.")
    if followup_role_ids == seed_role_ids:
        raise AssertionError("Follow-up role list is not a strict subset (no role was removed).")

# ----




def _safe_get_role(context, role_id):
    url = f"{BASE_URL}/users/rbac/roles/{role_id}"
    response = requests.get(url, timeout=10)
    response.raise_for_status()
    try:
        data = response.json()
    except ValueError as exc:
        raise AssertionError(f"GET {url} did not return valid JSON") from exc
    if not isinstance(data, dict):
        raise AssertionError(f"GET {url} expected JSON object, got {type(data).__name__}")
    return data, response.request


@given("a seed input that retrieves a specific role's current details by its identifier, producing a seed output that includes the role's existing list of permissions and contains the permission to be removed for MR14.")
def _mr_MR14_seed_input(context):
    # Use a deterministic role id; in a real setup this should be provided/created explicitly
    role_id = 1
    context.role_id = role_id

    role_data, req = _safe_get_role(context, role_id)
    context.seed_response = role_data
    context.seed_request = req

    permissions = role_data.get("permissions")
    if not isinstance(permissions, list) or not permissions:
        raise AssertionError("Seed role has no permissions list or it is empty.")

    first_permission = permissions[0]
    if not isinstance(first_permission, dict):
        raise AssertionError("Permission entry is not an object as expected.")

    permission_key = first_permission.get("permission")
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError("Permission object does not contain a valid 'permission' key.")

    context.permission_to_remove = permission_key


@when("a follow-up input is created by removing that existing permission from the same role, yielding a follow-up output that contains the updated details of that role for MR14.")
def _mr_MR14_followup_input(context):
    if not hasattr(context, "role_id"):
        raise AssertionError("role_id is not set in context from Given step.")
    if not hasattr(context, "permission_to_remove"):
        raise AssertionError("permission_to_remove is not set in context from Given step.")

    role_id = context.role_id
    permission_key = context.permission_to_remove

    # Use the removePermissionOnRole operation: DELETE /users/rbac/roles/{roleId}/permissions/{permissionKey}
    url = f"{BASE_URL}/users/rbac/roles/{role_id}/permissions/{permission_key}"
    response = requests.delete(url, timeout=10)
    response.raise_for_status()

    try:
        followup_data = response.json()
    except ValueError:
        # The API is specified to return RoleDTO on 200, but if no body is returned, treat as empty object.
        followup_data = {}

    if followup_data and not isinstance(followup_data, dict):
        raise AssertionError(f"DELETE {url} expected JSON object or empty body, got {type(followup_data).__name__}")

    context.followup_response = followup_data
    context.followup_request = response.request


@then("the follow-up output's list of permissions for that role should contain all permissions from the seed output except the removed permission, i.e., it should be a strict subset of the seed output's permission list for MR14.")
def _mr_MR14_followup_output(context):
    if not hasattr(context, "role_id"):
        raise AssertionError("role_id is not set in context from previous steps.")
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response is not set in context from Given step.")
    if not hasattr(context, "permission_to_remove"):
        raise AssertionError("permission_to_remove is not set in context from Given step.")

    role_id = context.role_id
    updated_role, _ = _safe_get_role(context, role_id)

    updated_permissions_raw = updated_role.get("permissions", [])
    if not isinstance(updated_permissions_raw, list):
        raise AssertionError("Updated role 'permissions' field is not a list.")

    # Extract permission strings safely
    updated_permissions = []
    for perm in updated_permissions_raw:
        if isinstance(perm, dict):
            key = perm.get("permission")
            if isinstance(key, str):
                updated_permissions.append(key)

    original_permissions_raw = context.seed_response.get("permissions", [])
    if not isinstance(original_permissions_raw, list):
        raise AssertionError("Seed role 'permissions' field is not a list.")

    original_permissions = []
    for perm in original_permissions_raw:
        if isinstance(perm, dict):
            key = perm.get("permission")
            if isinstance(key, str):
                original_permissions.append(key)

    if context.permission_to_remove in updated_permissions:
        raise AssertionError("The removed permission is still present in the role's permissions.")

    if not all(perm in original_permissions for perm in updated_permissions):
        raise AssertionError("The updated permissions are not a subset of the original permissions.")

    if len(updated_permissions) >= len(original_permissions):
        raise AssertionError("Updated permissions are not a strict subset; size did not decrease.")

# ----




@given("a seed input that retrieves a specific role's current details by its identifier, producing a seed output that includes the role's existing list of permissions for MR15.")
def _mr_MR15_seed_input(context):
    role_id = 1  # Replace with actual role ID if needed
    url = f"{BASE_URL}/users/rbac/roles/{role_id}"

    response = requests.get(url, timeout=10)
    response.raise_for_status()

    data = response.json()
    if not isinstance(data, dict):
        raise AssertionError("Seed response is not a JSON object.")

    # Ensure permissions field exists and is a list
    permissions = data.get("permissions", [])
    if permissions is None:
        permissions = []
    if not isinstance(permissions, list):
        raise AssertionError("Seed response 'permissions' field is not a list.")

    context.seed_response = {
        "id": data.get("id"),
        "permissions": permissions,
        "raw": data,
    }
    context.seed_request = {"roleId": role_id}


@when("a follow-up input is created by assigning an additional existing permission (not already present in the role) to the same role, yielding a follow-up output that contains the updated details of that role for MR15.")
def _mr_MR15_followup_input(context):
    seed_request = getattr(context, "seed_request", None)
    seed_response = getattr(context, "seed_response", None)

    if not isinstance(seed_request, dict) or "roleId" not in seed_request:
        raise AssertionError("Seed request with 'roleId' not found in context.")
    if not isinstance(seed_response, dict) or "permissions" not in seed_response:
        raise AssertionError("Seed response with 'permissions' not found in context.")

    role_id = seed_request["roleId"]

    # Get current role permissions as a set of strings (robustly)
    seed_permissions_list = seed_response.get("permissions") or []
    seed_permission_keys = set()
    for p in seed_permissions_list:
        if isinstance(p, dict):
            key = p.get("permission")
        elif isinstance(p, str):
            key = p
        else:
            key = None
        if isinstance(key, str):
            seed_permission_keys.add(key)

    # Fetch all available permissions
    permissions_url = f"{BASE_URL}/users/rbac/permissions"
    permissions_response = requests.get(permissions_url, timeout=10)
    permissions_response.raise_for_status()

    all_permissions = permissions_response.json()
    if not isinstance(all_permissions, list):
        raise AssertionError("Permissions list response is not a JSON array.")

    new_permission_key = None
    for perm in all_permissions:
        if isinstance(perm, dict):
            candidate = perm.get("permission")
        elif isinstance(perm, str):
            candidate = perm
        else:
            candidate = None
        if isinstance(candidate, str) and candidate not in seed_permission_keys:
            new_permission_key = candidate
            break

    if not isinstance(new_permission_key, str):
        raise AssertionError("No new permission found to add.")

    # Add the new permission to the role
    add_url = f"{BASE_URL}/users/rbac/roles/{role_id}/permissions/{new_permission_key}"
    add_permission_response = requests.post(add_url, timeout=10)
    add_permission_response.raise_for_status()

    follow_data = add_permission_response.json()
    if not isinstance(follow_data, dict):
        raise AssertionError("Follow-up response is not a JSON object.")

    follow_permissions = follow_data.get("permissions", [])
    if follow_permissions is None:
        follow_permissions = []
    if not isinstance(follow_permissions, list):
        raise AssertionError("Follow-up response 'permissions' field is not a list.")

    context.followup_response = {
        "id": follow_data.get("id"),
        "permissions": follow_permissions,
        "raw": follow_data,
    }
    context.followup_request = {
        "roleId": role_id,
        "newPermission": new_permission_key,
    }


@then("the follow-up output's list of permissions for that role should contain all permissions from the seed output plus the newly assigned permission, i.e., it should be a strict superset of the seed output's permission list for MR15.")
def _mr_MR15_assert_permissions(context):
    seed_response = getattr(context, "seed_response", None)
    followup_response = getattr(context, "followup_response", None)
    followup_request = getattr(context, "followup_request", None)

    if not isinstance(seed_response, dict) or "permissions" not in seed_response:
        raise AssertionError("Seed response with 'permissions' not found in context.")
    if not isinstance(followup_response, dict) or "permissions" not in followup_response:
        raise AssertionError("Follow-up response with 'permissions' not found in context.")
    if not isinstance(followup_request, dict) or "newPermission" not in followup_request:
        raise AssertionError("Follow-up request with 'newPermission' not found in context.")

    seed_permissions_list = seed_response.get("permissions") or []
    follow_permissions_list = followup_response.get("permissions") or []

    # Normalize to sets of permission keys (strings), robust to mixed representations
    def extract_keys(perms):
        keys = set()
        for p in perms:
            if isinstance(p, dict):
                key = p.get("permission")
            elif isinstance(p, str):
                key = p
            else:
                key = None
            if isinstance(key, str):
                keys.add(key)
        return keys

    seed_permission_set = extract_keys(seed_permissions_list)
    follow_permission_set = extract_keys(follow_permissions_list)

    new_permission = followup_request["newPermission"]

    if not isinstance(new_permission, str):
        raise AssertionError("Stored 'newPermission' is not a string.")

    if new_permission not in follow_permission_set:
        raise AssertionError("Newly added permission is not present in follow-up permissions.")

    if not seed_permission_set.issubset(follow_permission_set):
        raise AssertionError("Follow-up permissions do not include all seed permissions.")

    if len(follow_permission_set) <= len(seed_permission_set):
        raise AssertionError("Follow-up permissions are not a strict superset of seed permissions.")
