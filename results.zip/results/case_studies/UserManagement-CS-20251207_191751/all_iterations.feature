
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a role to a user should include the new role in the user's role list
    Given a seed input that retrieves a specific user's current details, producing a seed output that includes the user's existing list of roles for MR1.
    When a follow-up input is created by assigning an additional existing role to the same user, yielding a follow-up output for MR1.
    Then the follow-up output's list of roles for that user should contain all roles from the seed output plus the newly assigned role, i.e., it should be a strict superset of the seed output's role list for MR1.

  Scenario: MR2 Removing a role from a user should exclude the role from the user's role list
    Given a seed input that retrieves a specific user's current details, producing a seed output that includes the user's existing list of roles (including the role to be removed) for MR2.
    When a follow-up input is created by removing one of the existing roles from the same user, yielding a follow-up output for MR2.
    Then the follow-up output's list of roles for that user should contain all roles from the seed output except the removed role, i.e., it should be a strict subset of the seed output's role list for MR2.

  Scenario: MR3 Updating user information should only change the updated fields
    Given a seed input that retrieves a specific user's current information, producing a seed output with the complete set of the user's details for MR3.
    When a follow-up input is created to update the same user by sending values identical to the seed output for all fields except one field whose value is changed, yielding a follow-up output for MR3.
    Then the follow-up output should differ from the seed output only in the field whose value was changed in the update request; all other fields should match for MR3.

  Scenario: MR4 Creating a new user should increase the total user count
    Given a seed input that retrieves the current list of users, producing a seed output with the total number of users returned by the listing operation for MR4.
    When a follow-up input is created by successfully creating a new user account, after which the list of users is retrieved again, yielding a follow-up output for MR4.
    Then the follow-up output should have a total number of users that is exactly one more than in the seed output for MR4, assuming the creation request completed without error.

  Scenario: MR5 Deleting a user should decrease the total user count
    Given a seed input that retrieves the current list of users, producing a seed output with the total number of users returned by the listing operation for MR5, including the user that will be deleted.
    When a follow-up input is created by successfully deleting an existing user from this list, after which the list of users is retrieved again, yielding a follow-up output for MR5.
    Then the follow-up output should have a total number of users that is exactly one less than in the seed output for MR5, assuming the deletion request completed without error and targeted a user present in the seed list.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR6 Deleting a permission should remove it from the permission list
    Given a seed input that retrieves the current list of permissions via the permission-listing operation, producing a seed output with the total number of permissions including a specific permission that is eligible for deletion for MR6.
    When a follow-up input is created by successfully deleting that existing permission (identified from the seed output), after which the list of permissions is retrieved again in the same way, yielding a follow-up output for MR6.
    Then the follow-up output should have a total number of permissions that is exactly one less than in the seed output for MR6, assuming the deletion request completed without error and targeted a permission present in the seed list.

  Scenario: MR7 Adding a permission to a role should include the new permission in the role's permission list
    Given a seed input that retrieves a specific role's current details, producing a seed output that includes the role's existing list of permissions for MR7.
    When a follow-up input is created by successfully assigning an additional existing permission, identified by its key, to the same role and then retrieving the updated role details, yielding a follow-up output for MR7.
    Then the follow-up output's list of permissions for that role should contain all permissions from the seed output plus the newly assigned permission, i.e., it should be a strict superset of the seed output's permission list for MR7, assuming the assignment request completed without error.

  Scenario: MR8 Removing a permission from a role should exclude the permission from the role's permission list
    Given a seed input that retrieves a specific role's current details, producing a seed output that includes the role's existing list of permissions (including the permission to be removed, identified by its key) for MR8.
    When a follow-up input is created by successfully removing one of the existing permissions, using its key, from the same role and then retrieving the updated role details, yielding a follow-up output for MR8.
    Then the follow-up output's list of permissions for that role should contain all permissions from the seed output except the removed permission, i.e., it should be a strict subset of the seed output's permission list for MR8, assuming the removal request completed without error.

  Scenario: MR9 Creating a new role should increase the total role count
    Given a seed input that retrieves the current list of roles via the role-listing operation, producing a seed output with the total number of roles returned by the listing operation for MR9.
    When a follow-up input is created by successfully creating a new role with a role identifier not present in the seed list, after which the list of roles is retrieved again in the same way, yielding a follow-up output for MR9.
    Then the follow-up output should have a total number of roles that is exactly one more than in the seed output for MR9, assuming the creation request completed without error.

  Scenario: MR10 Deleting a role should decrease the total role count
    Given a seed input that retrieves the current list of roles via the role-listing operation, producing a seed output with the total number of roles returned by the listing operation for MR10, including a specific role that will be deleted.
    When a follow-up input is created by successfully deleting an existing role, identified by an id present in the seed list, after which the list of roles is retrieved again in the same way, yielding a follow-up output for MR10.
    Then the follow-up output should have a total number of roles that is exactly one less than in the seed output for MR10, assuming the deletion request completed without error and targeted a role present in the seed list.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR11 Generating a salt should produce a new random-like string each time
    Given a seed input that requests a salt generation, producing a seed output with a generated salt string for MR11.
    When a follow-up input is created by requesting another salt generation, yielding a follow-up output for MR11.
    Then the follow-up output's salt string is expected to be different from the seed output's salt string, i.e., multiple salt generation requests should typically return distinct string values for MR11.

  Scenario: MR12 Deleting a permission by key should remove it from the permission list
    Given a seed input that retrieves the current list of permissions, producing a seed output that includes a specific permission identified by its key for MR12.
    When a follow-up input is created by deleting that permission using its key and then retrieving the permission list again, yielding a follow-up output for MR12.
    Then the follow-up output's list of permissions should not include the deleted permission, i.e., it should be a strict subset of the seed output's permission list for MR12.

  Scenario: MR13 Deleting a role by ID should remove it from the role list
    Given a seed input that retrieves the current list of roles, producing a seed output that includes a specific role identified by its ID for MR13.
    When a follow-up input is created by deleting that role using its ID and then retrieving the role list again, yielding a follow-up output for MR13.
    Then the follow-up output's list of roles should not include the deleted role, i.e., it should be a strict subset of the seed output's role list for MR13.

  Scenario: MR14 Removing a permission from a role should exclude the permission from the role's permission list
    Given a seed input that retrieves a specific role's current details by its identifier, producing a seed output that includes the role's existing list of permissions and contains the permission to be removed for MR14.
    When a follow-up input is created by removing that existing permission from the same role, yielding a follow-up output that contains the updated details of that role for MR14.
    Then the follow-up output's list of permissions for that role should contain all permissions from the seed output except the removed permission, i.e., it should be a strict subset of the seed output's permission list for MR14.

  Scenario: MR15 Adding a permission to a role should include the new permission in the role's permission list
    Given a seed input that retrieves a specific role's current details by its identifier, producing a seed output that includes the role's existing list of permissions for MR15.
    When a follow-up input is created by assigning an additional existing permission (not already present in the role) to the same role, yielding a follow-up output that contains the updated details of that role for MR15.
    Then the follow-up output's list of permissions for that role should contain all permissions from the seed output plus the newly assigned permission, i.e., it should be a strict superset of the seed output's permission list for MR15.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR16 Logging in with valid credentials should return a consistent user object
    Given a seed input that contains valid login credentials, producing a seed output with a UserDTO object representing the authenticated user for MR16.
    When a follow-up input is created by using the same valid login credentials, yielding a follow-up output with a UserDTO object for MR16.
    Then the follow-up output should contain a UserDTO whose stable fields (such as id, username, name, surname, enabled, secured, roles, permissions, and other non-temporal attributes) match those in the seed output for MR16; only temporal fields like loginDt may differ between outputs for MR16.

  Scenario: MR17 Creating a permission should increase the total permission count
    Given a seed input that retrieves the current list of permissions, producing a seed output with the total number of permissions for MR17.
    When a follow-up input is created by successfully creating a new permission, after which the list of permissions is retrieved again, yielding a follow-up output for MR17.
    Then the follow-up output should have a total number of permissions that is exactly one more than in the seed output for MR17, assuming the creation request completed without error.

  Scenario: MR18 Deleting a role by ID should remove it from the role list
    Given a seed input that retrieves the current list of roles, producing a seed output that includes a specific role identified by its ID for MR18.
    When a follow-up input is created by deleting that role using its ID and then retrieving the role list again, yielding a follow-up output for MR18.
    Then the follow-up output's list of roles should not include the deleted role, i.e., it should be a strict subset of the seed output's role list for MR18.

  Scenario: MR19 Updating a permission should only change the updated fields
    Given a seed input that retrieves a specific permission's current details, producing a seed output with the complete set of the permission's details for MR19.
    When a follow-up input is created to update the same permission by sending values identical to the seed output for all fields except one field whose value is changed, yielding a follow-up output for MR19.
    Then the follow-up output should differ from the seed output only in the field whose value was changed in the update request; all other fields should match for MR19.

  Scenario: MR20 Removing a permission from a role should exclude the permission from the role's permission list
    Given a seed input that retrieves a specific role's current details, producing a seed output that includes the role's existing list of permissions (including the permission to be removed) for MR20.
    When a follow-up input is created by successfully removing one of the existing permissions from the same role, yielding a follow-up output for MR20.
    Then the follow-up output's list of permissions for that role should contain all permissions from the seed output except the removed permission, i.e., it should be a strict subset of the seed output's permission list for MR20.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR21 Deleting an error should result in an empty or generic response
    Given a seed input that retrieves the current error state using the GET method on the corresponding resource, producing a seed output with the error details for MR21.
    When a follow-up input is created by deleting the same error state using the DELETE method on the same resource, yielding a follow-up output for MR21.
    Then the follow-up output should return either a 204 No Content status or a 200 OK status with a generic object body, indicating the delete request for the error state has been processed for MR21.

  Scenario: MR22 Deleting a permission by key should result in a no content or generic response
    Given a seed input that retrieves a specific permission by its key using the GET method on the corresponding resource, producing a seed output with the permission details for MR22.
    When a follow-up input is created by deleting the same permission using the DELETE method on the same resource with that key, yielding a follow-up output for MR22.
    Then the follow-up output should return either a 204 No Content status or a 200 OK status with a generic object body, indicating the delete request for the permission has been processed for MR22.

  Scenario: MR23 Deleting a role by ID should result in a no content or generic response
    Given a seed input that retrieves a specific role by its ID using the GET method on the corresponding resource, producing a seed output with the role details for MR23.
    When a follow-up input is created by deleting the same role using the DELETE method on the same resource with that ID, yielding a follow-up output for MR23.
    Then the follow-up output should return either a 204 No Content status or a 200 OK status with a generic object body, indicating the delete request for the role has been processed for MR23.

  Scenario: MR24 Retrieving error details should return a consistent error object when the error state is unchanged
    Given a seed input that retrieves the current error details using the GET method on the corresponding resource, producing a seed output with the error object for MR24.
    When a follow-up input is created by retrieving the error details again using the same GET method without changing the underlying error condition, yielding a follow-up output for MR24.
    Then the follow-up output should contain an error object that matches the structure and values of the seed output, indicating consistent error details for MR24 when the state is unchanged.

  Scenario: MR25 Retrieving a permission by key should return a consistent permission object when unchanged
    Given a seed input that retrieves a specific permission by its key using the GET method on the corresponding resource, producing a seed output with the permission object for MR25.
    When a follow-up input is created by retrieving the same permission by its key again using the same GET method without modifying that permission in between, yielding a follow-up output for MR25.
    Then the follow-up output should contain a permission object that matches the seed output, indicating consistent permission details for MR25 when the permission has not been modified.

