Feature: Iteration 4 MRs

  Scenario: MR21 Deleting an error should result in an empty or generic response
    Given a seed input that retrieves the current error state using the GET method on the corresponding resource, producing a seed output with the error details for MR21.
    When a follow-up input is created by deleting the same error state using the DELETE method on the same resource, yielding a follow-up output for MR21.
    Then the follow-up output should return either a 204 No Content status or a 200 OK status with a generic object body, indicating the delete request for the error state has been processed for MR21.

  Scenario: MR22 Deleting a permission by key should result in a no content or generic response
    Given a seed input that retrieves a specific permission by its key using the GET method on the corresponding resource, producing a seed output with the permission details for MR22.
    When a follow-up input is created by deleting the same permission using the DELETE method on the same resource with that key, yielding a follow-up output for MR22.
    Then the follow-up output should return either a 204 No Content status or a 200 OK status with a generic object body, indicating the delete request for the permission has been processed for MR22.

  Scenario: MR23 Deleting a role by ID should result in a no content or generic response
    Given a seed input that retrieves a specific role by its ID using the GET method on the corresponding resource, producing a seed output with the role details for MR23.
    When a follow-up input is created by deleting the same role using the DELETE method on the same resource with that ID, yielding a follow-up output for MR23.
    Then the follow-up output should return either a 204 No Content status or a 200 OK status with a generic object body, indicating the delete request for the role has been processed for MR23.

  Scenario: MR24 Retrieving error details should return a consistent error object when the error state is unchanged
    Given a seed input that retrieves the current error details using the GET method on the corresponding resource, producing a seed output with the error object for MR24.
    When a follow-up input is created by retrieving the error details again using the same GET method without changing the underlying error condition, yielding a follow-up output for MR24.
    Then the follow-up output should contain an error object that matches the structure and values of the seed output, indicating consistent error details for MR24 when the state is unchanged.

  Scenario: MR25 Retrieving a permission by key should return a consistent permission object when unchanged
    Given a seed input that retrieves a specific permission by its key using the GET method on the corresponding resource, producing a seed output with the permission object for MR25.
    When a follow-up input is created by retrieving the same permission by its key again using the same GET method without modifying that permission in between, yielding a follow-up output for MR25.
    Then the follow-up output should contain a permission object that matches the seed output, indicating consistent permission details for MR25 when the permission has not been modified.
