from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the current error state using the GET method on the corresponding resource, producing a seed output with the error details for MR21.')
def step_mr_MR21_seed_input(context):
    url = f"{BASE_URL}/error"
    try:
        response = requests.get(url, timeout=10)
        # We allow any 2xx here but will store safely
        context.seed_response = response
        try:
            context.seed_body = response.json()
        except ValueError:
            context.seed_body = None
        context.seed_request = response.request
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Request failed in Given step for MR21: {e}") from e


@when('a follow-up input is created by deleting the same error state using the DELETE method on the same resource, yielding a follow-up output for MR21.')
def step_mr_MR21_followup_input(context):
    url = f"{BASE_URL}/error"
    try:
        response = requests.delete(url, timeout=10)
        context.followup_response = response
        context.followup_request = response.request
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Request failed in When step for MR21: {e}") from e


@then('the follow-up output should return either a 204 No Content status or a 200 OK status with a generic object body, indicating the delete request for the error state has been processed for MR21.')
def step_mr_MR21_followup_output(context):
    response = getattr(context, "followup_response", None)
    assert response is not None, "followup_response is not set on context"

    status = response.status_code
    assert status in (200, 204), (
        f"Expected status code 204 or 200, but got {status}"
    )

    if status == 200:
        # Safely parse JSON; if invalid, this will fail with a clear message
        try:
            followup_body = response.json()
        except ValueError as e:
            raise AssertionError(f"Expected JSON body for 200 OK, but could not parse it: {e}") from e
        assert isinstance(followup_body, dict), "Expected a generic object body (JSON object) in the response"

# ----




@given('a seed input that retrieves a specific permission by its key using the GET method on the corresponding resource, producing a seed output with the permission details for MR22.')
def step_mr_MR22_seed_input(context):
    permission_key = "example_permission_key"  # Replace with a valid permission key if needed
    context.permission_key = permission_key  # store so Given/When share the same key
    context.seed_request = {
        "method": "GET",
        "url": f"{BASE_URL}/users/rbac/permissions/{permission_key}"
    }
    try:
        response = requests.get(context.seed_request["url"], timeout=10)
        # Do not call raise_for_status here to avoid unexpected exceptions on non-2xx
        context.seed_response = response
        # Safely parse JSON if possible, otherwise store None
        try:
            context.seed_response_body = response.json()
        except (ValueError, json.JSONDecodeError):
            context.seed_response_body = None
    except requests.exceptions.RequestException as e:
        # Surface the error as an assertion failure instead of raw exception
        assert False, f"RequestException in GET for MR22: {e}"


@when('a follow-up input is created by deleting the same permission using the DELETE method on the same resource with that key, yielding a follow-up output for MR22.')
def step_mr_MR22_followup_input(context):
    # Reuse the same permission key from the Given step
    permission_key = getattr(context, "permission_key", "example_permission_key")
    context.followup_request = {
        "method": "DELETE",
        "url": f"{BASE_URL}/users/rbac/permissions/{permission_key}"
    }
    try:
        response = requests.delete(context.followup_request["url"], timeout=10)
        context.followup_response = response
    except requests.exceptions.RequestException as e:
        assert False, f"RequestException in DELETE for MR22: {e}"


@then('the follow-up output should return either a 204 No Content status or a 200 OK status with a generic object body, indicating the delete request for the permission has been processed for MR22.')
def step_mr_MR22_followup_output(context):
    response = getattr(context, "followup_response", None)
    assert response is not None, "followup_response is missing in context"

    status_code = getattr(response, "status_code", None)
    assert status_code is not None, "Response has no status_code attribute"
    assert status_code in (200, 204), (
        f"Expected status code 204 or 200, but got {status_code}"
    )

    if status_code == 200:
        # Safely parse JSON and check it is a dict (generic object body)
        try:
            body = response.json()
        except (ValueError, json.JSONDecodeError):
            assert False, "Expected a JSON object body in the 200 OK response, but response body is not valid JSON"
        assert isinstance(body, dict), "Expected a generic object body (JSON object) in the 200 OK response"

# ----




@given('a seed input that retrieves a specific role by its ID using the GET method on the corresponding resource, producing a seed output with the role details for MR23.')
def step_mr_MR23_seed_input(context):
    # Create a role to ensure it exists for retrieval and deletion
    role_data = {"role": "TestRole"}
    create_response = requests.post(f"{BASE_URL}/users/rbac/roles", json=role_data, timeout=10)

    # Ensure creation succeeded and response body is JSON with an 'id'
    create_response.raise_for_status()
    try:
        created_role = create_response.json()
    except ValueError as e:
        raise AssertionError(f"Create role response is not valid JSON: {e}, body: {create_response.text!r}")

    if not isinstance(created_role, dict):
        raise AssertionError(f"Expected created role to be a JSON object, got: {type(created_role).__name__}")

    role_id = created_role.get('id')
    if role_id is None:
        raise AssertionError(f"Created role JSON does not contain 'id': {json.dumps(created_role)}")

    context.role_id = role_id

    # Retrieve the role by ID using GET /users/rbac/roles/{roleId}
    get_response = requests.get(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
    get_response.raise_for_status()

    # Validate that the seed response is JSON with role details
    try:
        seed_body = get_response.json()
    except ValueError as e:
        raise AssertionError(f"Get role response is not valid JSON: {e}, body: {get_response.text!r}")

    if not isinstance(seed_body, dict):
        raise AssertionError(f"Expected role details as JSON object, got: {type(seed_body).__name__}")

    context.seed_response = seed_body


@when('a follow-up input is created by deleting the same role using the DELETE method on the same resource with that ID, yielding a follow-up output for MR23.')
def step_mr_MR23_followup_input(context):
    if not hasattr(context, 'role_id'):
        raise AssertionError("role_id is not set in context; Given step may have failed.")

    delete_response = requests.delete(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
    context.followup_response = delete_response


@then('the follow-up output should return either a 204 No Content status or a 200 OK status with a generic object body, indicating the delete request for the role has been processed for MR23.')
def step_mr_MR23_followup_output(context):
    if not hasattr(context, 'followup_response'):
        raise AssertionError("followup_response is not set in context; When step may have failed.")

    status_code = context.followup_response.status_code
    assert status_code in (200, 204), (
        f"Expected status code 204 or 200, but got {status_code}"
    )

    # If 200 OK, body should be a generic JSON object (per OpenAPI: type: object)
    if status_code == 200:
        try:
            body = context.followup_response.json()
        except ValueError as e:
            raise AssertionError(
                f"Expected JSON body for 200 OK delete response, but got parse error: {e}, "
                f"body: {context.followup_response.text!r}"
            )

        if not isinstance(body, dict):
            raise AssertionError(
                f"Expected generic JSON object for 200 OK delete response, got: {type(body).__name__}"
            )

# ----

import time



def _safe_get_json(response):
    """
    Safely extract JSON from a response.
    Returns a dict (or an empty dict) instead of raising ValueError/TypeError.
    """
    try:
        data = response.json()
        if isinstance(data, dict):
            return data
        # If JSON is valid but not an object, wrap it or normalize to dict
        return {"_value": data}
    except (ValueError, TypeError):
        # Response is not JSON; fall back to text to avoid TypeError in later steps
        return {"_text": getattr(response, "text", "")}


@given('a seed input that retrieves the current error details using the GET method on the corresponding resource, producing a seed output with the error object for MR24.')
def _mr_MR24_seed_input(context):
    try:
        response = requests.get(f"{BASE_URL}/error", timeout=10)
        response.raise_for_status()
        context.seed_response = _safe_get_json(response)
        context.seed_request = response.request
    except requests.exceptions.RequestException as e:
        print(f"Error in GIVEN step for MR24: {e}")
        raise


@when('a follow-up input is created by retrieving the error details again using the same GET method without changing the underlying error condition, yielding a follow-up output for MR24.')
def _mr_MR24_followup_input(context):
    try:
        response = requests.get(f"{BASE_URL}/error", timeout=10)
        response.raise_for_status()
        context.followup_response = _safe_get_json(response)
        context.followup_request = response.request
    except requests.exceptions.RequestException as e:
        print(f"Error in WHEN step for MR24: {e}")
        raise


@then('the follow-up output should contain an error object that matches the structure and values of the seed output, indicating consistent error details for MR24 when the state is unchanged.')
def _mr_MR24_assert_consistency(context):
    try:
        # Ensure attributes exist to avoid AttributeError
        seed = getattr(context, "seed_response", None)
        followup = getattr(context, "followup_response", None)

        assert isinstance(seed, dict), "Seed response is not a valid object (dict expected)"
        assert isinstance(followup, dict), "Follow-up response is not a valid object (dict expected)"

        assert seed == followup, "Follow-up output does not match seed output"
    except AssertionError as e:
        print(f"Assertion error in THEN step for MR24: {e}")
        raise

# ----




@given('a seed input that retrieves a specific permission by its key using the GET method on the corresponding resource, producing a seed output with the permission object for MR25.')
def _mr_MR25_seed_input(context):
    permission_key = "MR25"  # Example permission key for MR25

    url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        try:
            context.seed_response = response.json()
        except ValueError:
            context.seed_response = response.text
        context.seed_request = {
            "method": response.request.method,
            "url": response.request.url,
            "headers": dict(response.request.headers),
            "body": response.request.body.decode("utf-8") if isinstance(response.request.body, (bytes, bytearray)) else response.request.body,
        }
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in GIVEN step for MR25 when calling {url}: {e}") from e


@when('a follow-up input is created by retrieving the same permission by its key again using the same GET method without modifying that permission in between, yielding a follow-up output for MR25.')
def _mr_MR25_followup_input(context):
    permission_key = "MR25"  # Example permission key for MR25

    url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        try:
            context.followup_response = response.json()
        except ValueError:
            context.followup_response = response.text
        context.followup_request = {
            "method": response.request.method,
            "url": response.request.url,
            "headers": dict(response.request.headers),
            "body": response.request.body.decode("utf-8") if isinstance(response.request.body, (bytes, bytearray)) else response.request.body,
        }
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in WHEN step for MR25 when calling {url}: {e}") from e


@then('the follow-up output should contain a permission object that matches the seed output, indicating consistent permission details for MR25 when the permission has not been modified.')
def _mr_MR25_assertion(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is missing in context for MR25.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response is missing in context for MR25.")

    try:
        seed_serialized = json.dumps(context.seed_response, sort_keys=True)
        followup_serialized = json.dumps(context.followup_response, sort_keys=True)
    except (TypeError, ValueError) as e:
        raise AssertionError(f"Failed to serialize responses for comparison in MR25: {e}") from e

    if seed_serialized != followup_serialized:
        raise AssertionError(
            "Follow-up output does not match seed output for MR25.\n"
            f"Seed: {seed_serialized}\nFollow-up: {followup_serialized}"
        )
