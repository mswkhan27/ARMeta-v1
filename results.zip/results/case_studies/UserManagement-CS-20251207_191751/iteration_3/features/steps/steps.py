from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that contains valid login credentials, producing a seed output with a UserDTO object representing the authenticated user for MR16.')
def _mr_MR16_seed_input(context):
    context.seed_request = {
        "username": "valid_user",
        "password": "valid_password"
    }
    response = requests.post(
        f"{BASE_URL}/login",
        json=context.seed_request,
        timeout=10
    )
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError:
        raise AssertionError("Seed response is not valid JSON")

    if not isinstance(data, dict):
        raise AssertionError(f"Expected seed response to be a JSON object, got {type(data).__name__}")

    context.seed_response = data


@when('a follow-up input is created by using the same valid login credentials, yielding a follow-up output with a UserDTO object for MR16.')
def _mr_MR16_followup_input(context):
    if not hasattr(context, "seed_request") or not isinstance(context.seed_request, dict):
        raise AssertionError("seed_request is missing or invalid in context")

    response = requests.post(
        f"{BASE_URL}/login",
        json=context.seed_request,
        timeout=10
    )
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError:
        raise AssertionError("Follow-up response is not valid JSON")

    if not isinstance(data, dict):
        raise AssertionError(f"Expected follow-up response to be a JSON object, got {type(data).__name__}")

    context.followup_response = data


@then('the follow-up output should contain a UserDTO whose stable fields (such as id, username, name, surname, enabled, secured, roles, permissions, and other non-temporal attributes) match those in the seed output for MR16; only temporal fields like loginDt may differ between outputs for MR16.')
def _mr_MR16_followup_output(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("seed_response is missing or invalid in context")
    if not hasattr(context, "followup_response") or not isinstance(context.followup_response, dict):
        raise AssertionError("followup_response is missing or invalid in context")

    stable_fields = ['id', 'username', 'name', 'surname', 'enabled', 'secured', 'roles', 'permissions']

    for field in stable_fields:
        seed_value = context.seed_response.get(field, None)
        follow_value = context.followup_response.get(field, None)
        assert follow_value == seed_value, f"Mismatch in field '{field}': seed={seed_value}, follow-up={follow_value}"

    seed_login_dt = context.seed_response.get('loginDt')
    follow_login_dt = context.followup_response.get('loginDt')

    if seed_login_dt is None or follow_login_dt is None:
        raise AssertionError("Expected 'loginDt' to be present in both responses")

    assert follow_login_dt != seed_login_dt, "loginDt should differ between outputs"

# ----

import time



@given('a seed input that retrieves the current list of permissions, producing a seed output with the total number of permissions for MR17.')
def step_mr_MR17_seed_input(context):
    url = f"{BASE_URL}/users/rbac/permissions"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()

        # Ensure data is a list to avoid TypeError on len()
        if not isinstance(data, list):
            raise TypeError(f"Expected list of permissions, got {type(data).__name__}: {json.dumps(data, default=str)}")

        context.seed_response = data
        context.seed_request = response.request
        context.seed_output_count = len(data)
    except Exception as e:
        print(f"Error in Given step for MR17 on {url}: {e}")
        raise


@when('a follow-up input is created by successfully creating a new permission, after which the list of permissions is retrieved again, yielding a follow-up output for MR17.')
def step_mr_MR17_followup_input(context):
    url_permissions = f"{BASE_URL}/users/rbac/permissions"

    # Use a unique permission key based on time to reduce risk of conflicts
    unique_suffix = str(int(time.time() * 1000))
    new_permission = {
        "permission": f"mr17_permission_{unique_suffix}",
        "enabled": True,
        "note": "This is a new permission created for MR17"
    }

    try:
        create_response = requests.post(url_permissions, json=new_permission, timeout=10)
        create_response.raise_for_status()

        followup_response = requests.get(url_permissions, timeout=10)
        followup_response.raise_for_status()
        data = followup_response.json()

        if not isinstance(data, list):
            raise TypeError(f"Expected list of permissions, got {type(data).__name__}: {json.dumps(data, default=str)}")

        context.followup_response = data
        context.followup_request = followup_response.request
        context.followup_output_count = len(data)
    except Exception as e:
        print(f"Error in When step for MR17 on {url_permissions}: {e}")
        raise


@then('the follow-up output should have a total number of permissions that is exactly one more than in the seed output for MR17, assuming the creation request completed without error.')
def step_mr_MR17_followup_output(context):
    try:
        seed_count = getattr(context, 'seed_output_count', None)
        followup_count = getattr(context, 'followup_output_count', None)

        if not isinstance(seed_count, int):
            raise TypeError(f"seed_output_count must be int, got {type(seed_count).__name__}")
        if not isinstance(followup_count, int):
            raise TypeError(f"followup_output_count must be int, got {type(followup_count).__name__}")

        assert followup_count == seed_count + 1, (
            f"Expected {seed_count + 1} permissions after creation, "
            f"but got {followup_count}."
        )
    except Exception as e:
        print(f"Error in Then step for MR17: {e}")
        raise

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


@given("a seed input that retrieves the current list of roles, producing a seed output that includes a specific role identified by its ID for MR18.")
def step_mr_MR18_seed_input(context):
    # Retrieve the current list of roles
    response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    context.seed_status_code = response.status_code

    try:
        data = response.json()
    except ValueError:
        data = []

    # According to the OpenAPI spec, on success this endpoint returns an array of RoleDTO
    if context.seed_status_code == 200 and isinstance(data, list):
        context.seed_response = data
    else:
        context.seed_response = []

    # Ensure at least one role exists so we can delete it
    if not context.seed_response:
        raise AssertionError(
            f"No roles available to perform MR18. Status code: {context.seed_status_code}, body: {data}"
        )

    # Safely pick the first role that has both 'id' and 'role' fields
    role_id = None
    for role in context.seed_response:
        if isinstance(role, dict) and "id" in role and role["id"] is not None:
            role_id = role["id"]
            break

    if role_id is None:
        raise AssertionError(
            f"Could not find a valid role with an 'id' in the seed output. Seed output: {context.seed_response}"
        )

    context.role_id = role_id


@when("a follow-up input is created by deleting that role using its ID and then retrieving the role list again, yielding a follow-up output for MR18.")
def step_mr_MR18_followup_input(context):
    if not hasattr(context, "role_id"):
        raise AssertionError("role_id is not set in context from the Given step.")

    # Ensure role_id is int-compatible for the path parameter /users/rbac/roles/{roleId}
    try:
        role_id_int = int(context.role_id)
    except (TypeError, ValueError):
        raise AssertionError(f"role_id is not a valid integer: {context.role_id!r}")

    delete_url = f"{BASE_URL}/users/rbac/roles/{role_id_int}"
    delete_response = requests.delete(delete_url, timeout=10)
    context.delete_status_code = delete_response.status_code

    # Acceptable success codes per spec: 200 or 204
    if context.delete_status_code not in (200, 204):
        try:
            delete_body = delete_response.json()
        except ValueError:
            delete_body = delete_response.text
        raise AssertionError(
            f"Failed to delete role with id {role_id_int}. "
            f"Status code: {context.delete_status_code}, body: {delete_body}"
        )

    # Retrieve the role list again
    followup_request = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    context.followup_status_code = followup_request.status_code

    try:
        followup_data = followup_request.json()
    except ValueError:
        followup_data = []

    if context.followup_status_code == 200 and isinstance(followup_data, list):
        context.followup_response = followup_data
    else:
        context.followup_response = []
        raise AssertionError(
            f"Failed to retrieve roles after deletion. "
            f"Status code: {context.followup_status_code}, body: {followup_data}"
        )


@then("the follow-up output's list of roles should not include the deleted role, i.e., it should be a strict subset of the seed output's role list for MR18.")
def step_mr_MR18_followup_output(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AssertionError("Seed or follow-up responses are missing from context.")

    try:
        deleted_role_id = int(context.role_id)
    except (TypeError, ValueError):
        raise AssertionError(f"role_id is not a valid integer: {context.role_id!r}")

    # Build sets of role IDs safely
    def extract_ids(roles):
        ids = set()
        for role in roles:
            if isinstance(role, dict) and "id" in role and role["id"] is not None:
                try:
                    ids.add(int(role["id"]))
                except (TypeError, ValueError):
                    # Skip roles with non-integer IDs instead of failing with TypeError/ValueError
                    continue
        return ids

    seed_role_ids = extract_ids(context.seed_response)
    followup_role_ids = extract_ids(context.followup_response)

    if deleted_role_id not in seed_role_ids:
        raise AssertionError(
            f"The role with id {deleted_role_id} was not present in the seed output role IDs: {seed_role_ids}"
        )

    # Assert that the deleted role is not in the follow-up output
    if deleted_role_id in followup_role_ids:
        raise AssertionError(
            f"Deleted role with id {deleted_role_id} is still present in follow-up role IDs: {followup_role_ids}"
        )

    # Assert that the follow-up output's role IDs form a strict subset of the seed output's role IDs
    if not followup_role_ids.issubset(seed_role_ids):
        raise AssertionError(
            f"Follow-up role IDs are not a subset of seed role IDs. "
            f"Seed: {seed_role_ids}, Follow-up: {followup_role_ids}"
        )

    if followup_role_ids == seed_role_ids:
        raise AssertionError(
            "Follow-up role IDs are equal to seed role IDs; expected a strict subset after deletion."
        )

# ----




@given("a seed input that retrieves a specific permission's current details, producing a seed output with the complete set of the permission's details for MR19.")
def _mr_MR19_seed_input(context):
    # Create a permission so we have a concrete object to work with
    permission_data = {
        "enabled": True,
        "note": "Initial permission note",
        "permission": "initial_permission",
        "id": None,  # Explicitly allow None; server may ignore or overwrite
    }

    response = requests.post(
        f"{BASE_URL}/users/rbac/permissions",
        json=permission_data,
        timeout=10,
    )
    context.seed_request = response

    # Basic safety checks to avoid TypeError / ValueError later
    if response.status_code != 200:
        raise AssertionError(
            f"Failed to create permission: status={response.status_code}, body={response.text}"
        )

    try:
        seed_json = response.json()
    except ValueError as exc:
        raise AssertionError(f"Seed response is not valid JSON: {exc} | body={response.text}")

    if not isinstance(seed_json, dict):
        raise AssertionError(f"Expected seed response to be a JSON object, got: {type(seed_json)}")

    # Ensure we have at least the fields defined in PermissionDTO, if present
    for field in ["id", "enabled", "note", "permission"]:
        # Do not enforce presence strictly; just avoid KeyError later
        seed_json.setdefault(field, None)

    context.seed_response = seed_json


@when("a follow-up input is created to update the same permission by sending values identical to the seed output for all fields except one field whose value is changed, yielding a follow-up output for MR19.")
def _mr_MR19_followup_input(context):
    seed = getattr(context, "seed_response", None)
    if not isinstance(seed, dict):
        raise AssertionError("Seed response is missing or not a JSON object")

    # Copy the seed safely
    updated_permission_data = dict(seed)
    # Change exactly one field: note
    original_note = updated_permission_data.get("note")
    new_note = "Updated permission note" if original_note != "Updated permission note" else "Updated permission note 2"
    updated_permission_data["note"] = new_note

    response = requests.put(
        f"{BASE_URL}/users/rbac/permissions",
        json=updated_permission_data,
        timeout=10,
    )
    context.followup_request = response

    if response.status_code != 200:
        raise AssertionError(
            f"Failed to update permission: status={response.status_code}, body={response.text}"
        )

    try:
        followup_json = response.json()
    except ValueError as exc:
        raise AssertionError(f"Follow-up response is not valid JSON: {exc} | body={response.text}")

    if not isinstance(followup_json, dict):
        raise AssertionError(f"Expected follow-up response to be a JSON object, got: {type(followup_json)}")

    # Align keys to avoid KeyError: any missing key in follow-up is set to None
    for key in seed.keys():
        followup_json.setdefault(key, None)

    context.followup_response = followup_json


@then("the follow-up output should differ from the seed output only in the field whose value was changed in the update request; all other fields should match for MR19.")
def _mr_MR19_followup_output(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise AssertionError("Seed or follow-up response is missing or not a JSON object")

    # Check that the changed field ('note') is actually different
    seed_note = seed.get("note")
    followup_note = followup.get("note")
    if seed_note == followup_note:
        raise AssertionError(
            f"The 'note' field should be different after the update. seed={seed_note}, followup={followup_note}"
        )

    # Compare all other common keys; ignore keys that appear only in one of the responses
    seed_keys = set(seed.keys())
    followup_keys = set(followup.keys())
    common_keys = seed_keys.intersection(followup_keys)

    for key in common_keys:
        if key == "note":
            continue
        if followup.get(key) != seed.get(key):
            raise AssertionError(
                f"The field '{key}' should match the seed output. "
                f"seed={seed.get(key)!r}, followup={followup.get(key)!r}"
            )

# ----




@given(
    "a seed input that retrieves a specific role's current details, producing a seed output that includes the role's existing list of permissions (including the permission to be removed) for MR20."
)
def step_mr_MR20_seed_input(context):
    # Create a role to ensure it exists
    role_data = {"role": "TestRole_MR20"}
    role_resp = requests.post(f"{BASE_URL}/users/rbac/roles", json=role_data, timeout=10)
    try:
        role_resp.raise_for_status()
    except Exception as e:
        raise AssertionError(f"Failed to create role for MR20: {e}, response={role_resp.text}")

    role_json = {}
    try:
        role_json = role_resp.json() if role_resp.content else {}
    except ValueError:
        raise AssertionError(f"Role creation did not return valid JSON: {role_resp.text}")

    role_id = role_json.get("id")
    if role_id is None:
        raise AssertionError(f"Role id missing in createRole response: {role_json}")
    context.role_id = role_id

    # Ensure the role has at least one permission to remove:
    # 1. Create a permission
    perm_payload = {
        "permission": "MR20_TEST_PERMISSION",
        "note": "Permission for MR20 test",
        "enabled": True,
    }
    perm_resp = requests.post(f"{BASE_URL}/users/rbac/permissions", json=perm_payload, timeout=10)
    try:
        perm_resp.raise_for_status()
    except Exception as e:
        raise AssertionError(f"Failed to create permission for MR20: {e}, response={perm_resp.text}")

    try:
        perm_json = perm_resp.json() if perm_resp.content else {}
    except ValueError:
        raise AssertionError(f"Permission creation did not return valid JSON: {perm_resp.text}")

    permission_key = perm_json.get("permission")
    if not permission_key:
        raise AssertionError(f"Permission key missing in createPermission response: {perm_json}")
    context.permission_key = permission_key

    # 2. Add the permission to the role
    add_perm_resp = requests.post(
        f"{BASE_URL}/users/rbac/roles/{context.role_id}/permissions/{permission_key}",
        timeout=10,
    )
    try:
        add_perm_resp.raise_for_status()
    except Exception as e:
        raise AssertionError(
            f"Failed to add permission to role for MR20: {e}, response={add_perm_resp.text}"
        )

    # 3. Retrieve the role's current details as seed output
    seed_resp = requests.get(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
    try:
        seed_resp.raise_for_status()
    except Exception as e:
        raise AssertionError(
            f"Failed to get role details for MR20: {e}, response={seed_resp.text}"
        )

    try:
        seed_json = seed_resp.json() if seed_resp.content else {}
    except ValueError:
        raise AssertionError(f"Role details did not return valid JSON: {seed_resp.text}")

    permissions = seed_json.get("permissions")
    if permissions is None:
        permissions = []
    if not isinstance(permissions, list):
        raise AssertionError(f"'permissions' field is not a list in role details: {seed_json}")

    context.seed_role = seed_json
    context.seed_permissions = permissions

    # Ensure there is at least one permission to remove
    if not context.seed_permissions:
        raise AssertionError(
            "No permissions available on the role after setup; cannot run MR20."
        )


@when(
    "a follow-up input is created by successfully removing one of the existing permissions from the same role, yielding a follow-up output for MR20."
)
def step_mr_MR20_followup_input(context):
    # Choose a permission to remove from the seed permissions
    # Permissions are PermissionDTO objects: {id, permission, note, enabled}
    permission_obj = context.seed_permissions[0]
    if not isinstance(permission_obj, dict):
        raise AssertionError(f"Permission object is not a dict: {permission_obj}")

    permission_key = permission_obj.get("permission")
    if not permission_key:
        raise AssertionError(f"'permission' key missing in permission object: {permission_obj}")

    context.removed_permission_key = permission_key

    # Remove the permission from the role
    del_resp = requests.delete(
        f"{BASE_URL}/users/rbac/roles/{context.role_id}/permissions/{permission_key}",
        timeout=10,
    )
    try:
        del_resp.raise_for_status()
    except Exception as e:
        raise AssertionError(
            f"Failed to remove permission from role for MR20: {e}, response={del_resp.text}"
        )

    # Store follow-up role state after removal (by re-fetching the role)
    follow_role_resp = requests.get(
        f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10
    )
    try:
        follow_role_resp.raise_for_status()
    except Exception as e:
        raise AssertionError(
            f"Failed to get updated role details for MR20: {e}, response={follow_role_resp.text}"
        )

    try:
        follow_role_json = follow_role_resp.json() if follow_role_resp.content else {}
    except ValueError:
        raise AssertionError(
            f"Updated role details did not return valid JSON: {follow_role_resp.text}"
        )

    follow_permissions = follow_role_json.get("permissions")
    if follow_permissions is None:
        follow_permissions = []
    if not isinstance(follow_permissions, list):
        raise AssertionError(
            f"'permissions' field is not a list in updated role details: {follow_role_json}"
        )

    context.follow_role = follow_role_json
    context.follow_permissions = follow_permissions


@then(
    "the follow-up output's list of permissions for that role should contain all permissions from the seed output except the removed permission, i.e., it should be a strict subset of the seed output's permission list for MR20."
)
def step_mr_MR20_followup_output(context):
    # Build sets of permission keys for comparison
    seed_perm_keys = []
    for p in context.seed_permissions:
        if isinstance(p, dict):
            key = p.get("permission")
            if key is not None:
                seed_perm_keys.append(key)

    follow_perm_keys = []
    for p in context.follow_permissions:
        if isinstance(p, dict):
            key = p.get("permission")
            if key is not None:
                follow_perm_keys.append(key)

    removed_key = context.removed_permission_key

    # 1. The removed permission must not be in the follow-up list
    assert removed_key not in follow_perm_keys, (
        f"Removed permission '{removed_key}' is still present in the updated permissions: "
        f"{follow_perm_keys}"
    )

    # 2. Every permission in the follow-up list must have been present in the seed list
    missing_from_seed = [k for k in follow_perm_keys if k not in seed_perm_keys]
    assert not missing_from_seed, (
        "Updated permissions contain entries not present in seed permissions: "
        f"{missing_from_seed}"
    )

    # 3. The follow-up permission set must be a strict subset of the seed set
    seed_set = set(seed_perm_keys)
    follow_set = set(follow_perm_keys)

    assert follow_set.issubset(seed_set), (
        f"Follow-up permissions are not a subset of seed permissions. "
        f"seed={seed_set}, follow={follow_set}"
    )
    assert follow_set != seed_set, (
        "Follow-up permissions are not a strict subset of seed permissions "
        f"(no permission appears to have been removed). seed={seed_set}, follow={follow_set}"
    )
