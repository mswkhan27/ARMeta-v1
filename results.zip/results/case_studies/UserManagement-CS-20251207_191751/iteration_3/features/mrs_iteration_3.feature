Feature: Iteration 3 MRs

  Scenario: MR16 Logging in with valid credentials should return a consistent user object
    Given a seed input that contains valid login credentials, producing a seed output with a UserDTO object representing the authenticated user for MR16.
    When a follow-up input is created by using the same valid login credentials, yielding a follow-up output with a UserDTO object for MR16.
    Then the follow-up output should contain a UserDTO whose stable fields (such as id, username, name, surname, enabled, secured, roles, permissions, and other non-temporal attributes) match those in the seed output for MR16; only temporal fields like loginDt may differ between outputs for MR16.

  Scenario: MR17 Creating a permission should increase the total permission count
    Given a seed input that retrieves the current list of permissions, producing a seed output with the total number of permissions for MR17.
    When a follow-up input is created by successfully creating a new permission, after which the list of permissions is retrieved again, yielding a follow-up output for MR17.
    Then the follow-up output should have a total number of permissions that is exactly one more than in the seed output for MR17, assuming the creation request completed without error.

  Scenario: MR18 Deleting a role by ID should remove it from the role list
    Given a seed input that retrieves the current list of roles, producing a seed output that includes a specific role identified by its ID for MR18.
    When a follow-up input is created by deleting that role using its ID and then retrieving the role list again, yielding a follow-up output for MR18.
    Then the follow-up output's list of roles should not include the deleted role, i.e., it should be a strict subset of the seed output's role list for MR18.

  Scenario: MR19 Updating a permission should only change the updated fields
    Given a seed input that retrieves a specific permission's current details, producing a seed output with the complete set of the permission's details for MR19.
    When a follow-up input is created to update the same permission by sending values identical to the seed output for all fields except one field whose value is changed, yielding a follow-up output for MR19.
    Then the follow-up output should differ from the seed output only in the field whose value was changed in the update request; all other fields should match for MR19.

  Scenario: MR20 Removing a permission from a role should exclude the permission from the role's permission list
    Given a seed input that retrieves a specific role's current details, producing a seed output that includes the role's existing list of permissions (including the permission to be removed) for MR20.
    When a follow-up input is created by successfully removing one of the existing permissions from the same role, yielding a follow-up output for MR20.
    Then the follow-up output's list of permissions for that role should contain all permissions from the seed output except the removed permission, i.e., it should be a strict subset of the seed output's permission list for MR20.
