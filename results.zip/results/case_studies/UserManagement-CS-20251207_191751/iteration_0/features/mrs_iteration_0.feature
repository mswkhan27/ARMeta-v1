Feature: Iteration 0 MRs

  Scenario: MR1 Adding a role to a user should include the new role in the user's role list
    Given a seed input that retrieves a specific user's current details, producing a seed output that includes the user's existing list of roles for MR1.
    When a follow-up input is created by assigning an additional existing role to the same user, yielding a follow-up output for MR1.
    Then the follow-up output's list of roles for that user should contain all roles from the seed output plus the newly assigned role, i.e., it should be a strict superset of the seed output's role list for MR1.

  Scenario: MR2 Removing a role from a user should exclude the role from the user's role list
    Given a seed input that retrieves a specific user's current details, producing a seed output that includes the user's existing list of roles (including the role to be removed) for MR2.
    When a follow-up input is created by removing one of the existing roles from the same user, yielding a follow-up output for MR2.
    Then the follow-up output's list of roles for that user should contain all roles from the seed output except the removed role, i.e., it should be a strict subset of the seed output's role list for MR2.

  Scenario: MR3 Updating user information should only change the updated fields
    Given a seed input that retrieves a specific user's current information, producing a seed output with the complete set of the user's details for MR3.
    When a follow-up input is created to update the same user by sending values identical to the seed output for all fields except one field whose value is changed, yielding a follow-up output for MR3.
    Then the follow-up output should differ from the seed output only in the field whose value was changed in the update request; all other fields should match for MR3.

  Scenario: MR4 Creating a new user should increase the total user count
    Given a seed input that retrieves the current list of users, producing a seed output with the total number of users returned by the listing operation for MR4.
    When a follow-up input is created by successfully creating a new user account, after which the list of users is retrieved again, yielding a follow-up output for MR4.
    Then the follow-up output should have a total number of users that is exactly one more than in the seed output for MR4, assuming the creation request completed without error.

  Scenario: MR5 Deleting a user should decrease the total user count
    Given a seed input that retrieves the current list of users, producing a seed output with the total number of users returned by the listing operation for MR5, including the user that will be deleted.
    When a follow-up input is created by successfully deleting an existing user from this list, after which the list of users is retrieved again, yielding a follow-up output for MR5.
    Then the follow-up output should have a total number of users that is exactly one less than in the seed output for MR5, assuming the deletion request completed without error and targeted a user present in the seed list.
