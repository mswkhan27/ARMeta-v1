from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


def safe_get_json(response):
    try:
        return response.json()
    except ValueError:
        return {}


@given("a seed input that retrieves a specific user's current details, producing a seed output that includes the user's existing list of roles for MR1.")
def step_mr_MR1_seed_input(context):
    user_id = 1  # fixed seed user ID for the MR

    response = requests.get(f"{BASE_URL}/users/{user_id}", timeout=10)
    context.seed_response_raw = response
    context.seed_response = safe_get_json(response)

    assert response.status_code == 200, (
        f"Failed to retrieve user details: {response.status_code} {response.text}"
    )

    # Ensure roles is always a list to avoid TypeError later
    roles = context.seed_response.get("roles")
    if not isinstance(roles, list):
        roles = [] if roles is None else [roles]
    context.seed_roles = set(roles)


@when("a follow-up input is created by assigning an additional existing role to the same user, yielding a follow-up output for MR1.")
def step_mr_MR1_followup_input(context):
    user_id = 1
    role_id = 2  # assumed existing role ID as per MR intent

    response = requests.post(
        f"{BASE_URL}/users/{user_id}/roles/{role_id}",
        timeout=10,
    )
    context.followup_response_raw = response
    context.followup_response = safe_get_json(response)

    assert response.status_code in (200, 201), (
        f"Failed to add role: {response.status_code} {response.text}"
    )

    # Refresh user details after adding the role to avoid mismatch
    final_response = requests.get(f"{BASE_URL}/users/{user_id}", timeout=10)
    context.final_response_raw = final_response
    context.final_response = safe_get_json(final_response)

    assert final_response.status_code == 200, (
        f"Failed to retrieve updated user details: "
        f"{final_response.status_code} {final_response.text}"
    )

    # Normalize final roles
    final_roles = context.final_response.get("roles")
    if not isinstance(final_roles, list):
        final_roles = [] if final_roles is None else [final_roles]
    context.final_roles = set(final_roles)

    # Store the role identifier we just tried to add, using its string form
    context.added_role_identifier = str(role_id)


@then("the follow-up output's list of roles for that user should contain all roles from the seed output plus the newly assigned role, i.e., it should be a strict superset of the seed output's role list for MR1.")
def step_mr_MR1_followup_output(context):
    seed_roles = getattr(context, "seed_roles", set())
    final_roles = getattr(context, "final_roles", set())
    added_role_identifier = getattr(context, "added_role_identifier", None)

    # Cast role identifiers to string for comparison since RoleDTO.role is a string
    seed_roles_str = {str(r) for r in seed_roles}
    final_roles_str = {str(r) for r in final_roles}

    expected_roles = set(seed_roles_str)
    if added_role_identifier is not None:
        expected_roles.add(added_role_identifier)

    assert final_roles_str.issuperset(seed_roles_str), (
        f"Final roles {final_roles_str} are not a superset of seed roles {seed_roles_str}"
    )

    if added_role_identifier is not None:
        assert added_role_identifier in final_roles_str, (
            f"Newly assigned role '{added_role_identifier}' is not present "
            f"in final roles {final_roles_str}"
        )

    assert final_roles_str != seed_roles_str, (
        "Final roles are not a strict superset of seed roles "
        f"(both are {final_roles_str})"
    )

# ----




def _safe_json(response):
    try:
        return response.json()
    except ValueError:
        return None


@given(
    "a seed input that retrieves a specific user's current details, producing a seed output that includes the user's existing list of roles (including the role to be removed) for MR2."
)
def step_mr_MR2_seed_input(context):
    try:
        # Create a user for testing (fields allowed by CreateOrUpdateUserDTO)
        user_data = {
            "username": "testuser_mr2",
            "password": "password",
            "email": "testuser_mr2@example.com",
            "name": "Test",
            "surname": "User",
            "enabled": True,
        }
        create_resp = requests.post(
            f"{BASE_URL}/users", json=user_data, timeout=10
        )
        create_json = _safe_json(create_resp)

        assert create_resp.status_code in (
            200,
            201,
        ), f"Failed to create user: status={create_resp.status_code}, body={create_resp.text}"

        assert isinstance(create_json, dict), "Create user response JSON is not an object"
        user_id = create_json.get("id")
        assert isinstance(user_id, int), f"User id is missing or not an integer: {user_id}"

        context.user_id = user_id

        # Get current roles for the user
        get_user_resp = requests.get(
            f"{BASE_URL}/users/{user_id}", timeout=10
        )
        get_user_json = _safe_json(get_user_resp)

        assert get_user_resp.status_code == 200, (
            f"Failed to retrieve user details: status={get_user_resp.status_code}, "
            f"body={get_user_resp.text}"
        )
        assert isinstance(get_user_json, dict), "Get user response JSON is not an object"

        seed_roles = get_user_json.get("roles") or []
        assert isinstance(
            seed_roles, list
        ), f"'roles' field is not a list in seed response: {type(seed_roles)}"

        # If there are no roles, MR2 cannot be executed meaningfully
        assert (
            len(seed_roles) > 0
        ), "No roles found on the user; MR2 requires at least one existing role to remove."

        context.seed_user = get_user_json
        context.seed_roles = list(seed_roles)
        # Choose a role to remove; we only keep the role value, not assuming ID types
        context.role_to_remove = context.seed_roles[0]

    except Exception as e:
        print(f"Error in Given step for MR2: {e}")
        assert False


@when(
    "a follow-up input is created by removing one of the existing roles from the same user, yielding a follow-up output for MR2."
)
def step_mr_MR2_followup_input(context):
    try:
        user_id = context.user_id
        role_to_remove = context.role_to_remove

        # The API to remove a role from a user is DELETE /users/{id}/roles/{roleId}
        # roleId must be an integer (int64). We must not pass a string role name here.
        # We need to find a matching roleId from the available roles via RBAC endpoints.
        # Since the user's "roles" field is an array of strings, there is no direct mapping
        # from the string to roleId in the OpenAPI spec; MR2 cannot reliably remove
        # a specific role by ID. To keep this safe and TypeError-free, we will:
        # - attempt to interpret the stored role_to_remove as an integer ID if possible
        # - only call the DELETE endpoint if that succeeds

        role_id = None
        try:
            # try parsing as integer if it was an ID-like value
            role_id_candidate = int(role_to_remove)
            if role_id_candidate >= 0:
                role_id = role_id_candidate
        except (TypeError, ValueError):
            role_id = None

        assert (
            role_id is not None
        ), "role_to_remove cannot be mapped to a numeric roleId required by /users/{id}/roles/{roleId}."

        delete_resp = requests.delete(
            f"{BASE_URL}/users/{user_id}/roles/{role_id}", timeout=10
        )

        # DELETE /users/{id}/roles/{roleId} returns 200 with UserDTO or 204 No Content
        assert delete_resp.status_code in (
            200,
            204,
        ), f"Failed to remove role: status={delete_resp.status_code}, body={delete_resp.text}"

        # Retrieve updated user details
        followup_resp = requests.get(
            f"{BASE_URL}/users/{user_id}", timeout=10
        )
        followup_json = _safe_json(followup_resp)

        assert followup_resp.status_code == 200, (
            f"Failed to retrieve updated user details: status={followup_resp.status_code}, "
            f"body={followup_resp.text}"
        )
        assert isinstance(followup_json, dict), "Follow-up user response JSON is not an object"

        followup_roles = followup_json.get("roles") or []
        assert isinstance(
            followup_roles, list
        ), f"'roles' field is not a list in follow-up response: {type(followup_roles)}"

        context.followup_user = followup_json
        context.followup_roles = list(followup_roles)

    except Exception as e:
        print(f"Error in When step for MR2: {e}")
        assert False


@then(
    "the follow-up output's list of roles for that user should contain all roles from the seed output except the removed role, i.e., it should be a strict subset of the seed output's role list for MR2."
)
def step_mr_MR2_followup_output(context):
    try:
        seed_roles = list(context.seed_roles)
        followup_roles = list(context.followup_roles)
        role_to_remove = context.role_to_remove

        # Build expected roles list: all seed roles except the removed one
        expected_roles = [r for r in seed_roles if r != role_to_remove]

        # MR requirement: strict subset => follow-up must equal seed minus removed role
        assert followup_roles == expected_roles, (
            f"The follow-up roles do not match expected roles after removal.\n"
            f"Seed roles: {seed_roles}\n"
            f"Role to remove: {role_to_remove}\n"
            f"Expected roles: {expected_roles}\n"
            f"Actual follow-up roles: {followup_roles}"
        )

    except Exception as e:
        print(f"Error in Then step for MR2: {e}")
        assert False

# ----

import copy



@given("a seed input that retrieves a specific user's current information, producing a seed output with the complete set of the user's details for MR3.")
def step_mr_MR3_seed_input(context):
    # Create a user to ensure it exists
    user_data = {
        "username": "testuser_mr3",
        "password": "password123",
        "name": "Test",
        "surname": "User",
        "email": "testuser_mr3@example.com",
        "gender": "male",
        "enabled": True,
    }

    # /users POST expects CreateOrUpdateUserDTO
    try:
        response = requests.post(
            f"{BASE_URL}/users",
            json=user_data,
            timeout=10,
        )
    except requests.RequestException as e:
        raise RuntimeError(f"HTTP error during user creation in MR3 Given step: {e}") from e

    if not response.ok:
        raise AssertionError(
            f"Failed to create user in MR3 Given step: "
            f"status={response.status_code}, body={response.text}"
        )

    try:
        seed = response.json()
    except ValueError as e:
        raise RuntimeError(f"Non-JSON response when creating user in MR3 Given step: {e}") from e

    if not isinstance(seed, dict):
        raise TypeError(
            f"Expected seed user response to be a JSON object, got {type(seed).__name__}"
        )

    if "id" not in seed:
        raise KeyError(
            f"Created user response does not contain 'id' field. Response: {json.dumps(seed)}"
        )

    context.seed_response = seed
    context.user_id = seed["id"]


@when("a follow-up input is created to update the same user by sending values identical to the seed output for all fields except one field whose value is changed, yielding a follow-up output for MR3.")
def step_mr_MR3_followup_input(context):
    if not hasattr(context, "seed_response"):
        raise AttributeError("seed_response not found on context in MR3 When step.")
    if not hasattr(context, "user_id"):
        raise AttributeError("user_id not found on context in MR3 When step.")

    seed = context.seed_response
    if not isinstance(seed, dict):
        raise TypeError(
            f"seed_response is expected to be a dict in MR3 When step, got {type(seed).__name__}"
        )

    # Prepare the update data based on CreateOrUpdateUserDTO shape
    update_data = {}

    # Map from UserDTO fields to CreateOrUpdateUserDTO where applicable
    # Only include fields that exist in the seed response and are valid in the update DTO
    field_mapping = {
        "address": "address",
        "address2": "address2",
        "birthDate": "birthDate",
        "city": "city",
        "contactNote": "contactNote",
        "country": "country",
        "email": "email",
        "enabled": "enabled",
        "facebook": "facebook",
        "gender": "gender",
        "linkedin": "linkedin",
        "name": "name",
        "note": "note",
        "password": "password",
        "phone": "phone",
        "secured": "secured",
        "skype": "skype",
        "surname": "surname",
        "username": "username",
        "website": "website",
        "zipCode": "zipCode",
    }

    for src, dest in field_mapping.items():
        if src in seed:
            update_data[dest] = seed[src]

    # Ensure we have at least username and password in the update payload
    if "username" not in update_data and "username" in seed:
        update_data["username"] = seed["username"]
    if "password" not in update_data:
        # Use a default password if missing; API schema allows string
        update_data["password"] = "password123"

    # Change exactly one field - choose email as per MR
    new_email = "updateduser_mr3@example.com"
    update_data["email"] = new_email

    try:
        response = requests.put(
            f"{BASE_URL}/users/{context.user_id}",
            json=update_data,
            timeout=10,
        )
    except requests.RequestException as e:
        raise RuntimeError(f"HTTP error during user update in MR3 When step: {e}") from e

    if not response.ok:
        raise AssertionError(
            f"Failed to update user in MR3 When step: "
            f"status={response.status_code}, body={response.text}"
        )

    try:
        followup = response.json()
    except ValueError as e:
        raise RuntimeError(f"Non-JSON response when updating user in MR3 When step: {e}") from e

    if not isinstance(followup, dict):
        raise TypeError(
            f"Expected follow-up user response to be a JSON object, got {type(followup).__name__}"
        )

    context.followup_response = followup
    context.changed_field_name = "email"
    context.changed_field_new_value = new_email


@then("the follow-up output should differ from the seed output only in the field whose value was changed in the update request; all other fields should match for MR3.")
def step_mr_MR3_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AttributeError("seed_response not found on context in MR3 Then step.")
    if not hasattr(context, "followup_response"):
        raise AttributeError("followup_response not found on context in MR3 Then step.")
    if not hasattr(context, "changed_field_name"):
        raise AttributeError("changed_field_name not found on context in MR3 Then step.")
    if not hasattr(context, "changed_field_new_value"):
        raise AttributeError("changed_field_new_value not found on context in MR3 Then step.")

    seed = context.seed_response
    followup = context.followup_response
    field = context.changed_field_name
    new_value = context.changed_field_new_value

    if not isinstance(seed, dict):
        raise TypeError(
            f"seed_response is expected to be a dict in MR3 Then step, got {type(seed).__name__}"
        )
    if not isinstance(followup, dict):
        raise TypeError(
            f"followup_response is expected to be a dict in MR3 Then step, got {type(followup).__name__}"
        )

    if field not in followup:
        raise KeyError(
            f"Changed field '{field}' not present in follow-up response for MR3. "
            f"Response: {json.dumps(followup)}"
        )

    # Verify that the changed field has the new value
    if followup[field] != new_value:
        raise AssertionError(
            f"Field '{field}' was expected to be updated to '{new_value}' but is '{followup[field]}'"
        )

    # Compare all other top-level fields that are common between seed and follow-up
    # Only assert equality for keys that exist in both responses; ignore system-managed fields that may change
    ignore_keys = {"updatedDt", "loginDt", "creationDt"}
    for key in seed.keys():
        if key in ignore_keys or key == field:
            continue
        if key not in followup:
            # If follow-up doesn't contain this key, skip strict comparison to avoid KeyError/false failure
            continue
        if followup[key] != seed[key]:
            raise AssertionError(
                f"Field '{key}' should match the seed output for MR3. "
                f"Seed value={seed[key]!r}, follow-up value={followup[key]!r}"
            )

# ----

import time

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the current list of users, producing a seed output with the total number of users returned by the listing operation for MR4.')
def _mr_MR4_seed_input(context):
    response = requests.get(f"{BASE_URL}/users", timeout=10)
    response.raise_for_status()

    try:
        data = response.json()
    except ValueError:
        raise AssertionError("Seed /users response did not return valid JSON.")

    if not isinstance(data, dict):
        raise AssertionError(f"Expected JSON object from /users, got {type(data).__name__}.")

    user_list = data.get('userList', [])
    if user_list is None:
        user_list = []
    if not isinstance(user_list, list):
        raise AssertionError(f"Expected 'userList' to be a list, got {type(user_list).__name__}.")

    context.seed_response = data
    context.seed_request = response.request
    context.total_users_before = len(user_list)


@when('a follow-up input is created by successfully creating a new user account, after which the list of users is retrieved again, yielding a follow-up output for MR4.')
def _mr_MR4_followup_input(context):
    # According to the OpenAPI spec, /users/register expects RegisterUserAccountDTO
    # which includes: email, gender, name, password, surname, username
    timestamp = int(time.time() * 1000)
    new_user_data = {
        "username": f"newuser_{timestamp}",
        "password": "password123",
        "name": "New",
        "surname": "User",
        "email": f"newuser_{timestamp}@example.com",
        "gender": "other"
    }

    create_response = requests.post(f"{BASE_URL}/users/register", json=new_user_data, timeout=10)
    create_response.raise_for_status()

    # After successful creation, retrieve the list again from the same listing endpoint /users
    followup_response = requests.get(f"{BASE_URL}/users", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except ValueError:
        raise AssertionError("Follow-up /users response did not return valid JSON.")

    if not isinstance(followup_data, dict):
        raise AssertionError(f"Expected JSON object from /users, got {type(followup_data).__name__}.")

    followup_user_list = followup_data.get('userList', [])
    if followup_user_list is None:
        followup_user_list = []
    if not isinstance(followup_user_list, list):
        raise AssertionError(f"Expected 'userList' to be a list, got {type(followup_user_list).__name__}.")

    context.followup_response = followup_data
    context.followup_request = followup_response.request
    context.total_users_after = len(followup_user_list)


@then('the follow-up output should have a total number of users that is exactly one more than in the seed output for MR4, assuming the creation request completed without error.')
def _mr_MR4_followup_output(context):
    expected = getattr(context, "total_users_before", None)
    actual = getattr(context, "total_users_after", None)

    if not isinstance(expected, int):
        raise AssertionError(f"total_users_before is not an int: {repr(expected)}")
    if not isinstance(actual, int):
        raise AssertionError(f"total_users_after is not an int: {repr(actual)}")

    assert actual == expected + 1, (
        f"Expected total users after creation to be {expected + 1}, but got {actual}."
    )

# ----




def _safe_get_user_list():
    response = requests.get(f"{BASE_URL}/users", timeout=10)
    response.raise_for_status()
    try:
        data = response.json()
    except ValueError:
        raise AssertionError("GET /users did not return valid JSON.")
    if not isinstance(data, dict):
        raise AssertionError("GET /users response JSON is not an object.")
    user_list = data.get("userList", [])
    if user_list is None:
        user_list = []
    if not isinstance(user_list, list):
        raise AssertionError("GET /users response 'userList' is not a list.")
    return data, user_list, response.request


def _safe_create_user():
    # Minimal valid payload according to CreateOrUpdateUserDTO (all fields optional)
    user_data = {
        "username": "testuser_mr5",
        "password": "password",
        "name": "Test",
        "surname": "User",
        "email": "testuser_mr5@example.com"
    }
    response = requests.post(
        f"{BASE_URL}/users",
        json=user_data,
        timeout=10,
    )
    response.raise_for_status()
    try:
        data = response.json()
    except ValueError:
        raise AssertionError("POST /users did not return valid JSON.")
    if not isinstance(data, dict):
        raise AssertionError("POST /users response JSON is not an object.")
    user_id = data.get("id")
    if user_id is None:
        raise AssertionError("POST /users response does not contain 'id'.")
    return user_id


@given('a seed input that retrieves the current list of users, producing a seed output with the total number of users returned by the listing operation for MR5, including the user that will be deleted.')
def step_mr_MR5_seed_input(context):
    data, user_list, request_obj = _safe_get_user_list()
    context.seed_response = data
    context.seed_request = request_obj
    context.total_users_before_deletion = len(user_list)

    if context.total_users_before_deletion == 0:
        context.user_id_to_delete = _safe_create_user()
        # Refresh list so the seed output includes the user that will be deleted
        data, user_list, request_obj = _safe_get_user_list()
        context.seed_response = data
        context.seed_request = request_obj
        context.total_users_before_deletion = len(user_list)
    else:
        first_user = user_list[0]
        if not isinstance(first_user, dict):
            raise AssertionError("First element of 'userList' is not an object.")
        user_id = first_user.get("id")
        if user_id is None:
            raise AssertionError("User object in 'userList' does not contain 'id'.")
        context.user_id_to_delete = user_id


@when('a follow-up input is created by successfully deleting an existing user from this list, after which the list of users is retrieved again, yielding a follow-up output for MR5.')
def step_mr_MR5_followup_input(context):
    user_id = getattr(context, "user_id_to_delete", None)
    if user_id is None:
        raise AssertionError("Context is missing 'user_id_to_delete' before deletion step.")

    delete_response = requests.delete(f"{BASE_URL}/users/{user_id}", timeout=10)
    delete_response.raise_for_status()

    data, user_list, request_obj = _safe_get_user_list()
    context.followup_response = data
    context.followup_request = request_obj
    context.total_users_after_deletion = len(user_list)


@then('the follow-up output should have a total number of users that is exactly one less than in the seed output for MR5, assuming the deletion request completed without error and targeted a user present in the seed list.')
def step_mr_MR5_assert_followup_output(context):
    before = getattr(context, "total_users_before_deletion", None)
    after = getattr(context, "total_users_after_deletion", None)

    if not isinstance(before, int):
        raise AssertionError(f"'total_users_before_deletion' is not an int (value: {before!r}).")
    if not isinstance(after, int):
        raise AssertionError(f"'total_users_after_deletion' is not an int (value: {after!r}).")

    expected = before - 1
    assert after == expected, (
        f"Expected {expected} users after deletion, but got {after}. "
        f"Seed count was {before}."
    )
