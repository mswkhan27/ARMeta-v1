Feature: Iteration 1 MRs

  Scenario: MR6 Deleting a permission should remove it from the permission list
    Given a seed input that retrieves the current list of permissions via the permission-listing operation, producing a seed output with the total number of permissions including a specific permission that is eligible for deletion for MR6.
    When a follow-up input is created by successfully deleting that existing permission (identified from the seed output), after which the list of permissions is retrieved again in the same way, yielding a follow-up output for MR6.
    Then the follow-up output should have a total number of permissions that is exactly one less than in the seed output for MR6, assuming the deletion request completed without error and targeted a permission present in the seed list.

  Scenario: MR7 Adding a permission to a role should include the new permission in the role's permission list
    Given a seed input that retrieves a specific role's current details, producing a seed output that includes the role's existing list of permissions for MR7.
    When a follow-up input is created by successfully assigning an additional existing permission, identified by its key, to the same role and then retrieving the updated role details, yielding a follow-up output for MR7.
    Then the follow-up output's list of permissions for that role should contain all permissions from the seed output plus the newly assigned permission, i.e., it should be a strict superset of the seed output's permission list for MR7, assuming the assignment request completed without error.

  Scenario: MR8 Removing a permission from a role should exclude the permission from the role's permission list
    Given a seed input that retrieves a specific role's current details, producing a seed output that includes the role's existing list of permissions (including the permission to be removed, identified by its key) for MR8.
    When a follow-up input is created by successfully removing one of the existing permissions, using its key, from the same role and then retrieving the updated role details, yielding a follow-up output for MR8.
    Then the follow-up output's list of permissions for that role should contain all permissions from the seed output except the removed permission, i.e., it should be a strict subset of the seed output's permission list for MR8, assuming the removal request completed without error.

  Scenario: MR9 Creating a new role should increase the total role count
    Given a seed input that retrieves the current list of roles via the role-listing operation, producing a seed output with the total number of roles returned by the listing operation for MR9.
    When a follow-up input is created by successfully creating a new role with a role identifier not present in the seed list, after which the list of roles is retrieved again in the same way, yielding a follow-up output for MR9.
    Then the follow-up output should have a total number of roles that is exactly one more than in the seed output for MR9, assuming the creation request completed without error.

  Scenario: MR10 Deleting a role should decrease the total role count
    Given a seed input that retrieves the current list of roles via the role-listing operation, producing a seed output with the total number of roles returned by the listing operation for MR10, including a specific role that will be deleted.
    When a follow-up input is created by successfully deleting an existing role, identified by an id present in the seed list, after which the list of roles is retrieved again in the same way, yielding a follow-up output for MR10.
    Then the follow-up output should have a total number of roles that is exactly one less than in the seed output for MR10, assuming the deletion request completed without error and targeted a role present in the seed list.
