from behave import given, when, then
import os
import requests

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


@given("a seed input that retrieves the current list of permissions via the permission-listing operation, producing a seed output with the total number of permissions including a specific permission that is eligible for deletion for MR6.")
def step_mr_MR6_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
    response.raise_for_status()

    data = response.json()
    if not isinstance(data, list):
        raise TypeError(f"Expected list of permissions, got {type(data)}")

    if not data:
        raise ValueError("Permission list is empty; no permission available for deletion for MR6")

    first_permission = data[0]
    if not isinstance(first_permission, dict):
        raise TypeError(f"Expected permission object to be dict, got {type(first_permission)}")

    permission_key = first_permission.get("permission")
    if not isinstance(permission_key, str) or not permission_key:
        raise ValueError("Permission object does not contain a valid 'permission' key for deletion")

    context.seed_response = data
    context.seed_request = response.request
    context.permission_to_delete = permission_key
    context.seed_count = len(data)


@when("a follow-up input is created by successfully deleting that existing permission (identified from the seed output), after which the list of permissions is retrieved again in the same way, yielding a follow-up output for MR6.")
def step_mr_MR6_followup_input(context):
    if not hasattr(context, "permission_to_delete"):
        raise AttributeError("permission_to_delete not set in context from Given step")

    permission_key = context.permission_to_delete
    delete_url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"

    delete_response = requests.delete(delete_url, timeout=10)
    delete_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
    followup_response.raise_for_status()

    followup_data = followup_response.json()
    if not isinstance(followup_data, list):
        raise TypeError(f"Expected list of permissions in follow-up, got {type(followup_data)}")

    context.followup_response = followup_data
    context.followup_request = followup_response.request
    context.followup_count = len(followup_data)


@then("the follow-up output should have a total number of permissions that is exactly one less than in the seed output for MR6, assuming the deletion request completed without error and targeted a permission present in the seed list.")
def step_mr_MR6_followup_output(context):
    if not hasattr(context, "seed_count") or not hasattr(context, "followup_count"):
        raise AttributeError("seed_count or followup_count not set in context")

    expected_count = context.seed_count - 1
    actual_count = context.followup_count

    assert actual_count == expected_count, (
        f"Expected {expected_count} permissions after deletion, but got {actual_count}"
    )

# ----

import json



def _safe_get_json(response):
    try:
        return response.json()
    except ValueError:
        return {}


def _extract_permissions(role_obj):
    if not isinstance(role_obj, dict):
        return set()
    raw_perms = role_obj.get("permissions", [])
    if not isinstance(raw_perms, list):
        return set()

    permissions = set()
    for p in raw_perms:
        if isinstance(p, dict):
            val = p.get("permission")
            if isinstance(val, str):
                permissions.add(val)
        elif isinstance(p, str):
            permissions.add(p)
    return permissions


@given(
    "a seed input that retrieves a specific role's current details, producing a seed output that includes the role's existing list of permissions for MR7."
)
def _mr_MR7_seed_input(context):
    role_id = 1
    url = f"{BASE_URL}/users/rbac/roles/{role_id}"
    response = requests.get(url, timeout=10)
    response.raise_for_status()

    context.seed_response = _safe_get_json(response)
    if not isinstance(context.seed_response, dict):
        context.seed_response = {}
    context.seed_request = {"roleId": role_id}


@when(
    "a follow-up input is created by successfully assigning an additional existing permission, identified by its key, to the same role and then retrieving the updated role details, yielding a follow-up output for MR7."
)
def _mr_MR7_followup_input(context):
    role_id = context.seed_request.get("roleId")
    if not isinstance(role_id, int):
        raise AssertionError("roleId in seed_request must be an integer")

    permission_key = "new_permission"
    url_add = f"{BASE_URL}/users/rbac/roles/{role_id}/permissions/{permission_key}"
    add_permission_response = requests.post(url_add, timeout=10)
    add_permission_response.raise_for_status()

    url_get = f"{BASE_URL}/users/rbac/roles/{role_id}"
    followup_response = requests.get(url_get, timeout=10)
    followup_response.raise_for_status()

    context.followup_response = _safe_get_json(followup_response)
    if not isinstance(context.followup_response, dict):
        context.followup_response = {}
    context.followup_request = {"roleId": role_id, "permissionKey": permission_key}


@then(
    "the follow-up output's list of permissions for that role should contain all permissions from the seed output plus the newly assigned permission, i.e., it should be a strict superset of the seed output's permission list for MR7, assuming the assignment request completed without error."
)
def _mr_MR7_followup_output(context):
    seed_permissions = _extract_permissions(getattr(context, "seed_response", {}))
    followup_permissions = _extract_permissions(getattr(context, "followup_response", {}))

    if not followup_permissions.issuperset(seed_permissions):
        raise AssertionError(
            f"Follow-up permissions {followup_permissions} are not a superset of seed permissions {seed_permissions}"
        )

    if followup_permissions == seed_permissions:
        raise AssertionError(
            "Follow-up permissions are equal to seed permissions; expected a strict superset including the newly assigned permission."
        )

# ----




@given("a seed input that retrieves a specific role's current details, producing a seed output that includes the role's existing list of permissions (including the permission to be removed, identified by its key) for MR8.")
def step_mr_MR8_seed_input(context):
    role_id = 1  # Must be a valid existing role ID in the system

    try:
        response = requests.get(f"{BASE_URL}/users/rbac/roles/{role_id}", timeout=10)
        response.raise_for_status()

        data = response.json()
        if not isinstance(data, dict):
            raise AssertionError("Role details response is not a JSON object")

        permissions = data.get("permissions")
        if not isinstance(permissions, list) or not permissions:
            raise AssertionError("Role must have a non-empty list of permissions for MR8")

        for perm in permissions:
            if not isinstance(perm, dict):
                raise AssertionError("Each permission in the permissions list must be an object")
            if "permission" not in perm or not isinstance(perm["permission"], str):
                raise AssertionError("Each permission object must contain a string 'permission' field")

        context.seed_response = data
        context.seed_request = {"roleId": role_id}

        # Store the key of the permission to remove to avoid recomputing / index issues later
        context.permission_key_to_remove = permissions[0]["permission"]

    except (requests.RequestException, ValueError) as e:
        raise AssertionError(f"HTTP or JSON error in Given step for MR8: {e}") from e
    except Exception as e:
        raise AssertionError(f"Unexpected error in Given step for MR8: {e}") from e


@when("a follow-up input is created by successfully removing one of the existing permissions, using its key, from the same role and then retrieving the updated role details, yielding a follow-up output for MR8.")
def step_mr_MR8_followup_input(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "seed_request"):
        raise AssertionError("Seed context is not initialized before When step for MR8")

    role_id = context.seed_request.get("roleId")
    if not isinstance(role_id, int):
        raise AssertionError("roleId in context.seed_request must be an integer")

    permission_key_to_remove = getattr(context, "permission_key_to_remove", None)
    if not isinstance(permission_key_to_remove, str) or not permission_key_to_remove:
        raise AssertionError("permission_key_to_remove must be a non-empty string")

    try:
        delete_url = f"{BASE_URL}/users/rbac/roles/{role_id}/permissions/{permission_key_to_remove}"
        delete_response = requests.delete(delete_url, timeout=10)
        delete_response.raise_for_status()

        followup_response = requests.get(f"{BASE_URL}/users/rbac/roles/{role_id}", timeout=10)
        followup_response.raise_for_status()

        followup_data = followup_response.json()
        if not isinstance(followup_data, dict):
            raise AssertionError("Updated role details response is not a JSON object")

        permissions = followup_data.get("permissions")
        if not isinstance(permissions, list):
            raise AssertionError("Updated role must have a 'permissions' list field")

        for perm in permissions:
            if not isinstance(perm, dict):
                raise AssertionError("Each permission in the updated permissions list must be an object")
            if "permission" not in perm or not isinstance(perm["permission"], str):
                raise AssertionError("Each updated permission object must contain a string 'permission' field")

        context.followup_response = followup_data
        context.followup_request = {"roleId": role_id}

    except (requests.RequestException, ValueError) as e:
        raise AssertionError(f"HTTP or JSON error in When step for MR8: {e}") from e
    except Exception as e:
        raise AssertionError(f"Unexpected error in When step for MR8: {e}") from e


@then("the follow-up output's list of permissions for that role should contain all permissions from the seed output except the removed permission, i.e., it should be a strict subset of the seed output's permission list for MR8, assuming the removal request completed without error.")
def step_mr_MR8_followup_output(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AssertionError("Seed or follow-up response is missing in context for MR8")

    if not hasattr(context, "permission_key_to_remove"):
        raise AssertionError("permission_key_to_remove is missing in context for MR8")

    permission_key_to_remove = context.permission_key_to_remove
    if not isinstance(permission_key_to_remove, str) or not permission_key_to_remove:
        raise AssertionError("permission_key_to_remove must be a non-empty string in Then step")

    try:
        seed_permissions_raw = context.seed_response.get("permissions")
        followup_permissions_raw = context.followup_response.get("permissions")

        if not isinstance(seed_permissions_raw, list) or not isinstance(followup_permissions_raw, list):
            raise AssertionError("Both seed and follow-up 'permissions' fields must be lists")

        seed_permissions = set()
        for perm in seed_permissions_raw:
            if not isinstance(perm, dict):
                raise AssertionError("Each seed permission must be an object")
            key = perm.get("permission")
            if not isinstance(key, str):
                raise AssertionError("Each seed permission must contain a string 'permission' field")
            seed_permissions.add(key)

        followup_permissions = set()
        for perm in followup_permissions_raw:
            if not isinstance(perm, dict):
                raise AssertionError("Each follow-up permission must be an object")
            key = perm.get("permission")
            if not isinstance(key, str):
                raise AssertionError("Each follow-up permission must contain a string 'permission' field")
            followup_permissions.add(key)

        if permission_key_to_remove not in seed_permissions:
            raise AssertionError("The permission selected for removal was not present in the seed permissions")

        expected_permissions = seed_permissions - {permission_key_to_remove}

        assert followup_permissions == expected_permissions, (
            f"Follow-up permissions do not match expected permissions after removal. "
            f"Expected: {json.dumps(sorted(expected_permissions))}, "
            f"Actual: {json.dumps(sorted(followup_permissions))}"
        )

        assert len(followup_permissions) < len(seed_permissions), (
            "Follow-up permission list is not a strict subset (size did not decrease)"
        )

    except Exception as e:
        raise AssertionError(f"Error in Then step for MR8: {e}") from e

# ----

import time

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the current list of roles via the role-listing operation, producing a seed output with the total number of roles returned by the listing operation for MR9.')
def _mr_MR9_seed_input(context):
    try:
        response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
        response.raise_for_status()

        # According to the OpenAPI spec, this returns an array of RoleDTO
        try:
            data = response.json()
        except ValueError as e:
            raise RuntimeError(f"Failed to decode JSON from role list response: {e}") from e

        if not isinstance(data, list):
            raise TypeError(f"Expected role list to be a list, got {type(data).__name__}")

        context.seed_response = data
        context.seed_request = response.request
        context.total_roles_before = len(data)
    except Exception as e:
        print(f"Error in Given step for MR9: {e}")
        raise


@when('a follow-up input is created by successfully creating a new role with a role identifier not present in the seed list, after which the list of roles is retrieved again in the same way, yielding a follow-up output for MR9.')
def _mr_MR9_followup_input(context):
    # Unique role name to avoid clashes with existing roles
    new_role_name = f"role_{int(time.time())}"

    try:
        # Create a new role.
        # OpenAPI: POST /users/rbac/roles, body schema: string (role)
        create_response = requests.post(
            f"{BASE_URL}/users/rbac/roles",
            json=new_role_name,
            timeout=10,
        )
        create_response.raise_for_status()

        # Retrieve the updated list of roles
        followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
        followup_response.raise_for_status()

        try:
            followup_data = followup_response.json()
        except ValueError as e:
            raise RuntimeError(f"Failed to decode JSON from follow-up role list response: {e}") from e

        if not isinstance(followup_data, list):
            raise TypeError(f"Expected follow-up role list to be a list, got {type(followup_data).__name__}")

        context.followup_response = followup_data
        context.followup_request = followup_response.request
        context.total_roles_after = len(followup_data)
    except Exception as e:
        print(f"Error in When step for MR9: {e}")
        raise


@then('the follow-up output should have a total number of roles that is exactly one more than in the seed output for MR9, assuming the creation request completed without error.')
def _mr_MR9_assertion(context):
    try:
        before = getattr(context, "total_roles_before", None)
        after = getattr(context, "total_roles_after", None)

        if not isinstance(before, int):
            raise TypeError(f"total_roles_before is not an int: {before!r}")
        if not isinstance(after, int):
            raise TypeError(f"total_roles_after is not an int: {after!r}")

        assert after == before + 1, (
            f"Expected total roles after creation to be {before + 1}, "
            f"but got {after}."
        )
    except AssertionError as e:
        print(f"Assertion error in Then step for MR9: {e}")
        raise

# ----




@given('a seed input that retrieves the current list of roles via the role-listing operation, producing a seed output with the total number of roles returned by the listing operation for MR10, including a specific role that will be deleted.')
def _mr_MR10_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    response.raise_for_status()

    try:
        seed_response = response.json()
        if not isinstance(seed_response, list):
            raise ValueError("Expected a list of roles from /users/rbac/roles")
    except (ValueError, json.JSONDecodeError) as exc:
        raise AssertionError(f"Invalid JSON or structure from role list: {exc}") from exc

    context.seed_response = seed_response
    context.seed_request = response.request
    context.total_roles = len(seed_response)

    if context.total_roles == 0:
        # Create a role if none exists so that we have something to delete
        role_data = "TestRole"
        create_response = requests.post(
            f"{BASE_URL}/users/rbac/roles",
            json=role_data,
            timeout=10,
        )
        create_response.raise_for_status()
        try:
            created_role = create_response.json()
            if not isinstance(created_role, dict):
                raise ValueError("Expected object for created role")
        except (ValueError, json.JSONDecodeError) as exc:
            raise AssertionError(f"Invalid JSON or structure from role creation: {exc}") from exc

        role_id = created_role.get("id")
        if role_id is None:
            raise AssertionError("Created role does not contain 'id' field")

        context.role_to_delete = created_role
        # after creation, logically total_roles should be 1 for MR10
        context.total_roles = 1
    else:
        first_role = seed_response[0]
        if not isinstance(first_role, dict):
            raise AssertionError("Role list items must be objects with an 'id' field")
        role_id = first_role.get("id")
        if role_id is None:
            raise AssertionError("Seed role does not contain 'id' field")
        context.role_to_delete = first_role


@when('a follow-up input is created by successfully deleting an existing role, identified by an id present in the seed list, after which the list of roles is retrieved again in the same way, yielding a follow-up output for MR10.')
def _mr_MR10_followup_input(context):
    role = getattr(context, "role_to_delete", None)
    if not isinstance(role, dict):
        raise AssertionError("Context 'role_to_delete' must be a dict with an 'id'")

    role_id = role.get("id")
    if role_id is None:
        raise AssertionError("Context 'role_to_delete' does not contain 'id'")

    delete_response = requests.delete(f"{BASE_URL}/users/rbac/roles/{role_id}", timeout=10)
    delete_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_list = followup_response.json()
        if not isinstance(followup_list, list):
            raise ValueError("Expected a list of roles from /users/rbac/roles on follow-up")
    except (ValueError, json.JSONDecodeError) as exc:
        raise AssertionError(f"Invalid JSON or structure from follow-up role list: {exc}") from exc

    context.followup_response = followup_list


@then('the follow-up output should have a total number of roles that is exactly one less than in the seed output for MR10, assuming the deletion request completed without error and targeted a role present in the seed list.')
def _mr_MR10_assert_followup_output(context):
    followup_list = getattr(context, "followup_response", None)
    if not isinstance(followup_list, list):
        raise AssertionError("Context 'followup_response' must be a list")

    total_roles = getattr(context, "total_roles", None)
    if not isinstance(total_roles, int):
        raise AssertionError("Context 'total_roles' must be an integer")

    expected_count = total_roles - 1
    actual_count = len(followup_list)

    assert actual_count == expected_count, (
        f"Expected {expected_count} roles after deletion, but got {actual_count}"
    )
