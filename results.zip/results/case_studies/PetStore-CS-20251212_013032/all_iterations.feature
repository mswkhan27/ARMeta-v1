
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet with a given status should increase the count of pets with that status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR1.
    When a follow-up input is created by first adding a new pet with status 'available' and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR1.
    Then the follow-up output should have a count of pets with status 'available' that is one more than the seed output for MR1, assuming the newly added pet did not previously exist.

  Scenario: MR2 Updating a pet's status should reflect in subsequent status-based queries
    Given a seed input that first creates or identifies a pet with status 'available' and then retrieves the list of pets filtered by status 'pending', producing a seed output with a list of pending pets that does not include this pet for MR2.
    When a follow-up input is created by updating that pet's status from 'available' to 'pending' and then retrieving again the list of pets filtered by status 'pending', yielding a follow-up output for MR2.
    Then the follow-up output should include the updated pet in the list of pending pets, whereas it was absent from the seed output for MR2.

  Scenario: MR3 Deleting a pet should decrease the count of pets with its status
    Given a seed input that creates or identifies a pet with a known status (for example, 'available') and then retrieves the list of pets filtered by that same status, producing a seed output with a count of pets for that status for MR3.
    When a follow-up input is created by deleting that identified pet and then retrieving again the list of pets filtered by the same status, yielding a follow-up output for MR3.
    Then the follow-up output should have a count of pets with that status that is one less than the seed output for MR3.

  Scenario: MR5 Updating a user's information with a full representation should only change the explicitly modified fields
    Given a seed input that retrieves a specific user's details, producing a seed output with the current values for all of the user's fields for MR5.
    When a follow-up input is created by sending a complete user representation that is identical to the seed output except for a changed email value, and then retrieving the same user's details again, yielding a follow-up output for MR5.
    Then the follow-up output should differ from the seed output only in the email field; all other user fields should remain identical for MR5.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR6 Deleting a user should remove the user from subsequent retrievals
    Given a seed input that retrieves a specific user's details by username, producing a seed output with the user's information for MR6.
    When a follow-up input is created by deleting the user with the same username and then attempting to retrieve the user's details again, yielding a follow-up output for MR6.
    Then the follow-up output should indicate that the user is not found, contrasting with the presence of the user in the seed output for MR6.

  Scenario: MR7 Uploading an image for a pet should not alter the pet's other attributes
    Given a seed input that retrieves a pet's details by petId, producing a seed output with the pet's current attributes for MR7.
    When a follow-up input is created by uploading an image for the pet with the same petId and then retrieving the pet's details again, yielding a follow-up output for MR7.
    Then the follow-up output should have the same pet attributes as the seed output, since uploading an image only affects associated media and does not modify the pet's core data for MR7.

  Scenario: MR8 Creating multiple users with a list should make each user individually retrievable
    Given a seed input that attempts to retrieve several users by a set of distinct usernames, producing a seed output in which these users are not yet present or have different details for MR8.
    When a follow-up input is created by adding a list of new users with those usernames and then retrieving each user again by username, yielding a follow-up output for MR8.
    Then the follow-up output should show that each of the newly added users is now retrievable by username with details matching the created user data for MR8.

  Scenario: MR9 Placing an order should make that order retrievable by its identifier
    Given a seed input that places a new order for a pet, producing a seed output that includes the created order details and its identifier for MR9.
    When a follow-up input is created by retrieving the order using the same identifier from the seed output, yielding a follow-up output for MR9.
    Then the follow-up output should contain order details consistent with the seed output, reflecting the same identifier, associated pet, quantity, and status for MR9.

  Scenario: MR10 Retrieving pets by tags should return a consistent set of pets for the same tags
    Given a seed input that retrieves pets by a specific set of tags, producing a seed output with a list of pets for those tags for MR10.
    When a follow-up input is created by retrieving pets again with the same set of tags, assuming no intervening changes to the pets associated with those tags, yielding a follow-up output for MR10.
    Then the follow-up output should be identical to the seed output, reflecting a stable mapping from the given tags to the corresponding pets for MR10.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR11 Deleting an order should make it non-retrievable
    Given a seed input that retrieves an order by its ID, producing a seed output with the order details for MR11.
    When a follow-up input is created by deleting the order with the same ID and then attempting to retrieve the order again, yielding a follow-up output for MR11.
    Then the follow-up output should indicate that the order is not found (for example, via a not-found error), contrasting with the presence of the order in the seed output for MR11.

  Scenario: MR12 Retrieving inventory should reflect consistent status counts
    Given a seed input that retrieves the pet inventory by status, producing a seed output with a map of status codes to quantities for MR12.
    When a follow-up input is created by retrieving the inventory again without performing any operations that change pet statuses or quantities, yielding a follow-up output for MR12.
    Then the follow-up output should be identical to the seed output, reflecting consistent status counts for MR12 when no intervening changes have been made.

  Scenario: MR13 Logging in should return consistent login metadata
    Given a seed input that logs a user into the system with valid credentials, producing a seed output containing a login response body and login-related headers (such as rate limit and expiration information) for MR13.
    When a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR13.
    Then the follow-up output should again indicate a successful login and provide login-related headers (such as rate limit and expiration information); the expiration information in the follow-up output should be equal to or later than that in the seed output for MR13.

  Scenario: MR15 Updating a pet's details should reflect only the changes made
    Given a seed input that retrieves a pet's details by petId, producing a seed output with the pet's current attributes for MR15.
    When a follow-up input is created by updating the pet's name while keeping all other attributes the same in the update request, and then retrieving the pet's details again, yielding a follow-up output for MR15.
    Then the follow-up output should show the updated name while all other pet attributes that were left unchanged in the update request remain identical to those in the seed output for MR15.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR16 Updating a pet's details with form data should reflect only the changes made
    Given a seed input that retrieves a pet's details by petId, producing a seed output with the pet's current attributes for MR16.
    When a follow-up input is created by updating the pet's name using form data parameters while not providing values for any other pet attributes, and then retrieving the pet's details again, yielding a follow-up output for MR16.
    Then the follow-up output should show the updated name while all other pet attributes for which no new values were provided in the update request remain identical to those in the seed output for MR16.

  Scenario: MR17 Updating a user's information should reflect only the changes made
    Given a seed input that retrieves a specific user's details by username, producing a seed output with the user's current attributes for MR17.
    When a follow-up input is created by updating the user's email in the user resource while not providing changes to any other user attributes, and then retrieving the user's details again, yielding a follow-up output for MR17.
    Then the follow-up output should differ from the seed output only in the email field for which a new value was provided; all other user fields should remain identical for MR17.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR18 Logging out should return a successful operation response
    Given a seed input that logs a user into the system, producing a seed output with a successful login response and any associated login metadata for MR18.
    When a follow-up input is created by logging out the user using the logout operation, yielding a follow-up output for MR18.
    Then the follow-up output should indicate a successful operation with the expected success status for MR18.

