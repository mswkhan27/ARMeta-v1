from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, step_name: str):
    """Raise an AssertionError if the response indicates a server error."""
    status = getattr(response, "status_code", None)
    if status is None:
        raise AssertionError(f"{step_name}: Response object has no status_code")
    if 500 <= status <= 599:
        raise AssertionError(
            f"{step_name}: Server error {status} for URL {response.url} with body: {response.text}"
        )


@given("a seed input that retrieves a pet's details by petId, producing a seed output with the pet's current attributes for MR16.")
def _mr_MR16_seed_input(context):
    # Create a pet to ensure it exists, using POST /pet per OpenAPI (addPet)
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_500(response, "Given MR16 - create pet")
    try:
        response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Given MR16 - failed to create pet: {e}, body: {response.text}")

    try:
        seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Given MR16 - could not decode JSON from create pet response: {e}")

    if not isinstance(seed_response, dict):
        raise AssertionError("Given MR16 - expected JSON object for created pet")

    pet_id = seed_response.get("id")
    if pet_id is None:
        raise AssertionError("Given MR16 - created pet response missing 'id'")

    # Now retrieve the pet's details by petId using GET /pet/{petId} (getPetById)
    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_500(get_response, "Given MR16 - get pet by id")
    try:
        get_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Given MR16 - failed to retrieve pet by id: {e}, body: {get_response.text}")

    try:
        get_pet = get_response.json()
    except ValueError as e:
        raise AssertionError(f"Given MR16 - could not decode JSON from get pet response: {e}")

    if not isinstance(get_pet, dict):
        raise AssertionError("Given MR16 - expected JSON object for get pet by id response")

    context.seed_request = pet_data
    context.seed_response = get_pet
    context.pet_id = pet_id


@when("a follow-up input is created by updating the pet's name using form data parameters while not providing values for any other pet attributes, and then retrieving the pet's details again, yielding a follow-up output for MR16.")
def _mr_MR16_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AssertionError("When MR16 - context.pet_id is missing from Given step")

    pet_id = context.pet_id

    # Update the pet's name using form data parameters via POST /pet/{petId} (updatePetWithForm)
    params = {
        "name": "new_doggie"
        # status intentionally omitted to satisfy MR requirement
    }

    update_response = requests.post(f"{BASE_URL}/pet/{pet_id}", params=params, timeout=10)
    _check_500(update_response, "When MR16 - update pet with form")
    try:
        update_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"When MR16 - failed to update pet with form data: {e}, body: {update_response.text}")

    # Retrieve the pet's details again using GET /pet/{petId}
    followup_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_500(followup_response, "When MR16 - get pet after update")
    try:
        followup_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"When MR16 - failed to retrieve pet after update: {e}, body: {followup_response.text}")

    try:
        followup_pet = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"When MR16 - could not decode JSON from follow-up get pet response: {e}")

    if not isinstance(followup_pet, dict):
        raise AssertionError("When MR16 - expected JSON object for follow-up get pet response")

    context.followup_request = {"name": "new_doggie"}
    context.followup_response = followup_pet


@then("the follow-up output should show the updated name while all other pet attributes for which no new values were provided in the update request remain identical to those in the seed output for MR16.")
def _mr_MR16_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Then MR16 - context.seed_response is missing")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Then MR16 - context.followup_response is missing")
    if not hasattr(context, "followup_request"):
        raise AssertionError("Then MR16 - context.followup_request is missing")

    seed = context.seed_response
    followup = context.followup_response
    new_name = context.followup_request.get("name")

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise AssertionError("Then MR16 - seed and follow-up responses must be dicts")

    if "name" not in followup:
        raise AssertionError("Then MR16 - follow-up response missing 'name' field")
    if followup["name"] != new_name:
        raise AssertionError(
            f"Then MR16 - Name was not updated correctly. "
            f"Expected '{new_name}', got '{followup['name']}'"
        )

    # Compare all other attributes that existed in the seed output
    for key, seed_value in seed.items():
        if key == "name":
            continue
        if key not in followup:
            raise AssertionError(f"Then MR16 - follow-up response missing key '{key}' present in seed response")
        follow_value = followup[key]
        if follow_value != seed_value:
            raise AssertionError(
                f"Then MR16 - Field '{key}' changed unexpectedly. "
                f"Seed: {json.dumps(seed_value, sort_keys=True)}, "
                f"Follow-up: {json.dumps(follow_value, sort_keys=True)}"
            )

# ----






@given("a seed input that retrieves a specific user's details by username, producing a seed output with the user's current attributes for MR17.")
def _mr_MR17_seed_input(context):
    username = "theUser"
    context.seed_request = {"username": username}

    response = None
    try:
        response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
        _check_500(response, "GIVEN")
        response.raise_for_status()
        # Ensure JSON decoding is safe
        try:
            context.seed_response = response.json()
        except ValueError as e:
            raise AssertionError(f"Invalid JSON in GIVEN step for MR17: {e}")
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in GIVEN step for MR17: {e}")


@when("a follow-up input is created by updating the user's email in the user resource while not providing changes to any other user attributes, and then retrieving the user's details again, yielding a follow-up output for MR17.")
def _mr_MR17_followup_input(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("Seed response is missing or invalid in WHEN step for MR17.")

    username = context.seed_response.get("username")
    if not isinstance(username, str) or not username:
        raise AssertionError("Username is missing or invalid in seed response for MR17.")

    updated_email = "new_email@example.com"

    update_data = {
        "id": context.seed_response.get("id"),
        "username": username,
        "firstName": context.seed_response.get("firstName"),
        "lastName": context.seed_response.get("lastName"),
        "email": updated_email,
        "password": context.seed_response.get("password"),
        "phone": context.seed_response.get("phone"),
        "userStatus": context.seed_response.get("userStatus"),
    }

    # Remove keys with value None to avoid sending explicit nulls unintentionally
    update_data = {k: v for k, v in update_data.items() if v is not None}

    update_response = None
    followup_response = None
    try:
        update_response = requests.put(f"{BASE_URL}/user/{username}", json=update_data, timeout=10)
        _check_500(update_response, "WHEN (update)")
        update_response.raise_for_status()

        followup_response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
        _check_500(followup_response, "WHEN (follow-up get)")
        followup_response.raise_for_status()
        try:
            context.followup_response = followup_response.json()
        except ValueError as e:
            raise AssertionError(f"Invalid JSON in WHEN follow-up GET for MR17: {e}")
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in WHEN step for MR17: {e}")


@then("the follow-up output should differ from the seed output only in the email field for which a new value was provided; all other user fields should remain identical for MR17.")
def _mr_MR17_followup_output(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("Seed response is missing or invalid in THEN step for MR17.")
    if not hasattr(context, "followup_response") or not isinstance(context.followup_response, dict):
        raise AssertionError("Follow-up response is missing or invalid in THEN step for MR17.")

    expected_email = "new_email@example.com"
    actual_email = context.followup_response.get("email")
    assert actual_email == expected_email, (
        f"Email field did not update correctly. Expected '{expected_email}', got '{actual_email}'."
    )

    for key in ["id", "username", "firstName", "lastName", "password", "phone", "userStatus"]:
        seed_value = context.seed_response.get(key)
        followup_value = context.followup_response.get(key)
        assert followup_value == seed_value, f"{key} field should remain unchanged for MR17."
