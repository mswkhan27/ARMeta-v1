Feature: Iteration 3 MRs

  Scenario: MR16 Updating a pet's details with form data should reflect only the changes made
    Given a seed input that retrieves a pet's details by petId, producing a seed output with the pet's current attributes for MR16.
    When a follow-up input is created by updating the pet's name using form data parameters while not providing values for any other pet attributes, and then retrieving the pet's details again, yielding a follow-up output for MR16.
    Then the follow-up output should show the updated name while all other pet attributes for which no new values were provided in the update request remain identical to those in the seed output for MR16.

  Scenario: MR17 Updating a user's information should reflect only the changes made
    Given a seed input that retrieves a specific user's details by username, producing a seed output with the user's current attributes for MR17.
    When a follow-up input is created by updating the user's email in the user resource while not providing changes to any other user attributes, and then retrieving the user's details again, yielding a follow-up output for MR17.
    Then the follow-up output should differ from the seed output only in the email field for which a new value was provided; all other user fields should remain identical for MR17.
