from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, step_name: str) -> None:
    """Fail the test explicitly on any 5xx response."""
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"{step_name} received server error {response.status_code}: {response.text}"
        )


@given('a seed input that logs a user into the system, producing a seed output with a successful login response and any associated login metadata for MR18.')
def _mr_MR18_seed_input(context):
    context.seed_request = {
        'username': 'testuser',
        'password': 'testpassword'
    }

    response = requests.get(
        f"{BASE_URL}/user/login",
        params=context.seed_request,
        timeout=10
    )
    _check_500(response, "MR18 Given /user/login")
    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"MR18 Given step failed: {e} - Body: {response.text}")

    # /user/login returns a string in JSON or XML; treat JSON safely
    try:
        # For safety, accept either JSON string or raw text
        try:
            parsed = response.json()
        except ValueError:
            parsed = response.text

        context.seed_response = parsed
        if not isinstance(parsed, str):
            raise AssertionError(
                f"MR18 Given expected login response to be a string, got {type(parsed)}: {parsed!r}"
            )
    except Exception as e:
        raise AssertionError(f"MR18 Given step processing failed: {e}")


@when('a follow-up input is created by logging out the user using the logout operation, yielding a follow-up output for MR18.')
def _mr_MR18_followup_input(context):
    response = requests.get(
        f"{BASE_URL}/user/logout",
        timeout=10
    )
    _check_500(response, "MR18 When /user/logout")
    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"MR18 When step failed: {e} - Body: {response.text}")

    # /user/logout 200 response has no defined body; handle safely
    try:
        try:
            context.followup_response = response.json()
        except ValueError:
            # No JSON body; store empty dict to avoid TypeError later
            context.followup_response = {}
    except Exception as e:
        raise AssertionError(f"MR18 When step processing failed: {e}")


@then('the follow-up output should indicate a successful operation with the expected success status for MR18.')
def _mr_MR18_followup_output(context):
    # Success is primarily indicated by HTTP 200 from the When step.
    # Here we only check that we have a safely stored response object.
    try:
        # Ensure attribute exists and is a dict or string (both safe given the spec)
        if not hasattr(context, "followup_response"):
            raise AssertionError("MR18 Then step: followup_response is missing from context.")

        if context.followup_response is not None and not isinstance(
            context.followup_response, (dict, str)
        ):
            raise AssertionError(
                f"MR18 Then step: unexpected type for followup_response: {type(context.followup_response)}"
            )
    except Exception as e:
        raise AssertionError(f"MR18 Then step validation failed: {e}")
