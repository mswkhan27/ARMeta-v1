Feature: Iteration 4 MRs

  Scenario: MR18 Logging out should return a successful operation response
    Given a seed input that logs a user into the system, producing a seed output with a successful login response and any associated login metadata for MR18.
    When a follow-up input is created by logging out the user using the logout operation, yielding a follow-up output for MR18.
    Then the follow-up output should indicate a successful operation with the expected success status for MR18.
