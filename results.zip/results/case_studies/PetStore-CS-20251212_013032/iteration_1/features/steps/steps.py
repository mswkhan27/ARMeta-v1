from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


def _check_server_error(response, step_name: str) -> None:
    """
    Ensure no 5xx response is silently accepted.
    Raises AssertionError so Behave marks the step as failed.
    """
    status = getattr(response, "status_code", None)
    if isinstance(status, int) and 500 <= status <= 599:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"{step_name}: Server error {status} from {response.request.method} "
            f"{response.request.url} - Response body: {body}"
        )


@given(
    "a seed input that retrieves a specific user's details by username, producing a seed output with the user's information for MR6."
)
def _mr_MR6_seed_input(context):
    username = "testuser"
    context.seed_request = {"username": username}

    # Create the user first using POST /user
    user_data = {
        "id": 0,
        "username": username,
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1,
    }

    create_resp = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    _check_server_error(create_resp, "Given MR6 - create user")
    # For MR semantics we expect a successful creation; fail otherwise
    assert 200 <= create_resp.status_code < 300, (
        f"Given MR6 - create user failed with status {create_resp.status_code}: "
        f"{create_resp.text}"
    )

    # Now retrieve the user using GET /user/\{username\}
    get_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    _check_server_error(get_resp, "Given MR6 - get user")
    assert 200 <= get_resp.status_code < 300, (
        f"Given MR6 - expected to retrieve created user, got status "
        f"{get_resp.status_code}: {get_resp.text}"
    )

    try:
        context.seed_response = get_resp.json()
    except ValueError as exc:
        raise AssertionError(
            f"Given MR6 - response from GET /user/{{username}} is not valid JSON: {exc}"
        )


@when(
    "a follow-up input is created by deleting the user with the same username and then attempting to retrieve the user's details again, yielding a follow-up output for MR6."
)
def _mr_MR6_followup_input(context):
    username = context.seed_request.get("username")
    if not isinstance(username, str):
        raise AssertionError("When MR6 - username in seed_request is missing or not a string")

    # Delete the user using DELETE /user/\{username\}
    delete_resp = requests.delete(f"{BASE_URL}/user/{username}", timeout=10)
    _check_server_error(delete_resp, "When MR6 - delete user")
    # Allow non-2xx (e.g., 404) but store for debugging
    context.delete_status_code = delete_resp.status_code
    context.delete_response_text = delete_resp.text

    # Attempt to retrieve the user again using GET /user/\{username\}
    followup_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    _check_server_error(followup_resp, "When MR6 - get user after delete")
    context.followup_response = followup_resp


@then(
    "the follow-up output should indicate that the user is not found, contrasting with the presence of the user in the seed output for MR6."
)
def _mr_MR6_followup_output(context):
    followup_resp = getattr(context, "followup_response", None)
    assert followup_resp is not None, "Then MR6 - followup_response is missing from context"

    status = getattr(followup_resp, "status_code", None)
    assert status == 404, (
        f"Then MR6 - expected 404 user not found after deletion, "
        f"got {status} with body: {followup_resp.text}"
    )

    seed_resp = getattr(context, "seed_response", None)
    assert isinstance(seed_resp, dict), "Then MR6 - seed_response is missing or not a dict"

    seed_username = seed_resp.get("username")
    request_username = context.seed_request.get("username")
    assert seed_username == request_username, (
        f"Then MR6 - seed output should contain the username before deletion. "
        f"Expected '{request_username}', got '{seed_username}'."
    )

# ----




def _check_response_no_500(response, context_message: str) -> None:
    status = getattr(response, "status_code", None)
    if status is None:
        raise AssertionError(f"{context_message}: Response has no status_code")
    if status >= 500:
        raise AssertionError(f"{context_message}: Server error {status}: {response.text}")


@given("a seed input that retrieves a pet's details by petId, producing a seed output with the pet's current attributes for MR7.")
def _mr_MR7_seed_input(context):
    pet_id = 1  # Assuming petId 1 exists for testing

    context.seed_request = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(context.seed_request, "Failed to retrieve pet details (seed)")
    if context.seed_request.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve pet details (seed): "
            f"status={context.seed_request.status_code}, body={context.seed_request.text}"
        )

    try:
        context.seed_response = context.seed_request.json()
    except json.JSONDecodeError as exc:
        raise AssertionError(
            f"Failed to decode JSON response for seed pet details: {context.seed_request.text}"
        ) from exc

    if not isinstance(context.seed_response, dict):
        raise AssertionError(
            f"Seed response is not a JSON object: {context.seed_response!r}"
        )


@when("a follow-up input is created by uploading an image for the pet with the same petId and then retrieving the pet's details again, yielding a follow-up output for MR7.")
def _mr_MR7_followup_input(context):
    pet_id = context.seed_response.get("id", 1)

    # The OpenAPI spec defines requestBody for /pet/{petId}/uploadImage with
    # content: application/octet-stream; we send raw bytes accordingly.
    image_bytes = b"\x89PNG\r\n\x1a\n"  # Minimal dummy bytes; replace with real image if needed.
    headers = {"Content-Type": "application/octet-stream"}

    upload_response = requests.post(
        f"{BASE_URL}/pet/{pet_id}/uploadImage",
        data=image_bytes,
        headers=headers,
        timeout=10,
    )
    _check_response_no_500(upload_response, "Failed to upload image (follow-up)")

    if upload_response.status_code != 200:
        # Try to include JSON if available, otherwise raw text
        try:
            body = upload_response.json()
        except json.JSONDecodeError:
            body = upload_response.text
        raise AssertionError(
            f"Failed to upload image for petId {pet_id}: "
            f"status={upload_response.status_code}, body={body}"
        )

    context.followup_request = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(context.followup_request, "Failed to retrieve pet details after upload (follow-up)")

    if context.followup_request.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve pet details after upload: "
            f"status={context.followup_request.status_code}, body={context.followup_request.text}"
        )

    try:
        context.followup_response = context.followup_request.json()
    except json.JSONDecodeError as exc:
        raise AssertionError(
            f"Failed to decode JSON response for follow-up pet details: {context.followup_request.text}"
        ) from exc

    if not isinstance(context.followup_response, dict):
        raise AssertionError(
            f"Follow-up response is not a JSON object: {context.followup_response!r}"
        )


@then("the follow-up output should have the same pet attributes as the seed output, since uploading an image only affects associated media and does not modify the pet's core data for MR7.")
def _mr_MR7_assert_followup_output(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise AssertionError(
            f"Seed or follow-up response is missing or not a dict: "
            f"seed={seed!r}, followup={followup!r}"
        )

    for key in ["id", "name", "category", "tags", "status", "photoUrls"]:
        if key not in seed:
            raise AssertionError(f"Seed response missing expected key: {key}")
        if key not in followup:
            raise AssertionError(f"Follow-up response missing expected key: {key}")

    assert followup["id"] == seed["id"], "Pet ID should match between seed and follow-up"
    assert followup["name"] == seed["name"], "Pet name should match between seed and follow-up"
    assert followup["category"] == seed["category"], "Pet category should match between seed and follow-up"
    assert followup["tags"] == seed["tags"], "Pet tags should match between seed and follow-up"
    assert followup["status"] == seed["status"], "Pet status should match between seed and follow-up"
    assert followup["photoUrls"] == seed["photoUrls"], "Pet photoUrls should remain unchanged after image upload"

# ----

from requests import Response

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _safe_get_json(response: Response):
    try:
        return response.json()
    except ValueError:
        return None


def _check_500(response: Response, step_name: str):
    if response is not None and response.status_code >= 500:
        raise AssertionError(
            f"Server error {response.status_code} in {step_name}: {response.text}"
        )


@given('a seed input that attempts to retrieve several users by a set of distinct usernames, producing a seed output in which these users are not yet present or have different details for MR8.')
def _mr_MR8_seed_input(context):
    context.usernames = ['user1', 'user2', 'user3']
    context.seed_response = []

    for username in context.usernames:
        try:
            response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
            _check_500(response, "MR8 seed input - GET /user/\\{username\\}")
        except requests.RequestException as e:
            raise AssertionError(f"HTTP error in seed input for MR8 while retrieving user '{username}': {e}") from e

        if response.status_code == 404:
            context.seed_response.append({'username': username, 'exists': False})
        else:
            # For any non-404 (e.g., 200, 400, etc.), mark as exists=True; do not assume JSON shape here
            context.seed_response.append({'username': username, 'exists': True})


@when('a follow-up input is created by adding a list of new users with those usernames and then retrieving each user again by username, yielding a follow-up output for MR8.')
def _mr_MR8_followup_input(context):
    context.new_users = [
        {
            "id": 1,
            "username": "user1",
            "firstName": "John",
            "lastName": "Doe",
            "email": "john@example.com",
            "password": "password1",
            "phone": "1111111111",
            "userStatus": 1
        },
        {
            "id": 2,
            "username": "user2",
            "firstName": "Jane",
            "lastName": "Doe",
            "email": "jane@example.com",
            "password": "password2",
            "phone": "2222222222",
            "userStatus": 1
        },
        {
            "id": 3,
            "username": "user3",
            "firstName": "Jim",
            "lastName": "Beam",
            "email": "jim@example.com",
            "password": "password3",
            "phone": "3333333333",
            "userStatus": 1
        }
    ]

    # Create users with list endpoint: POST /user/createWithList
    try:
        create_response = requests.post(
            f"{BASE_URL}/user/createWithList",
            json=context.new_users,
            timeout=10
        )
        _check_500(create_response, "MR8 follow-up input - POST /user/createWithList")
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in follow-up input for MR8 while creating users: {e}") from e

    if create_response.status_code != 200:
        raise AssertionError(
            f"Failed to create users for MR8: status={create_response.status_code}, body={create_response.text}"
        )

    # Retrieve each user again by username: GET /user/{username}
    context.followup_response = []
    for username in context.usernames:
        try:
            response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
            _check_500(response, "MR8 follow-up input - GET /user/\\{username\\}")
        except requests.RequestException as e:
            raise AssertionError(
                f"HTTP error in follow-up input for MR8 while retrieving user '{username}': {e}"
            ) from e

        if response.status_code == 200:
            data = _safe_get_json(response)
            if isinstance(data, dict):
                context.followup_response.append(data)
            else:
                # If body is not valid JSON object, still record existence but avoid type errors
                context.followup_response.append({'username': username, 'exists': True})
        else:
            # For non-200, record as not existing for assertion in then-step
            context.followup_response.append({'username': username, 'exists': False})


@then('the follow-up output should show that each of the newly added users is now retrievable by username with details matching the created user data for MR8.')
def _mr_MR8_followup_output(context):
    # Build a lookup dict for expected users by username to avoid repeated scans
    expected_by_username = {u.get('username'): u for u in getattr(context, 'new_users', [])}

    for user in context.followup_response:
        # Ensure we safely get the username key as a string
        username = None
        if isinstance(user, dict):
            username = user.get('username')
        if not isinstance(username, str):
            # If username is missing or not a string, this is an unexpected shape
            raise AssertionError(f"Follow-up response entry has invalid or missing 'username': {user}")

        exists_flag = True
        if isinstance(user, dict) and 'exists' in user:
            exists_flag = bool(user.get('exists'))

        if not exists_flag:
            raise AssertionError(f"User {username} should exist after creation in MR8 but was not found.")

        expected_user = expected_by_username.get(username)
        if expected_user is None:
            raise AssertionError(f"User {username} not found in new users list for MR8.")

        # Only perform comparisons on keys we know we set to avoid KeyError/TypeError
        for field in ['firstName', 'lastName', 'email']:
            actual_value = None
            if isinstance(user, dict):
                actual_value = user.get(field)
            expected_value = expected_user.get(field)
            if actual_value != expected_value:
                raise AssertionError(
                    f"{field} mismatch for user '{username}' in MR8: "
                    f"expected={expected_value!r}, actual={actual_value!r}"
                )

# ----






@given(
    "a seed input that places a new order for a pet, producing a seed output that includes the created order details and its identifier for MR9."
)
def _mr_MR9_seed_input(context):
    # Construct a valid order body according to the OpenAPI Order schema
    pet_id = 198772  # example petId from the spec; assuming such a pet can exist
    order_data = {
        "petId": pet_id,
        "quantity": 1,
        "status": "placed",
        "complete": False,
    }

    context.seed_request = order_data

    response = requests.post(f"{BASE_URL}/store/order", json=order_data, timeout=10)
    _check_response_no_500(response, "Given MR9 (place order)")

    # Raise for non-2xx after checking 5xx explicitly
    response.raise_for_status()

    # Safely parse JSON; this will raise ValueError if invalid, which is desired
    seed_response = response.json()
    if not isinstance(seed_response, dict):
        raise AssertionError(
            f"Given MR9 (place order) expected response JSON object, got: {type(seed_response)}"
        )

    # Ensure an 'id' is present to avoid AttributeError/TypeError later
    order_id = seed_response.get("id")
    if not isinstance(order_id, int):
        raise AssertionError(
            f"Given MR9 (place order) expected integer 'id' in response, got: {order_id!r}"
        )

    context.seed_response = seed_response


@when(
    "a follow-up input is created by retrieving the order using the same identifier from the seed output, yielding a follow-up output for MR9."
)
def _mr_MR9_followup_input(context):
    # Defensive extraction of order id from seed response
    if not hasattr(context, "seed_response") or not isinstance(
        context.seed_response, dict
    ):
        raise AssertionError(
            "When MR9 (get order) requires 'seed_response' dict set by Given step."
        )

    order_id = context.seed_response.get("id")
    if not isinstance(order_id, int):
        raise AssertionError(
            f"When MR9 (get order) expected integer 'id' in seed_response, got: {order_id!r}"
        )

    response = requests.get(
        f"{BASE_URL}/store/order/{order_id}",
        timeout=10,
    )
    _check_response_no_500(response, "When MR9 (get order by id)")

    response.raise_for_status()

    followup_response = response.json()
    if not isinstance(followup_response, dict):
        raise AssertionError(
            f"When MR9 (get order) expected response JSON object, got: {type(followup_response)}"
        )

    context.followup_response = followup_response


@then(
    "the follow-up output should contain order details consistent with the seed output, reflecting the same identifier, associated pet, quantity, and status for MR9."
)
def _mr_MR9_followup_output(context):
    if not hasattr(context, "seed_response") or not isinstance(
        context.seed_response, dict
    ):
        raise AssertionError(
            "Then MR9 requires 'seed_response' dict set by Given step."
        )
    if not hasattr(context, "followup_response") or not isinstance(
        context.followup_response, dict
    ):
        raise AssertionError(
            "Then MR9 requires 'followup_response' dict set by When step."
        )

    seed = context.seed_response
    follow = context.followup_response

    # Use get with explicit comparison to avoid TypeError
    assert follow.get("id") == seed.get("id"), (
        f"Order ID does not match: seed={seed.get('id')!r}, "
        f"followup={follow.get('id')!r}"
    )
    assert follow.get("petId") == seed.get("petId"), (
        f"Pet ID does not match: seed={seed.get('petId')!r}, "
        f"followup={follow.get('petId')!r}"
    )
    assert follow.get("quantity") == seed.get("quantity"), (
        f"Quantity does not match: seed={seed.get('quantity')!r}, "
        f"followup={follow.get('quantity')!r}"
    )
    assert follow.get("status") == seed.get("status"), (
        f"Status does not match: seed={seed.get('status')!r}, "
        f"followup={follow.get('status')!r}"
    )

# ----


TAGS = ["tag1", "tag2"]  # Example tags used consistently across steps


def _check_response_for_server_error(response, step_name: str) -> None:
    """
    Raises an AssertionError if the response indicates a server error (HTTP 5xx).
    """
    if response is None:
        raise AssertionError(f"{step_name}: No response received from the server.")
    status_code = getattr(response, "status_code", None)
    if status_code is None:
        raise AssertionError(f"{step_name}: Response has no status_code attribute.")
    if 500 <= status_code <= 599:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unavailable>"
        raise AssertionError(
            f"{step_name}: Server error {status_code} received from API. Response body: {body}"
        )




@given('a seed input that retrieves pets by a specific set of tags, producing a seed output with a list of pets for those tags for MR10.')
def _mr_MR10_seed_input(context):
    # /pet/findByTags matches: "Finds Pets by tags. Multiple tags can be provided..."
    params = [("tags", tag) for tag in TAGS]
    response = requests.get(f"{BASE_URL}/pet/findByTags", params=params, timeout=10)

    context.seed_request = response
    context.seed_response = _safe_get_json(response, "MR10 Given")

    if response.status_code != 200:
        raise AssertionError(
            f"MR10 Given: Expected status code 200 but received {response.status_code}. "
            f"Body: {response.text}"
        )


@when('a follow-up input is created by retrieving pets again with the same set of tags, assuming no intervening changes to the pets associated with those tags, yielding a follow-up output for MR10.')
def _mr_MR10_followup_input(context):
    params = [("tags", tag) for tag in TAGS]
    response = requests.get(f"{BASE_URL}/pet/findByTags", params=params, timeout=10)

    context.followup_request = response
    context.followup_response = _safe_get_json(response, "MR10 When")

    if response.status_code != 200:
        raise AssertionError(
            f"MR10 When: Expected status code 200 but received {response.status_code}. "
            f"Body: {response.text}"
        )


@then('the follow-up output should be identical to the seed output, reflecting a stable mapping from the given tags to the corresponding pets for MR10.')
def _mr_MR10_assert_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("MR10 Then: seed_response is missing from context.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("MR10 Then: followup_response is missing from context.")

    try:
        seed_json = json.dumps(context.seed_response, sort_keys=True)
        followup_json = json.dumps(context.followup_response, sort_keys=True)
    except (TypeError, ValueError) as exc:
        raise AssertionError(f"MR10 Then: Unable to serialize responses for comparison: {exc}")

    if seed_json != followup_json:
        raise AssertionError(
            "MR10 Then: Follow-up output does not match seed output.\n"
            f"Seed output: {seed_json}\n"
            f"Follow-up output: {followup_json}"
        )
