Feature: Iteration 1 MRs

  Scenario: MR6 Deleting a user should remove the user from subsequent retrievals
    Given a seed input that retrieves a specific user's details by username, producing a seed output with the user's information for MR6.
    When a follow-up input is created by deleting the user with the same username and then attempting to retrieve the user's details again, yielding a follow-up output for MR6.
    Then the follow-up output should indicate that the user is not found, contrasting with the presence of the user in the seed output for MR6.

  Scenario: MR7 Uploading an image for a pet should not alter the pet's other attributes
    Given a seed input that retrieves a pet's details by petId, producing a seed output with the pet's current attributes for MR7.
    When a follow-up input is created by uploading an image for the pet with the same petId and then retrieving the pet's details again, yielding a follow-up output for MR7.
    Then the follow-up output should have the same pet attributes as the seed output, since uploading an image only affects associated media and does not modify the pet's core data for MR7.

  Scenario: MR8 Creating multiple users with a list should make each user individually retrievable
    Given a seed input that attempts to retrieve several users by a set of distinct usernames, producing a seed output in which these users are not yet present or have different details for MR8.
    When a follow-up input is created by adding a list of new users with those usernames and then retrieving each user again by username, yielding a follow-up output for MR8.
    Then the follow-up output should show that each of the newly added users is now retrievable by username with details matching the created user data for MR8.

  Scenario: MR9 Placing an order should make that order retrievable by its identifier
    Given a seed input that places a new order for a pet, producing a seed output that includes the created order details and its identifier for MR9.
    When a follow-up input is created by retrieving the order using the same identifier from the seed output, yielding a follow-up output for MR9.
    Then the follow-up output should contain order details consistent with the seed output, reflecting the same identifier, associated pet, quantity, and status for MR9.

  Scenario: MR10 Retrieving pets by tags should return a consistent set of pets for the same tags
    Given a seed input that retrieves pets by a specific set of tags, producing a seed output with a list of pets for those tags for MR10.
    When a follow-up input is created by retrieving pets again with the same set of tags, assuming no intervening changes to the pets associated with those tags, yielding a follow-up output for MR10.
    Then the follow-up output should be identical to the seed output, reflecting a stable mapping from the given tags to the corresponding pets for MR10.
