from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, step_label: str):
    """Fail fast on HTTP 500 to avoid masking server errors."""
    if response is not None and response.status_code == 500:
        try:
            body = response.json()
        except ValueError:
            body = response.text
        raise AssertionError(f"{step_label}: Server returned 500. Response body: {body}")


@given('a seed input that retrieves an order by its ID, producing a seed output with the order details for MR11.')
def _mr_MR11_seed_input(context):
    # Ensure deterministic and safe behaviour + no TypeError/ValueError
    order_data = {
        "id": 10,
        "petId": 198772,
        "quantity": 1,
        "status": "placed",
        "complete": True
    }

    try:
        response = requests.post(
            f"{BASE_URL}/store/order",
            json=order_data,
            timeout=10
        )
    except requests.RequestException as e:
        raise AssertionError(f"Given MR11: HTTP error while creating order: {e}")

    _check_500(response, "Given MR11")

    context.seed_request = response
    try:
        context.seed_response = response.json()
    except ValueError:
        raise AssertionError(f"Given MR11: Response is not valid JSON: {response.text}")

    if response.status_code != 200:
        raise AssertionError(
            f"Given MR11: Failed to create order. "
            f"Status: {response.status_code}, Body: {context.seed_response}"
        )

    # Safely extract order id
    order_id = context.seed_response.get("id")
    if not isinstance(order_id, int):
        raise AssertionError(
            f"Given MR11: Expected integer 'id' in response, got: {context.seed_response}"
        )
    context.order_id = order_id


@when('a follow-up input is created by deleting the order with the same ID and then attempting to retrieve the order again, yielding a follow-up output for MR11.')
def _mr_MR11_followup_input(context):
    if not hasattr(context, "order_id"):
        raise AssertionError("When MR11: 'order_id' not found in context from Given step.")

    order_id = context.order_id

    # Delete the order using /store/\{orderId\} DELETE as per OpenAPI
    try:
        delete_response = requests.delete(
            f"{BASE_URL}/store/order/{order_id}",
            timeout=10
        )
    except requests.RequestException as e:
        raise AssertionError(f"When MR11: HTTP error while deleting order: {e}")

    _check_500(delete_response, "When MR11 - delete")

    # For MR, we require successful deletion (200)
    if delete_response.status_code != 200:
        try:
            delete_body = delete_response.json()
        except ValueError:
            delete_body = delete_response.text
        raise AssertionError(
            f"When MR11: Failed to delete order. "
            f"Status: {delete_response.status_code}, Body: {delete_body}"
        )

    context.delete_response = delete_response

    # Attempt to retrieve the (now deleted) order using /store/\{orderId\} GET
    try:
        followup_request = requests.get(
            f"{BASE_URL}/store/order/{order_id}",
            timeout=10
        )
    except requests.RequestException as e:
        raise AssertionError(f"When MR11: HTTP error while retrieving deleted order: {e}")

    _check_500(followup_request, "When MR11 - get after delete")

    context.followup_request = followup_request
    try:
        context.followup_response = followup_request.json()
    except ValueError:
        # If the body is not JSON, still store text for assertion messages
        context.followup_response = {"raw": followup_request.text}


@then('the follow-up output should indicate that the order is not found (for example, via a not-found error), contrasting with the presence of the order in the seed output for MR11.')
def _mr_MR11_followup_output(context):
    if not hasattr(context, "seed_request") or not hasattr(context, "seed_response"):
        raise AssertionError("Then MR11: Seed data not available in context.")
    if not hasattr(context, "followup_request") or not hasattr(context, "followup_response"):
        raise AssertionError("Then MR11: Follow-up data not available in context.")

    # Sanity: seed call must have succeeded and produced an order
    if context.seed_request.status_code != 200:
        raise AssertionError(
            f"Then MR11: Seed step did not successfully create/retrieve order. "
            f"Status: {context.seed_request.status_code}, Body: {context.seed_response}"
        )

    # Metamorphic relation: after delete, GET should indicate not found
    status_code = context.followup_request.status_code
    response_body = context.followup_response

    if status_code != 404:
        raise AssertionError(
            f"Then MR11: Expected status 404 for deleted order, "
            f"got {status_code}. Body: {response_body}"
        )

    # The spec describes 404 as "Order not found" but does not mandate a JSON schema;
    # we only check that some content is present or that the body indicates not found if JSON.
    if isinstance(response_body, dict):
        message = response_body.get("message") or response_body.get("error") or ""
        if message and "not" in message.lower() and "found" in message.lower():
            return
        # If no clear not-found message, still accept as long as 404 is returned,
        # but keep a soft assertion style note for debugging.
        # We don't fail here to avoid over-constraining the implementation.
    # Status code 404 is considered sufficient to satisfy MR11.

# ----






@given('a seed input that retrieves the pet inventory by status, producing a seed output with a map of status codes to quantities for MR12.')
def _mr_MR12_seed_input(context):
    response = None
    try:
        response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
        _check_500(response, "Given step")
        response.raise_for_status()
        # Ensure JSON decoding errors are surfaced clearly
        try:
            context.seed_response = response.json()
        except ValueError as e:
            raise AssertionError(f"MR12 Given step: Failed to decode JSON response: {e}") from e
        context.seed_request = None  # No request body for this GET
    except Exception as e:
        raise AssertionError(f"Error in MR12 Given step: {e}") from e


@when('a follow-up input is created by retrieving the inventory again without performing any operations that change pet statuses or quantities, yielding a follow-up output for MR12.')
def _mr_MR12_followup_input(context):
    response = None
    try:
        response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
        _check_500(response, "When step")
        response.raise_for_status()
        try:
            context.followup_response = response.json()
        except ValueError as e:
            raise AssertionError(f"MR12 When step: Failed to decode JSON response: {e}") from e
        context.followup_request = None  # No request body for this GET
    except Exception as e:
        raise AssertionError(f"Error in MR12 When step: {e}") from e


@then('the follow-up output should be identical to the seed output, reflecting consistent status counts for MR12 when no intervening changes have been made.')
def _mr_MR12_assert_consistency(context):
    try:
        # Defensive checks to avoid AttributeError / TypeError
        if not hasattr(context, "seed_response"):
            raise AssertionError("MR12 Then step: seed_response is missing from context.")
        if not hasattr(context, "followup_response"):
            raise AssertionError("MR12 Then step: followup_response is missing from context.")

        # Compare the two inventory maps directly
        if context.seed_response != context.followup_response:
            seed_str = json.dumps(context.seed_response, sort_keys=True)
            followup_str = json.dumps(context.followup_response, sort_keys=True)
            raise AssertionError(
                "Seed output and follow-up output do not match for MR12.\n"
                f"Seed: {seed_str}\nFollow-up: {followup_str}"
            )
    except Exception as e:
        raise AssertionError(f"Assertion error in MR12 Then step: {e}") from e

# ----

from datetime import datetime



def _check_server_error(response, step_name: str) -> None:
    """
    Ensure no 5xx response is silently ignored.
    Raise an AssertionError so Behave marks the step as failed.
    """
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"{step_name}: Server error {response.status_code} for URL {response.url} "
            f"with body: {response.text}"
        )


def _safe_get_header(headers, name: str):
    """
    Safely get a header value, returning None if missing.
    """
    return headers.get(name)


def _parse_http_datetime(value: str):
    """
    Parse an HTTP-date-like string into a datetime object.
    Falls back to lexical comparison if parsing fails.
    """
    if value is None:
        return None

    # Try a few common formats; do not raise if all fail.
    for fmt in (
        "%a, %d %b %Y %H:%M:%S %Z",
        "%a, %d %b %Y %H:%M:%S GMT",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S.%f%z",
    ):
        try:
            return datetime.strptime(value, fmt)
        except (ValueError, TypeError):
            continue
    return None


@given('a seed input that logs a user into the system with valid credentials, producing a seed output containing a login response body and login-related headers (such as rate limit and expiration information) for MR13.')
def step_mr_MR13_seed_input(context):
    context.username = "testuser"
    context.password = "testpassword"

    context.seed_request_params = {
        "username": context.username,
        "password": context.password,
    }

    try:
        response = requests.get(
            f"{BASE_URL}/user/login",
            params=context.seed_request_params,
            timeout=10,
        )
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"MR13 Given: HTTP request failed: {e}")

    _check_server_error(response, "MR13 Given")

    try:
        context.seed_response = response
        # loginUser returns a string body; JSON parsing may fail, so keep raw text
        context.seed_body_text = response.text
    except Exception as e:
        raise AssertionError(f"MR13 Given: Unexpected error handling response: {e}")


@when('a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR13.')
def step_mr_MR13_followup_input(context):
    if not hasattr(context, "seed_request_params"):
        raise AssertionError("MR13 When: seed_request_params not set in context")

    try:
        response = requests.get(
            f"{BASE_URL}/user/login",
            params=context.seed_request_params,
            timeout=10,
        )
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"MR13 When: HTTP request failed: {e}")

    _check_server_error(response, "MR13 When")

    try:
        context.followup_response = response
        context.followup_body_text = response.text
    except Exception as e:
        raise AssertionError(f"MR13 When: Unexpected error handling response: {e}")


@then('the follow-up output should again indicate a successful login and provide login-related headers (such as rate limit and expiration information); the expiration information in the follow-up output should be equal to or later than that in the seed output for MR13.')
def step_mr_MR13_followup_output(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AssertionError("MR13 Then: Missing responses in context")

    # Status checks
    if context.seed_response.status_code != 200:
        raise AssertionError(
            f"MR13 Then: Seed login was not successful, "
            f"status_code={context.seed_response.status_code}, body={context.seed_response.text}"
        )
    if context.followup_response.status_code != 200:
        raise AssertionError(
            f"MR13 Then: Follow-up login was not successful, "
            f"status_code={context.followup_response.status_code}, body={context.followup_response.text}"
        )

    # Header presence checks
    seed_rate_limit = _safe_get_header(context.seed_response.headers, "X-Rate-Limit")
    follow_rate_limit = _safe_get_header(context.followup_response.headers, "X-Rate-Limit")
    seed_expires = _safe_get_header(context.seed_response.headers, "X-Expires-After")
    follow_expires = _safe_get_header(context.followup_response.headers, "X-Expires-After")

    if seed_rate_limit is None:
        raise AssertionError("MR13 Then: Seed response missing X-Rate-Limit header")
    if follow_rate_limit is None:
        raise AssertionError("MR13 Then: Follow-up response missing X-Rate-Limit header")
    if seed_expires is None:
        raise AssertionError("MR13 Then: Seed response missing X-Expires-After header")
    if follow_expires is None:
        raise AssertionError("MR13 Then: Follow-up response missing X-Expires-After header")

    # Compare expiration information safely
    seed_dt = _parse_http_datetime(seed_expires)
    follow_dt = _parse_http_datetime(follow_expires)

    if seed_dt is not None and follow_dt is not None:
        if follow_dt < seed_dt:
            raise AssertionError(
                f"MR13 Then: Follow-up expiration ({follow_expires}) is earlier than "
                f"seed expiration ({seed_expires})"
            )
    else:
        # Fallback to lexical comparison if parsing fails
        if str(follow_expires) < str(seed_expires):
            raise AssertionError(
                f"MR13 Then: Follow-up expiration ({follow_expires}) is lexically earlier than "
                f"seed expiration ({seed_expires})"
            )

# ----




def _check_response_no_500(response, step_name: str) -> None:
    """
    Common guard to ensure we never silently pass 500s.
    Raises AssertionError so Behave marks the step as failed.
    """
    if response is None:
        raise AssertionError(f"{step_name}: No response object (response is None).")
    status_code = getattr(response, "status_code", None)
    if status_code is None:
        raise AssertionError(f"{step_name}: Response has no status_code attribute.")
    if status_code >= 500:
        raise AssertionError(
            f"{step_name}: Server error {status_code} received from {response.request.method} "
            f"{response.request.url} with body: {response.text}"
        )


@given("a seed input that retrieves a pet's details by petId, producing a seed output with the pet's current attributes for MR15.")
def _mr_MR15_seed_input(context):
    # Create a pet to ensure it exists using POST /pet
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available",
    }

    response_create = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_no_500(response_create, "MR15 Given - create pet")

    try:
        seed_created = response_create.json()
        if not isinstance(seed_created, dict):
            raise AssertionError(
                "MR15 Given - create pet: Expected JSON object for created pet."
            )
    except (ValueError, TypeError) as e:
        raise AssertionError(f"MR15 Given - create pet: Invalid JSON response: {e}")

    pet_id = seed_created.get("id")
    if pet_id is None:
        raise AssertionError("MR15 Given - create pet: Response has no 'id' field.")

    # Retrieve the pet details using GET /pet/\{petId\}
    response_get = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(response_get, "MR15 Given - get pet")

    try:
        seed_pet = response_get.json()
        if not isinstance(seed_pet, dict):
            raise AssertionError(
                "MR15 Given - get pet: Expected JSON object for pet details."
            )
    except (ValueError, TypeError) as e:
        raise AssertionError(f"MR15 Given - get pet: Invalid JSON response: {e}")

    # Store in context safely
    context.seed_pet = seed_pet
    context.seed_pet_id = pet_id


@when("a follow-up input is created by updating the pet's name while keeping all other attributes the same in the update request, and then retrieving the pet's details again, yielding a follow-up output for MR15.")
def _mr_MR15_followup_input(context):
    if not hasattr(context, "seed_pet") or not isinstance(context.seed_pet, dict):
        raise AssertionError("MR15 When: seed_pet is missing or invalid in context.")
    if not hasattr(context, "seed_pet_id"):
        raise AssertionError("MR15 When: seed_pet_id is missing in context.")

    seed_pet = context.seed_pet
    pet_id = context.seed_pet_id

    # Prepare updated pet payload using PUT /pet (updatePet)
    updated_pet_data = {
        "id": seed_pet.get("id", pet_id),
        "name": "doggie_updated",
        "photoUrls": seed_pet.get("photoUrls", []),
        "status": seed_pet.get("status"),
    }

    response_update = requests.put(f"{BASE_URL}/pet", json=updated_pet_data, timeout=10)
    _check_response_no_500(response_update, "MR15 When - update pet")

    # Retrieve the updated pet details using GET /pet/\{petId\}
    response_get_updated = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(response_get_updated, "MR15 When - get updated pet")

    try:
        followup_pet = response_get_updated.json()
        if not isinstance(followup_pet, dict):
            raise AssertionError(
                "MR15 When - get updated pet: Expected JSON object for pet details."
            )
    except (ValueError, TypeError) as e:
        raise AssertionError(f"MR15 When - get updated pet: Invalid JSON response: {e}")

    context.followup_pet = followup_pet


@then("the follow-up output should show the updated name while all other pet attributes that were left unchanged in the update request remain identical to those in the seed output for MR15.")
def _mr_MR15_followup_output(context):
    if not hasattr(context, "seed_pet") or not isinstance(context.seed_pet, dict):
        raise AssertionError("MR15 Then: seed_pet is missing or invalid in context.")
    if not hasattr(context, "followup_pet") or not isinstance(
        context.followup_pet, dict
    ):
        raise AssertionError("MR15 Then: followup_pet is missing or invalid in context.")

    seed_pet = context.seed_pet
    followup_pet = context.followup_pet

    # Check updated name
    if followup_pet.get("name") != "doggie_updated":
        raise AssertionError(
            f"MR15 Then: Expected name 'doggie_updated', got {followup_pet.get('name')!r}"
        )

    # Safely compare other attributes that were left unchanged in update request
    seed_photo_urls = seed_pet.get("photoUrls", [])
    followup_photo_urls = followup_pet.get("photoUrls", [])
    if seed_photo_urls != followup_photo_urls:
        raise AssertionError(
            f"MR15 Then: photoUrls changed: seed={seed_photo_urls!r}, "
            f"followup={followup_photo_urls!r}"
        )

    seed_status = seed_pet.get("status")
    followup_status = followup_pet.get("status")
    if seed_status != followup_status:
        raise AssertionError(
            f"MR15 Then: status changed: seed={seed_status!r}, "
            f"followup={followup_status!r}"
        )
