Feature: Iteration 2 MRs

  Scenario: MR11 Deleting an order should make it non-retrievable
    Given a seed input that retrieves an order by its ID, producing a seed output with the order details for MR11.
    When a follow-up input is created by deleting the order with the same ID and then attempting to retrieve the order again, yielding a follow-up output for MR11.
    Then the follow-up output should indicate that the order is not found (for example, via a not-found error), contrasting with the presence of the order in the seed output for MR11.

  Scenario: MR12 Retrieving inventory should reflect consistent status counts
    Given a seed input that retrieves the pet inventory by status, producing a seed output with a map of status codes to quantities for MR12.
    When a follow-up input is created by retrieving the inventory again without performing any operations that change pet statuses or quantities, yielding a follow-up output for MR12.
    Then the follow-up output should be identical to the seed output, reflecting consistent status counts for MR12 when no intervening changes have been made.

  Scenario: MR13 Logging in should return consistent login metadata
    Given a seed input that logs a user into the system with valid credentials, producing a seed output containing a login response body and login-related headers (such as rate limit and expiration information) for MR13.
    When a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR13.
    Then the follow-up output should again indicate a successful login and provide login-related headers (such as rate limit and expiration information); the expiration information in the follow-up output should be equal to or later than that in the seed output for MR13.

  Scenario: MR15 Updating a pet's details should reflect only the changes made
    Given a seed input that retrieves a pet's details by petId, producing a seed output with the pet's current attributes for MR15.
    When a follow-up input is created by updating the pet's name while keeping all other attributes the same in the update request, and then retrieving the pet's details again, yielding a follow-up output for MR15.
    Then the follow-up output should show the updated name while all other pet attributes that were left unchanged in the update request remain identical to those in the seed output for MR15.
