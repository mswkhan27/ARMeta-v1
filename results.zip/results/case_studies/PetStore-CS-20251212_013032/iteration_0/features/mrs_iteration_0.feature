Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet with a given status should increase the count of pets with that status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR1.
    When a follow-up input is created by first adding a new pet with status 'available' and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR1.
    Then the follow-up output should have a count of pets with status 'available' that is one more than the seed output for MR1, assuming the newly added pet did not previously exist.

  Scenario: MR2 Updating a pet's status should reflect in subsequent status-based queries
    Given a seed input that first creates or identifies a pet with status 'available' and then retrieves the list of pets filtered by status 'pending', producing a seed output with a list of pending pets that does not include this pet for MR2.
    When a follow-up input is created by updating that pet's status from 'available' to 'pending' and then retrieving again the list of pets filtered by status 'pending', yielding a follow-up output for MR2.
    Then the follow-up output should include the updated pet in the list of pending pets, whereas it was absent from the seed output for MR2.

  Scenario: MR3 Deleting a pet should decrease the count of pets with its status
    Given a seed input that creates or identifies a pet with a known status (for example, 'available') and then retrieves the list of pets filtered by that same status, producing a seed output with a count of pets for that status for MR3.
    When a follow-up input is created by deleting that identified pet and then retrieving again the list of pets filtered by the same status, yielding a follow-up output for MR3.
    Then the follow-up output should have a count of pets with that status that is one less than the seed output for MR3.

  Scenario: MR5 Updating a user's information with a full representation should only change the explicitly modified fields
    Given a seed input that retrieves a specific user's details, producing a seed output with the current values for all of the user's fields for MR5.
    When a follow-up input is created by sending a complete user representation that is identical to the seed output except for a changed email value, and then retrieving the same user's details again, yielding a follow-up output for MR5.
    Then the follow-up output should differ from the seed output only in the email field; all other user fields should remain identical for MR5.
