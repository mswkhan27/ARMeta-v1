from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_response_no_500(response, step_name: str) -> None:
    """
    Ensure that no 5xx error is returned.
    Raises an AssertionError so Behave marks the step as failed.
    """
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"{step_name}: Server error {response.status_code} received from {response.request.method} "
            f"{response.request.url} with body: {response.text}"
        )


@given("a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR1.")
def _mr_MR1_seed_input(context):
    # Retrieve the list of pets with status 'available'
    url = f"{BASE_URL}/pet/findByStatus"
    try:
        response = requests.get(url, params={"status": "available"}, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Given step MR1: Request to {url} failed: {e}") from e

    _check_response_no_500(response, "Given step MR1")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"Given step MR1: Non-success status {response.status_code} from {url}: {response.text}") from e

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Given step MR1: Response from {url} is not valid JSON: {response.text}") from e

    if not isinstance(data, list):
        raise AssertionError(f"Given step MR1: Expected a list of pets from {url}, got: {type(data).__name__}")

    context.seed_request = response
    context.seed_response = data
    context.available_count = len(data)


@when("a follow-up input is created by first adding a new pet with status 'available' and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR1.")
def _mr_MR1_followup_input(context):
    # Create a new pet with status 'available'
    create_url = f"{BASE_URL}/pet"
    new_pet = {
        "name": "NewAvailablePet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    try:
        create_response = requests.post(create_url, json=new_pet, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"When step MR1 (create pet): Request to {create_url} failed: {e}") from e

    _check_response_no_500(create_response, "When step MR1 (create pet)")

    try:
        create_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"When step MR1 (create pet): Non-success status {create_response.status_code} from "
            f"{create_url}: {create_response.text}"
        ) from e

    # Optionally ensure created pet JSON is well-formed (but we don't rely on its fields here)
    try:
        _ = create_response.json()
    except ValueError:
        # If body is not JSON, we still proceed as long as status is 2xx; no TypeError risk later
        pass

    # Retrieve the list of pets with status 'available' again
    list_url = f"{BASE_URL}/pet/findByStatus"
    try:
        followup_response = requests.get(list_url, params={"status": "available"}, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"When step MR1 (list pets): Request to {list_url} failed: {e}") from e

    _check_response_no_500(followup_response, "When step MR1 (list pets)")

    try:
        followup_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"When step MR1 (list pets): Non-success status {followup_response.status_code} from "
            f"{list_url}: {followup_response.text}"
        ) from e

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(
            f"When step MR1 (list pets): Response from {list_url} is not valid JSON: {followup_response.text}"
        ) from e

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"When step MR1 (list pets): Expected a list of pets from {list_url}, got: {type(followup_data).__name__}"
        )

    context.followup_request = followup_response
    context.followup_response = followup_data


@then("the follow-up output should have a count of pets with status 'available' that is one more than the seed output for MR1, assuming the newly added pet did not previously exist.")
def _mr_MR1_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AssertionError("Then step MR1: followup_response is missing from context.")
    if not hasattr(context, "available_count"):
        raise AssertionError("Then step MR1: available_count is missing from context.")

    followup_data = context.followup_response
    if not isinstance(followup_data, list):
        raise AssertionError(
            f"Then step MR1: Expected followup_response to be a list, got: {type(followup_data).__name__}"
        )

    try:
        followup_count = len(followup_data)
    except TypeError as e:
        raise AssertionError(f"Then step MR1: Could not get length of followup_response: {e}") from e

    expected_count = context.available_count + 1
    assert followup_count == expected_count, (
        f"Then step MR1: Expected {expected_count} pets with status 'available', "
        f"but got {followup_count}."
    )

# ----





    status_code = getattr(response, "status_code", None)
    if status_code is None:
        raise AssertionError(f"{step_name}: Response has no status_code attribute")

    if 500 <= status_code <= 599:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unavailable>"
        raise AssertionError(
            f"{step_name}: Server error {status_code} received. Response body: {body}"
        )


def _safe_json(response, step_name: str):
    """
    Safely parse JSON from the response, avoiding TypeError/ValueError.
    """
    if response is None:
        raise AssertionError(f"{step_name}: Cannot parse JSON from None response")
    try:
        return response.json()
    except ValueError as e:
        raise AssertionError(f"{step_name}: Failed to decode JSON response: {e}") from e


@given(
    "a seed input that first creates or identifies a pet with status 'available' and then retrieves the list of pets filtered by status 'pending', producing a seed output with a list of pending pets that does not include this pet for MR2."
)
def _mr_MR2_seed_input(context):
    step_name = "Given MR2 seed input"
    # Create a pet with status 'available' using POST /pet
    pet_data = {
        "name": "Test Pet MR2",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_no_500(response, step_name)
    response.raise_for_status()
    context.seed_response = _safe_json(response, step_name)

    # Retrieve pets with status 'pending' using GET /pet/findByStatus
    pending_response = requests.get(
        f"{BASE_URL}/pet/findByStatus", params={"status": "pending"}, timeout=10
    )
    _check_response_no_500(pending_response, step_name)
    pending_response.raise_for_status()
    context.pending_pets = _safe_json(pending_response, step_name)

    # Be defensive about types
    if not isinstance(context.pending_pets, list):
        raise AssertionError(
            f"{step_name}: Expected list of pets for pending status, got {type(context.pending_pets)}"
        )

    created_id = context.seed_response.get("id")
    if created_id is None:
        raise AssertionError(f"{step_name}: Created pet has no 'id' field: {json.dumps(context.seed_response)}")

    # Assert that the created pet is not in the pending pets
    for pet in context.pending_pets:
        if not isinstance(pet, dict):
            raise AssertionError(f"{step_name}: Expected each pet to be an object, got {type(pet)}")
    assert not any(
        isinstance(pet, dict) and pet.get("id") == created_id for pet in context.pending_pets
    ), "Seed output includes the created pet in pending pets."


@when(
    "a follow-up input is created by updating that pet's status from 'available' to 'pending' and then retrieving again the list of pets filtered by status 'pending', yielding a follow-up output for MR2."
)
def _mr_MR2_followup_input(context):
    step_name = "When MR2 follow-up input"

    if not hasattr(context, "seed_response"):
        raise AssertionError(f"{step_name}: seed_response is missing from context")

    # Update the pet's status to 'pending' using PUT /pet (full Pet object)
    update_data = dict(context.seed_response)
    update_data["status"] = "pending"

    followup_request = requests.put(f"{BASE_URL}/pet", json=update_data, timeout=10)
    _check_response_no_500(followup_request, step_name)
    followup_request.raise_for_status()
    context.followup_response = _safe_json(followup_request, step_name)

    # Retrieve pets with status 'pending' again using GET /pet/findByStatus
    followup_pending_response = requests.get(
        f"{BASE_URL}/pet/findByStatus", params={"status": "pending"}, timeout=10
    )
    _check_response_no_500(followup_pending_response, step_name)
    followup_pending_response.raise_for_status()
    context.followup_pending_pets = _safe_json(followup_pending_response, step_name)

    if not isinstance(context.followup_pending_pets, list):
        raise AssertionError(
            f"{step_name}: Expected list of pets for follow-up pending status, got {type(context.followup_pending_pets)}"
        )


@then(
    "the follow-up output should include the updated pet in the list of pending pets, whereas it was absent from the seed output for MR2."
)
def _mr_MR2_followup_output(context):
    step_name = "Then MR2 follow-up output"

    if not hasattr(context, "followup_response"):
        raise AssertionError(f"{step_name}: followup_response is missing from context")
    if not hasattr(context, "followup_pending_pets"):
        raise AssertionError(f"{step_name}: followup_pending_pets is missing from context")

    updated_id = context.followup_response.get("id")
    if updated_id is None:
        raise AssertionError(f"{step_name}: Updated pet has no 'id' field: {json.dumps(context.followup_response)}")

    pets_list = context.followup_pending_pets
    if not isinstance(pets_list, list):
        raise AssertionError(
            f"{step_name}: Expected followup_pending_pets to be a list, got {type(pets_list)}"
        )

    for pet in pets_list:
        if not isinstance(pet, dict):
            raise AssertionError(f"{step_name}: Expected each pet to be an object, got {type(pet)}")

    assert any(
        pet.get("id") == updated_id for pet in pets_list
    ), "Follow-up output does not include the updated pet in pending pets."

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")




@given(
    "a seed input that creates or identifies a pet with a known status (for example, 'available') "
    "and then retrieves the list of pets filtered by that same status, producing a seed output "
    "with a count of pets for that status for MR3."
)
def step_mr_MR3_seed_input(context):
    # Create a pet with status 'available'
    pet_data = {
        "name": "Test Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }

    # Add a new pet to the store: POST /pet
    seed_request = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_no_500(seed_request, "Given step MR3 - create pet")
    seed_request.raise_for_status()

    # Safely parse JSON and extract pet id
    try:
        seed_pet = seed_request.json()
        if not isinstance(seed_pet, dict):
            raise AssertionError(
                f"Given step MR3 - create pet: Expected JSON object, got {type(seed_pet)}"
            )
    except (ValueError, json.JSONDecodeError) as exc:
        raise AssertionError(f"Given step MR3 - create pet: Invalid JSON response: {exc}")

    pet_id = seed_pet.get("id")
    if pet_id is None:
        raise AssertionError("Given step MR3 - create pet: Response JSON does not contain 'id' field.")

    context.seed_pet_id = pet_id
    context.seed_request = seed_request

    # Retrieve the list of pets with status 'available': GET /pet/findByStatus
    seed_response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params={"status": "available"},
        timeout=10,
    )
    _check_response_no_500(seed_response, "Given step MR3 - findByStatus (seed)")
    seed_response.raise_for_status()

    # Safely parse and count list
    try:
        pets_list = seed_response.json()
    except (ValueError, json.JSONDecodeError) as exc:
        raise AssertionError(
            f"Given step MR3 - findByStatus (seed): Invalid JSON response: {exc}"
        )

    if not isinstance(pets_list, list):
        raise AssertionError(
            f"Given step MR3 - findByStatus (seed): Expected list, got {type(pets_list)}"
        )

    context.seed_response = seed_response
    context.seed_count = len(pets_list)


@when(
    "a follow-up input is created by deleting that identified pet and then retrieving again the list "
    "of pets filtered by the same status, yielding a follow-up output for MR3."
)
def step_mr_MR3_followup_input(context):
    if not hasattr(context, "seed_pet_id"):
        raise AssertionError(
            "When step MR3 - follow-up: 'seed_pet_id' not found in context; Given step may have failed."
        )

    pet_id = context.seed_pet_id

    # Delete the pet: DELETE /pet/\{petId\}
    delete_response = requests.delete(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(delete_response, "When step MR3 - delete pet")
    delete_response.raise_for_status()
    context.delete_response = delete_response

    # Retrieve the list of pets with status 'available' again: GET /pet/findByStatus
    followup_response = requests.get(
        f"{BASE_URL}/pet/findByStatus",
        params={"status": "available"},
        timeout=10,
    )
    _check_response_no_500(followup_response, "When step MR3 - findByStatus (follow-up)")
    followup_response.raise_for_status()

    # Safely parse and count list
    try:
        pets_list_followup = followup_response.json()
    except (ValueError, json.JSONDecodeError) as exc:
        raise AssertionError(
            f"When step MR3 - findByStatus (follow-up): Invalid JSON response: {exc}"
        )

    if not isinstance(pets_list_followup, list):
        raise AssertionError(
            "When step MR3 - findByStatus (follow-up): Expected list, "
            f"got {type(pets_list_followup)}"
        )

    context.followup_response = followup_response
    context.followup_count = len(pets_list_followup)


@then(
    "the follow-up output should have a count of pets with that status that is one less than the seed output for MR3."
)
def step_mr_MR3_followup_output(context):
    if not hasattr(context, "seed_count") or not hasattr(context, "followup_count"):
        raise AssertionError(
            "Then step MR3: seed_count or followup_count missing from context; "
            "Given/When steps may have failed."
        )

    expected_count = context.seed_count - 1
    actual_count = context.followup_count

    assert actual_count == expected_count, (
        f"MR3 violation: Expected follow-up count to be {expected_count}, "
        f"but got {actual_count} (seed_count={context.seed_count})."
    )

# ----

import copy



def _check_500(response, step_name: str) -> None:
    """
    Fail fast on HTTP 500-class errors in Behave.
    """
    status = getattr(response, "status_code", None)
    if status is None:
        raise AssertionError(f"{step_name}: No HTTP status code in response object")
    if status >= 500:
        # Mark this step as failed explicitly if server error occurs
        raise AssertionError(
            f"{step_name}: Server error {status} received. Body: {response.text}"
        )


@given("a seed input that retrieves a specific user's details, producing a seed output with the current values for all of the user's fields for MR5.")
def step_mr_MR5_seed_input(context):
    username = "theUser"  # Using example username from OpenAPI spec
    url = f"{BASE_URL}/user/{username}"

    response = requests.get(url, timeout=10)
    _check_500(response, "MR5 Given - get user by name")
    if response.status_code != 200:
        raise AssertionError(
            f"MR5 Given - Failed to retrieve user. "
            f"Status: {response.status_code}, Body: {response.text}"
        )

    # Ensure we always store a dict; handle possible non-JSON safely
    try:
        data = response.json()
    except ValueError as exc:
        raise AssertionError(
            f"MR5 Given - Response is not valid JSON. Body: {response.text}"
        ) from exc

    if not isinstance(data, dict):
        raise AssertionError(
            f"MR5 Given - Expected JSON object for user, got: {type(data).__name__}"
        )

    # Deep copy to avoid accidental mutation in later steps
    context.seed_response = copy.deepcopy(data)
    context.username = username


@when("a follow-up input is created by sending a complete user representation that is identical to the seed output except for a changed email value, and then retrieving the same user's details again, yielding a follow-up output for MR5.")
def step_mr_MR5_followup_input(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("MR5 When - seed_response is not available from Given step")

    username = getattr(context, "username", "theUser")
    url_update = f"{BASE_URL}/user/{username}"
    url_get = f"{BASE_URL}/user/{username}"

    # Work on a copy to avoid mutating context.seed_response
    updated_user = copy.deepcopy(context.seed_response)

    # Set a deterministic new email; ensure key exists
    updated_user["email"] = "new_email@example.com"

    # Send full representation update via PUT /user/{username}
    update_response = requests.put(url_update, json=updated_user, timeout=10)
    _check_500(update_response, "MR5 When - update user")
    if update_response.status_code != 200:
        raise AssertionError(
            f"MR5 When - Failed to update user. "
            f"Status: {update_response.status_code}, Body: {update_response.text}"
        )

    # Retrieve updated user
    get_response = requests.get(url_get, timeout=10)
    _check_500(get_response, "MR5 When - get updated user")
    if get_response.status_code != 200:
        raise AssertionError(
            f"MR5 When - Failed to retrieve updated user. "
            f"Status: {get_response.status_code}, Body: {get_response.text}"
        )

    try:
        followup_data = get_response.json()
    except ValueError as exc:
        raise AssertionError(
            f"MR5 When - Updated user response is not valid JSON. "
            f"Body: {get_response.text}"
        ) from exc

    if not isinstance(followup_data, dict):
        raise AssertionError(
            f"MR5 When - Expected JSON object for updated user, got: "
            f"{type(followup_data).__name__}"
        )

    if followup_data.get("email") != updated_user.get("email"):
        raise AssertionError(
            f"MR5 When - Email was not updated correctly. "
            f"Expected: {updated_user.get('email')}, "
            f"Got: {followup_data.get('email')}"
        )

    context.updated_user = updated_user
    context.followup_response = followup_data


@then("the follow-up output should differ from the seed output only in the email field; all other user fields should remain identical for MR5.")
def step_mr_MR5_followup_output(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AssertionError(
            "MR5 Then - seed_response or followup_response not available from previous steps"
        )

    seed = context.seed_response
    followup = context.followup_response

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise AssertionError(
            "MR5 Then - Both seed_response and followup_response must be JSON objects"
        )

    # Compare keys present in either object to avoid KeyError
    all_keys = set(seed.keys()) | set(followup.keys())

    for key in all_keys:
        seed_val = seed.get(key)
        follow_val = followup.get(key)

        if key == "email":
            if seed_val == follow_val:
                raise AssertionError(
                    f"MR5 Then - Email field did not change as expected. "
                    f"Seed: {seed_val}, Follow-up: {follow_val}"
                )
        else:
            if seed_val != follow_val:
                raise AssertionError(
                    f"MR5 Then - Field '{key}' differs between seed and follow-up. "
                    f"Seed: {json.dumps(seed_val, ensure_ascii=False)}, "
                    f"Follow-up: {json.dumps(follow_val, ensure_ascii=False)}"
                )
