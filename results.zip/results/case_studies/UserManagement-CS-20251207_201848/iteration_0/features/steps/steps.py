from behave import given, when, then
import os
import json
import time
import requests
from typing import Any, Dict

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


def safe_get_user_list_count(response_json: Dict[str, Any]) -> int:
    """
    Safely extract the user list count from the /users GET response.

    According to the OpenAPI spec, the response is UserListDTO:
    {
      "userList": [ UserDTO, ... ]
    }
    """
    if not isinstance(response_json, dict):
        return 0
    user_list = response_json.get("userList", [])
    if not isinstance(user_list, list):
        return 0
    return len(user_list)


@given(
    "a seed input that retrieves the list of users via the user list retrieval operation, producing a seed output with a count of users for MR1."
)
def step_mr_MR1_seed_input(context):
    try:
        url = f"{BASE_URL}/users"
        response = requests.get(url, timeout=10)
        response.raise_for_status()

        try:
            context.seed_response = response.json()
        except ValueError:
            context.seed_response = {}

        context.seed_request = response.request
        context.user_count = safe_get_user_list_count(context.seed_response)

    except requests.RequestException as e:
        print(f"HTTP error in GIVEN step for MR1: {e}")
        raise
    except Exception as e:
        print(f"Unexpected error in GIVEN step for MR1: {e}")
        raise


@when(
    "a follow-up input is created by adding a new user using the user creation operation, yielding a follow-up output representing the list of users for MR1."
)
def step_mr_MR1_followup_input(context):
    # Create a valid CreateOrUpdateUserDTO according to the OpenAPI spec.
    # All fields are optional, but username/password/email should be sufficient.
    timestamp = int(time.time() * 1000)
    new_user = {
        "username": f"new_user_{timestamp}",
        "password": "password123",
        "email": f"new_user_{timestamp}@example.com",
        "name": "New",
        "surname": "User",
    }

    try:
        create_url = f"{BASE_URL}/users"
        create_response = requests.post(create_url, json=new_user, timeout=10)
        create_response.raise_for_status()

        # After creation, retrieve the user list again via the same user list retrieval operation.
        list_url = f"{BASE_URL}/users"
        list_response = requests.get(list_url, timeout=10)
        list_response.raise_for_status()

        try:
            context.followup_response = list_response.json()
        except ValueError:
            context.followup_response = {}

    except requests.RequestException as e:
        print(f"HTTP error in WHEN step for MR1: {e}")
        raise
    except Exception as e:
        print(f"Unexpected error in WHEN step for MR1: {e}")
        raise


@then(
    "the follow-up output should have a user list size that is one greater than the seed output for MR1."
)
def step_mr_MR1_followup_output(context):
    try:
        followup_user_count = safe_get_user_list_count(
            getattr(context, "followup_response", {})
        )
        seed_user_count = getattr(context, "user_count", 0)

        assert (
            isinstance(seed_user_count, int) and isinstance(followup_user_count, int)
        ), "User counts must be integers."

        assert (
            followup_user_count == seed_user_count + 1
        ), f"Expected user count to be {seed_user_count + 1}, but got {followup_user_count}."
    except AssertionError:
        raise
    except Exception as e:
        print(f"Unexpected error in THEN step for MR1: {e}")
        raise

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the list of users via the user list retrieval operation, producing a seed output with a count of users for MR2.')
def step_mr_MR2_seed_input(context):
    try:
        response = requests.get(f"{BASE_URL}/users", timeout=10)
        response.raise_for_status()

        try:
            data = response.json()
        except ValueError:
            raise AssertionError("Seed response is not valid JSON.")

        if not isinstance(data, dict):
            raise AssertionError(f"Seed response JSON is not an object: {type(data)}")

        user_list = data.get('userList', [])
        if user_list is None:
            user_list = []
        if not isinstance(user_list, list):
            raise AssertionError(f"'userList' is not a list in seed response: {type(user_list)}")

        context.seed_response = data
        context.seed_request = response.request
        context.seed_user_count = len(user_list)
    except Exception as e:
        print(f"Error in step_mr_MR2_seed_input: {str(e)}")
        raise


@when('a follow-up input is created by deleting an existing user using the user deletion operation, yielding a follow-up output representing the list of users for MR2.')
def step_mr_MR2_followup_input(context):
    try:
        data = getattr(context, "seed_response", None)
        if not isinstance(data, dict):
            raise AssertionError("Seed response missing or not a JSON object on context.")

        user_list = data.get('userList', [])
        if user_list is None:
            user_list = []
        if not isinstance(user_list, list):
            raise AssertionError(f"'userList' is not a list in seed response: {type(user_list)}")

        if not user_list:
            raise AssertionError("No users available to delete.")

        user = user_list[0]
        if not isinstance(user, dict):
            raise AssertionError(f"First user entry is not an object: {type(user)}")

        user_id = user.get('id', None)
        if user_id is None:
            raise AssertionError("User to delete has no 'id' field.")
        if not isinstance(user_id, int):
            try:
                user_id = int(user_id)
            except (TypeError, ValueError):
                raise AssertionError(f"User 'id' is not an integer and cannot be cast: {user_id!r}")

        delete_response = requests.delete(f"{BASE_URL}/users/{user_id}", timeout=10)
        delete_response.raise_for_status()

        followup_response = requests.get(f"{BASE_URL}/users", timeout=10)
        followup_response.raise_for_status()

        try:
            followup_data = followup_response.json()
        except ValueError:
            raise AssertionError("Follow-up response is not valid JSON.")

        if not isinstance(followup_data, dict):
            raise AssertionError(f"Follow-up response JSON is not an object: {type(followup_data)}")

        followup_user_list = followup_data.get('userList', [])
        if followup_user_list is None:
            followup_user_list = []
        if not isinstance(followup_user_list, list):
            raise AssertionError(f"'userList' is not a list in follow-up response: {type(followup_user_list)}")

        context.followup_response = followup_data
        context.followup_request = followup_response.request
        context.followup_user_count = len(followup_user_list)
    except Exception as e:
        print(f"Error in step_mr_MR2_followup_input: {str(e)}")
        raise


@then('the follow-up output should have a user list size that is one less than the seed output for MR2.')
def step_mr_MR2_followup_output(context):
    try:
        seed_count = getattr(context, "seed_user_count", None)
        followup_count = getattr(context, "followup_user_count", None)

        if not isinstance(seed_count, int):
            raise AssertionError(f"seed_user_count is not an int on context: {seed_count!r}")
        if not isinstance(followup_count, int):
            raise AssertionError(f"followup_user_count is not an int on context: {followup_count!r}")

        expected = seed_count - 1
        assert followup_count == expected, (
            f"Expected user count to be {expected}, but got {followup_count} "
            f"(seed was {seed_count})."
        )
    except Exception as e:
        print(f"Error in step_mr_MR2_followup_output: {str(e)}")
        raise

# ----




@given("a seed input that retrieves a user's details by ID via the user detail retrieval operation, producing a seed output with user information for MR3.")
def step_mr_MR3_seed_input(context):
    # Create a user to ensure we have a valid ID to retrieve
    user_data = {
        "username": "testuser",
        "password": "password123",
        "name": "Test",
        "surname": "User",
        "email": "testuser@example.com",
        "gender": "male",
        "enabled": True
    }
    try:
        create_response = requests.post(
            f"{BASE_URL}/users",
            json=user_data,
            timeout=10
        )
        create_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Failed to create user in Given step for MR3: {e}") from e

    try:
        seed_response = create_response.json()
    except ValueError as e:
        raise AssertionError(f"Create user response is not valid JSON in Given step for MR3: {e}") from e

    if not isinstance(seed_response, dict):
        raise AssertionError(
            "Create user response JSON is not an object as expected for UserDTO in Given step for MR3."
        )

    user_id = seed_response.get("id")
    if user_id is None:
        raise AssertionError("Create user response does not contain 'id' field in Given step for MR3.")

    context.seed_response = seed_response
    context.user_id = user_id

    # Retrieve the user details to set the seed output
    try:
        get_response = requests.get(
            f"{BASE_URL}/users/{context.user_id}",
            timeout=10
        )
        get_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Failed to retrieve user by ID in Given step for MR3: {e}") from e

    try:
        seed_output = get_response.json()
    except ValueError as e:
        raise AssertionError(f"Get user-by-id response is not valid JSON in Given step for MR3: {e}") from e

    if not isinstance(seed_output, dict):
        raise AssertionError(
            "Get user-by-id response JSON is not an object as expected for UserDTO in Given step for MR3."
        )

    # Store only fields that actually exist to avoid KeyError/TypeError later
    context.seed_output = {
        key: seed_output.get(key, None)
        for key in [
            "id",
            "username",
            "email",
            "name",
            "surname",
            "gender",
            "enabled"
        ]
    }


@when("a follow-up input is created by updating the user's information using the user update operation with specific fields changed, yielding a follow-up output for MR3.")
def step_mr_MR3_followup_input(context):
    if not hasattr(context, "user_id"):
        raise AssertionError("Context is missing 'user_id' in When step for MR3.")

    update_data = {
        "username": "updateduser",
        "email": "updateduser@example.com"
    }
    try:
        update_response = requests.put(
            f"{BASE_URL}/users/{context.user_id}",
            json=update_data,
            timeout=10
        )
        update_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"Failed to update user in When step for MR3: {e}") from e

    try:
        followup_response = update_response.json()
    except ValueError as e:
        raise AssertionError(f"Update user response is not valid JSON in When step for MR3: {e}") from e

    if not isinstance(followup_response, dict):
        raise AssertionError(
            "Update user response JSON is not an object as expected for UserDTO in When step for MR3."
        )

    context.followup_response = followup_response


@then("the follow-up output should reflect the updated values for the fields provided in the update request while preserving the same user identifier and keeping other user attributes consistent with the API behavior for MR3.")
def step_mr_MR3_followup_output(context):
    if not hasattr(context, "seed_output"):
        raise AssertionError("Context is missing 'seed_output' in Then step for MR3.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Context is missing 'followup_response' in Then step for MR3.")

    seed = context.seed_output
    follow = context.followup_response

    if not isinstance(seed, dict) or not isinstance(follow, dict):
        raise AssertionError("Seed or follow-up output is not a JSON object in Then step for MR3.")

    # Helper to safely get fields
    def get_field(obj, field_name):
        return obj.get(field_name, None) if isinstance(obj, dict) else None

    # ID must remain the same
    seed_id = get_field(seed, "id")
    follow_id = get_field(follow, "id")
    assert seed_id == follow_id, f"User ID should remain the same. Seed ID: {seed_id}, Follow-up ID: {follow_id}"

    # Updated fields
    assert get_field(follow, "username") == "updateduser", (
        f"Username should be updated to 'updateduser'. Actual: {get_field(follow, 'username')}"
    )
    assert get_field(follow, "email") == "updateduser@example.com", (
        f"Email should be updated to 'updateduser@example.com'. Actual: {get_field(follow, 'email')}"
    )

    # Fields expected to remain unchanged (only compare if present in seed)
    for field in ["name", "surname", "gender", "enabled"]:
        seed_val = get_field(seed, field)
        follow_val = get_field(follow, field)
        if seed_val is not None:
            assert seed_val == follow_val, (
                f"Field '{field}' should remain the same. Seed: {seed_val}, Follow-up: {follow_val}"
            )

# ----




@given("a seed input that retrieves a role's details, including its permissions, via the role detail retrieval operation, producing a seed output with a count of permissions for MR4.")
def step_mr_MR4_seed_input(context):
    # Create a role first to ensure it exists (matches summary: createRole)
    role_data = {"role": "test_role_mr4"}
    try:
        response = requests.post(
            f"{BASE_URL}/users/rbac/roles",
            json=role_data,
            timeout=10
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP request failed while creating role: {e}")

    if not (200 <= response.status_code < 300):
        raise AssertionError(f"Failed to create role, status code: {response.status_code}, body: {response.text}")

    try:
        body = response.json()
    except ValueError:
        raise AssertionError(f"Role creation response is not valid JSON: {response.text}")

    role_id = body.get("id")
    if role_id is None:
        raise AssertionError(f"'id' not found in role creation response JSON: {body}")

    context.role_response = response
    context.role_id = role_id

    # Now retrieve the role details (matches summary: getRoleById)
    try:
        seed_request = requests.get(
            f"{BASE_URL}/users/rbac/roles/{context.role_id}",
            timeout=10
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP request failed while retrieving role details: {e}")

    if seed_request.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve role details, status code: {seed_request.status_code}, body: {seed_request.text}"
        )

    try:
        seed_response = seed_request.json()
    except ValueError:
        raise AssertionError(f"Role detail response is not valid JSON: {seed_request.text}")

    permissions = seed_response.get("permissions")
    if permissions is None:
        # According to RoleDTO, 'permissions' should be an array; treat missing as empty list safely
        permissions = []

    if not isinstance(permissions, list):
        raise AssertionError(f"'permissions' is not a list in role detail response: {seed_response}")

    context.seed_request = seed_request
    context.seed_response = seed_response
    context.seed_permission_count = len(permissions)


@when("a follow-up input is created by adding a new permission to the role using the role-permission association creation operation, yielding a follow-up output with the updated role details for MR4.")
def step_mr_MR4_followup_input(context):
    # Define a new permission to add (matches summary: createPermission)
    permission_data = {
        "permission": "mr4_new_permission",
        "enabled": True
    }

    try:
        permission_response = requests.post(
            f"{BASE_URL}/users/rbac/permissions",
            json=permission_data,
            timeout=10
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP request failed while creating permission: {e}")

    if not (200 <= permission_response.status_code < 300):
        raise AssertionError(
            f"Failed to create permission, status code: {permission_response.status_code}, body: {permission_response.text}"
        )

    try:
        permission_body = permission_response.json()
    except ValueError:
        raise AssertionError(f"Permission creation response is not valid JSON: {permission_response.text}")

    permission_key = permission_body.get("permission")
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError(f"'permission' key not found or invalid in permission creation response: {permission_body}")

    context.permission_response = permission_response
    context.permission_key = permission_key

    # Add the permission to the role (matches summary: addPermissionOnRole)
    try:
        followup_request = requests.post(
            f"{BASE_URL}/users/rbac/roles/{context.role_id}/permissions/{context.permission_key}",
            timeout=10
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP request failed while adding permission to role: {e}")

    if followup_request.status_code != 200:
        raise AssertionError(
            f"Failed to add permission to role, status code: {followup_request.status_code}, body: {followup_request.text}"
        )

    try:
        followup_response = followup_request.json()
    except ValueError:
        raise AssertionError(f"Follow-up role response is not valid JSON: {followup_request.text}")

    permissions = followup_response.get("permissions")
    if permissions is None:
        permissions = []

    if not isinstance(permissions, list):
        raise AssertionError(f"'permissions' is not a list in follow-up role response: {followup_response}")

    context.followup_request = followup_request
    context.followup_response = followup_response


@then("the follow-up output should have a permission list size that is one greater than the seed output for MR4, assuming the added permission was not already present.")
def step_mr_MR4_assertion(context):
    permissions = context.followup_response.get("permissions")
    if permissions is None:
        permissions = []

    if not isinstance(permissions, list):
        raise AssertionError(f"'permissions' is not a list in follow-up role response: {context.followup_response}")

    followup_permission_count = len(permissions)

    if not isinstance(context.seed_permission_count, int):
        raise AssertionError(f"Seed permission count is not an integer: {context.seed_permission_count}")

    expected_count = context.seed_permission_count + 1
    assert followup_permission_count == expected_count, (
        f"Expected permission count to be {expected_count}, "
        f"but got {followup_permission_count}. Seed response: {context.seed_response}, "
        f"follow-up response: {context.followup_response}"
    )

# ----




@given("a seed input that retrieves a role's details, including its permissions, via the role detail retrieval operation, producing a seed output with a count of permissions for MR5.")
def step_mr_MR5_seed_input(context):
    # Create a role first to ensure it exists
    role_data = {"role": "TestRole"}
    response = requests.post(f"{BASE_URL}/users/rbac/roles", json=role_data, timeout=10)
    response.raise_for_status()

    data = response.json()
    role_id = data.get("id")
    if role_id is None:
        raise AssertionError("Role creation response does not contain 'id'.")

    context.role_id = role_id

    # Retrieve the role details (role detail retrieval operation)
    seed_request = requests.get(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
    seed_request.raise_for_status()

    try:
        seed_response = seed_request.json()
    except ValueError as exc:
        raise AssertionError(f"Seed role details response is not valid JSON: {exc}") from exc

    permissions = seed_response.get("permissions")
    if permissions is None:
        # Normalize to empty list if field missing
        permissions = []
    elif not isinstance(permissions, list):
        raise AssertionError(f"'permissions' field is not a list: {type(permissions)}")

    context.seed_response = seed_response
    context.seed_permission_count = len(permissions)

    # If there are no permissions yet, create one so that MR5 can remove it
    if context.seed_permission_count == 0:
        perm_body = {
            "permission": "TEST_PERMISSION_FOR_MR5",
            "enabled": True,
            "note": "Permission for MR5 removal test"
        }
        perm_create_resp = requests.post(f"{BASE_URL}/users/rbac/permissions", json=perm_body, timeout=10)
        perm_create_resp.raise_for_status()

        try:
            created_perm = perm_create_resp.json()
        except ValueError as exc:
            raise AssertionError(f"Permission creation response is not valid JSON: {exc}") from exc

        permission_key = created_perm.get("permission")
        if not isinstance(permission_key, str) or not permission_key:
            raise AssertionError("Created permission does not contain a valid 'permission' key.")

        # Associate the permission with the role (role-permission association add operation)
        add_resp = requests.post(
            f"{BASE_URL}/users/rbac/roles/{context.role_id}/permissions/{permission_key}",
            timeout=10,
        )
        add_resp.raise_for_status()

        # Re-fetch the role details after association
        seed_request = requests.get(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
        seed_request.raise_for_status()
        try:
            seed_response = seed_request.json()
        except ValueError as exc:
            raise AssertionError(f"Seed role details response after add is not valid JSON: {exc}") from exc

        permissions = seed_response.get("permissions")
        if permissions is None:
            permissions = []
        elif not isinstance(permissions, list):
            raise AssertionError(f"'permissions' field after add is not a list: {type(permissions)}")

        context.seed_response = seed_response
        context.seed_permission_count = len(permissions)

    # Final safety check
    if context.seed_permission_count < 1:
        raise AssertionError("Role must have at least one permission for MR5, but none were found or could be created.")


@when("a follow-up input is created by removing an existing permission from the role using the role-permission association removal operation, yielding a follow-up output with the updated role details for MR5.")
def step_mr_MR5_followup_input(context):
    seed_permissions = context.seed_response.get("permissions") or []
    if not isinstance(seed_permissions, list):
        raise AssertionError(f"'permissions' field is not a list: {type(seed_permissions)}")
    if not seed_permissions:
        raise AssertionError("No permissions available to remove for MR5.")

    first_perm = seed_permissions[0]
    if not isinstance(first_perm, dict):
        raise AssertionError(f"Permission entry is not an object: {type(first_perm)}")

    permission_key = first_perm.get("permission")
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError("Permission object does not contain a valid 'permission' key to remove.")

    # Role-permission association removal operation
    followup_request = requests.delete(
        f"{BASE_URL}/users/rbac/roles/{context.role_id}/permissions/{permission_key}",
        timeout=10,
    )
    followup_request.raise_for_status()

    # Retrieve the updated role details (same role detail retrieval operation)
    followup_response = requests.get(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_data = followup_response.json()
    except ValueError as exc:
        raise AssertionError(f"Follow-up role details response is not valid JSON: {exc}") from exc

    permissions = followup_data.get("permissions")
    if permissions is None:
        permissions = []
    elif not isinstance(permissions, list):
        raise AssertionError(f"'permissions' field in follow-up is not a list: {type(permissions)}")

    context.followup_response_data = followup_data
    context.followup_permission_count = len(permissions)


@then("the follow-up output should have a permission list size that is one less than the seed output for MR5.")
def step_mr_MR5_assertion(context):
    seed_count = getattr(context, "seed_permission_count", None)
    followup_count = getattr(context, "followup_permission_count", None)

    if not isinstance(seed_count, int):
        raise AssertionError(f"Seed permission count is not an int: {seed_count!r}")
    if not isinstance(followup_count, int):
        raise AssertionError(f"Follow-up permission count is not an int: {followup_count!r}")

    expected = seed_count - 1
    if followup_count != expected:
        raise AssertionError(
            f"Expected permission count to be {expected}, but got {followup_count} "
            f"(seed was {seed_count})."
        )
