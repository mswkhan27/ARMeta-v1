Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new user should increase the user list size by one
    Given a seed input that retrieves the list of users via the user list retrieval operation, producing a seed output with a count of users for MR1.
    When a follow-up input is created by adding a new user using the user creation operation, yielding a follow-up output representing the list of users for MR1.
    Then the follow-up output should have a user list size that is one greater than the seed output for MR1.

  Scenario: MR2 Deleting a user should decrease the user list size by one
    Given a seed input that retrieves the list of users via the user list retrieval operation, producing a seed output with a count of users for MR2.
    When a follow-up input is created by deleting an existing user using the user deletion operation, yielding a follow-up output representing the list of users for MR2.
    Then the follow-up output should have a user list size that is one less than the seed output for MR2.

  Scenario: MR3 Updating a user's information should modify only the intended user data
    Given a seed input that retrieves a user's details by ID via the user detail retrieval operation, producing a seed output with user information for MR3.
    When a follow-up input is created by updating the user's information using the user update operation with specific fields changed, yielding a follow-up output for MR3.
    Then the follow-up output should reflect the updated values for the fields provided in the update request while preserving the same user identifier and keeping other user attributes consistent with the API behavior for MR3.

  Scenario: MR4 Adding a permission to a role should increase the role's permission list size by one
    Given a seed input that retrieves a role's details, including its permissions, via the role detail retrieval operation, producing a seed output with a count of permissions for MR4.
    When a follow-up input is created by adding a new permission to the role using the role-permission association creation operation, yielding a follow-up output with the updated role details for MR4.
    Then the follow-up output should have a permission list size that is one greater than the seed output for MR4, assuming the added permission was not already present.

  Scenario: MR5 Removing a permission from a role should decrease the role's permission list size by one
    Given a seed input that retrieves a role's details, including its permissions, via the role detail retrieval operation, producing a seed output with a count of permissions for MR5.
    When a follow-up input is created by removing an existing permission from the role using the role-permission association removal operation, yielding a follow-up output with the updated role details for MR5.
    Then the follow-up output should have a permission list size that is one less than the seed output for MR5.
