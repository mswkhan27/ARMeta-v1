Feature: Iteration 1 MRs

  Scenario: MR6 Retrieving permissions should return the same list if no changes are made within the system
    Given a seed input that retrieves the list of permissions via the permission list retrieval operation, producing a seed output with a list of permissions for MR6.
    When a follow-up input is created by retrieving the list of permissions again, without performing any permission creation, update, or deletion operations in between, yielding a follow-up output for MR6.
    Then the follow-up output should be identical to the seed output for MR6.

  Scenario: MR7 Deleting a role should remove it from the role list
    Given a seed input that retrieves the list of roles via the role list retrieval operation, producing a seed output with a count of roles for MR7, and selecting an existing role from this list.
    When a follow-up input is created by first deleting the selected role using the role deletion operation and then retrieving the list of roles again via the role list retrieval operation, yielding a follow-up output representing the updated list of roles for MR7.
    Then the follow-up output should have a role list size that is one less than the seed output for MR7, assuming the deletion operation completed successfully and no other role creation or deletion operations occurred in between.

  Scenario: MR8 Adding a role to a user should increase the user's role list size by one
    Given a seed input that retrieves a user's details, including their roles, via the user detail retrieval operation, producing a seed output with a count of roles for MR8.
    When a follow-up input is created by adding a new, previously unassigned role to the user using the user-role association creation operation, yielding a follow-up output with the updated user details for MR8.
    Then the follow-up output should have a role list size that is one greater than the seed output for MR8.

  Scenario: MR9 Removing a role from a user should decrease the user's role list size by one
    Given a seed input that retrieves a user's details, including their roles, via the user detail retrieval operation, producing a seed output with a count of roles for MR9 and identifying an existing role assigned to that user.
    When a follow-up input is created by removing the identified existing role from the user using the user-role association removal operation, yielding a follow-up output with the updated user details for MR9.
    Then the follow-up output should have a role list size that is one less than the seed output for MR9.
