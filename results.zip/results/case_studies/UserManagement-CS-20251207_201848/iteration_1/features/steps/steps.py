from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the list of permissions via the permission list retrieval operation, producing a seed output with a list of permissions for MR6.')
def step_mr_MR6_seed_input(context):
    url = f"{BASE_URL}/users/rbac/permissions"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        try:
            context.seed_response = response.json()
        except ValueError:
            context.seed_response = response.text
        context.seed_request = response.request
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in Given step for MR6 when calling {url}: {e}") from e
    except Exception as e:
        raise AssertionError(f"Unexpected error in Given step for MR6: {e}") from e


@when('a follow-up input is created by retrieving the list of permissions again, without performing any permission creation, update, or deletion operations in between, yielding a follow-up output for MR6.')
def step_mr_MR6_followup_input(context):
    url = f"{BASE_URL}/users/rbac/permissions"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        try:
            context.followup_response = response.json()
        except ValueError:
            context.followup_response = response.text
        context.followup_request = response.request
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in When step for MR6 when calling {url}: {e}") from e
    except Exception as e:
        raise AssertionError(f"Unexpected error in When step for MR6: {e}") from e


@then('the follow-up output should be identical to the seed output for MR6.')
def step_mr_MR6_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is missing in context for MR6.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response is missing in context for MR6.")

    try:
        seed_serialized = json.dumps(context.seed_response, sort_keys=True)
        followup_serialized = json.dumps(context.followup_response, sort_keys=True)
    except TypeError as e:
        raise AssertionError(f"Non-serializable data in responses for MR6 comparison: {e}") from e

    assert followup_serialized == seed_serialized, "Follow-up output does not match seed output for MR6."

# ----




@given('a seed input that retrieves the list of roles via the role list retrieval operation, producing a seed output with a count of roles for MR7, and selecting an existing role from this list.')
def step_mr_MR7_seed_input(context):
    # Retrieve the list of roles
    response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    response.raise_for_status()

    try:
        roles = response.json()
    except ValueError as e:
        raise AssertionError(f"Seed roles response is not valid JSON: {e}")

    if roles is None:
        roles = []

    if not isinstance(roles, list):
        raise AssertionError(f"Expected roles list (array) from GET /users/rbac/roles, got: {type(roles)}")

    # Ensure there are roles to select from; if none, create one via createRole
    if len(roles) == 0:
        role_data = "test_role"
        create_response = requests.post(
            f"{BASE_URL}/users/rbac/roles",
            json=role_data,
            timeout=10,
        )
        create_response.raise_for_status()
        try:
            created_role = create_response.json()
        except ValueError as e:
            raise AssertionError(f"Create role response is not valid JSON: {e}")

        if not isinstance(created_role, dict):
            raise AssertionError(
                f"Expected created role object from POST /users/rbac/roles, got: {type(created_role)}"
            )

        roles = [created_role]

    first_role = roles[0]
    if not isinstance(first_role, dict):
        raise AssertionError(f"Role entry is not an object: {type(first_role)}")

    role_id = first_role.get("id")
    if role_id is None:
        raise AssertionError("Selected role does not contain 'id' field")

    try:
        # Ensure role_id can be used as a path parameter that expects int64
        context.selected_role = int(role_id)
    except (TypeError, ValueError):
        raise AssertionError(f"Role 'id' is not convertible to int: {role_id!r}")

    context.seed_roles = roles
    context.seed_request = response.request


@when('a follow-up input is created by first deleting the selected role using the role deletion operation and then retrieving the list of roles again via the role list retrieval operation, yielding a follow-up output representing the updated list of roles for MR7.')
def step_mr_MR7_followup_input(context):
    if not hasattr(context, "selected_role"):
        raise AssertionError("selected_role not set in context")

    role_id = context.selected_role

    # Delete the selected role using deleteRoleById
    delete_response = requests.delete(
        f"{BASE_URL}/users/rbac/roles/{role_id}",
        timeout=10,
    )
    delete_response.raise_for_status()

    # Retrieve the list of roles again
    followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_roles = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up roles response is not valid JSON: {e}")

    if followup_roles is None:
        followup_roles = []

    if not isinstance(followup_roles, list):
        raise AssertionError(
            f"Expected roles list (array) from GET /users/rbac/roles, got: {type(followup_roles)}"
        )

    context.followup_roles = followup_roles
    context.followup_request = followup_response.request


@then('the follow-up output should have a role list size that is one less than the seed output for MR7, assuming the deletion operation completed successfully and no other role creation or deletion operations occurred in between.')
def step_mr_MR7_assert_followup_output(context):
    if not hasattr(context, "seed_roles") or not hasattr(context, "followup_roles"):
        raise AssertionError("Seed or follow-up roles not found in context")

    seed_roles = context.seed_roles or []
    followup_roles = context.followup_roles or []

    if not isinstance(seed_roles, list):
        raise AssertionError(f"Seed roles is not a list: {type(seed_roles)}")
    if not isinstance(followup_roles, list):
        raise AssertionError(f"Follow-up roles is not a list: {type(followup_roles)}")

    seed_count = len(seed_roles)
    followup_count = len(followup_roles)

    expected_followup = seed_count - 1
    if followup_count != expected_followup:
        raise AssertionError(
            f"Expected follow-up role count to be {expected_followup}, but got {followup_count}"
        )

# ----




@given("a seed input that retrieves a user's details, including their roles, via the user detail retrieval operation, producing a seed output with a count of roles for MR8.")
def _mr_MR8_seed_input(context):
    # Create a role to ensure we can assign it later
    role_payload = "mr8_seed_role"
    role_resp = requests.post(
        f"{BASE_URL}/users/rbac/roles",
        json=role_payload,
        timeout=10
    )
    if not role_resp.ok:
        raise AssertionError(f"Failed to create seed role, status={role_resp.status_code}, body={role_resp.text}")
    role_json = role_resp.json() if role_resp.content else {}
    context.seed_role_id = role_json.get("id")
    if context.seed_role_id is None:
        raise AssertionError(f"Seed role id not found in response: {json.dumps(role_json, default=str)}")

    # Create a user to ensure we have a valid user to retrieve
    user_data = {
        "username": "testuser_mr8",
        "password": "password",
        "email": "testuser_mr8@example.com",
        "name": "Test",
        "surname": "User"
    }
    user_resp = requests.post(
        f"{BASE_URL}/users",
        json=user_data,
        timeout=10
    )
    if not user_resp.ok:
        raise AssertionError(f"Failed to create user, status={user_resp.status_code}, body={user_resp.text}")
    user_json = user_resp.json() if user_resp.content else {}
    user_id = user_json.get("id")
    if user_id is None:
        raise AssertionError(f"User id not found in create response: {json.dumps(user_json, default=str)}")
    context.user_id = user_id

    # Optionally, start with the user having the seed role already, so we can add another later
    add_seed_role_resp = requests.post(
        f"{BASE_URL}/users/{context.user_id}/roles/{context.seed_role_id}",
        timeout=10
    )
    if not add_seed_role_resp.ok:
        raise AssertionError(
            f"Failed to add initial role to user, status={add_seed_role_resp.status_code}, body={add_seed_role_resp.text}"
        )

    # Retrieve the user details to get the roles
    detail_resp = requests.get(
        f"{BASE_URL}/users/{context.user_id}",
        timeout=10
    )
    if not detail_resp.ok:
        raise AssertionError(f"Failed to retrieve user details, status={detail_resp.status_code}, body={detail_resp.text}")
    detail_json = detail_resp.json() if detail_resp.content else {}

    roles = detail_json.get("roles")
    if roles is None:
        # If roles is missing or not a list, treat as empty list defensively
        roles = []
    elif not isinstance(roles, list):
        raise AssertionError(f"'roles' field is not a list: {json.dumps(detail_json, default=str)}")

    context.initial_role_count = len(roles)
    context.seed_user_details = detail_json


@when("a follow-up input is created by adding a new, previously unassigned role to the user using the user-role association creation operation, yielding a follow-up output with the updated user details for MR8.")
def _mr_MR8_followup_input(context):
    if not hasattr(context, "user_id"):
        raise AssertionError("user_id not set in context from Given step")
    user_id = context.user_id

    # Create a new role to assign to the user (previously unassigned)
    new_role_payload = "mr8_new_unique_role"
    role_resp = requests.post(
        f"{BASE_URL}/users/rbac/roles",
        json=new_role_payload,
        timeout=10
    )
    if not role_resp.ok:
        raise AssertionError(f"Failed to create new role, status={role_resp.status_code}, body={role_resp.text}")
    role_json = role_resp.json() if role_resp.content else {}
    role_id = role_json.get("id")
    if role_id is None:
        raise AssertionError(f"New role id not found in response: {json.dumps(role_json, default=str)}")

    context.new_role_id = role_id

    # Assign the new role to the user using user-role association creation operation
    assoc_resp = requests.post(
        f"{BASE_URL}/users/{user_id}/roles/{role_id}",
        timeout=10
    )
    if not assoc_resp.ok:
        raise AssertionError(
            f"Failed to associate role to user, status={assoc_resp.status_code}, body={assoc_resp.text}"
        )

    # Retrieve the updated user details
    followup_resp = requests.get(
        f"{BASE_URL}/users/{user_id}",
        timeout=10
    )
    if not followup_resp.ok:
        raise AssertionError(
            f"Failed to retrieve updated user details, status={followup_resp.status_code}, body={followup_resp.text}"
        )
    followup_json = followup_resp.json() if followup_resp.content else {}

    roles = followup_json.get("roles")
    if roles is None:
        roles = []
    elif not isinstance(roles, list):
        raise AssertionError(f"'roles' field is not a list in follow-up response: {json.dumps(followup_json, default=str)}")

    context.followup_user_details = followup_json
    context.updated_role_count = len(roles)


@then("the follow-up output should have a role list size that is one greater than the seed output for MR8.")
def _mr_MR8_assert_role_count(context):
    if not hasattr(context, "initial_role_count"):
        raise AssertionError("initial_role_count not set in context from Given step")
    if not hasattr(context, "updated_role_count"):
        raise AssertionError("updated_role_count not set in context from When step")

    expected = context.initial_role_count + 1
    actual = context.updated_role_count
    assert actual == expected, (
        f"Expected role count to be {expected}, but got {actual}. "
        f"Seed user: {json.dumps(getattr(context, 'seed_user_details', {}), default=str)}, "
        f"Follow-up user: {json.dumps(getattr(context, 'followup_user_details', {}), default=str)}"
    )

# ----

import time

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


def _safe_get_json(response):
    try:
        return response.json()
    except ValueError:
        return {}


def _ensure_user_has_at_least_one_role(context):
    """
    Ensure the user has at least one role assigned.
    Safely handles empty role list and HTTP errors.
    """
    if not hasattr(context, "user_id") or context.user_id is None:
        raise AssertionError("User ID is not set in context.")

    # Get available roles
    roles_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    roles_response.raise_for_status()
    try:
        roles = roles_response.json()
    except ValueError:
        roles = []

    if not isinstance(roles, list) or not roles:
        raise AssertionError("No roles available in the system to assign to user.")

    role = roles[0]
    role_id = role.get("id")
    if role_id is None:
        raise AssertionError("Role object does not contain 'id' field.")

    # Assign role to user
    assign_response = requests.post(
        f"{BASE_URL}/users/{context.user_id}/roles/{role_id}",
        timeout=10,
    )
    assign_response.raise_for_status()

    # Update initial role count after assignment
    user_response = requests.get(f"{BASE_URL}/users/{context.user_id}", timeout=10)
    user_response.raise_for_status()
    user_json = _safe_get_json(user_response)
    roles_list = user_json.get("roles", [])
    if roles_list is None:
        roles_list = []
    if not isinstance(roles_list, list):
        raise AssertionError("User 'roles' field is not a list.")

    context.initial_role_count = len(roles_list)
    context.role_to_remove = role_id


@given(
    "a seed input that retrieves a user's details, including their roles, via the user detail retrieval operation, producing a seed output with a count of roles for MR9 and identifying an existing role assigned to that user."
)
def step_mr_MR9_seed_input(context):
    # Create a user for testing using /users (createUser)
    user_data = {
        "username": "testuser_mr9",
        "password": "testpassword",
        "email": "testuser_mr9@example.com",
        "name": "Test",
        "surname": "User",
    }

    response = requests.post(f"{BASE_URL}/users", json=user_data, timeout=10)
    response.raise_for_status()
    seed_json = _safe_get_json(response)

    user_id = seed_json.get("id")
    if user_id is None:
        raise AssertionError("Created user response does not contain 'id' field.")
    context.user_id = user_id

    # Retrieve user details via user detail retrieval operation: GET /users/{id}
    detail_response = requests.get(f"{BASE_URL}/users/{context.user_id}", timeout=10)
    detail_response.raise_for_status()
    context.seed_response = _safe_get_json(detail_response)

    roles_list = context.seed_response.get("roles", [])
    if roles_list is None:
        roles_list = []
    if not isinstance(roles_list, list):
        raise AssertionError("User 'roles' field is not a list.")
    context.initial_role_count = len(roles_list)

    # Ensure there is at least one role assigned so MR9 is meaningful
    if context.initial_role_count == 0:
        _ensure_user_has_at_least_one_role(context)
    else:
        # If already has roles, identify a role to remove
        roles_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
        roles_response.raise_for_status()
        try:
            available_roles = roles_response.json()
        except ValueError:
            available_roles = []

        role_id_to_remove = None
        if isinstance(available_roles, list):
            # We don't know the mapping between role names and role IDs, so we
            # safely pick any available role ID to operate with the user-role API.
            for role in available_roles:
                rid = role.get("id")
                if rid is not None:
                    role_id_to_remove = rid
                    break

        if role_id_to_remove is None:
            raise AssertionError("No suitable role found to remove from user.")

        # Make sure the role is actually assigned (idempotent if already there)
        assign_response = requests.post(
            f"{BASE_URL}/users/{context.user_id}/roles/{role_id_to_remove}",
            timeout=10,
        )
        assign_response.raise_for_status()

        # Refresh user details and role count
        refresh_response = requests.get(
            f"{BASE_URL}/users/{context.user_id}", timeout=10
        )
        refresh_response.raise_for_status()
        user_json = _safe_get_json(refresh_response)
        roles_list = user_json.get("roles", [])
        if roles_list is None:
            roles_list = []
        if not isinstance(roles_list, list):
            raise AssertionError("User 'roles' field is not a list after assignment.")

        context.initial_role_count = len(roles_list)
        context.role_to_remove = role_id_to_remove


@when(
    "a follow-up input is created by removing the identified existing role from the user using the user-role association removal operation, yielding a follow-up output with the updated user details for MR9."
)
def step_mr_MR9_followup_input(context):
    if not hasattr(context, "user_id") or context.user_id is None:
        raise AssertionError("User ID is not set in context.")
    if not hasattr(context, "role_to_remove") or context.role_to_remove is None:
        raise AssertionError("Role to remove is not set in context.")

    # Remove the role from the user via DELETE /users/{id}/roles/{roleId}
    delete_response = requests.delete(
        f"{BASE_URL}/users/{context.user_id}/roles/{context.role_to_remove}",
        timeout=10,
    )
    delete_response.raise_for_status()

    # Retrieve the updated user details via GET /users/{id}
    response = requests.get(f"{BASE_URL}/users/{context.user_id}", timeout=10)
    response.raise_for_status()
    context.followup_response = _safe_get_json(response)


@then(
    "the follow-up output should have a role list size that is one less than the seed output for MR9."
)
def step_mr_MR9_assert_role_count(context):
    if not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response is not available in context.")
    if not hasattr(context, "initial_role_count"):
        raise AssertionError("Initial role count is not available in context.")

    roles_list = context.followup_response.get("roles", [])
    if roles_list is None:
        roles_list = []
    if not isinstance(roles_list, list):
        raise AssertionError("User 'roles' field in follow-up response is not a list.")

    followup_role_count = len(roles_list)
    expected_count = context.initial_role_count - 1
    assert (
        followup_role_count == expected_count
    ), f"Expected role count to be {expected_count}, but got {followup_role_count}."
