Feature: Iteration 2 MRs

  Scenario: MR10 Deleting a permission should remove it from the permission list
    Given a seed input that retrieves the list of permissions via the permission list retrieval operation, producing a seed output with a count of permissions for MR10.
    When a follow-up input is created by deleting an existing permission using the permission deletion operation and then retrieving the permission list again, yielding a follow-up output representing the updated list of permissions for MR10.
    Then the follow-up output should have a permission list size that is one less than the seed output for MR10, assuming the deleted permission previously existed in the seed list.

  Scenario: MR11 Generating a salt should produce a unique string each time
    Given a seed input that generates a salt via the salt generation operation, producing a seed output with a salt string for MR11.
    When a follow-up input is created by generating a new salt using the same salt generation operation, yielding a follow-up output with another salt string for MR11.
    Then the follow-up output salt string should differ from the seed output salt string for MR11, reflecting that each salt generation call returns a newly generated string.

  Scenario: MR13 Updating a permission should modify only the updated fields
    Given a seed input that retrieves a permission's details by key via the permission detail retrieval operation, producing a seed output with permission information for MR13.
    When a follow-up input is created by updating the permission's details using the permission update operation with specific fields changed and then retrieving the permission details again, yielding a follow-up output for MR13.
    Then the follow-up output should reflect the updated values for the fields provided in the update request while preserving the same permission identifier and keeping other permission attributes consistent with the corresponding values in the seed output for MR13.

  Scenario: MR14 Registering a new user should increase the user list size by one
    Given a seed input that retrieves the list of users via the user list retrieval operation, producing a seed output with a count of users for MR14.
    When a follow-up input is created by registering a new user using the user registration operation and then retrieving the list of users again, yielding a follow-up output representing the updated list of users for MR14.
    Then the follow-up output should have a user list size that is one greater than the seed output for MR14, assuming the registration succeeds and creates a new user record.
