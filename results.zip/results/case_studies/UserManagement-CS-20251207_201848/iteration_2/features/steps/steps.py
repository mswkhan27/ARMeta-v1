from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


@given("a seed input that retrieves the list of permissions via the permission list retrieval operation, producing a seed output with a count of permissions for MR10.")
def step_mr_MR10_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
    response.raise_for_status()

    try:
        permissions = response.json()
        if not isinstance(permissions, list):
            raise TypeError(f"Expected a list of permissions, got {type(permissions).__name__}")
    except (ValueError, TypeError) as e:
        raise AssertionError(f"Failed to parse permissions list JSON: {e}")

    context.seed_response = permissions
    context.seed_request = response.request
    context.seed_permission_count = len(permissions)

    if context.seed_permission_count < 1:
        raise AssertionError("Seed permission list is empty; MR10 requires at least one existing permission to delete.")


@when("a follow-up input is created by deleting an existing permission using the permission deletion operation and then retrieving the permission list again, yielding a follow-up output representing the updated list of permissions for MR10.")
def step_mr_MR10_followup_input(context):
    permissions = getattr(context, "seed_response", None)
    if not isinstance(permissions, list) or len(permissions) == 0:
        raise AssertionError("Seed response must be a non-empty list of permissions before deletion step.")

    first_perm = permissions[0]
    if not isinstance(first_perm, dict):
        raise AssertionError(f"Expected permission item to be dict, got {type(first_perm).__name__}")

    permission_key = first_perm.get("permission")
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError("Permission item does not contain a valid 'permission' key required for deletion.")

    delete_url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"
    delete_response = requests.delete(delete_url, timeout=10)
    delete_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_permissions = followup_response.json()
        if not isinstance(followup_permissions, list):
            raise TypeError(f"Expected a list of permissions, got {type(followup_permissions).__name__}")
    except (ValueError, TypeError) as e:
        raise AssertionError(f"Failed to parse follow-up permissions list JSON: {e}")

    context.followup_response = followup_permissions
    context.followup_request = followup_response.request
    context.followup_permission_count = len(followup_permissions)


@then("the follow-up output should have a permission list size that is one less than the seed output for MR10, assuming the deleted permission previously existed in the seed list.")
def step_mr_MR10_followup_output(context):
    if not hasattr(context, "seed_permission_count") or not hasattr(context, "followup_permission_count"):
        raise AssertionError("Permission counts were not properly set in previous steps.")

    seed_count = context.seed_permission_count
    followup_count = context.followup_permission_count

    if not isinstance(seed_count, int) or not isinstance(followup_count, int):
        raise AssertionError("Permission counts must be integers.")

    expected_count = seed_count - 1
    assert followup_count == expected_count, (
        f"Expected permission count to be {expected_count}, but got {followup_count}."
    )

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that generates a salt via the salt generation operation, producing a seed output with a salt string for MR11.')
def step_mr_MR11_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/salt", timeout=10)
    response.raise_for_status()
    # /users/rbac/salt returns a plain string according to the OpenAPI spec
    context.seed_response = response.text if response.text is not None else ""  # ensure string
    context.seed_request = None  # No request body for GET


@when('a follow-up input is created by generating a new salt using the same salt generation operation, yielding a follow-up output with another salt string for MR11.')
def step_mr_MR11_followup_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/salt", timeout=10)
    response.raise_for_status()
    context.followup_response = response.text if response.text is not None else ""  # ensure string
    context.followup_request = None  # No request body for GET


@then('the follow-up output salt string should differ from the seed output salt string for MR11, reflecting that each salt generation call returns a newly generated string.')
def step_mr_MR11_assert_different(context):
    seed = getattr(context, "seed_response", "")
    followup = getattr(context, "followup_response", "")
    assert isinstance(seed, str), "Seed salt response should be a string."
    assert isinstance(followup, str), "Follow-up salt response should be a string."
    assert seed != followup, "The follow-up salt should be different from the seed salt."

# ----




def safe_get_json(response):
    try:
        return response.json()
    except ValueError:
        return None


@given("a seed input that retrieves a permission's details by key via the permission detail retrieval operation, producing a seed output with permission information for MR13.")
def step_mr_MR13_seed_input(context):
    # Create a permission first so that we have a known key
    create_payload = {
        "enabled": True,
        "note": "Seed permission for MR13",
        "permission": "mr13_seed_permission"
    }
    create_resp = requests.post(
        f"{BASE_URL}/users/rbac/permissions",
        json=create_payload,
        timeout=10,
    )
    assert create_resp.status_code == 200, (
        f"Failed to create seed permission: "
        f"{create_resp.status_code} {create_resp.text}"
    )

    created_perm = safe_get_json(create_resp)
    assert isinstance(created_perm, dict), "Create permission response is not JSON object"

    permission_key = created_perm.get("permission")
    assert permission_key, "Created permission has no 'permission' key"

    context.permission_key = permission_key

    # Retrieve the permission details by key (detail retrieval operation)
    seed_req = requests.get(
        f"{BASE_URL}/users/rbac/permissions/{permission_key}",
        timeout=10,
    )
    assert seed_req.status_code == 200, (
        f"Failed to retrieve permission: "
        f"{seed_req.status_code} {seed_req.text}"
    )

    seed_json = safe_get_json(seed_req)
    assert isinstance(seed_json, dict), "Seed permission response is not JSON object"

    context.seed_request = seed_req
    context.seed_response = seed_json


@when("a follow-up input is created by updating the permission's details using the permission update operation with specific fields changed and then retrieving the permission details again, yielding a follow-up output for MR13.")
def step_mr_MR13_followup_input(context):
    assert hasattr(context, "seed_response"), "Seed response not found in context"
    seed = context.seed_response

    # Build update payload with specific fields changed
    enabled_value = seed.get("enabled")
    if isinstance(enabled_value, bool):
        new_enabled = not enabled_value
    else:
        new_enabled = True

    updated_permission = {
        "id": seed.get("id"),
        "permission": seed.get("permission"),
        "enabled": new_enabled,
        "note": "Updated note for testing",
    }

    # Permission update operation: PUT /users/rbac/permissions
    update_resp = requests.put(
        f"{BASE_URL}/users/rbac/permissions",
        json=updated_permission,
        timeout=10,
    )
    assert update_resp.status_code == 200, (
        f"Failed to update permission: "
        f"{update_resp.status_code} {update_resp.text}"
    )

    updated_json = safe_get_json(update_resp)
    assert isinstance(updated_json, dict), "Update permission response is not JSON object"

    # Retrieve permission details again by key (same operation as in Given)
    permission_key = context.permission_key
    follow_req = requests.get(
        f"{BASE_URL}/users/rbac/permissions/{permission_key}",
        timeout=10,
    )
    assert follow_req.status_code == 200, (
        f"Failed to retrieve updated permission: "
        f"{follow_req.status_code} {follow_req.text}"
    )

    follow_json = safe_get_json(follow_req)
    assert isinstance(follow_json, dict), "Follow-up permission response is not JSON object"

    context.update_response = updated_json
    context.followup_request = follow_req
    context.followup_response = follow_json


@then("the follow-up output should reflect the updated values for the fields provided in the update request while preserving the same permission identifier and keeping other permission attributes consistent with the corresponding values in the seed output for MR13.")
def step_mr_MR13_followup_output(context):
    assert hasattr(context, "seed_response"), "Seed response not found in context"
    assert hasattr(context, "followup_response"), "Follow-up response not found in context"

    seed = context.seed_response
    follow = context.followup_response

    seed_id = seed.get("id")
    follow_id = follow.get("id")
    assert seed_id == follow_id, "Permission ID should remain the same."

    # Check updated fields
    seed_enabled = seed.get("enabled")
    follow_enabled = follow.get("enabled")
    assert isinstance(follow_enabled, bool) or follow_enabled is None or isinstance(
        follow_enabled, (str, int)
    ), "Enabled field type is unexpected in follow-up response"

    if isinstance(seed_enabled, bool) and isinstance(follow_enabled, bool):
        assert seed_enabled != follow_enabled, "Enabled status should be updated."

    assert follow.get("note") == "Updated note for testing", "Note should reflect the updated value."

    # Check that other attributes remain unchanged
    for key, seed_value in seed.items():
        if key in ["enabled", "note"]:
            continue
        follow_value = follow.get(key)
        assert follow_value == seed_value, f"{key} should remain unchanged."

# ----




def safe_get_user_count(response_json):
    """
    Safely extract user count from the response JSON.
    Returns an integer >= 0.
    """
    if not isinstance(response_json, dict):
        return 0
    user_list = response_json.get('userList', [])
    if not isinstance(user_list, list):
        return 0
    return len(user_list)


@given('a seed input that retrieves the list of users via the user list retrieval operation, producing a seed output with a count of users for MR14.')
def step_mr_MR14_seed_input(context):
    url = f"{BASE_URL}/users"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        try:
            context.seed_response = response.json()
        except ValueError:
            context.seed_response = {}
        context.seed_request = response.request
        context.seed_user_count = safe_get_user_count(context.seed_response)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in Given step for MR14 when calling {url}: {e}")
    except Exception as e:
        raise AssertionError(f"Unexpected error in Given step for MR14: {e}")


@when('a follow-up input is created by registering a new user using the user registration operation and then retrieving the list of users again, yielding a follow-up output representing the updated list of users for MR14.')
def step_mr_MR14_followup_input(context):
    # Use a username that is likely to be unique to avoid conflicts
    new_user_data = {
        "username": "mr14_user_001",
        "password": "password123",
        "name": "New",
        "surname": "User",
        "email": "mr14_user_001@example.com",
        "gender": "other"
    }

    register_url = f"{BASE_URL}/users/register"
    users_url = f"{BASE_URL}/users"

    try:
        # Register new user
        register_response = requests.post(register_url, json=new_user_data, timeout=10)
        register_response.raise_for_status()

        # Retrieve updated user list
        followup_response = requests.get(users_url, timeout=10)
        followup_response.raise_for_status()

        try:
            context.followup_response = followup_response.json()
        except ValueError:
            context.followup_response = {}

        context.followup_request = followup_response.request
        context.followup_user_count = safe_get_user_count(context.followup_response)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in When step for MR14 (register or list users): {e}")
    except Exception as e:
        raise AssertionError(f"Unexpected error in When step for MR14: {e}")


@then('the follow-up output should have a user list size that is one greater than the seed output for MR14, assuming the registration succeeds and creates a new user record.')
def step_mr_MR14_followup_output(context):
    try:
        expected_count = int(getattr(context, 'seed_user_count', 0)) + 1
        actual_count = int(getattr(context, 'followup_user_count', 0))
        assert actual_count == expected_count, (
            f"Expected user count to be {expected_count}, but got {actual_count}."
        )
    except (TypeError, ValueError) as e:
        raise AssertionError(f"Type conversion error in Then step for MR14: {e}")
    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError(f"Unexpected error in Then step for MR14: {e}")
