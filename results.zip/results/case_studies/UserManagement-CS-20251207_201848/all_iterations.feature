
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new user should increase the user list size by one
    Given a seed input that retrieves the list of users via the user list retrieval operation, producing a seed output with a count of users for MR1.
    When a follow-up input is created by adding a new user using the user creation operation, yielding a follow-up output representing the list of users for MR1.
    Then the follow-up output should have a user list size that is one greater than the seed output for MR1.

  Scenario: MR2 Deleting a user should decrease the user list size by one
    Given a seed input that retrieves the list of users via the user list retrieval operation, producing a seed output with a count of users for MR2.
    When a follow-up input is created by deleting an existing user using the user deletion operation, yielding a follow-up output representing the list of users for MR2.
    Then the follow-up output should have a user list size that is one less than the seed output for MR2.

  Scenario: MR3 Updating a user's information should modify only the intended user data
    Given a seed input that retrieves a user's details by ID via the user detail retrieval operation, producing a seed output with user information for MR3.
    When a follow-up input is created by updating the user's information using the user update operation with specific fields changed, yielding a follow-up output for MR3.
    Then the follow-up output should reflect the updated values for the fields provided in the update request while preserving the same user identifier and keeping other user attributes consistent with the API behavior for MR3.

  Scenario: MR4 Adding a permission to a role should increase the role's permission list size by one
    Given a seed input that retrieves a role's details, including its permissions, via the role detail retrieval operation, producing a seed output with a count of permissions for MR4.
    When a follow-up input is created by adding a new permission to the role using the role-permission association creation operation, yielding a follow-up output with the updated role details for MR4.
    Then the follow-up output should have a permission list size that is one greater than the seed output for MR4, assuming the added permission was not already present.

  Scenario: MR5 Removing a permission from a role should decrease the role's permission list size by one
    Given a seed input that retrieves a role's details, including its permissions, via the role detail retrieval operation, producing a seed output with a count of permissions for MR5.
    When a follow-up input is created by removing an existing permission from the role using the role-permission association removal operation, yielding a follow-up output with the updated role details for MR5.
    Then the follow-up output should have a permission list size that is one less than the seed output for MR5.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR6 Retrieving permissions should return the same list if no changes are made within the system
    Given a seed input that retrieves the list of permissions via the permission list retrieval operation, producing a seed output with a list of permissions for MR6.
    When a follow-up input is created by retrieving the list of permissions again, without performing any permission creation, update, or deletion operations in between, yielding a follow-up output for MR6.
    Then the follow-up output should be identical to the seed output for MR6.

  Scenario: MR7 Deleting a role should remove it from the role list
    Given a seed input that retrieves the list of roles via the role list retrieval operation, producing a seed output with a count of roles for MR7, and selecting an existing role from this list.
    When a follow-up input is created by first deleting the selected role using the role deletion operation and then retrieving the list of roles again via the role list retrieval operation, yielding a follow-up output representing the updated list of roles for MR7.
    Then the follow-up output should have a role list size that is one less than the seed output for MR7, assuming the deletion operation completed successfully and no other role creation or deletion operations occurred in between.

  Scenario: MR8 Adding a role to a user should increase the user's role list size by one
    Given a seed input that retrieves a user's details, including their roles, via the user detail retrieval operation, producing a seed output with a count of roles for MR8.
    When a follow-up input is created by adding a new, previously unassigned role to the user using the user-role association creation operation, yielding a follow-up output with the updated user details for MR8.
    Then the follow-up output should have a role list size that is one greater than the seed output for MR8.

  Scenario: MR9 Removing a role from a user should decrease the user's role list size by one
    Given a seed input that retrieves a user's details, including their roles, via the user detail retrieval operation, producing a seed output with a count of roles for MR9 and identifying an existing role assigned to that user.
    When a follow-up input is created by removing the identified existing role from the user using the user-role association removal operation, yielding a follow-up output with the updated user details for MR9.
    Then the follow-up output should have a role list size that is one less than the seed output for MR9.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR10 Deleting a permission should remove it from the permission list
    Given a seed input that retrieves the list of permissions via the permission list retrieval operation, producing a seed output with a count of permissions for MR10.
    When a follow-up input is created by deleting an existing permission using the permission deletion operation and then retrieving the permission list again, yielding a follow-up output representing the updated list of permissions for MR10.
    Then the follow-up output should have a permission list size that is one less than the seed output for MR10, assuming the deleted permission previously existed in the seed list.

  Scenario: MR11 Generating a salt should produce a unique string each time
    Given a seed input that generates a salt via the salt generation operation, producing a seed output with a salt string for MR11.
    When a follow-up input is created by generating a new salt using the same salt generation operation, yielding a follow-up output with another salt string for MR11.
    Then the follow-up output salt string should differ from the seed output salt string for MR11, reflecting that each salt generation call returns a newly generated string.

  Scenario: MR13 Updating a permission should modify only the updated fields
    Given a seed input that retrieves a permission's details by key via the permission detail retrieval operation, producing a seed output with permission information for MR13.
    When a follow-up input is created by updating the permission's details using the permission update operation with specific fields changed and then retrieving the permission details again, yielding a follow-up output for MR13.
    Then the follow-up output should reflect the updated values for the fields provided in the update request while preserving the same permission identifier and keeping other permission attributes consistent with the corresponding values in the seed output for MR13.

  Scenario: MR14 Registering a new user should increase the user list size by one
    Given a seed input that retrieves the list of users via the user list retrieval operation, producing a seed output with a count of users for MR14.
    When a follow-up input is created by registering a new user using the user registration operation and then retrieving the list of users again, yielding a follow-up output representing the updated list of users for MR14.
    Then the follow-up output should have a user list size that is one greater than the seed output for MR14, assuming the registration succeeds and creates a new user record.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR16 Logging in with valid credentials should return consistent user identity details
    Given a seed input with valid login credentials via the login operation, producing a seed output with user identity details for MR16.
    When a follow-up input is created by using the same valid login credentials again, yielding a follow-up output for MR16.
    Then the follow-up output should be consistent with the seed output in terms of core user identity information (such as user id and username), even if other mutable fields differ, for MR16.

  Scenario: MR17 Registering a new user should return a successful response with user details
    Given a seed input that registers a new user via the user registration operation, producing a seed output with a successful response (for example, including created user details) for MR17.
    When a follow-up input is created by registering another new user with different details, yielding a follow-up output for MR17.
    Then the follow-up output should also return a successful response (for example, including the newly created user’s details), indicating successful registration for MR17.

  Scenario: MR19 Generating a salt should be able to produce different strings across calls
    Given a seed input that generates a salt via the salt generation operation, producing a seed output with a salt string for MR19.
    When a follow-up input is created by generating a new salt using the same salt generation operation, yielding a follow-up output with another salt string for MR19.
    Then the follow-up output salt string is expected to differ from the seed output salt string for MR19 in typical cases, reflecting that repeated salt generation calls can return newly generated strings.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR21 Deleting a permission by key should make it unavailable for subsequent retrieval
    Given a seed input that retrieves a permission by key via the permission detail retrieval operation, producing a seed output with permission details for MR21.
    When a follow-up input is created by deleting the permission using the permission deletion operation by key, yielding a follow-up output for MR21.
    Then the follow-up output should indicate successful deletion with either an 'OK' or 'No Content' response, and a subsequent attempt to retrieve the same permission key should no longer return the original permission details for MR21.

  Scenario: MR22 Deleting a role by ID should make it unavailable for subsequent retrieval
    Given a seed input that retrieves a role by ID via the role detail retrieval operation, producing a seed output with role details for MR22.
    When a follow-up input is created by deleting the role using the role deletion operation by ID, yielding a follow-up output for MR22.
    Then the follow-up output should indicate successful deletion with either an 'OK' or 'No Content' response, and a subsequent attempt to retrieve the same role ID should no longer return the original role details for MR22.


# --- From iteration_5\features\mrs_iteration_5.feature ---

Feature: Iteration 5 MRs

  Scenario: MR24 Deleting a permission by key should make it unavailable for subsequent successful retrieval
    Given a seed input that retrieves a permission by key via the permission detail retrieval operation, producing a seed output with permission details for MR24.
    When a follow-up input is created by deleting the permission using the permission deletion operation by key, yielding a follow-up output for MR24.
    Then the follow-up output should indicate successful deletion with either an 'OK' or 'No Content' response, and a subsequent attempt to retrieve the same permission key should not return a successful response containing the original permission details (for example, it may indicate that the permission cannot be found) for MR24.

  Scenario: MR25 Deleting a role by ID should make it unavailable for subsequent successful retrieval
    Given a seed input that retrieves a role by ID via the role detail retrieval operation, producing a seed output with role details for MR25.
    When a follow-up input is created by deleting the role using the role deletion operation by ID, yielding a follow-up output for MR25.
    Then the follow-up output should indicate successful deletion with either an 'OK' or 'No Content' response, and a subsequent attempt to retrieve the same role ID should not return a successful response containing the original role details (for example, it may indicate that the role cannot be found) for MR25.

