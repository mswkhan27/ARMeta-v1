Feature: Iteration 1 MRs

  Scenario: Deleting a user should make the user inaccessible by username
    Given a seed input that creates (if necessary) and then retrieves a user by their username, producing a seed output with the user's details for MR5.
    When a follow-up input is created by deleting the user with the same username and then attempting to retrieve the user again by the same username, yielding a follow-up output for MR5.
    Then the follow-up output should indicate that the user is not found (for example, via an appropriate error status or message), differing from the seed output which contained the user's details for MR5.

  Scenario: Uploading an image for a pet should not affect the pet's other details
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's details including name, status, and tags for MR7.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by its identifier, yielding a follow-up output for MR7.
    Then the follow-up output should have the same name, status, and tags as the seed output for MR7, indicating that these fields remain unchanged.

  Scenario: Logging in a user twice with the same credentials should yield consistent successful responses
    Given a seed input that attempts to log in a user with valid credentials, producing a seed output that indicates a successful login with a string response body for MR8.
    When a follow-up input is created by logging in the same user again with the same credentials, yielding a follow-up output for MR8.
    Then the follow-up output should also indicate a successful login with a string response body of the same type and structure as the seed output for MR8.

  Scenario: Retrieving inventory should reflect changes in pet status
    Given a seed input that retrieves the inventory of pets by status, producing a seed output with counts of pets for each status for MR9.
    When a follow-up input is created by changing the status of an existing pet from one valid status value to another valid status value and then retrieving the inventory again, yielding a follow-up output for MR9.
    Then the follow-up output should reflect updated counts for the affected statuses (for example, a decrease in the count for the original status and an increase in the count for the new status), differing from the seed output for MR9.
