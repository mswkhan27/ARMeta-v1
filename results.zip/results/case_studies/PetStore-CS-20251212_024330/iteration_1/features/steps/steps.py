from behave import given, when, then
import os
import json
import requests
import time

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, step_name: str) -> None:
    """
    Fail fast if the API returns a 500-series error.
    Ensures no silent server errors in Behave steps.
    """
    if response is None:
        raise AssertionError(f"{step_name}: Response is None")
    status = getattr(response, "status_code", None)
    if not isinstance(status, int):
        raise AssertionError(f"{step_name}: Invalid status_code type: {type(status)}")
    if 500 <= status <= 599:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"{step_name}: Server error {status} received from API. Body: {body}"
        )


@given(
    "a seed input that creates (if necessary) and then retrieves a user by their username, producing a seed output with the user's details for MR5."
)
def _mr_MR5_create_and_retrieve_user(context):
    username = "testuser_mr5"
    user_data = {
        "id": 0,
        "username": username,
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1,
    }

    # Create user (POST /user)
    try:
        create_resp = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Given step MR5: error calling POST /user: {e}") from e

    _check_500(create_resp, "Given step MR5 - create user")

    # For MR we only need the user to exist; 200 is the only success code per spec
    if create_resp.status_code != 200:
        raise AssertionError(
            f"Given step MR5: Expected 200 from POST /user, got {create_resp.status_code}. "
            f"Body: {create_resp.text}"
        )

    context.seed_request = create_resp

    # Retrieve user (GET /user/\{username\})
    try:
        retrieve_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Given step MR5: error calling GET /user/{{username}}: {e}") from e

    _check_500(retrieve_resp, "Given step MR5 - retrieve user")

    if retrieve_resp.status_code != 200:
        raise AssertionError(
            f"Given step MR5: Expected 200 from GET /user/{{username}}, got {retrieve_resp.status_code}. "
            f"Body: {retrieve_resp.text}"
        )

    # Safely parse JSON
    try:
        body = retrieve_resp.json()
        if not isinstance(body, dict):
            raise AssertionError(
                f"Given step MR5: Expected JSON object from GET /user/{{username}}, got: {body!r}"
            )
    except (ValueError, json.JSONDecodeError) as e:
        raise AssertionError(
            f"Given step MR5: Failed to decode JSON from GET /user/{{username}}: {e}. "
            f"Raw body: {retrieve_resp.text!r}"
        ) from e

    if body.get("username") != username:
        raise AssertionError(
            f"Given step MR5: Retrieved username does not match. "
            f"Expected {username!r}, got {body.get('username')!r}"
        )

    context.username_mr5 = username
    context.seed_response = retrieve_resp
    context.seed_user_body = body


@when(
    "a follow-up input is created by deleting the user with the same username and then attempting to retrieve the user again by the same username, yielding a follow-up output for MR5."
)
def _mr_MR5_delete_and_retrieve_user(context):
    username = getattr(context, "username_mr5", "testuser_mr5")

    # Delete user (DELETE /user/\{username\})
    try:
        delete_resp = requests.delete(f"{BASE_URL}/user/{username}", timeout=10)
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"When step MR5: error calling DELETE /user/{{username}}: {e}") from e

    _check_500(delete_resp, "When step MR5 - delete user")

    # According to spec, 200 indicates successful deletion, but we don't hard-fail
    # if API returns a documented client error since MR still can be evaluated.
    if delete_resp.status_code not in (200, 400, 404):
        raise AssertionError(
            f"When step MR5: Unexpected status from DELETE /user/{{username}}: "
            f"{delete_resp.status_code}. Body: {delete_resp.text}"
        )

    context.followup_request = delete_resp

    # Attempt to retrieve user again (GET /user/\{username\})
    try:
        retrieve_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    except requests.exceptions.RequestException as e:
        raise AssertionError(
            f"When step MR5: error calling follow-up GET /user/{{username}}: {e}"
        ) from e

    _check_500(retrieve_resp, "When step MR5 - follow-up retrieve user")

    context.followup_response = retrieve_resp


@then(
    "the follow-up output should indicate that the user is not found (for example, via an appropriate error status or message), differing from the seed output which contained the user's details for MR5."
)
def _mr_MR5_assert_user_not_found(context):
    followup_resp = getattr(context, "followup_response", None)
    if followup_resp is None:
        raise AssertionError("Then step MR5: followup_response is not set in context")

    _check_500(followup_resp, "Then step MR5 - assert user not found")

    # Per spec for GET /user/\{username\}, 404 -> 'User not found'
    if followup_resp.status_code != 404:
        raise AssertionError(
            f"Then step MR5: Expected status 404 for GET /user/{{username}} after deletion, "
            f"got {followup_resp.status_code}. Body: {followup_resp.text}"
        )

    body_text = followup_resp.text or ""
    if "User not found" not in body_text:
        raise AssertionError(
            "Then step MR5: Expected 'User not found' in response body for 404 after deletion. "
            f"Body: {body_text!r}"
        )

    seed_body = getattr(context, "seed_user_body", None)
    if not isinstance(seed_body, dict):
        raise AssertionError(
            f"Then step MR5: seed_user_body missing or invalid type: {type(seed_body)}"
        )

    # Confirm metamorphic change: seed had user details, follow-up indicates not found
    if seed_body.get("username") is None:
        raise AssertionError(
            "Then step MR5: Seed response did not contain a 'username' field as expected."
        )

# ----




def _check_response_no_500(response, step_label: str) -> None:
    """Fail the scenario if the API returns 500 or above."""
    status = getattr(response, "status_code", None)
    if status is None:
        raise AssertionError(f"{step_label}: Response has no status_code")
    if status >= 500:
        raise AssertionError(
            f"{step_label}: Server error {status} received. Body: {getattr(response, 'text', '')}"
        )


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's details including name, status, and tags for MR7.")
def _mr_MR7_seed_input(context):
    pet_id = 1  # Using a fixed pet ID for the test; must exist in the system

    url = f"{BASE_URL}/pet/{pet_id}"
    context.seed_request = requests.get(url, timeout=10)

    _check_response_no_500(context.seed_request, "MR7 seed GET /pet/{petId}")

    try:
        context.seed_response = context.seed_request.json()
    except json.JSONDecodeError as exc:
        raise AssertionError(
            f"MR7 seed: Failed to decode JSON response from {url}: {context.seed_request.text}"
        ) from exc

    if context.seed_request.status_code != 200:
        raise AssertionError(
            f"MR7 seed: Expected 200 when retrieving pet, got "
            f"{context.seed_request.status_code} with body: {context.seed_response}"
        )

    # Ensure keys exist to avoid KeyError in the assertion step
    if not isinstance(context.seed_response, dict):
        raise AssertionError(
            f"MR7 seed: Expected JSON object for pet, got: {type(context.seed_response)}"
        )

    for key in ("name", "status", "tags"):
        if key not in context.seed_response:
            # Tags may legitimately be missing; normalize to default values
            if key == "tags":
                context.seed_response["tags"] = []
            else:
                raise AssertionError(
                    f"MR7 seed: Expected key '{key}' in pet response but it was missing. "
                    f"Response body: {context.seed_response}"
                )

    # Normalize tags to list to prevent TypeError later
    if context.seed_response["tags"] is None:
        context.seed_response["tags"] = []
    elif not isinstance(context.seed_response["tags"], list):
        context.seed_response["tags"] = [context.seed_response["tags"]]


@when("a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by its identifier, yielding a follow-up output for MR7.")
def _mr_MR7_followup_input(context):
    pet_id = 1  # Same pet ID used in the seed input

    image_path = os.environ.get("PET_IMAGE_PATH", "path/to/image.jpg")

    if not os.path.isfile(image_path):
        raise AssertionError(
            f"MR7 follow-up: Image file does not exist at '{image_path}'. "
            f"Provide a valid path via PET_IMAGE_PATH environment variable."
        )

    upload_url = f"{BASE_URL}/pet/{pet_id}/uploadImage"
    with open(image_path, "rb") as image_file:
        # OpenAPI: /pet/{petId}/uploadImage, POST, requestBody: application/octet-stream
        # Using 'files' to send binary content is acceptable for this test client
        upload_response = requests.post(
            upload_url,
            files={"file": image_file},
            timeout=30,
        )

    _check_response_no_500(upload_response, "MR7 follow-up POST /pet/{petId}/uploadImage")

    if upload_response.status_code != 200:
        raise AssertionError(
            f"MR7 follow-up: Expected 200 when uploading image, got "
            f"{upload_response.status_code} with body: {upload_response.text}"
        )

    followup_url = f"{BASE_URL}/pet/{pet_id}"
    context.followup_request = requests.get(followup_url, timeout=10)

    _check_response_no_500(context.followup_request, "MR7 follow-up GET /pet/{petId}")

    try:
        context.followup_response = context.followup_request.json()
    except json.JSONDecodeError as exc:
        raise AssertionError(
            f"MR7 follow-up: Failed to decode JSON response from {followup_url}: "
            f"{context.followup_request.text}"
        ) from exc

    if context.followup_request.status_code != 200:
        raise AssertionError(
            f"MR7 follow-up: Expected 200 when retrieving pet after upload, got "
            f"{context.followup_request.status_code} with body: {context.followup_response}"
        )

    if not isinstance(context.followup_response, dict):
        raise AssertionError(
            f"MR7 follow-up: Expected JSON object for pet, got: {type(context.followup_response)}"
        )

    for key in ("name", "status", "tags"):
        if key not in context.followup_response:
            if key == "tags":
                context.followup_response["tags"] = []
            else:
                raise AssertionError(
                    f"MR7 follow-up: Expected key '{key}' in pet response but it was missing. "
                    f"Response body: {context.followup_response}"
                )

    if context.followup_response["tags"] is None:
        context.followup_response["tags"] = []
    elif not isinstance(context.followup_response["tags"], list):
        context.followup_response["tags"] = [context.followup_response["tags"]]


@then("the follow-up output should have the same name, status, and tags as the seed output for MR7, indicating that these fields remain unchanged.")
def _mr_MR7_assert_followup_output(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise AssertionError(
            "MR7 assert: Seed or follow-up response is not a JSON object. "
            f"Seed type: {type(seed)}, follow-up type: {type(followup)}"
        )

    seed_name = seed.get("name")
    follow_name = followup.get("name")
    seed_status = seed.get("status")
    follow_status = followup.get("status")

    seed_tags = seed.get("tags", [])
    follow_tags = followup.get("tags", [])

    if seed_tags is None:
        seed_tags = []
    if follow_tags is None:
        follow_tags = []

    if not isinstance(seed_tags, list):
        seed_tags = [seed_tags]
    if not isinstance(follow_tags, list):
        follow_tags = [follow_tags]

    if follow_name != seed_name:
        raise AssertionError(
            f"MR7 assert: Name has changed after image upload. "
            f"Seed name='{seed_name}', follow-up name='{follow_name}'"
        )

    if follow_status != seed_status:
        raise AssertionError(
            f"MR7 assert: Status has changed after image upload. "
            f"Seed status='{seed_status}', follow-up status='{follow_status}'"
        )

    if follow_tags != seed_tags:
        raise AssertionError(
            f"MR7 assert: Tags have changed after image upload. "
            f"Seed tags={seed_tags}, follow-up tags={follow_tags}"
        )

# ----






@given(
    'a seed input that attempts to log in a user with valid credentials, producing a seed output that indicates a successful login with a string response body for MR8.'
)
def _mr_MR8_seed_login(context):
    context.username = "testuser"
    context.password = "testpassword"

    # Request definition according to OpenAPI: GET /user/login with query params
    params = {
        "username": context.username,
        "password": context.password,
    }
    context.seed_request = params

    try:
        response = requests.get(
            f"{BASE_URL}/user/login",
            params=params,
            timeout=10,
        )
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in seed login request for MR8: {e}") from e

    _check_500(response, "Seed login (MR8)")

    # Ensure we captured a successful seed output as required by MR
    if response.status_code != 200:
        raise AssertionError(
            f"Seed login for MR8 did not succeed as expected. "
            f"Status: {response.status_code}, Body: {response.text}"
        )

    # Body must be a string as per OpenAPI (application/json or xml with type string)
    if not isinstance(response.text, str):
        raise AssertionError(
            f"Seed login response body is not a string. "
            f"Type: {type(response.text)}"
        )

    context.seed_response = response


@when(
    'a follow-up input is created by logging in the same user again with the same credentials, yielding a follow-up output for MR8.'
)
def _mr_MR8_followup_login(context):
    # Safely reuse the previously stored request parameters
    params = getattr(context, "seed_request", None)
    if not isinstance(params, dict):
        raise AssertionError(
            "MR8 follow-up login could not find a valid seed_request dict on context."
        )

    try:
        response = requests.get(
            f"{BASE_URL}/user/login",
            params=params,
            timeout=10,
        )
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in follow-up login request for MR8: {e}") from e

    _check_500(response, "Follow-up login (MR8)")

    context.followup_response = response


@then(
    'the follow-up output should also indicate a successful login with a string response body of the same type and structure as the seed output for MR8.'
)
def _mr_MR8_assert_followup_response(context):
    seed_response = getattr(context, "seed_response", None)
    followup_response = getattr(context, "followup_response", None)

    if seed_response is None or followup_response is None:
        raise AssertionError(
            "MR8 expectations require both seed_response and followup_response to be present on context."
        )

    _check_500(seed_response, "Seed login (MR8)")
    _check_500(followup_response, "Follow-up login (MR8)")

    # Both responses should be successful
    if seed_response.status_code != 200:
        raise AssertionError(
            f"Seed response was not successful (expected 200): "
            f"{seed_response.status_code} - {seed_response.text}"
        )

    if followup_response.status_code != 200:
        raise AssertionError(
            f"Follow-up response was not successful (expected 200): "
            f"{followup_response.status_code} - {followup_response.text}"
        )

    # Both bodies should be strings (as per OpenAPI: type string)
    if not isinstance(seed_response.text, str):
        raise AssertionError(
            f"Seed response body is not a string. Type: {type(seed_response.text)}"
        )

    if not isinstance(followup_response.text, str):
        raise AssertionError(
            f"Follow-up response body is not a string. Type: {type(followup_response.text)}"
        )

    # Same "type and structure": for plain strings, we can compare that both are non-empty
    # and have the same basic shape (e.g., both contain or both do not contain '=' as in token style).
    if (len(seed_response.text) == 0) != (len(followup_response.text) == 0):
        raise AssertionError(
            "Seed and follow-up responses do not have the same emptiness property."
        )

    seed_has_equals = "=" in seed_response.text
    followup_has_equals = "=" in followup_response.text
    if seed_has_equals != followup_has_equals:
        raise AssertionError(
            "Seed and follow-up responses do not share the same structural pattern."
        )

# ----






@given('a seed input that retrieves the inventory of pets by status, producing a seed output with counts of pets for each status for MR9.')
def _mr_MR9_seed_input(context):
    # Retrieve the initial inventory of pets
    response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    _check_500(response, "MR9 Given /store/inventory")
    response.raise_for_status()

    try:
        context.seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"MR9 Given: Failed to decode JSON from /store/inventory: {e}")

    context.seed_request = None  # No request payload for this step


@when('a follow-up input is created by changing the status of an existing pet from one valid status value to another valid status value and then retrieving the inventory again, yielding a follow-up output for MR9.')
def _mr_MR9_followup_input(context):
    # Create a new pet with status 'available'
    new_pet = {
        "name": "TestPet_MR9",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    add_response = requests.post(f"{BASE_URL}/pet", json=new_pet, timeout=10)
    _check_500(add_response, "MR9 When POST /pet")
    add_response.raise_for_status()

    try:
        added_pet = add_response.json()
    except ValueError as e:
        raise AssertionError(f"MR9 When: Failed to decode JSON from POST /pet: {e}")

    pet_id = added_pet.get("id")
    if pet_id is None:
        raise AssertionError("MR9 When: Created pet response does not contain an 'id' field")

    # Update the pet's status to 'sold' using PUT /pet (Update an existing pet.)
    updated_pet = dict(added_pet)
    updated_pet["status"] = "sold"

    update_response = requests.put(f"{BASE_URL}/pet", json=updated_pet, timeout=10)
    _check_500(update_response, "MR9 When PUT /pet")
    update_response.raise_for_status()

    # Retrieve the inventory again
    followup_response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    _check_500(followup_response, "MR9 When GET /store/inventory (follow-up)")
    followup_response.raise_for_status()

    try:
        context.followup_response = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"MR9 When: Failed to decode JSON from follow-up /store/inventory: {e}")

    context.followup_request = None  # No request payload for this step


@then('the follow-up output should reflect updated counts for the affected statuses (for example, a decrease in the count for the original status and an increase in the count for the new status), differing from the seed output for MR9.')
def _mr_MR9_followup_output(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AssertionError("MR9 Then: Missing seed or follow-up responses in context")

    if not isinstance(context.seed_response, dict):
        raise AssertionError("MR9 Then: seed_response is not a JSON object (dict)")
    if not isinstance(context.followup_response, dict):
        raise AssertionError("MR9 Then: followup_response is not a JSON object (dict)")

    seed_available_count = context.seed_response.get("available", 0)
    seed_sold_count = context.seed_response.get("sold", 0)

    followup_available_count = context.followup_response.get("available", 0)
    followup_sold_count = context.followup_response.get("sold", 0)

    for name, value in [
        ("seed_available_count", seed_available_count),
        ("seed_sold_count", seed_sold_count),
        ("followup_available_count", followup_available_count),
        ("followup_sold_count", followup_sold_count),
    ]:
        if not isinstance(value, int):
            raise AssertionError(f"MR9 Then: {name} is not an integer (value: {value})")

    if followup_available_count != seed_available_count - 1:
        raise AssertionError(
            f"MR9 Then: Available count did not decrease by 1 as expected "
            f"(seed={seed_available_count}, follow-up={followup_available_count})"
        )

    if followup_sold_count != seed_sold_count + 1:
        raise AssertionError(
            f"MR9 Then: Sold count did not increase by 1 as expected "
            f"(seed={seed_sold_count}, follow-up={followup_sold_count})"
        )
