from behave import given, when, then
import os
import json
import requests
from requests import Response

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _safe_json(response: Response):
    """
    Safely parse JSON and ensure a predictable type.
    Returns list for array responses, or [] if not a list.
    Raises AssertionError on HTTP 500.
    """
    if response.status_code == 500:
        raise AssertionError(f"Server error 500 for URL {response.url}")

    try:
        data = response.json()
    except ValueError:
        # JSON decode error, fail the step explicitly
        raise AssertionError(f"Response is not valid JSON for URL {response.url}")

    # For this MR we expect array responses from /pet/findByStatus
    if isinstance(data, list):
        return data
    # If not a list, convert to empty list to avoid TypeError in len(...)
    return []


@given("a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR1.")
def _mr_MR1_seed_input(context):
    # Retrieve the list of pets with status 'available' using the correct API:
    # GET /pet/findByStatus (summary: Finds Pets by status.)
    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByStatus",
            params={"status": "available"},
            timeout=10
        )
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"HTTP error in GIVEN step for MR1: {e}")

    # Explicit 500 check as required
    if response.status_code == 500:
        raise AssertionError(f"Server error 500 in GIVEN step for MR1 on {response.url}")

    # Raise for other non-successful statuses
    try:
        response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        raise AssertionError(f"Unexpected HTTP status {response.status_code} in GIVEN step for MR1: {e}")

    context.seed_request = response
    context.seed_response = _safe_json(response)

    # Count of pets with status 'available'
    try:
        context.misc = len(context.seed_response)
    except TypeError as e:
        raise AssertionError(f"Type error when counting seed_response in GIVEN step for MR1: {e}")


@when("a follow-up input is created by adding a new pet whose status is set to 'available' and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR1.")
def _mr_MR1_followup_input(context):
    # Create a new pet with status 'available' using:
    # POST /pet (summary: Add a new pet to the store.)
    new_pet = {
        "name": "New Available Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    # POST /pet
    try:
        create_response = requests.post(
            f"{BASE_URL}/pet",
            json=new_pet,
            timeout=10
        )
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"HTTP error when creating pet in WHEN step for MR1: {e}")

    if create_response.status_code == 500:
        raise AssertionError(f"Server error 500 while creating pet in WHEN step for MR1 on {create_response.url}")

    try:
        create_response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        raise AssertionError(
            f"Unexpected HTTP status {create_response.status_code} when creating pet in WHEN step for MR1: {e}"
        )

    # Optionally ensure created pet JSON is valid (defensive, but not used later)
    try:
        _ = create_response.json()
    except ValueError:
        # We don't depend on this payload for MR logic, but fail clearly if it's invalid JSON
        raise AssertionError(f"Create-pet response is not valid JSON in WHEN step for MR1: {create_response.url}")

    # Retrieve the list of pets with status 'available' again using:
    # GET /pet/findByStatus (summary: Finds Pets by status.)
    try:
        followup_response = requests.get(
            f"{BASE_URL}/pet/findByStatus",
            params={"status": "available"},
            timeout=10
        )
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"HTTP error when retrieving follow-up list in WHEN step for MR1: {e}")

    if followup_response.status_code == 500:
        raise AssertionError(f"Server error 500 in follow-up GET for WHEN step MR1 on {followup_response.url}")

    try:
        followup_response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        raise AssertionError(
            f"Unexpected HTTP status {followup_response.status_code} "
            f"when retrieving follow-up list in WHEN step for MR1: {e}"
        )

    context.followup_request = followup_response
    context.followup_response = _safe_json(followup_response)


@then("assuming no other operations modify pets with status 'available' between the two retrievals, the follow-up output should have a count of pets with status 'available' that is exactly one more than the seed output for MR1.")
def _mr_MR1_assert_count(context):
    # Defensive checks to avoid TypeError/AttributeError
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response is missing in THEN step for MR1.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("followup_response is missing in THEN step for MR1.")
    if not hasattr(context, "misc"):
        raise AssertionError("Seed count (context.misc) is missing in THEN step for MR1.")

    if not isinstance(context.seed_response, list):
        raise AssertionError(f"Seed response is not a list in THEN step for MR1, got {type(context.seed_response)}")
    if not isinstance(context.followup_response, list):
        raise AssertionError(f"Follow-up response is not a list in THEN step for MR1, got {type(context.followup_response)}")

    try:
        seed_count = int(context.misc)
    except (TypeError, ValueError) as e:
        raise AssertionError(f"Invalid seed count stored in context.misc in THEN step for MR1: {e}")

    followup_count = len(context.followup_response)

    if followup_count != seed_count + 1:
        raise AssertionError(
            f"MR1 violated: expected follow-up count {seed_count + 1}, "
            f"but got {followup_count} (seed was {seed_count})."
        )

# ----




def _check_response_no_500(response, step_name: str) -> None:
    """Raise an AssertionError if server returned 500-level error."""
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"{step_name}: Server error {response.status_code} for {response.request.method} "
            f"{response.request.url} with body={response.text!r}"
        )


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status and other details for MR2.")
def step_mr_MR2_seed_input(context):
    # Create a pet to ensure it exists (matches POST /pet Add a new pet to the store.)
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_no_500(response, "Given MR2 - create pet")
    context.seed_create_response = response

    try:
        context.seed_response = response.json()
    except ValueError as exc:
        raise AssertionError(f"Given MR2 - invalid JSON in create pet response: {exc}; body={response.text!r}")

    # Safely extract id
    pet_id = context.seed_response.get("id")
    if pet_id is None:
        raise AssertionError(f"Given MR2 - created pet has no 'id' field: {context.seed_response!r}")
    context.pet_id = pet_id

    # Retrieve the pet by ID (matches GET /pet/\{petId\} Find pet by ID.)
    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(get_response, "Given MR2 - get pet by id")
    context.seed_get_response = get_response

    try:
        context.seed_get_body = get_response.json()
    except ValueError as exc:
        raise AssertionError(f"Given MR2 - invalid JSON in get pet response: {exc}; body={get_response.text!r}")

    # Basic consistency checks, using .get to avoid KeyError/TypeError
    if context.seed_get_body.get("id") != pet_id:
        raise AssertionError(
            f"Given MR2 - mismatch between created pet id {pet_id!r} and retrieved id {context.seed_get_body.get('id')!r}"
        )

    seed_status_created = context.seed_response.get("status")
    seed_status_fetched = context.seed_get_body.get("status")
    if seed_status_created != seed_status_fetched:
        raise AssertionError(
            f"Given MR2 - status mismatch between created ({seed_status_created!r}) "
            f"and retrieved ({seed_status_fetched!r}) pet"
        )


@when("a follow-up input is created by updating that pet so that its status is changed to 'sold', and then retrieving the same pet again by its identifier, yielding a follow-up output for MR2.")
def step_mr_MR2_followup_input(context):
    if not hasattr(context, "seed_get_body"):
        raise AssertionError("When MR2 - seed_get_body not found on context; Given step may have failed.")

    seed_body = context.seed_get_body
    pet_id = context.pet_id

    # Build update payload based on current pet to keep other fields unchanged.
    # Matches PUT /pet Update an existing pet.
    update_data = {
        "id": pet_id,
        "name": seed_body.get("name", "doggie"),
        "photoUrls": seed_body.get("photoUrls", ["url1"]),
        "status": "sold",
    }
    # Carry over optional fields if present to keep them consistent
    if "category" in seed_body:
        update_data["category"] = seed_body["category"]
    if "tags" in seed_body:
        update_data["tags"] = seed_body["tags"]

    update_response = requests.put(f"{BASE_URL}/pet", json=update_data, timeout=10)
    _check_response_no_500(update_response, "When MR2 - update pet")
    context.update_response_raw = update_response

    try:
        context.update_response = update_response.json()
    except ValueError as exc:
        raise AssertionError(f"When MR2 - invalid JSON in update pet response: {exc}; body={update_response.text!r}")

    # Retrieve the pet again by ID (GET /pet/\{petId\})
    followup_get = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(followup_get, "When MR2 - get updated pet")
    context.followup_get_response = followup_get

    try:
        context.followup_response = followup_get.json()
    except ValueError as exc:
        raise AssertionError(
            f"When MR2 - invalid JSON in get updated pet response: {exc}; body={followup_get.text!r}"
        )

    # Basic id consistency check
    if context.followup_response.get("id") != pet_id:
        raise AssertionError(
            f"When MR2 - mismatch between expected pet id {pet_id!r} and retrieved id {context.followup_response.get('id')!r}"
        )


@then("the follow-up output should show the pet with the same identifier as in the seed output and with its status updated to 'sold'; fields not changed by the update request should remain consistent with the seed output for MR2.")
def step_mr_MR2_followup_output(context):
    if not hasattr(context, "seed_get_body") or not hasattr(context, "followup_response"):
        raise AssertionError("Then MR2 - required context attributes missing; previous steps may have failed.")

    seed_body = context.seed_get_body
    followup_body = context.followup_response

    pet_id = context.pet_id

    # Same identifier
    if followup_body.get("id") != pet_id:
        raise AssertionError(
            f"Then MR2 - expected pet id {pet_id!r}, got {followup_body.get('id')!r} in follow-up output"
        )

    # Status updated to 'sold'
    if followup_body.get("status") != "sold":
        raise AssertionError(
            f"Then MR2 - expected status 'sold', got {followup_body.get('status')!r} in follow-up output"
        )

    # Fields not changed by the update request should remain the same.
    # We explicitly changed only 'status'; all other keys present in both
    # seed and follow-up and not 'status' should match.
    for key in seed_body.keys():
        if key == "status":
            continue
        if key in followup_body:
            if followup_body[key] != seed_body[key]:
                raise AssertionError(
                    f"Then MR2 - field {key!r} changed unexpectedly between seed and follow-up. "
                    f"Seed: {seed_body[key]!r}, Follow-up: {followup_body[key]!r}"
                )

# ----




def _check_server_error(response, step_name: str) -> None:
    """
    Ensure no 5xx errors. If found, raise an AssertionError so Behave marks the step failed.
    """
    if 500 <= response.status_code <= 599:
        # Try to include any error payload safely
        try:
            body = response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"{step_name}: Server error {response.status_code} from {response.request.method} "
            f"{response.request.url}. Response body: {body}"
        )


@given("a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR3, and selecting from that list a specific pet identifier to be deleted.")
def _mr_MR3_seed_input(context):
    # Retrieve the list of pets with status 'available'
    url_find_by_status = f"{BASE_URL}/pet/findByStatus"
    try:
        response = requests.get(url_find_by_status, params={"status": "available"}, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"MR3 seed step: request to {url_find_by_status} failed: {e}") from e

    _check_server_error(response, "MR3 seed step")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"MR3 seed step: non-success status code {response.status_code} "
                             f"for {url_find_by_status}: {response.text}") from e

    try:
        seed_data = response.json()
    except ValueError as e:
        raise AssertionError(f"MR3 seed step: response from {url_find_by_status} is not valid JSON: {e}") from e

    # Ensure we have a list; if not, coerce safely
    if isinstance(seed_data, list):
        context.seed_response = seed_data
    elif seed_data is None:
        context.seed_response = []
    else:
        # Unexpected shape – avoid TypeError later
        context.seed_response = []

    # If there are no available pets, create one to satisfy the MR
    if not context.seed_response:
        new_pet = {
            "name": "Test Pet MR3",
            "photoUrls": ["http://example.com/photo.jpg"],
            "status": "available"
        }
        url_create_pet = f"{BASE_URL}/pet"
        try:
            create_response = requests.post(url_create_pet, json=new_pet, timeout=10)
        except requests.RequestException as e:
            raise AssertionError(f"MR3 seed step: request to {url_create_pet} failed: {e}") from e

        _check_server_error(create_response, "MR3 seed step (create pet)")

        try:
            create_response.raise_for_status()
        except requests.HTTPError as e:
            raise AssertionError(
                f"MR3 seed step: non-success status code {create_response.status_code} "
                f"for {url_create_pet}: {create_response.text}"
            ) from e

        try:
            created_pet = create_response.json()
        except ValueError as e:
            raise AssertionError(f"MR3 seed step: create pet response is not valid JSON: {e}") from e

        if not isinstance(created_pet, dict):
            raise AssertionError("MR3 seed step: created pet response is not an object")

        context.seed_response = [created_pet]

    # Safely select a specific pet identifier to delete
    first_pet = context.seed_response[0]
    if not isinstance(first_pet, dict):
        raise AssertionError("MR3 seed step: first pet item is not an object")

    pet_id = first_pet.get("id")
    if not isinstance(pet_id, int):
        # The API defines id as integer; enforce to avoid ValueError/TypeError later
        raise AssertionError(f"MR3 seed step: pet id is missing or not an integer: {pet_id!r}")

    context.pet_to_delete = pet_id
    context.seed_count = len(context.seed_response)


@when("a follow-up input is created by deleting the selected pet and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR3.")
def _mr_MR3_followup_input(context):
    if not hasattr(context, "pet_to_delete"):
        raise AssertionError("MR3 follow-up step: 'pet_to_delete' not set in context")

    pet_id = context.pet_to_delete
    if not isinstance(pet_id, int):
        raise AssertionError(f"MR3 follow-up step: 'pet_to_delete' is not an integer: {pet_id!r}")

    # Delete the selected pet
    url_delete_pet = f"{BASE_URL}/pet/{pet_id}"
    try:
        delete_response = requests.delete(url_delete_pet, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"MR3 follow-up step: request to {url_delete_pet} failed: {e}") from e

    _check_server_error(delete_response, "MR3 follow-up step (delete pet)")

    try:
        delete_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"MR3 follow-up step: non-success status code {delete_response.status_code} "
            f"for {url_delete_pet}: {delete_response.text}"
        ) from e

    # Retrieve the list of pets with status 'available' again
    url_find_by_status = f"{BASE_URL}/pet/findByStatus"
    try:
        followup_response = requests.get(url_find_by_status, params={"status": "available"}, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"MR3 follow-up step: request to {url_find_by_status} failed: {e}") from e

    _check_server_error(followup_response, "MR3 follow-up step (findByStatus)")

    try:
        followup_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"MR3 follow-up step: non-success status code {followup_response.status_code} "
            f"for {url_find_by_status}: {followup_response.text}"
        ) from e

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"MR3 follow-up step: response from {url_find_by_status} is not valid JSON: {e}") from e

    if isinstance(followup_data, list):
        context.followup_response = followup_data
    elif followup_data is None:
        context.followup_response = []
    else:
        context.followup_response = []


@then("assuming no other operations modify pets with status 'available' between the two retrievals, the follow-up output should have a count of pets with status 'available' that is exactly one less than the seed output for MR3, and the deleted pet should no longer appear in the list.")
def _mr_MR3_assertion(context):
    if not hasattr(context, "seed_count"):
        raise AssertionError("MR3 assertion step: 'seed_count' not set in context")
    if not hasattr(context, "followup_response"):
        raise AssertionError("MR3 assertion step: 'followup_response' not set in context")
    if not hasattr(context, "pet_to_delete"):
        raise AssertionError("MR3 assertion step: 'pet_to_delete' not set in context")

    followup = context.followup_response
    if not isinstance(followup, list):
        raise AssertionError("MR3 assertion step: follow-up response is not a list")

    expected_count = context.seed_count - 1
    actual_count = len(followup)
    if actual_count != expected_count:
        raise AssertionError(
            f"MR3 assertion step: expected {expected_count} pets with status 'available', "
            f"but got {actual_count}"
        )

    deleted_id = context.pet_to_delete
    # Ensure the deleted pet does not appear in the list
    for pet in followup:
        if not isinstance(pet, dict):
            raise AssertionError("MR3 assertion step: an item in follow-up response is not an object")
        if pet.get("id") == deleted_id:
            raise AssertionError(
                f"MR3 assertion step: deleted pet with id {deleted_id} still appears in the list"
            )

# ----

from requests import Response
from typing import Any, Dict, List



def _safe_get_json(response: Response) -> Any:
    """
    Safely parse JSON from a response. If parsing fails, raise an assertion
    with a clear message to avoid uncaught ValueError/TypeError.
    """
    try:
        return response.json()
    except ValueError:
        assert False, f"Response is not valid JSON. Status: {response.status_code}, Body: {response.text}"


def _assert_no_500(response: Response, step_name: str) -> None:
    """
    Ensure that no 5xx error is returned. If it is, fail the step explicitly
    so it is visible in the Behave report.
    """
    if 500 <= response.status_code <= 599:
        assert False, (
            f"Server error (status {response.status_code}) encountered in {step_name}. "
            f"Response body: {response.text}"
        )


def _ensure_list_of_pets(data: Any, step_name: str) -> List[Dict[str, Any]]:
    """
    Ensure that the response data is a list of pet objects and avoid TypeError.
    """
    if not isinstance(data, list):
        assert False, f"{step_name}: Expected a list of pets, got {type(data).__name__}: {data}"
    validated: List[Dict[str, Any]] = []
    for idx, item in enumerate(data):
        if not isinstance(item, dict):
            assert False, (
                f"{step_name}: Expected each pet to be an object (dict). "
                f"Item at index {idx} has type {type(item).__name__}: {item}"
            )
        # 'id' is optional in schema, so we only consider pets with an integer id
        pet_id = item.get("id")
        if pet_id is not None and not isinstance(pet_id, int):
            assert False, (
                f"{step_name}: Expected pet 'id' to be an integer when present. "
                f"Got {repr(pet_id)} of type {type(pet_id).__name__} in item at index {idx}"
            )
        validated.append(item)
    return validated


@given("a seed input that retrieves pets filtered by a single tag 'tag1', producing a seed output with a list of pets for MR4.")
def _mr_MR4_seed_input(context):
    # According to OpenAPI, use GET /pet/findByTags with required query param "tags"
    params = {'tags': 'tag1'}
    response = requests.get(f"{BASE_URL}/pet/findByTags", params=params, timeout=10)
    _assert_no_500(response, "Given step for MR4 (seed input)")
    assert response.status_code == 200, (
        f"Failed to retrieve pets with tag 'tag1'. "
        f"Status: {response.status_code}, Body: {response.text}"
    )

    data = _safe_get_json(response)
    pets = _ensure_list_of_pets(data, "Given step for MR4 (seed input)")

    context.seed_request = response
    context.seed_response = pets


@when("a follow-up input is created by retrieving pets filtered by multiple tags 'tag1, tag2' using the same filtering rules, yielding a follow-up output for MR4.")
def _mr_MR4_followup_input(context):
    # Same endpoint and method as Given step, but with multiple tags
    params = {'tags': 'tag1,tag2'}
    response = requests.get(f"{BASE_URL}/pet/findByTags", params=params, timeout=10)
    _assert_no_500(response, "When step for MR4 (follow-up input)")
    assert response.status_code == 200, (
        f"Failed to retrieve pets with tags 'tag1, tag2'. "
        f"Status: {response.status_code}, Body: {response.text}"
    )

    data = _safe_get_json(response)
    pets = _ensure_list_of_pets(data, "When step for MR4 (follow-up input)")

    context.followup_request = response
    context.followup_response = pets


@then("every pet returned in the seed output for tag 'tag1' should also be present in the follow-up output obtained when searching with tags 'tag1, tag2', so that the follow-up output is a superset or equal set relative to the seed output for MR4.")
def _mr_MR4_assert_superset(context):
    # Defensive checks to avoid AttributeError/TypeError
    seed_data = getattr(context, "seed_response", None)
    followup_data = getattr(context, "followup_response", None)

    assert isinstance(seed_data, list), (
        f"Then step for MR4: seed_response is not a list. Got {type(seed_data).__name__}: {seed_data}"
    )
    assert isinstance(followup_data, list), (
        f"Then step for MR4: followup_response is not a list. Got {type(followup_data).__name__}: {followup_data}"
    )

    # Extract IDs only from pets that actually have an integer 'id'
    seed_pet_ids = {
        pet["id"] for pet in seed_data
        if isinstance(pet, dict) and isinstance(pet.get("id"), int)
    }
    followup_pet_ids = {
        pet["id"] for pet in followup_data
        if isinstance(pet, dict) and isinstance(pet.get("id"), int)
    }

    assert seed_pet_ids.issubset(followup_pet_ids), (
        "Not all pets from seed output are present in follow-up output. "
        f"Missing IDs: {sorted(seed_pet_ids - followup_pet_ids)}"
    )
