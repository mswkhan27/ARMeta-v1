Feature: Iteration 0 MRs

  Scenario: Adding a new pet with a given status should increase the count of pets with that status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR1.
    When a follow-up input is created by adding a new pet whose status is set to 'available' and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR1.
    Then assuming no other operations modify pets with status 'available' between the two retrievals, the follow-up output should have a count of pets with status 'available' that is exactly one more than the seed output for MR1.

  Scenario: Updating a pet's status should be observable when retrieving that pet by its identifier
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status and other details for MR2.
    When a follow-up input is created by updating that pet so that its status is changed to 'sold', and then retrieving the same pet again by its identifier, yielding a follow-up output for MR2.
    Then the follow-up output should show the pet with the same identifier as in the seed output and with its status updated to 'sold'; fields not changed by the update request should remain consistent with the seed output for MR2.

  Scenario: Deleting a pet with a given status should reduce the count of pets with that status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR3, and selecting from that list a specific pet identifier to be deleted.
    When a follow-up input is created by deleting the selected pet and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR3.
    Then assuming no other operations modify pets with status 'available' between the two retrievals, the follow-up output should have a count of pets with status 'available' that is exactly one less than the seed output for MR3, and the deleted pet should no longer appear in the list.

  Scenario: Finding pets by multiple tags should include pets found by an individual tag
    Given a seed input that retrieves pets filtered by a single tag 'tag1', producing a seed output with a list of pets for MR4.
    When a follow-up input is created by retrieving pets filtered by multiple tags 'tag1, tag2' using the same filtering rules, yielding a follow-up output for MR4.
    Then every pet returned in the seed output for tag 'tag1' should also be present in the follow-up output obtained when searching with tags 'tag1, tag2', so that the follow-up output is a superset or equal set relative to the seed output for MR4.
