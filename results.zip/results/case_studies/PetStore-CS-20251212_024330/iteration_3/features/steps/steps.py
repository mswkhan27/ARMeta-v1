from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, step_name: str) -> None:
    """Fail fast on HTTP 500 errors."""
    if response is None:
        raise AssertionError(f"{step_name}: No response object to check for 500 errors.")
    if response.status_code == 500:
        raise AssertionError(
            f"{step_name}: Received 500 Internal Server Error from API at {response.url}"
        )


@given("a seed input that retrieves a user by their username, producing a seed output with the user's current details for MR14.")
def _mr_MR14_seed_input(context):
    username = "theUser"
    context.seed_request = {"username": username}

    try:
        response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"GIVEN MR14: HTTP request failed: {e}") from e

    _check_500(response, "GIVEN MR14")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"GIVEN MR14: Unexpected HTTP status {response.status_code} for GET /user/{{username}}") from e

    try:
        context.seed_response = response.json()
        if not isinstance(context.seed_response, dict):
            raise AssertionError("GIVEN MR14: Expected JSON object for user, got non-dict value.")
    except (ValueError, TypeError) as e:
        raise AssertionError(f"GIVEN MR14: Failed to parse JSON response: {e}") from e


@when("a follow-up input is created by updating the user's details using the same username identifier and then retrieving the user again by that username, yielding a follow-up output for MR14.")
def _mr_MR14_followup_input(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("WHEN MR14: seed_response is missing or not a dict from GIVEN step.")

    username = context.seed_response.get("username") or context.seed_request.get("username") or "theUser"

    updated_user = {
        "id": context.seed_response.get("id"),
        "username": username,
        "firstName": "UpdatedFirstName",
        "lastName": context.seed_response.get("lastName"),
        "email": context.seed_response.get("email"),
        "password": context.seed_response.get("password"),
        "phone": context.seed_response.get("phone"),
        "userStatus": context.seed_response.get("userStatus"),
    }
    context.followup_request = updated_user

    try:
        update_response = requests.put(f"{BASE_URL}/user/{username}", json=updated_user, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"WHEN MR14: HTTP request failed during update: {e}") from e

    _check_500(update_response, "WHEN MR14 (update)")

    try:
        update_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"WHEN MR14: Unexpected HTTP status {update_response.status_code} for PUT /user/{{username}}"
        ) from e

    try:
        followup_response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"WHEN MR14: HTTP request failed during follow-up GET: {e}") from e

    _check_500(followup_response, "WHEN MR14 (follow-up get)")

    try:
        followup_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"WHEN MR14: Unexpected HTTP status {followup_response.status_code} for GET /user/{{username}}"
        ) from e

    try:
        context.followup_response = followup_response.json()
        if not isinstance(context.followup_response, dict):
            raise AssertionError("WHEN MR14: Expected JSON object for user, got non-dict value.")
    except (ValueError, TypeError) as e:
        raise AssertionError(f"WHEN MR14: Failed to parse JSON response: {e}") from e


@then("the follow-up output should reflect the updated details provided in the update request, while fields that were not modified should remain consistent with the seed output for MR14.")
def _mr_MR14_followup_output(context):
    if not hasattr(context, "followup_response") or not isinstance(context.followup_response, dict):
        raise AssertionError("THEN MR14: followup_response is missing or not a dict from WHEN step.")
    if not hasattr(context, "followup_request") or not isinstance(context.followup_request, dict):
        raise AssertionError("THEN MR14: followup_request is missing or not a dict from WHEN step.")
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("THEN MR14: seed_response is missing or not a dict from GIVEN step.")

    fr = context.followup_response
    fu = context.followup_request
    seed = context.seed_response

    try:
        assert fr.get("firstName") == fu.get("firstName"), "First name should be updated."
        assert fr.get("lastName") == seed.get("lastName"), "Last name should remain unchanged."
        assert fr.get("email") == seed.get("email"), "Email should remain unchanged."
        assert fr.get("password") == seed.get("password"), "Password should remain unchanged."
        assert fr.get("phone") == seed.get("phone"), "Phone should remain unchanged."
        assert fr.get("userStatus") == seed.get("userStatus"), "User status should remain unchanged."
    except AssertionError as e:
        raise AssertionError(f"THEN MR14: {e}") from e

# ----




def _check_response_for_500(response, step_name: str) -> None:
    """Fail fast if the API returns a 500-level error."""
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"{step_name}: Server error {response.status_code} for URL {response.url} "
            f"with body: {response.text}"
        )


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's status and other details for MR15.")
def step_mr_MR15_seed_input(context):
    # Create a pet to ensure it exists, then retrieve it by ID (as per MR description)
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    # Create the pet: POST /pet
    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_for_500(response, "MR15 Given (create pet)")
    try:
        response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"MR15 Given (create pet) failed: {e}, body: {response.text}")

    # Safely parse JSON
    try:
        created_pet = response.json()
    except ValueError as e:
        raise AssertionError(f"MR15 Given (create pet) invalid JSON response: {e}, body: {response.text}")

    pet_id = created_pet.get("id")
    if pet_id is None:
        raise AssertionError(f"MR15 Given (create pet) response missing 'id': {created_pet}")

    # Retrieve the pet by ID: GET /pet/\{petId\}
    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_for_500(get_response, "MR15 Given (get pet by id)")
    try:
        get_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"MR15 Given (get pet by id) failed: {e}, body: {get_response.text}")

    try:
        pet_details = get_response.json()
    except ValueError as e:
        raise AssertionError(f"MR15 Given (get pet by id) invalid JSON response: {e}, body: {get_response.text}")

    # Store seed request/response safely
    context.seed_request = pet_data
    context.seed_response = pet_details
    if "status" not in context.seed_response:
        raise AssertionError(f"MR15 Given: 'status' not found in seed_response: {json.dumps(context.seed_response)}")


@when("a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by its identifier, yielding a follow-up output for MR15.")
def step_mr_MR15_followup_input(context):
    seed_response = getattr(context, "seed_response", None)
    if not isinstance(seed_response, dict):
        raise AssertionError("MR15 When: seed_response is not available or not a dict")

    pet_id = seed_response.get("id")
    if pet_id is None:
        raise AssertionError(f"MR15 When: seed_response missing 'id': {json.dumps(seed_response)}")

    # Upload an image for the pet: POST /pet/\{petId\}/uploadImage
    image_data = b"fake_image_data"  # Simulating image data
    upload_response = requests.post(
        f"{BASE_URL}/pet/{pet_id}/uploadImage",
        data=image_data,
        timeout=10,
    )
    _check_response_for_500(upload_response, "MR15 When (upload image)")
    try:
        upload_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"MR15 When (upload image) failed: {e}, body: {upload_response.text}")

    # Retrieve the pet again: GET /pet/\{petId\}
    followup_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_for_500(followup_response, "MR15 When (get pet again)")
    try:
        followup_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"MR15 When (get pet again) failed: {e}, body: {followup_response.text}")

    try:
        context.followup_response = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"MR15 When (get pet again) invalid JSON response: {e}, body: {followup_response.text}")

    if not isinstance(context.followup_response, dict):
        raise AssertionError(
            f"MR15 When: followup_response is not an object: {json.dumps(context.followup_response)}"
        )


@then("the follow-up output should have the same status value as the seed output, indicating that uploading an image does not change the pet status for MR15.")
def step_mr_MR15_followup_output(context):
    seed_response = getattr(context, "seed_response", None)
    followup_response = getattr(context, "followup_response", None)

    if not isinstance(seed_response, dict):
        raise AssertionError("MR15 Then: seed_response is not available or not a dict")
    if not isinstance(followup_response, dict):
        raise AssertionError("MR15 Then: followup_response is not available or not a dict")

    if "status" not in seed_response:
        raise AssertionError(f"MR15 Then: 'status' not found in seed_response: {json.dumps(seed_response)}")
    if "status" not in followup_response:
        raise AssertionError(f"MR15 Then: 'status' not found in followup_response: {json.dumps(followup_response)}")

    seed_status = seed_response["status"]
    followup_status = followup_response["status"]

    if seed_status != followup_status:
        raise AssertionError(
            f"MR15 Then: Expected status '{seed_status}' but got '{followup_status}'. "
            f"Seed: {json.dumps(seed_response)}, Follow-up: {json.dumps(followup_response)}"
        )

# ----




def _send_request(method, url, **kwargs):
    """
    Helper to send HTTP requests safely and enforce 500-checks.

    Raises:
        AssertionError if a 500 response is returned.
        requests.RequestException for network/HTTP protocol errors.
        ValueError/TypeError are avoided by defensive checks.
    """
    session = requests.Session()
    try:
        req = requests.Request(method=method, url=url, **kwargs)
        prepared = session.prepare_request(req)
        response = session.send(prepared, timeout=10)
    except requests.RequestException as e:
        # Network or protocol level error, surface as-is
        raise e

    # Explicit 500 check as required
    if response.status_code >= 500:
        raise AssertionError(
            f"Server error {response.status_code} for {method} {url}: {response.text}"
        )

    return response


@given('a seed input that retrieves the list of pets filtered by a specific status value, producing a seed output with the current list and its size for MR16.')
def step_mr_MR16_seed_input(context):
    status = 'available'  # Using 'available' as the specific status value

    url = f"{BASE_URL}/pet/findByStatus"
    params = {'status': status}

    response = _send_request('GET', url, params=params)

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in seed response for MR16: {e}") from e

    if not isinstance(data, list):
        raise AssertionError(
            f"Expected list from /pet/findByStatus but got {type(data).__name__}: {data}"
        )

    context.seed_status = status
    context.seed_response = data
    context.seed_size = len(data)


@when('a follow-up input is created by adding a new pet assigned the same status value and then retrieving the list of pets again with that same status filter, yielding a follow-up output for MR16.')
def step_mr_MR16_followup_input(context):
    status = getattr(context, 'seed_status', 'available')

    # Construct a valid Pet per OpenAPI schema
    new_pet = {
        "name": "New Pet MR16",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": status
    }

    # Add new pet: POST /pet
    add_pet_url = f"{BASE_URL}/pet"
    add_pet_response = _send_request('POST', add_pet_url, json=new_pet)

    try:
        created_pet = add_pet_response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in add-pet response for MR16: {e}") from e

    if not isinstance(created_pet, dict):
        raise AssertionError(
            f"Expected object from POST /pet but got {type(created_pet).__name__}: {created_pet}"
        )

    context.created_pet = created_pet

    # Retrieve list again: GET /pet/findByStatus with same status filter
    find_url = f"{BASE_URL}/pet/findByStatus"
    params = {'status': status}

    followup_response = _send_request('GET', find_url, params=params)

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in follow-up response for MR16: {e}") from e

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"Expected list from /pet/findByStatus in follow-up but got {type(followup_data).__name__}: {followup_data}"
        )

    context.followup_response = followup_data


@then('the follow-up output should have a list size that is exactly one more than the seed output list size for that status, assuming no other operations modify pets with that status for MR16.')
def step_mr_MR16_followup_output(context):
    if not hasattr(context, 'seed_size'):
        raise AssertionError("seed_size is not set in context for MR16.")
    if not hasattr(context, 'followup_response'):
        raise AssertionError("followup_response is not set in context for MR16.")

    followup_list = context.followup_response
    if not isinstance(followup_list, list):
        raise AssertionError(
            f"Expected followup_response to be a list but got {type(followup_list).__name__}: {followup_list}"
        )

    expected_size = context.seed_size + 1
    actual_size = len(followup_list)

    assert actual_size == expected_size, (
        f"MR16 violated: expected follow-up size {expected_size}, "
        f"but got {actual_size}"
    )
