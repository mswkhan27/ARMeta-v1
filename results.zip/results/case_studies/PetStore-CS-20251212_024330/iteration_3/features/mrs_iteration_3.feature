Feature: Iteration 3 MRs

  Scenario: Updating a user's details should reflect the changes when retrieved
    Given a seed input that retrieves a user by their username, producing a seed output with the user's current details for MR14.
    When a follow-up input is created by updating the user's details using the same username identifier and then retrieving the user again by that username, yielding a follow-up output for MR14.
    Then the follow-up output should reflect the updated details provided in the update request, while fields that were not modified should remain consistent with the seed output for MR14.

  Scenario: Uploading an image for a pet should not affect the pet's status
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's status and other details for MR15.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by its identifier, yielding a follow-up output for MR15.
    Then the follow-up output should have the same status value as the seed output, indicating that uploading an image does not change the pet status for MR15.

  Scenario: Adding a new pet with a specific status should increase the count of pets with that status
    Given a seed input that retrieves the list of pets filtered by a specific status value, producing a seed output with the current list and its size for MR16.
    When a follow-up input is created by adding a new pet assigned the same status value and then retrieving the list of pets again with that same status filter, yielding a follow-up output for MR16.
    Then the follow-up output should have a list size that is exactly one more than the seed output list size for that status, assuming no other operations modify pets with that status for MR16.
