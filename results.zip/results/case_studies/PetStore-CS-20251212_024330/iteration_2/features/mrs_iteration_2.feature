Feature: Iteration 2 MRs

  Scenario: Deleting a pet should make the pet inaccessible by its identifier
    Given a seed input that successfully retrieves a pet by its identifier, producing a seed output with the pet's details for MR10.
    When a follow-up input is created by successfully deleting the pet with the same identifier and then attempting to retrieve the pet again by the same identifier, yielding a follow-up output for MR10.
    Then the follow-up output should indicate that the pet is not found (for example, via an appropriate error status or message), differing from the seed output which contained the pet's details for MR10.

  Scenario: Deleting an order should make the order inaccessible by its identifier
    Given a seed input that successfully retrieves an existing order by its identifier, producing a seed output with the order's details for MR11.
    When a follow-up input is created by successfully deleting the order with the same identifier and then attempting to retrieve the order again by the same identifier, yielding a follow-up output for MR11.
    Then the follow-up output should indicate that the order is not found (for example, via an appropriate error status or message), differing from the seed output which contained the order's details for MR11.
