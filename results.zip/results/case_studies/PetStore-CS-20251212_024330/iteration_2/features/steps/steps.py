from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, operation_name: str) -> None:
    """Fail-fast helper to ensure no 500-level errors pass silently."""
    try:
        status_code = int(response.status_code)
    except (TypeError, ValueError):
        raise AssertionError(f"{operation_name}: Invalid status code type: {response.status_code!r}")

    if status_code >= 500:
        body_text: str
        try:
            body_text = response.text
        except Exception:
            body_text = "<unreadable body>"
        raise AssertionError(f"{operation_name}: Server error {status_code} - {body_text}")


@given("a seed input that successfully retrieves a pet by its identifier, producing a seed output with the pet's details for MR10.")
def _mr_MR10_seed_input(context):
    pet_id = 1  # Using pet_id 1 for the test as a sample valid identifier

    try:
        response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Error while retrieving pet in seed step: {e}")

    _check_500(response, "GET /pet/\\{petId\\} (seed retrieval)")

    if response.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve pet in seed step, expected 200 but got "
            f"{response.status_code} - {getattr(response, 'text', '')}"
        )

    context.seed_request = response

    try:
        seed_json = response.json()
    except ValueError as e:
        raise AssertionError(f"Seed response is not valid JSON: {e}")

    if not isinstance(seed_json, dict):
        raise AssertionError(f"Seed response JSON is not an object: {seed_json!r}")

    context.seed_response = seed_json


@when("a follow-up input is created by successfully deleting the pet with the same identifier and then attempting to retrieve the pet again by the same identifier, yielding a follow-up output for MR10.")
def _mr_MR10_followup_input(context):
    # Ensure seed step has run
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is missing; the Given step might not have been executed.")

    pet_id = context.seed_response.get("id", 1)

    try:
        delete_response = requests.delete(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Error while deleting pet in follow-up step: {e}")

    _check_500(delete_response, "DELETE /pet/\\{petId\\}")

    if delete_response.status_code != 200:
        raise AssertionError(
            f"Failed to delete pet in follow-up step, expected 200 but got "
            f"{delete_response.status_code} - {getattr(delete_response, 'text', '')}"
        )

    context.delete_response = delete_response

    try:
        followup_request = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"Error while retrieving pet after deletion in follow-up step: {e}")

    _check_500(followup_request, "GET /pet/\\{petId\\} (post-deletion retrieval)")

    context.followup_request = followup_request

    # The follow-up GET may return non-JSON for some implementations; handle safely.
    try:
        followup_json = followup_request.json()
    except ValueError:
        # Fallback: store raw text if JSON parsing fails
        followup_json = {"raw_body": getattr(followup_request, "text", "")}

    context.followup_response = followup_json


@then("the follow-up output should indicate that the pet is not found (for example, via an appropriate error status or message), differing from the seed output which contained the pet's details for MR10.")
def _mr_MR10_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is missing; the Given step might not have been executed.")
    if not hasattr(context, "followup_request") or not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response is missing; the When step might not have been executed.")

    # After deletion, spec for GET /pet/\{petId\} says '404: Pet not found' for missing pet
    status_code = context.followup_request.status_code
    if status_code != 404:
        raise AssertionError(
            f"Expected status code 404 for missing pet after deletion, got {status_code} - "
            f"{getattr(context.followup_request, 'text', '')}"
        )

    # Ensure that the follow-up output differs from the seed output as per MR definition
    try:
        seed_serialized = json.dumps(context.seed_response, sort_keys=True)
        followup_serialized = json.dumps(context.followup_response, sort_keys=True)
    except (TypeError, ValueError) as e:
        raise AssertionError(f"Error serializing responses for comparison: {e}")

    if seed_serialized == followup_serialized:
        raise AssertionError(
            "Follow-up output should differ from seed output, but they appear to be identical."
        )

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


def _safe_json(response):
    try:
        return response.json()
    except ValueError:
        # Non‑JSON response; return text safely
        return {"raw_body": response.text}


def _assert_no_500(response, step_name: str):
    if response is None:
        raise AssertionError(f"{step_name}: No response object available to check for 500 error.")
    if response.status_code >= 500:
        body = _safe_json(response)
        raise AssertionError(
            f"{step_name}: Server error {response.status_code} when calling {response.request.method} "
            f"{response.request.url}. Response body: {body}"
        )


@given(
    "a seed input that successfully retrieves an existing order by its identifier, producing a seed output with the order's details for MR11."
)
def _mr_MR11_seed_input(context):
    # According to OpenAPI: POST /store/order (placeOrder) then GET /store/\{orderId\} (getOrderById)
    order_data = {
        "petId": 198772,
        "quantity": 1,
        "status": "placed",
        "complete": False,
    }

    # Create an order
    create_response = requests.post(f"{BASE_URL}/store/order", json=order_data, timeout=10)
    _assert_no_500(create_response, "MR11 Given - create order")

    seed_body = _safe_json(create_response)
    if create_response.status_code != 200:
        raise AssertionError(f"MR11 Given - Failed to create order. Status: {create_response.status_code}, Body: {seed_body}")

    order_id = seed_body.get("id")
    if order_id is None:
        raise AssertionError(f"MR11 Given - Created order does not contain 'id'. Body: {seed_body}")

    # Retrieve the created order by its identifier to produce the seed output
    get_response = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    _assert_no_500(get_response, "MR11 Given - get order")

    get_body = _safe_json(get_response)
    if get_response.status_code != 200:
        raise AssertionError(
            f"MR11 Given - Failed to retrieve created order. Status: {get_response.status_code}, Body: {get_body}"
        )

    context.seed_order_id = order_id
    context.seed_get_response = get_response
    context.seed_get_body = get_body


@when(
    "a follow-up input is created by successfully deleting the order with the same identifier and then attempting to retrieve the order again by the same identifier, yielding a follow-up output for MR11."
)
def _mr_MR11_followup_input(context):
    if not hasattr(context, "seed_order_id"):
        raise AssertionError("MR11 When - seed_order_id is not available from Given step.")

    order_id = context.seed_order_id

    # Delete the order: DELETE /store/\{orderId\}
    delete_response = requests.delete(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    _assert_no_500(delete_response, "MR11 When - delete order")

    delete_body = _safe_json(delete_response)
    if delete_response.status_code != 200:
        raise AssertionError(
            f"MR11 When - Failed to delete order. Status: {delete_response.status_code}, Body: {delete_body}"
        )

    # Attempt to retrieve the deleted order again
    followup_response = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    _assert_no_500(followup_response, "MR11 When - get deleted order")

    followup_body = _safe_json(followup_response)

    context.followup_response = followup_response
    context.followup_body = followup_body


@then(
    "the follow-up output should indicate that the order is not found (for example, via an appropriate error status or message), differing from the seed output which contained the order's details for MR11."
)
def _mr_MR11_followup_output(context):
    if not hasattr(context, "seed_get_response") or not hasattr(context, "followup_response"):
        raise AssertionError("MR11 Then - Missing responses from previous steps.")

    seed_status = context.seed_get_response.status_code
    followup_status = context.followup_response.status_code

    # Seed must have been a successful retrieval (details present)
    if seed_status != 200:
        raise AssertionError(
            f"MR11 Then - Seed retrieval did not succeed as expected. Status: {seed_status}, Body: {context.seed_get_body}"
        )

    # Follow-up should indicate that the order is not found
    if followup_status != 404:
        raise AssertionError(
            f"MR11 Then - Expected 404 for deleted order, got {followup_status}. Body: {context.followup_body}"
        )

    # Ensure follow-up output differs from seed output
    if context.seed_get_body == context.followup_body:
        raise AssertionError(
            f"MR11 Then - Follow-up body should differ from seed body after deletion, but they are equal. "
            f"Seed: {context.seed_get_body}, Follow-up: {context.followup_body}"
        )
