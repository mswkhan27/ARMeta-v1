
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: Adding a new pet with a given status should increase the count of pets with that status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR1.
    When a follow-up input is created by adding a new pet whose status is set to 'available' and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR1.
    Then assuming no other operations modify pets with status 'available' between the two retrievals, the follow-up output should have a count of pets with status 'available' that is exactly one more than the seed output for MR1.

  Scenario: Updating a pet's status should be observable when retrieving that pet by its identifier
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current status and other details for MR2.
    When a follow-up input is created by updating that pet so that its status is changed to 'sold', and then retrieving the same pet again by its identifier, yielding a follow-up output for MR2.
    Then the follow-up output should show the pet with the same identifier as in the seed output and with its status updated to 'sold'; fields not changed by the update request should remain consistent with the seed output for MR2.

  Scenario: Deleting a pet with a given status should reduce the count of pets with that status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets having status 'available' for MR3, and selecting from that list a specific pet identifier to be deleted.
    When a follow-up input is created by deleting the selected pet and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR3.
    Then assuming no other operations modify pets with status 'available' between the two retrievals, the follow-up output should have a count of pets with status 'available' that is exactly one less than the seed output for MR3, and the deleted pet should no longer appear in the list.

  Scenario: Finding pets by multiple tags should include pets found by an individual tag
    Given a seed input that retrieves pets filtered by a single tag 'tag1', producing a seed output with a list of pets for MR4.
    When a follow-up input is created by retrieving pets filtered by multiple tags 'tag1, tag2' using the same filtering rules, yielding a follow-up output for MR4.
    Then every pet returned in the seed output for tag 'tag1' should also be present in the follow-up output obtained when searching with tags 'tag1, tag2', so that the follow-up output is a superset or equal set relative to the seed output for MR4.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: Deleting a user should make the user inaccessible by username
    Given a seed input that creates (if necessary) and then retrieves a user by their username, producing a seed output with the user's details for MR5.
    When a follow-up input is created by deleting the user with the same username and then attempting to retrieve the user again by the same username, yielding a follow-up output for MR5.
    Then the follow-up output should indicate that the user is not found (for example, via an appropriate error status or message), differing from the seed output which contained the user's details for MR5.

  Scenario: Uploading an image for a pet should not affect the pet's other details
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's details including name, status, and tags for MR7.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by its identifier, yielding a follow-up output for MR7.
    Then the follow-up output should have the same name, status, and tags as the seed output for MR7, indicating that these fields remain unchanged.

  Scenario: Logging in a user twice with the same credentials should yield consistent successful responses
    Given a seed input that attempts to log in a user with valid credentials, producing a seed output that indicates a successful login with a string response body for MR8.
    When a follow-up input is created by logging in the same user again with the same credentials, yielding a follow-up output for MR8.
    Then the follow-up output should also indicate a successful login with a string response body of the same type and structure as the seed output for MR8.

  Scenario: Retrieving inventory should reflect changes in pet status
    Given a seed input that retrieves the inventory of pets by status, producing a seed output with counts of pets for each status for MR9.
    When a follow-up input is created by changing the status of an existing pet from one valid status value to another valid status value and then retrieving the inventory again, yielding a follow-up output for MR9.
    Then the follow-up output should reflect updated counts for the affected statuses (for example, a decrease in the count for the original status and an increase in the count for the new status), differing from the seed output for MR9.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: Deleting a pet should make the pet inaccessible by its identifier
    Given a seed input that successfully retrieves a pet by its identifier, producing a seed output with the pet's details for MR10.
    When a follow-up input is created by successfully deleting the pet with the same identifier and then attempting to retrieve the pet again by the same identifier, yielding a follow-up output for MR10.
    Then the follow-up output should indicate that the pet is not found (for example, via an appropriate error status or message), differing from the seed output which contained the pet's details for MR10.

  Scenario: Deleting an order should make the order inaccessible by its identifier
    Given a seed input that successfully retrieves an existing order by its identifier, producing a seed output with the order's details for MR11.
    When a follow-up input is created by successfully deleting the order with the same identifier and then attempting to retrieve the order again by the same identifier, yielding a follow-up output for MR11.
    Then the follow-up output should indicate that the order is not found (for example, via an appropriate error status or message), differing from the seed output which contained the order's details for MR11.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: Updating a user's details should reflect the changes when retrieved
    Given a seed input that retrieves a user by their username, producing a seed output with the user's current details for MR14.
    When a follow-up input is created by updating the user's details using the same username identifier and then retrieving the user again by that username, yielding a follow-up output for MR14.
    Then the follow-up output should reflect the updated details provided in the update request, while fields that were not modified should remain consistent with the seed output for MR14.

  Scenario: Uploading an image for a pet should not affect the pet's status
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's status and other details for MR15.
    When a follow-up input is created by uploading an image for the same pet and then retrieving the pet again by its identifier, yielding a follow-up output for MR15.
    Then the follow-up output should have the same status value as the seed output, indicating that uploading an image does not change the pet status for MR15.

  Scenario: Adding a new pet with a specific status should increase the count of pets with that status
    Given a seed input that retrieves the list of pets filtered by a specific status value, producing a seed output with the current list and its size for MR16.
    When a follow-up input is created by adding a new pet assigned the same status value and then retrieving the list of pets again with that same status filter, yielding a follow-up output for MR16.
    Then the follow-up output should have a list size that is exactly one more than the seed output list size for that status, assuming no other operations modify pets with that status for MR16.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: Logging out a user should indicate successful session termination
    Given a seed input that logs in a user, producing a seed output indicating a successful login for MR17.
    When a follow-up input is created by logging out the user using the user logout operation, yielding a follow-up output for MR17.
    Then the follow-up output should indicate a successful logout according to the documented response (for example, a successful status code), differing from the seed output for MR17.

  Scenario: Creating a list of users should make them retrievable by username
    Given a seed input that attempts to retrieve a set of users by their usernames, producing a seed output with the current retrieval results for those usernames for MR18.
    When a follow-up input is created by using the operation that creates users from a list to add a new list of users, and then retrieving each of these users by their username, yielding a follow-up output for MR18.
    Then the follow-up output should include each newly created user when retrieved by username, with user details consistent with the creation request, and these results should differ from the seed output for MR18 for users that did not previously exist.

  Scenario: Updating a pet's details should reflect the changes when retrieved
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR19.
    When a follow-up input is created by using the pet update operation that accepts the pet identifier and new details, and then retrieving the pet again by its identifier, yielding a follow-up output for MR19.
    Then the follow-up output should reflect the updated details provided in the update request, while fields that were not modified should remain consistent with the seed output for MR19.


# --- From iteration_5\features\mrs_iteration_5.feature ---

Feature: Iteration 5 MRs

  Scenario: Adding a new pet with a specific status should make it retrievable when filtering by that status
    Given a seed input that retrieves the list of pets filtered by a specific status, producing a seed output with the current list and its size for MR20.
    When a follow-up input is created by adding a new pet with the same status and then retrieving the list of pets again with that status filter, yielding a follow-up output for MR20.
    Then the follow-up output should include the newly added pet with the specified status, and the list size should be exactly one more than the seed output list size for that status, assuming no other operations modify pets with that status for MR20.

  Scenario: Updating a pet's name should reflect the change when retrieved by its identifier
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current name and other details for MR21.
    When a follow-up input is created by updating the pet's name using the same identifier and then retrieving the pet again by its identifier, yielding a follow-up output for MR21.
    Then the follow-up output should reflect the updated name provided in the update request, while fields that were not modified should remain consistent with the seed output for MR21.

  Scenario: Adding a pet with a unique identifier should make it retrievable by that identifier
    Given a seed input that retrieves a pet by a unique identifier, producing a seed output indicating the pet is not found for MR22.
    When a follow-up input is created by adding a new pet with that unique identifier and then retrieving the pet again by the same identifier, yielding a follow-up output for MR22.
    Then the follow-up output should include the newly added pet with the specified identifier, differing from the seed output which indicated the pet was not found for MR22.

  Scenario: Changing a pet's status should be reflected in the inventory count
    Given a seed input that retrieves the inventory of pets by status, producing a seed output with counts of pets for each status for MR23.
    When a follow-up input is created by changing the status of an existing pet from 'available' to 'sold' and then retrieving the inventory again, yielding a follow-up output for MR23.
    Then the follow-up output should reflect a decrease in the count for 'available' status and an increase in the count for 'sold' status, differing from the seed output for MR23.

  Scenario: Adding a pet with a specific tag should make it retrievable by that tag
    Given a seed input that retrieves pets filtered by a specific tag, producing a seed output with the current list and its size for MR24.
    When a follow-up input is created by adding a new pet with the same tag and then retrieving the list of pets again with that tag filter, yielding a follow-up output for MR24.
    Then the follow-up output should include the newly added pet with the specified tag, and the list size should be exactly one more than the seed output list size for that tag, assuming no other operations modify pets with that tag for MR24.

