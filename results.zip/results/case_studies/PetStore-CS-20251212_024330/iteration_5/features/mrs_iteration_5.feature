Feature: Iteration 5 MRs

  Scenario: Adding a new pet with a specific status should make it retrievable when filtering by that status
    Given a seed input that retrieves the list of pets filtered by a specific status, producing a seed output with the current list and its size for MR20.
    When a follow-up input is created by adding a new pet with the same status and then retrieving the list of pets again with that status filter, yielding a follow-up output for MR20.
    Then the follow-up output should include the newly added pet with the specified status, and the list size should be exactly one more than the seed output list size for that status, assuming no other operations modify pets with that status for MR20.

  Scenario: Updating a pet's name should reflect the change when retrieved by its identifier
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current name and other details for MR21.
    When a follow-up input is created by updating the pet's name using the same identifier and then retrieving the pet again by its identifier, yielding a follow-up output for MR21.
    Then the follow-up output should reflect the updated name provided in the update request, while fields that were not modified should remain consistent with the seed output for MR21.

  Scenario: Adding a pet with a unique identifier should make it retrievable by that identifier
    Given a seed input that retrieves a pet by a unique identifier, producing a seed output indicating the pet is not found for MR22.
    When a follow-up input is created by adding a new pet with that unique identifier and then retrieving the pet again by the same identifier, yielding a follow-up output for MR22.
    Then the follow-up output should include the newly added pet with the specified identifier, differing from the seed output which indicated the pet was not found for MR22.

  Scenario: Changing a pet's status should be reflected in the inventory count
    Given a seed input that retrieves the inventory of pets by status, producing a seed output with counts of pets for each status for MR23.
    When a follow-up input is created by changing the status of an existing pet from 'available' to 'sold' and then retrieving the inventory again, yielding a follow-up output for MR23.
    Then the follow-up output should reflect a decrease in the count for 'available' status and an increase in the count for 'sold' status, differing from the seed output for MR23.

  Scenario: Adding a pet with a specific tag should make it retrievable by that tag
    Given a seed input that retrieves pets filtered by a specific tag, producing a seed output with the current list and its size for MR24.
    When a follow-up input is created by adding a new pet with the same tag and then retrieving the list of pets again with that tag filter, yielding a follow-up output for MR24.
    Then the follow-up output should include the newly added pet with the specified tag, and the list size should be exactly one more than the seed output list size for that tag, assuming no other operations modify pets with that tag for MR24.
