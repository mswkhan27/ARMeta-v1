from behave import given, when, then
import os
import json
import requests
from requests.exceptions import RequestException, Timeout

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, step_name: str) -> None:
    """Fail explicitly if a 500-level server error is returned."""
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"Server error {response.status_code} in {step_name}: {response.text}"
        )


@given('a seed input that retrieves the list of pets filtered by a specific status, producing a seed output with the current list and its size for MR20.')
def _mr_MR20_seed_input(context):
    status = 'available'
    context.seed_request = {'status': status}

    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByStatus",
            params=context.seed_request,
            timeout=10
        )
    except (RequestException, Timeout) as e:
        raise AssertionError(f"Request failed in Given step for MR20: {e}") from e

    _check_500(response, "Given step for MR20")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"Non-success status in Given step for MR20: {e}") from e

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in Given step for MR20: {e}") from e

    if not isinstance(data, list):
        raise AssertionError(
            f"Expected list of pets in Given step for MR20, got {type(data).__name__}"
        )

    context.seed_response = data
    context.seed_size = len(data)


@when('a follow-up input is created by adding a new pet with the same status and then retrieving the list of pets again with that status filter, yielding a follow-up output for MR20.')
def _mr_MR20_followup_input(context):
    # Ensure seed_size exists and is an int
    if not hasattr(context, "seed_size"):
        raise AssertionError("seed_size is not set in context before When step for MR20.")
    if not isinstance(context.seed_size, int):
        raise AssertionError(
            f"seed_size must be int in When step for MR20, got {type(context.seed_size).__name__}"
        )

    new_pet = {
        "name": "New Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    try:
        add_response = requests.post(
            f"{BASE_URL}/pet",
            json=new_pet,
            timeout=10
        )
    except (RequestException, Timeout) as e:
        raise AssertionError(f"Add-pet request failed in When step for MR20: {e}") from e

    _check_500(add_response, "When step for MR20 (add pet)")

    try:
        add_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"Non-success status when adding pet in MR20: {e}") from e

    try:
        created_pet = add_response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON for created pet in MR20: {e}") from e

    if not isinstance(created_pet, dict):
        raise AssertionError(
            f"Expected created pet as JSON object in MR20, got {type(created_pet).__name__}"
        )

    new_pet_id = created_pet.get("id")
    if new_pet_id is None:
        raise AssertionError("Created pet in MR20 has no 'id' field.")
    context.new_pet_id = new_pet_id

    try:
        followup_response = requests.get(
            f"{BASE_URL}/pet/findByStatus",
            params={'status': 'available'},
            timeout=10
        )
    except (RequestException, Timeout) as e:
        raise AssertionError(f"Follow-up request failed in When step for MR20: {e}") from e

    _check_500(followup_response, "When step for MR20 (follow-up list)")

    try:
        followup_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"Non-success status in follow-up list for MR20: {e}") from e

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in follow-up list for MR20: {e}") from e

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"Expected list of pets in follow-up output for MR20, got {type(followup_data).__name__}"
        )

    context.followup_response = followup_data


@then('the follow-up output should include the newly added pet with the specified status, and the list size should be exactly one more than the seed output list size for MR20.')
def _mr_MR20_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AssertionError("followup_response is not set in context before Then step for MR20.")
    if not hasattr(context, "seed_size"):
        raise AssertionError("seed_size is not set in context before Then step for MR20.")
    if not hasattr(context, "new_pet_id"):
        raise AssertionError("new_pet_id is not set in context before Then step for MR20.")

    if not isinstance(context.followup_response, list):
        raise AssertionError(
            f"followup_response must be a list in Then step for MR20, got {type(context.followup_response).__name__}"
        )
    if not isinstance(context.seed_size, int):
        raise AssertionError(
            f"seed_size must be int in Then step for MR20, got {type(context.seed_size).__name__}"
        )

    actual_size = len(context.followup_response)
    expected_size = context.seed_size + 1

    if actual_size != expected_size:
        raise AssertionError(
            f"List size did not increase by one in MR20. "
            f"Expected {expected_size}, got {actual_size}."
        )

    new_pet_id = context.new_pet_id
    try:
        new_pet_found = any(
            isinstance(pet, dict) and pet.get('id') == new_pet_id
            for pet in context.followup_response
        )
    except Exception as e:
        raise AssertionError(f"Error while searching for newly added pet in MR20: {e}") from e

    if not new_pet_found:
        raise AssertionError(
            f"Newly added pet with id={new_pet_id} is not found in the follow-up output for MR20."
        )

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")




@given(
    "a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current name and other details for MR21."
)
def _mr_MR21_seed_input(context):
    # Create a pet to ensure it exists before retrieving
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available",
    }

    create_response = None
    get_response = None

    try:
        # Add a new pet (POST /pet)
        create_response = requests.post(
            f"{BASE_URL}/pet",
            json=pet_data,
            timeout=10,
        )
        _check_500(create_response, "GIVEN step (create pet)")
        create_response.raise_for_status()

        seed_response = create_response.json() if create_response.content else {}
        pet_id = seed_response.get("id")
        if pet_id is None:
            raise AssertionError(
                "Response from POST /pet does not contain 'id' field."
            )

        # Retrieve the pet by ID (GET /pet/\{petId\})
        get_response = requests.get(
            f"{BASE_URL}/pet/{pet_id}",
            timeout=10,
        )
        _check_500(get_response, "GIVEN step (get pet by id)")
        get_response.raise_for_status()

        context.seed_request = pet_data
        context.seed_response = get_response.json() if get_response.content else {}
        context.pet_id = pet_id
    except Exception as e:
        # Include HTTP response details if available
        details = {
            "create_status": getattr(create_response, "status_code", None),
            "create_body": getattr(create_response, "text", None),
            "get_status": getattr(get_response, "status_code", None),
            "get_body": getattr(get_response, "text", None),
        }
        raise AssertionError(f"Error in GIVEN step for MR21: {e}. Details: {json.dumps(details)}")


@when(
    "a follow-up input is created by updating the pet's name using the same identifier and then retrieving the pet again by its identifier, yielding a follow-up output for MR21."
)
def _mr_MR21_followup_input(context):
    update_response = None
    followup_get_response = None

    try:
        if not hasattr(context, "pet_id"):
            raise AssertionError("pet_id is missing from context in WHEN step for MR21.")
        if not isinstance(context.pet_id, int):
            raise AssertionError("pet_id in context must be an integer.")

        pet_id = context.pet_id
        seed_response = getattr(context, "seed_response", {}) or {}

        updated_name = "doggie_updated"

        # Prepare update payload, preserving unmodified fields
        update_data = {
            "id": pet_id,
            "name": updated_name,
            "photoUrls": seed_response.get("photoUrls", ["url1", "url2"]),
            "status": seed_response.get("status", "available"),
        }

        # Include optional fields if present in seed_response, to keep them unchanged
        for optional_field in ("category", "tags"):
            if optional_field in seed_response:
                update_data[optional_field] = seed_response[optional_field]

        # Update the pet (PUT /pet)
        update_response = requests.put(
            f"{BASE_URL}/pet",
            json=update_data,
            timeout=10,
        )
        _check_500(update_response, "WHEN step (update pet)")
        update_response.raise_for_status()

        # Retrieve the pet again by ID (GET /pet/\{petId\})
        followup_get_response = requests.get(
            f"{BASE_URL}/pet/{pet_id}",
            timeout=10,
        )
        _check_500(followup_get_response, "WHEN step (get updated pet)")
        followup_get_response.raise_for_status()

        context.followup_request = update_data
        context.followup_response = (
            followup_get_response.json() if followup_get_response.content else {}
        )
    except Exception as e:
        details = {
            "update_status": getattr(update_response, "status_code", None),
            "update_body": getattr(update_response, "text", None),
            "get_status": getattr(followup_get_response, "status_code", None),
            "get_body": getattr(followup_get_response, "text", None),
        }
        raise AssertionError(f"Error in WHEN step for MR21: {e}. Details: {json.dumps(details)}")


@then(
    "the follow-up output should reflect the updated name provided in the update request, while fields that were not modified should remain consistent with the seed output for MR21."
)
def _mr_MR21_followup_output(context):
    try:
        followup = getattr(context, "followup_response", {}) or {}
        followup_req = getattr(context, "followup_request", {}) or {}
        seed = getattr(context, "seed_response", {}) or {}

        # Name should be updated
        assert (
            "name" in followup and "name" in followup_req
        ), "Missing 'name' in follow-up response or request."
        assert (
            followup["name"] == followup_req["name"]
        ), f"Name was not updated correctly: expected {followup_req['name']}, got {followup['name']}."

        # Unmodified fields should remain consistent
        if "photoUrls" in seed:
            assert (
                "photoUrls" in followup
            ), "Missing 'photoUrls' in follow-up response."
            assert (
                followup["photoUrls"] == seed["photoUrls"]
            ), f"Photo URLs should remain unchanged. Seed: {seed['photoUrls']}, Follow-up: {followup['photoUrls']}."

        if "status" in seed:
            assert "status" in followup, "Missing 'status' in follow-up response."
            assert (
                followup["status"] == seed["status"]
            ), f"Status should remain unchanged. Seed: {seed['status']}, Follow-up: {followup['status']}."

        # Optional fields like category and tags, if present and not modified, should remain consistent
        for field in ("category", "tags"):
            if field in seed:
                assert field in followup, f"Missing '{field}' in follow-up response."
                assert (
                    followup[field] == seed[field]
                ), f"Field '{field}' should remain unchanged."
    except AssertionError as e:
        raise AssertionError(f"Assertion error in THEN step for MR21: {e}")
    except Exception as e:
        raise AssertionError(f"Error in THEN step for MR21: {e}")

# ----




def _check_response_no_500(response, step_name: str) -> None:
    """Fail the test explicitly if the API returns a 5xx error."""
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"{step_name}: Server error {response.status_code} for URL {response.url} "
            f"with body: {response.text}"
        )


@given('a seed input that retrieves a pet by a unique identifier, producing a seed output indicating the pet is not found for MR22.')
def _mr_MR22_seed_input(context):
    pet_id = 99999  # Assuming a non-existing pet ID for the seed
    context.seed_request = {
        "petId": pet_id
    }

    response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(response, "MR22 Given")
    # The API returns 404 when the pet is not found according to the spec.
    assert response.status_code == 404, (
        f"Expected 404 (pet not found) for seed input, got {response.status_code}"
    )

    # Response body for 404 may not be JSON; parse safely.
    try:
        context.seed_response = response.json()
    except ValueError:
        context.seed_response = {"raw_body": response.text}


@when('a follow-up input is created by adding a new pet with that unique identifier and then retrieving the pet again by the same identifier, yielding a follow-up output for MR22.')
def _mr_MR22_followup_input(context):
    pet_id = context.seed_request.get("petId")
    # Ensure pet_id is an integer as required by the OpenAPI spec.
    try:
        pet_id_int = int(pet_id)
    except (TypeError, ValueError):
        raise AssertionError(f"MR22 When: petId is not a valid integer: {pet_id!r}")

    pet_data = {
        "id": pet_id_int,
        "name": "Fluffy",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    # Add the new pet using POST /pet (addPet)
    add_response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_no_500(add_response, "MR22 When (add pet)")
    assert add_response.status_code == 200, (
        f"MR22 When: Failed to add pet, expected 200 got {add_response.status_code}, "
        f"body: {add_response.text}"
    )

    # Retrieve the pet again using GET /pet/\{petId\} (getPetById)
    followup_response = requests.get(f"{BASE_URL}/pet/{pet_id_int}", timeout=10)
    _check_response_no_500(followup_response, "MR22 When (get pet)")
    assert followup_response.status_code == 200, (
        f"MR22 When: Failed to retrieve the added pet, expected 200 got "
        f"{followup_response.status_code}, body: {followup_response.text}"
    )

    try:
        context.followup_response = followup_response.json()
    except ValueError:
        raise AssertionError(
            f"MR22 When: Follow-up response is not valid JSON: {followup_response.text}"
        )


@then('the follow-up output should include the newly added pet with the specified identifier, differing from the seed output which indicated the pet was not found for MR22.')
def _mr_MR22_followup_output(context):
    followup = context.followup_response
    pet_id = context.seed_request.get("petId")

    if not isinstance(followup, dict):
        raise AssertionError(f"MR22 Then: Follow-up response is not an object: {followup!r}")

    if "id" not in followup:
        raise AssertionError("MR22 Then: Follow-up response does not contain 'id' field")

    assert followup["id"] == int(pet_id), (
        f"MR22 Then: Pet ID does not match, expected {pet_id}, got {followup['id']}"
    )
    assert followup.get("name") == "Fluffy", (
        f"MR22 Then: Pet name does not match, expected 'Fluffy', got {followup.get('name')!r}"
    )
    assert followup.get("status") == "available", (
        f"MR22 Then: Pet status does not match, expected 'available', got {followup.get('status')!r}"
    )
    # Seed was a not-found response (404), follow-up is a successful retrieval (200)
    assert context.seed_response != context.followup_response, (
        "MR22 Then: Seed and follow-up responses should differ"
    )

# ----




def _check_response_for_server_error(response, step_name: str):
    """Raise an AssertionError if a 5xx error is returned."""
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"Server error in {step_name}: {response.status_code} - {response.text}"
        )


def _safe_get_inventory(step_name: str):
    response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    _check_response_for_server_error(response, step_name)
    response.raise_for_status()
    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in inventory response during {step_name}: {e}")
    if not isinstance(data, dict):
        raise AssertionError(f"Inventory response during {step_name} is not an object: {data}")
    return data


def _safe_add_pet(step_name: str, pet_data: dict):
    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_for_server_error(response, step_name)
    response.raise_for_status()
    try:
        pet = response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON when adding pet during {step_name}: {e}")
    if not isinstance(pet, dict):
        raise AssertionError(f"Add-pet response during {step_name} is not an object: {pet}")
    pet_id = pet.get("id")
    if pet_id is None:
        raise AssertionError(f"No 'id' field returned for created pet during {step_name}: {pet}")
    return pet_id


def _safe_update_pet_status(step_name: str, pet_id, status: str):
    # Ensure pet_id is an int to avoid /pet/{petId} path issues
    try:
        pet_id_int = int(pet_id)
    except (TypeError, ValueError):
        raise AssertionError(f"pet_id is not a valid integer during {step_name}: {pet_id}")

    # According to OpenAPI, /pet/\{petId\} POST updates via form/query params
    params = {"status": status}
    response = requests.post(
        f"{BASE_URL}/pet/{pet_id_int}",
        params=params,
        timeout=10,
    )
    _check_response_for_server_error(response, step_name)
    response.raise_for_status()
    # Response body is a Pet; we don't strictly need it here but validate JSON if present
    if response.content:
        try:
            response.json()
        except ValueError:
            # Non‑JSON body is allowed by spec, so don't fail here
            pass


@given(
    "a seed input that retrieves the inventory of pets by status, producing a seed output with counts of pets for each status for MR23."
)
def step_mr_MR23_seed_input(context):
    inventory = _safe_get_inventory("GIVEN step for MR23")
    context.seed_response = inventory
    context.seed_request = None  # No request payload for inventory


@when(
    "a follow-up input is created by changing the status of an existing pet from 'available' to 'sold' and then retrieving the inventory again, yielding a follow-up output for MR23."
)
def step_mr_MR23_followup_input(context):
    # First, create a pet in 'available' status
    pet_data = {
        "name": "TestPet_MR23",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }
    pet_id = _safe_add_pet("WHEN step (add pet) for MR23", pet_data)

    # Change status to 'sold' using /pet/\{petId\} POST with query parameter 'status'
    _safe_update_pet_status("WHEN step (update status) for MR23", pet_id, "sold")

    # Retrieve the inventory again
    inventory = _safe_get_inventory("WHEN step (get follow-up inventory) for MR23")
    context.followup_response = inventory
    context.followup_request = None


@then(
    "the follow-up output should reflect a decrease in the count for 'available' status and an increase in the count for 'sold' status, differing from the seed output for MR23."
)
def step_mr_MR23_followup_output(context):
    if not hasattr(context, "seed_response") or not hasattr(context, "followup_response"):
        raise AssertionError("Seed or follow-up inventory is missing in context for MR23.")

    seed = context.seed_response or {}
    followup = context.followup_response or {}

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise AssertionError(
            f"Inventory responses must be JSON objects. "
            f"Seed type: {type(seed)}, Follow-up type: {type(followup)}"
        )

    seed_available_count = seed.get("available", 0)
    seed_sold_count = seed.get("sold", 0)

    followup_available_count = followup.get("available", 0)
    followup_sold_count = followup.get("sold", 0)

    for label, value in [
        ("seed_available_count", seed_available_count),
        ("seed_sold_count", seed_sold_count),
        ("followup_available_count", followup_available_count),
        ("followup_sold_count", followup_sold_count),
    ]:
        if not isinstance(value, int):
            raise AssertionError(f"{label} is not an integer: {value!r}")

    if followup_available_count != seed_available_count - 1:
        raise AssertionError(
            f"Expected 'available' count to decrease by 1: "
            f"seed={seed_available_count}, follow-up={followup_available_count}"
        )

    if followup_sold_count != seed_sold_count + 1:
        raise AssertionError(
            f"Expected 'sold' count to increase by 1: "
            f"seed={seed_sold_count}, follow-up={followup_sold_count}"
        )

# ----






@given('a seed input that retrieves pets filtered by a specific tag, producing a seed output with the current list and its size for MR24.')
def _mr_MR24_seed_input(context):
    # Define the tag to filter by
    tag = "dog"

    # Retrieve pets by tag using /pet/findByTags as per OpenAPI summary "Finds Pets by tags."
    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params={"tags": tag},
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"Given step MR24: HTTP request failed: {e}")

    _check_response_no_500(response, "Given step MR24")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"Given step MR24: Non-success status code {response.status_code}: {e}")

    try:
        seed_list = response.json()
        if not isinstance(seed_list, list):
            raise AssertionError(
                f"Given step MR24: Expected list response from /pet/findByTags, got {type(seed_list)}"
            )
    except (ValueError, TypeError) as e:
        raise AssertionError(f"Given step MR24: Failed to parse JSON response: {e}")

    context.seed_response = seed_list
    context.seed_request = {"tags": tag}
    context.seed_size = len(seed_list)


@when('a follow-up input is created by adding a new pet with the same tag and then retrieving the list of pets again with that tag filter, yielding a follow-up output for MR24.')
def _mr_MR24_followup_input(context):
    # Ensure seed_size exists to avoid AttributeError
    if not hasattr(context, "seed_size"):
        raise AssertionError("When step MR24: seed_size not found on context; Given step may have failed or not run.")

    # Create a new pet with the same tag, using /pet (POST) "Add a new pet to the store."
    new_pet = {
        "name": "Buddy",
        "photoUrls": ["http://example.com/photo.jpg"],
        "tags": [{"id": 1, "name": "dog"}],
        "status": "available",
    }

    try:
        add_response = requests.post(
            f"{BASE_URL}/pet",
            json=new_pet,
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"When step MR24: HTTP request to add pet failed: {e}")

    _check_response_no_500(add_response, "When step MR24 (add pet)")

    try:
        add_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"When step MR24: Failed to add pet, status {add_response.status_code}: {e}, body: {add_response.text}"
        )

    # Optionally parse added pet safely to confirm structure (no assumption of 200 body shape)
    try:
        _ = add_response.json()
    except ValueError:
        # If body is not JSON, don't fail here as spec only requires 200 with Pet, but be robust
        pass

    # Retrieve pets by tag again using the same filter API /pet/findByTags
    try:
        followup_response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params={"tags": "dog"},
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"When step MR24: HTTP request to retrieve pets by tag failed: {e}")

    _check_response_no_500(followup_response, "When step MR24 (findByTags)")

    try:
        followup_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"When step MR24: Failed to retrieve pets by tag, status {followup_response.status_code}: {e}"
        )

    try:
        followup_list = followup_response.json()
        if not isinstance(followup_list, list):
            raise AssertionError(
                f"When step MR24: Expected list response from /pet/findByTags, got {type(followup_list)}"
            )
    except (ValueError, TypeError) as e:
        raise AssertionError(f"When step MR24: Failed to parse JSON response: {e}")

    context.followup_response = followup_list
    context.followup_request = {"tags": "dog"}


@then('the follow-up output should include the newly added pet with the specified tag, and the list size should be exactly one more than the seed output list size for that tag, assuming no other operations modify pets with that tag for MR24.')
def _mr_MR24_followup_output(context):
    # Ensure required attributes exist
    for attr in ("seed_size", "followup_response"):
        if not hasattr(context, attr):
            raise AssertionError(
                f"Then step MR24: context is missing required attribute '{attr}'; previous steps may have failed."
            )

    followup_list = context.followup_response
    if not isinstance(followup_list, list):
        raise AssertionError(
            f"Then step MR24: followup_response is not a list, got {type(followup_list)}"
        )

    # Safely extract names (handle missing or non-dict entries defensively)
    new_pet_names = []
    for pet in followup_list:
        if isinstance(pet, dict):
            name = pet.get("name")
            if isinstance(name, str):
                new_pet_names.append(name)

    if "Buddy" not in new_pet_names:
        raise AssertionError("Then step MR24: Newly added pet 'Buddy' is not in the follow-up output.")

    expected_size = context.seed_size + 1
    actual_size = len(followup_list)
    if actual_size != expected_size:
        raise AssertionError(
            f"Then step MR24: Follow-up output size {actual_size} is not exactly one more than seed size {context.seed_size}."
        )
