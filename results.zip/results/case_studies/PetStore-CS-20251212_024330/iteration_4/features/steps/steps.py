from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_response_no_500(response, step_name: str) -> None:
    """Utility to ensure no 500 error is silently ignored."""
    if response is None:
        raise AssertionError(f"{step_name}: Response is None")
    status = getattr(response, "status_code", None)
    if status is None:
        raise AssertionError(f"{step_name}: Response has no status_code")
    if 500 <= status <= 599:
        raise AssertionError(
            f"{step_name}: Server error {status} received from {response.request.method} {response.request.url}"
        )


@given('a seed input that logs in a user, producing a seed output indicating a successful login for MR17.')
def step_mr_MR17_seed_login(context):
    # Create a user according to POST /user schema and then log in with GET /user/login
    user_data = {
        "id": 12345,
        "username": "testuser_mr17",
        "firstName": "Test",
        "lastName": "User",
        "email": "testuser_mr17@example.com",
        "password": "testpassword",
        "phone": "1234567890",
        "userStatus": 1,
    }

    # Create user
    create_resp = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    _check_response_no_500(create_resp, "MR17 Given - create user")
    if create_resp.status_code != 200:
        raise AssertionError(
            f"MR17 Given - Failed to create user, status={create_resp.status_code}, body={create_resp.text}"
        )

    # Login user (returns a string body per spec)
    login_params = {
        "username": user_data["username"],
        "password": user_data["password"],
    }
    login_resp = requests.get(f"{BASE_URL}/user/login", params=login_params, timeout=10)
    _check_response_no_500(login_resp, "MR17 Given - login user")
    if login_resp.status_code != 200:
        raise AssertionError(
            f"MR17 Given - Login failed, status={login_resp.status_code}, body={login_resp.text}"
        )

    # Store seed output safely as text
    context.seed_login_status = login_resp.status_code
    context.seed_response_body = login_resp.text


@when('a follow-up input is created by logging out the user using the user logout operation, yielding a follow-up output for MR17.')
def step_mr_MR17_logout(context):
    # Logout via GET /user/logout
    logout_resp = requests.get(f"{BASE_URL}/user/logout", timeout=10)
    _check_response_no_500(logout_resp, "MR17 When - logout user")

    # According to spec, 200 indicates successful operation; body is not specified
    context.followup_logout_status = logout_resp.status_code
    context.followup_response_body = logout_resp.text


@then('the follow-up output should indicate a successful logout according to the documented response (for example, a successful status code), differing from the seed output for MR17.')
def step_mr_MR17_assert_logout(context):
    # Ensure we have stored statuses safely
    if not hasattr(context, "seed_login_status"):
        raise AssertionError("MR17 Then - seed_login_status not set in context")
    if not hasattr(context, "followup_logout_status"):
        raise AssertionError("MR17 Then - followup_logout_status not set in context")

    # Successful logout: 200 per /user/logout spec
    if context.followup_logout_status != 200:
        raise AssertionError(
            f"MR17 Then - Expected logout status 200, got {context.followup_logout_status}, "
            f"body={getattr(context, 'followup_response_body', '')}"
        )

    # Follow-up output should differ from seed output
    # At minimum, the body should differ; login returns token/string, logout usually returns empty/other text.
    seed_body = getattr(context, "seed_response_body", None)
    follow_body = getattr(context, "followup_response_body", None)

    if seed_body is None or follow_body is None:
        raise AssertionError(
            "MR17 Then - Missing response bodies to compare for difference between seed and follow-up outputs"
        )

    if seed_body == follow_body and context.seed_login_status == context.followup_logout_status:
        raise AssertionError(
            "MR17 Then - Follow-up output should differ from seed output (both status and body are identical)"
        )

# ----




def _check_500(response, step_name: str):
    """Fail fast on HTTP 5xx responses to surface server errors in Behave reports."""
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"{step_name}: Server error {response.status_code} for URL {response.url} "
            f"with body: {response.text}"
        )


@given('a seed input that attempts to retrieve a set of users by their usernames, producing a seed output with the current retrieval results for those usernames for MR18.')
def step_mr_MR18_seed_input(context):
    # define a deterministic list of usernames we will probe as "seed" users
    usernames = ["user_mr18_seed_1", "user_mr18_seed_2"]
    context.seed_usernames = usernames

    context.seed_response = []
    for username in usernames:
        # GET /user/\{username\} – may be 200/400/404; only 5xx should hard‑fail early
        resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
        _check_500(resp, "Given MR18")
        # For 2xx, record the user payload; for others, record None
        if resp.ok:
            try:
                context.seed_response.append(resp.json())
            except ValueError:
                # Non‑JSON successful response – record raw text to avoid TypeError later
                context.seed_response.append(resp.text)
        else:
            context.seed_response.append(None)

    # Store the raw seed "request" conceptually as the list of usernames
    context.seed_request = usernames


@when('a follow-up input is created by using the operation that creates users from a list to add a new list of users, and then retrieving each of these users by their username, yielding a follow-up output for MR18.')
def step_mr_MR18_followup_input(context):
    # Create a new list of users using the bulk creation endpoint:
    # POST /user/createWithList – "Creates list of users with given input array."
    new_users_to_create = [
        {
            "id": 1001,
            "username": "user_mr18_new_1",
            "firstName": "Alice",
            "lastName": "Smith",
            "email": "alice@example.com",
            "password": "password",
            "phone": "1231231234",
            "userStatus": 1,
        },
        {
            "id": 1002,
            "username": "user_mr18_new_2",
            "firstName": "Bob",
            "lastName": "Brown",
            "email": "bob@example.com",
            "password": "password",
            "phone": "3213214321",
            "userStatus": 1,
        },
    ]
    context.followup_request = new_users_to_create

    # Call the correct bulk‑creation operation: POST /user/createWithList
    resp = requests.post(
        f"{BASE_URL}/user/createWithList",
        json=new_users_to_create,
        timeout=10,
    )
    _check_500(resp, "When MR18")
    # According to spec, default error is "Unexpected error"; treat non‑2xx as failure
    if not resp.ok:
        raise AssertionError(
            f"When MR18: Failed to create users list, "
            f"status={resp.status_code}, body={resp.text}"
        )

    # Retrieve each newly created user by username using GET /user/\{username\}
    followup_responses = []
    for user in new_users_to_create:
        username = user.get("username")
        if not isinstance(username, str):
            raise AssertionError("When MR18: Each user must have a string 'username' field.")

        user_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
        _check_500(user_resp, "When MR18 – retrieve user")
        if not user_resp.ok:
            raise AssertionError(
                f"When MR18: Failed to retrieve created user '{username}', "
                f"status={user_resp.status_code}, body={user_resp.text}"
            )
        try:
            followup_responses.append(user_resp.json())
        except ValueError:
            raise AssertionError(
                f"When MR18: Expected JSON body when retrieving user '{username}', "
                f"got: {user_resp.text}"
            )

    context.followup_response = followup_responses


@then('the follow-up output should include each newly created user when retrieved by username, with user details consistent with the creation request, and these results should differ from the seed output for MR18 for users that did not previously exist.')
def step_mr_MR18_followup_output(context):
    # Safety checks to avoid TypeError / AttributeError
    if not hasattr(context, "followup_request") or not hasattr(context, "followup_response"):
        raise AssertionError("Then MR18: followup_request or followup_response missing from context.")
    if not isinstance(context.followup_request, list) or not isinstance(context.followup_response, list):
        raise AssertionError("Then MR18: followup_request and followup_response must be lists.")

    # Map follow‑up responses by username for easier comparison
    followup_by_username = {}
    for u in context.followup_response:
        if not isinstance(u, dict):
            raise AssertionError(f"Then MR18: Each follow-up response must be a JSON object, got: {type(u)}")
        username = u.get("username")
        if not isinstance(username, str):
            raise AssertionError("Then MR18: Each follow-up user must contain a string 'username' field.")
        followup_by_username[username] = u

    # Check that each newly created user is present in follow‑up output
    for created_user in context.followup_request:
        if not isinstance(created_user, dict):
            raise AssertionError("Then MR18: Each created user in followup_request must be a dict.")
        username = created_user.get("username")
        if not isinstance(username, str):
            raise AssertionError("Then MR18: Each created user must have a string 'username' field.")

        retrieved_user = followup_by_username.get(username)
        assert retrieved_user is not None, (
            f"Then MR18: Newly created user '{username}' not found in follow-up output."
        )

        # Verify core fields are consistent between creation request and retrieved user.
        # Only compare keys that exist in both dicts to avoid KeyError / TypeError.
        for key in ["id", "username", "firstName", "lastName", "email", "phone", "userStatus"]:
            if key in created_user and key in retrieved_user:
                assert created_user[key] == retrieved_user[key], (
                    f"Then MR18: Mismatch for field '{key}' of user '{username}': "
                    f"created={created_user[key]!r}, retrieved={retrieved_user[key]!r}"
                )

    # Ensure the follow‑up results differ from the seed results for users that did not previously exist
    seed_usernames = set()
    if hasattr(context, "seed_usernames") and isinstance(context.seed_usernames, list):
        seed_usernames = set(
            uname for uname in context.seed_usernames if isinstance(uname, str)
        )

    for created_user in context.followup_request:
        username = created_user.get("username")
        if isinstance(username, str) and username not in seed_usernames:
            # This user did not previously exist in the seed input; ensure there is
            # no identical user object in the seed responses.
            for seed_entry in getattr(context, "seed_response", []):
                # seed_entry may be None or non‑dict; skip safely
                if isinstance(seed_entry, dict) and seed_entry.get("username") == username:
                    # If the seed also had this username, the objects should differ
                    # from the follow-up retrieved version.
                    followup_user = followup_by_username.get(username)
                    if isinstance(followup_user, dict):
                        assert seed_entry != followup_user, (
                            f"Then MR18: User '{username}' appears unchanged between seed and follow-up, "
                            f"but should have been newly created in follow-up."
                        )

# ----




def _check_server_error(response, step_name: str):
    """Fail fast on 5xx responses to avoid silent server errors."""
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"{step_name}: Server returned {response.status_code} for {response.request.method} "
            f"{response.request.url} with body: {response.text}"
        )


@given("a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR19.")
def step_mr_MR19_seed_input(context):
    # Create a pet to ensure it exists (POST /pet - addPet)
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_server_error(response, "MR19 Given (create pet)")
    # raise_for_status will not raise on 5xx because we already guarded above
    response.raise_for_status()

    try:
        seed_created = response.json()
    except ValueError as e:
        raise AssertionError(f"MR19 Given (create pet): Failed to decode JSON response: {e}")

    if not isinstance(seed_created, dict):
        raise AssertionError(f"MR19 Given (create pet): Expected JSON object, got {type(seed_created)}")

    pet_id = seed_created.get("id")
    if pet_id is None:
        raise AssertionError("MR19 Given (create pet): Response JSON does not contain 'id' field")

    context.seed_request = pet_data

    # Retrieve the pet by its ID (GET /pet/\{petId\} - getPetById)
    response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_server_error(response, "MR19 Given (get pet by id)")
    response.raise_for_status()

    try:
        seed_fetched = response.json()
    except ValueError as e:
        raise AssertionError(f"MR19 Given (get pet by id): Failed to decode JSON response: {e}")

    if not isinstance(seed_fetched, dict):
        raise AssertionError(f"MR19 Given (get pet by id): Expected JSON object, got {type(seed_fetched)}")

    # store full seed output for comparison
    context.seed_response = seed_fetched
    context.pet_id = pet_id


@when("a follow-up input is created by using the pet update operation that accepts the pet identifier and new details, and then retrieving the pet again by its identifier, yielding a follow-up output for MR19.")
def step_mr_MR19_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AssertionError("MR19 When: 'pet_id' not found in context from Given step")

    pet_id = context.pet_id

    # Prepare updated pet data; keep fields that should remain unchanged where needed
    updated_data = {
        "id": pet_id,
        "name": "doggie_updated",
        "photoUrls": ["url1_updated", "url2_updated"],
        # keep same status as seed (unmodified field in MR)
        "status": context.seed_response.get("status", "available")
    }

    # Update the pet using PUT /pet - updatePet
    response = requests.put(f"{BASE_URL}/pet", json=updated_data, timeout=10)
    _check_server_error(response, "MR19 When (update pet)")
    response.raise_for_status()

    # Retrieve the pet again to get the follow-up output (GET /pet/\{petId\})
    response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_server_error(response, "MR19 When (get updated pet by id)")
    response.raise_for_status()

    try:
        followup = response.json()
    except ValueError as e:
        raise AssertionError(f"MR19 When (get updated pet by id): Failed to decode JSON response: {e}")

    if not isinstance(followup, dict):
        raise AssertionError(f"MR19 When (get updated pet by id): Expected JSON object, got {type(followup)}")

    context.followup_response = followup
    context.updated_request = updated_data


@then("the follow-up output should reflect the updated details provided in the update request, while fields that were not modified should remain consistent with the seed output for MR19.")
def step_mr_MR19_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AssertionError("MR19 Then: 'followup_response' not found in context")
    if not hasattr(context, "seed_response"):
        raise AssertionError("MR19 Then: 'seed_response' not found in context")
    if not hasattr(context, "updated_request"):
        raise AssertionError("MR19 Then: 'updated_request' not found in context")

    followup = context.followup_response
    seed = context.seed_response
    updated = context.updated_request

    # Validate updated fields
    if followup.get("name") != updated.get("name"):
        raise AssertionError(
            f"MR19 Then: Name was not updated correctly. "
            f"Expected '{updated.get('name')}', got '{followup.get('name')}'"
        )

    if followup.get("photoUrls") != updated.get("photoUrls"):
        raise AssertionError(
            f"MR19 Then: photoUrls were not updated correctly. "
            f"Expected {updated.get('photoUrls')}, got {followup.get('photoUrls')}"
        )

    # Validate unmodified fields remain the same (e.g., status)
    if "status" in seed:
        if followup.get("status") != seed.get("status"):
            raise AssertionError(
                f"MR19 Then: Status should remain unchanged. "
                f"Seed status '{seed.get('status')}', follow-up status '{followup.get('status')}'"
            )

    # Optionally verify ID is unchanged
    if "id" in seed:
        if followup.get("id") != seed.get("id"):
            raise AssertionError(
                f"MR19 Then: Pet ID changed after update. "
                f"Seed id '{seed.get('id')}', follow-up id '{followup.get('id')}'"
            )
