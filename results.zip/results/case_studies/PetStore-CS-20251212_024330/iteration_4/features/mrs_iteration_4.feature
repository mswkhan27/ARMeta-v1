Feature: Iteration 4 MRs

  Scenario: Logging out a user should indicate successful session termination
    Given a seed input that logs in a user, producing a seed output indicating a successful login for MR17.
    When a follow-up input is created by logging out the user using the user logout operation, yielding a follow-up output for MR17.
    Then the follow-up output should indicate a successful logout according to the documented response (for example, a successful status code), differing from the seed output for MR17.

  Scenario: Creating a list of users should make them retrievable by username
    Given a seed input that attempts to retrieve a set of users by their usernames, producing a seed output with the current retrieval results for those usernames for MR18.
    When a follow-up input is created by using the operation that creates users from a list to add a new list of users, and then retrieving each of these users by their username, yielding a follow-up output for MR18.
    Then the follow-up output should include each newly created user when retrieved by username, with user details consistent with the creation request, and these results should differ from the seed output for MR18 for users that did not previously exist.

  Scenario: Updating a pet's details should reflect the changes when retrieved
    Given a seed input that retrieves a pet by its identifier, producing a seed output with the pet's current details for MR19.
    When a follow-up input is created by using the pet update operation that accepts the pet identifier and new details, and then retrieving the pet again by its identifier, yielding a follow-up output for MR19.
    Then the follow-up output should reflect the updated details provided in the update request, while fields that were not modified should remain consistent with the seed output for MR19.
