from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _safe_json(response):
    try:
        return response.json()
    except ValueError:
        raise AssertionError(
            f"Response from {response.request.method} {response.request.url} "
            f"is not valid JSON. Status code: {response.status_code}, Body: {response.text}"
        )


def _check_response(response, step_label):
    # Explicit 500-check as required
    if response.status_code >= 500:
        raise AssertionError(
            f"{step_label}: Server error {response.status_code} from "
            f"{response.request.method} {response.request.url} - Body: {response.text}"
        )
    try:
        response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(
            f"{step_label}: HTTP error for {response.request.method} {response.request.url}: "
            f"{e} - Body: {response.text}"
        ) from e


@given(
    "a seed input that retrieves the list of pets filtered by status 'available', "
    "producing a seed output with a count of pets in status 'available' for MR1."
)
def _mr_MR1_seed_input(context):
    # Retrieve the list of pets with status 'available'
    url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}
    response = requests.get(url, params=params, timeout=10)
    _check_response(response, "GIVEN MR1")

    data = _safe_json(response)

    if not isinstance(data, list):
        raise AssertionError(
            f"GIVEN MR1: Expected response to be a list of pets, "
            f"got {type(data).__name__}: {json.dumps(data, ensure_ascii=False)}"
        )

    context.seed_response = data
    context.seed_request = {'status': 'available'}
    context.seed_count = len(data)


@when(
    "a follow-up input is created by adding a new pet whose status is set to 'available', "
    "and the list of pets is retrieved again using status 'available', yielding a follow-up output for MR1."
)
def _mr_MR1_followup_input(context):
    # Create a new pet with status 'available'
    new_pet = {
        "name": "New Available Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    add_url = f"{BASE_URL}/pet"
    add_response = requests.post(add_url, json=new_pet, timeout=10)
    _check_response(add_response, "WHEN MR1 - add pet")

    created_pet = _safe_json(add_response)
    if not isinstance(created_pet, dict):
        raise AssertionError(
            f"WHEN MR1 - add pet: Expected created pet to be an object, "
            f"got {type(created_pet).__name__}: {json.dumps(created_pet, ensure_ascii=False)}"
        )
    context.created_pet = created_pet

    # Retrieve the list of pets with status 'available' again
    list_url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}
    followup_response = requests.get(list_url, params=params, timeout=10)
    _check_response(followup_response, "WHEN MR1 - follow-up list")

    followup_data = _safe_json(followup_response)
    if not isinstance(followup_data, list):
        raise AssertionError(
            f"WHEN MR1 - follow-up list: Expected response to be a list of pets, "
            f"got {type(followup_data).__name__}: {json.dumps(followup_data, ensure_ascii=False)}"
        )

    context.followup_response = followup_data
    context.followup_count = len(followup_data)


@then(
    "the follow-up output should have a count of pets in status 'available' that is one more than "
    "the seed output for MR1, assuming no other operations modified pets with status 'available' in between."
)
def _mr_MR1_followup_output(context):
    if not hasattr(context, "seed_count") or not hasattr(context, "followup_count"):
        raise AssertionError(
            "THEN MR1: Missing seed_count or followup_count on context. "
            "Ensure GIVEN and WHEN steps executed successfully."
        )

    expected = context.seed_count + 1
    actual = context.followup_count
    if actual != expected:
        raise AssertionError(
            f"THEN MR1: Expected follow-up count to be {expected}, "
            f"but got {actual}. Seed count: {context.seed_count}."
        )

# ----




def _check_response_no_500(response, step_name: str) -> None:
    """Ensure no 5xx error; raise AssertionError for Behave reporting."""
    status = getattr(response, "status_code", None)
    if status is None:
        raise AssertionError(f"{step_name}: Response has no status_code.")
    if 500 <= status <= 599:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"{step_name}: Server error {status} received. Response body: {body}"
        )


@given("a seed input that retrieves the list of pets filtered by status 'pending', producing a seed output with a list of pets in status 'pending' for MR2.")
def _mr_MR2_seed_input(context):
    # Retrieve pets with status 'pending'
    url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "pending"}

    response = requests.get(url, params=params, timeout=10)
    _check_response_no_500(response, "MR2 Given")
    try:
        response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"MR2 Given: HTTP error during seed fetch: {e}") from e

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"MR2 Given: Unable to decode JSON response: {e}") from e

    if data is None:
        data = []

    if not isinstance(data, list):
        raise AssertionError(
            f"MR2 Given: Expected list of pets, got {type(data).__name__}: {data}"
        )

    context.seed_response = data
    context.seed_request = {'status': 'pending'}


@when("a follow-up input is created by updating one of these pet's status from 'pending' to 'sold', and the list of pets is retrieved again using status 'pending', yielding a follow-up output for MR2.")
def _mr_MR2_followup_input(context):
    # Ensure seed_response exists and is a non-empty list
    seed_response = getattr(context, "seed_response", None)
    if seed_response is None:
        raise AssertionError("MR2 When: seed_response is missing from context.")
    if not isinstance(seed_response, list):
        raise AssertionError(
            f"MR2 When: seed_response should be a list, got {type(seed_response).__name__}"
        )
    if not seed_response:
        raise AssertionError("MR2 When: No pets found in seed response to update.")

    # Safely select the first pet and validate structure
    pet_to_update = seed_response[0]
    if not isinstance(pet_to_update, dict):
        raise AssertionError(
            f"MR2 When: Expected pet object to be dict, got {type(pet_to_update).__name__}"
        )

    pet_id = pet_to_update.get("id")
    if pet_id is None:
        raise AssertionError("MR2 When: Pet object has no 'id' field.")
    if not isinstance(pet_id, int):
        raise AssertionError(
            f"MR2 When: Pet 'id' must be integer (int64), got {type(pet_id).__name__}: {pet_id}"
        )

    # Create a safe copy and update the status to 'sold'
    updated_pet = json.loads(json.dumps(pet_to_update))
    updated_pet["status"] = "sold"

    # Update the pet using PUT /pet (updatePet)
    update_url = f"{BASE_URL}/pet"
    update_response = requests.put(update_url, json=updated_pet, timeout=10)
    _check_response_no_500(update_response, "MR2 When - updatePet")
    try:
        update_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"MR2 When: HTTP error during pet update: {e}") from e

    # Retrieve pets with status 'pending' again using GET /pet/findByStatus
    find_url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "pending"}
    followup_response = requests.get(find_url, params=params, timeout=10)
    _check_response_no_500(followup_response, "MR2 When - findByStatus")
    try:
        followup_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"MR2 When: HTTP error during follow-up fetch: {e}") from e

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"MR2 When: Unable to decode JSON follow-up response: {e}") from e

    if followup_data is None:
        followup_data = []

    if not isinstance(followup_data, list):
        raise AssertionError(
            f"MR2 When: Expected list of pets in follow-up, got {type(followup_data).__name__}: {followup_data}"
        )

    context.followup_response = followup_data
    context.followup_request = {'status': 'pending'}
    # Persist the updated pet id for assertion
    context.updated_pet_id = pet_id


@then("the follow-up output should no longer include the updated pet in the list of pets with status 'pending', differing from the seed output for MR2.")
def _mr_MR2_followup_output(context):
    followup_response = getattr(context, "followup_response", None)
    if followup_response is None:
        raise AssertionError("MR2 Then: followup_response is missing from context.")
    if not isinstance(followup_response, list):
        raise AssertionError(
            f"MR2 Then: followup_response should be a list, got {type(followup_response).__name__}"
        )

    updated_pet_id = getattr(context, "updated_pet_id", None)
    if updated_pet_id is None:
        # Fallback to seed_response[0]['id'] with safety checks
        seed_response = getattr(context, "seed_response", None)
        if (
            isinstance(seed_response, list)
            and seed_response
            and isinstance(seed_response[0], dict)
            and "id" in seed_response[0]
        ):
            updated_pet_id = seed_response[0]["id"]
        else:
            raise AssertionError(
                "MR2 Then: Unable to determine updated pet id from context."
            )

    if not isinstance(updated_pet_id, int):
        raise AssertionError(
            f"MR2 Then: updated_pet_id must be integer, got {type(updated_pet_id).__name__}: {updated_pet_id}"
        )

    for pet in followup_response:
        if not isinstance(pet, dict):
            raise AssertionError(
                f"MR2 Then: Each pet in followup_response must be dict, got {type(pet).__name__}"
            )
        pet_id = pet.get("id")
        if pet_id == updated_pet_id:
            raise AssertionError(
                "MR2 Then: The updated pet is still present in the follow-up output with status 'pending'."
            )

# ----






def _safe_get_json(response, step_name: str):
    """
    Safely parse JSON from a response and guard against TypeError/ValueError.
    """
    if response is None:
        raise AssertionError(f"{step_name}: Cannot parse JSON from None response.")
    try:
        return response.json()
    except ValueError as exc:
        raise AssertionError(
            f"{step_name}: Failed to parse JSON response: {exc}. Body: {response.text}"
        )


@given(
    "a seed input that retrieves the list of pets filtered by a specific status (for example, 'available') that includes a particular pet, producing a seed output with a count of pets for that status for MR3."
)
def step_mr_MR3_seed_input(context):
    # Ensure context.misc exists to avoid AttributeError/TypeError
    if not hasattr(context, "misc") or context.misc is None:
        context.misc = {}

    status_value = "available"

    # Create a pet with the target status so we know at least one exists
    pet_data = {
        "name": "TestPet-MR3",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": status_value,
    }

    seed_create_response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_no_500(seed_create_response, "MR3 Given - create pet")
    # Raise for non-2xx; this will surface 4xx issues clearly
    seed_create_response.raise_for_status()

    created_pet = _safe_get_json(seed_create_response, "MR3 Given - create pet")
    if not isinstance(created_pet, dict):
        raise AssertionError(
            f"MR3 Given - create pet: Expected JSON object for created pet, got {type(created_pet)!r}"
        )

    pet_id = created_pet.get("id")
    if pet_id is None:
        raise AssertionError("MR3 Given - create pet: Created pet has no 'id' field.")

    context.created_pet_id = pet_id

    # Retrieve the list of pets filtered by the same status
    seed_list_response = requests.get(
        f"{BASE_URL}/pet/findByStatus", params={"status": status_value}, timeout=10
    )
    _check_response_no_500(seed_list_response, "MR3 Given - list pets by status")
    seed_list_response.raise_for_status()

    seed_pets = _safe_get_json(seed_list_response, "MR3 Given - list pets by status")
    if not isinstance(seed_pets, list):
        raise AssertionError(
            f"MR3 Given - list pets by status: Expected a list of pets, got {type(seed_pets)!r}"
        )

    # Verify that the created pet is present in the list
    found_created = False
    for pet in seed_pets:
        if not isinstance(pet, dict):
            continue
        if pet.get("id") == pet_id:
            found_created = True
            break

    if not found_created:
        raise AssertionError(
            "MR3 Given - list pets by status: Seed pet not found in the 'available' pets list."
        )

    # Store seed count safely
    context.misc["seed_count"] = len(seed_pets)
    context.misc["status_value"] = status_value


@when(
    "a follow-up input is created by deleting that specific pet, and the list of pets is retrieved again using the same status filter, yielding a follow-up output for MR3."
)
def step_mr_MR3_followup_input(context):
    if not hasattr(context, "misc") or context.misc is None:
        context.misc = {}

    pet_id = getattr(context, "created_pet_id", None)
    if pet_id is None:
        raise AssertionError(
            "MR3 When: No created_pet_id found on context; Given step may have failed."
        )

    status_value = context.misc.get("status_value")
    if status_value is None:
        raise AssertionError(
            "MR3 When: No status_value found on context.misc; Given step may have failed."
        )

    # Delete the specific pet
    delete_response = requests.delete(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(delete_response, "MR3 When - delete pet")
    delete_response.raise_for_status()

    # Retrieve the list again using the same status filter
    followup_response = requests.get(
        f"{BASE_URL}/pet/findByStatus", params={"status": status_value}, timeout=10
    )
    _check_response_no_500(followup_response, "MR3 When - list pets by status after delete")
    followup_response.raise_for_status()

    followup_pets = _safe_get_json(
        followup_response, "MR3 When - list pets by status after delete"
    )
    if not isinstance(followup_pets, list):
        raise AssertionError(
            f"MR3 When - list pets by status after delete: Expected a list of pets, got {type(followup_pets)!r}"
        )

    context.misc["followup_count"] = len(followup_pets)


@then(
    "the follow-up output should have a count of pets for that status that is one less than the seed output for MR3, assuming no other operations modified pets with that status in between."
)
def step_mr_MR3_followup_output(context):
    if not hasattr(context, "misc") or context.misc is None:
        raise AssertionError("MR3 Then: context.misc is missing; previous steps may have failed.")

    if "seed_count" not in context.misc:
        raise AssertionError("MR3 Then: seed_count missing from context.misc.")
    if "followup_count" not in context.misc:
        raise AssertionError("MR3 Then: followup_count missing from context.misc.")

    seed_count = context.misc["seed_count"]
    followup_count = context.misc["followup_count"]

    if not isinstance(seed_count, int):
        raise AssertionError(
            f"MR3 Then: seed_count should be int, got {type(seed_count)!r} with value {seed_count!r}"
        )
    if not isinstance(followup_count, int):
        raise AssertionError(
            f"MR3 Then: followup_count should be int, got {type(followup_count)!r} with value {followup_count!r}"
        )

    expected_followup = seed_count - 1
    assert (
        followup_count == expected_followup
    ), f"MR3 Then: Expected follow-up count to be {expected_followup}, but got {followup_count}."

# ----






@given("a seed input that retrieves pets filtered by the tag 'tag1', producing a seed output with a list of pets for MR4.")
def _mr_MR4_seed_input(context):
    # Retrieve pets with tag 'tag1' using /pet/findByTags (GET) as per OpenAPI
    context.seed_request = {'tags': ['tag1']}

    response = requests.get(
        f"{BASE_URL}/pet/findByTags",
        params=context.seed_request,
        timeout=10,
    )
    _check_response_no_500(response, "Given MR4 seed input")

    # Raise for non-2xx/3xx client errors explicitly after 5xx check
    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"Given MR4 seed input: HTTP error {response.status_code}: {e}") from e

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Given MR4 seed input: Response is not valid JSON") from e

    if not isinstance(data, list):
        raise AssertionError(
            f"Given MR4 seed input: Expected JSON array of pets, got {type(data).__name__}"
        )

    context.seed_response = data


@when("a follow-up input is created by retrieving pets filtered by both 'tag1' and an additional tag 'tag2', yielding a follow-up output for MR4.")
def _mr_MR4_followup_input(context):
    # Retrieve pets with tags 'tag1' and 'tag2' using same /pet/findByTags endpoint
    context.followup_request = {'tags': ['tag1', 'tag2']}

    response = requests.get(
        f"{BASE_URL}/pet/findByTags",
        params=context.followup_request,
        timeout=10,
    )
    _check_response_no_500(response, "When MR4 follow-up input")

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"When MR4 follow-up input: HTTP error {response.status_code}: {e}") from e

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"When MR4 follow-up input: Response is not valid JSON") from e

    if not isinstance(data, list):
        raise AssertionError(
            f"When MR4 follow-up input: Expected JSON array of pets, got {type(data).__name__}"
        )

    context.followup_response = data


@then("the follow-up output should include all pets that appeared in the seed output (those matching 'tag1'), plus any additional pets that match either 'tag1' or 'tag2' for MR4.")
def _mr_MR4_followup_output(context):
    # Safely extract IDs from seed and follow-up responses
    try:
        seed_ids = {
            pet["id"]
            for pet in context.seed_response
            if isinstance(pet, dict) and "id" in pet
        }
        followup_ids = {
            pet["id"]
            for pet in context.followup_response
            if isinstance(pet, dict) and "id" in pet
        }
    except TypeError as e:
        raise AssertionError(f"Then MR4: Invalid response structure when extracting IDs: {e}") from e

    # Assert that all seed pets are in the follow-up output
    if not seed_ids.issubset(followup_ids):
        missing = seed_ids - followup_ids
        raise AssertionError(
            f"Then MR4: Not all seed pets are included in the follow-up output. Missing IDs: {missing}"
        )

    # For safety, interpret tags field according to Pet schema: list of Tag objects with 'name'
    for pet in context.followup_response:
        if not isinstance(pet, dict):
            raise AssertionError(
                f"Then MR4: Expected each pet to be an object, got {type(pet).__name__}"
            )

        raw_tags = pet.get("tags", [])
        if raw_tags is None:
            raw_tags = []

        if not isinstance(raw_tags, list):
            raise AssertionError(
                "Then MR4: 'tags' field is not a list in follow-up response pet"
            )

        tag_names = set()
        for tag in raw_tags:
            if isinstance(tag, dict):
                name = tag.get("name")
                if isinstance(name, str):
                    tag_names.add(name)
            elif isinstance(tag, str):
                # Be tolerant if backend returns simple strings instead of objects
                tag_names.add(tag)

        if "tag1" not in tag_names and "tag2" not in tag_names:
            raise AssertionError(
                "Then MR4: Follow-up output contains a pet that does not match 'tag1' or 'tag2'"
            )
