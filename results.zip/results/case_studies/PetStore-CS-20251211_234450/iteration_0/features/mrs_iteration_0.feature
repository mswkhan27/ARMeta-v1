Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet with a given status should increase the count for that status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets in status 'available' for MR1.
    When a follow-up input is created by adding a new pet whose status is set to 'available', and the list of pets is retrieved again using status 'available', yielding a follow-up output for MR1.
    Then the follow-up output should have a count of pets in status 'available' that is one more than the seed output for MR1, assuming no other operations modified pets with status 'available' in between.

  Scenario: MR2 Updating a pet's status should reflect in subsequent status-based retrieval
    Given a seed input that retrieves the list of pets filtered by status 'pending', producing a seed output with a list of pets in status 'pending' for MR2.
    When a follow-up input is created by updating one of these pet's status from 'pending' to 'sold', and the list of pets is retrieved again using status 'pending', yielding a follow-up output for MR2.
    Then the follow-up output should no longer include the updated pet in the list of pets with status 'pending', differing from the seed output for MR2.

  Scenario: MR3 Deleting a pet should decrease the count of pets for that pet’s status
    Given a seed input that retrieves the list of pets filtered by a specific status (for example, 'available') that includes a particular pet, producing a seed output with a count of pets for that status for MR3.
    When a follow-up input is created by deleting that specific pet, and the list of pets is retrieved again using the same status filter, yielding a follow-up output for MR3.
    Then the follow-up output should have a count of pets for that status that is one less than the seed output for MR3, assuming no other operations modified pets with that status in between.

  Scenario: MR4 Finding pets by multiple tags should include all pets found by a subset of those tags
    Given a seed input that retrieves pets filtered by the tag 'tag1', producing a seed output with a list of pets for MR4.
    When a follow-up input is created by retrieving pets filtered by both 'tag1' and an additional tag 'tag2', yielding a follow-up output for MR4.
    Then the follow-up output should include all pets that appeared in the seed output (those matching 'tag1'), plus any additional pets that match either 'tag1' or 'tag2' for MR4.
