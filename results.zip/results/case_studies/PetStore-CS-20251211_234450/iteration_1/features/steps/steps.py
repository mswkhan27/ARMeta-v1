from behave import given, when, then
import os
import json
import requests
import time

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


def _check_response_no_500(response, step_name: str) -> None:
    """Ensure no 5xx error; fail fast in Behave if it happens."""
    if response is None:
        raise AssertionError(f"{step_name}: No response received from the server.")
    status = response.status_code
    if 500 <= status <= 599:
        body = None
        try:
            body = response.json()
        except ValueError:
            body = response.text
        raise AssertionError(
            f"{step_name}: Server returned 5xx error ({status}). "
            f"Response body: {body}"
        )


@given(
    "a seed input that retrieves a user by username, producing a seed output with the user's details for MR5."
)
def _mr_MR5_seed_input(context):
    username = "testuser"
    context.seed_request = {"username": username}

    user_data = {
        "id": 0,
        "username": username,
        "firstName": "Test",
        "lastName": "User",
        "email": "testuser@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1,
    }

    try:
        create_response = requests.post(
            f"{BASE_URL}/user", json=user_data, timeout=10
        )
        _check_response_no_500(create_response, "MR5 Given - createUser")
        create_response.raise_for_status()
    except requests.RequestException as e:
        raise AssertionError(f"MR5 Given - Error creating user: {e}") from e

    try:
        get_response = requests.get(
            f"{BASE_URL}/user/{username}", timeout=10
        )
        _check_response_no_500(get_response, "MR5 Given - getUserByName")
        get_response.raise_for_status()
        try:
            context.seed_response = get_response.json()
        except ValueError as e:
            raise AssertionError(
                f"MR5 Given - Failed to decode JSON from getUserByName response: {e}"
            ) from e
    except requests.RequestException as e:
        raise AssertionError(f"MR5 Given - Error retrieving user: {e}") from e


@when(
    "a follow-up input is created by deleting the user with the same username, and an attempt is made to retrieve the user again, yielding a follow-up output for MR5."
)
def _mr_MR5_followup_input(context):
    username = context.seed_request.get("username")
    if not isinstance(username, str):
        raise AssertionError(
            "MR5 When - 'username' in seed_request is missing or not a string."
        )

    try:
        delete_response = requests.delete(
            f"{BASE_URL}/user/{username}", timeout=10
        )
        _check_response_no_500(delete_response, "MR5 When - deleteUser")
        # We do not require a specific 2xx/4xx code here; just ensure no 5xx and capture it.
        context.delete_status_code = delete_response.status_code
    except requests.RequestException as e:
        raise AssertionError(f"MR5 When - Error deleting user: {e}") from e

    try:
        followup_response = requests.get(
            f"{BASE_URL}/user/{username}", timeout=10
        )
        _check_response_no_500(followup_response, "MR5 When - getUserByName after delete")
        context.followup_response = followup_response
    except requests.RequestException as e:
        raise AssertionError(
            f"MR5 When - Error retrieving user after delete: {e}"
        ) from e


@then(
    "the follow-up output should indicate that the user is not found (for example, via a corresponding error status or message), differing from the seed output for MR5."
)
def _mr_MR5_followup_output(context):
    followup_response = getattr(context, "followup_response", None)
    if followup_response is None:
        raise AssertionError(
            "MR5 Then - followup_response is missing from context. "
            "Ensure the When step completed successfully."
        )

    status_code = followup_response.status_code
    assert status_code == 404, (
        f"Expected status code 404 for user not found, but got {status_code}."
    )

    # Attempt to parse body safely; body might be empty or non-JSON.
    body = None
    try:
        body = followup_response.json()
    except ValueError:
        body = followup_response.text

    # If body is JSON with a message, we can optionally check it; do not raise
    # a ValueError if structure differs, just enforce the not-found semantics by code.
    if isinstance(body, dict) and "message" in body:
        message = body.get("message")
        # Do a soft assertion on the message content if present
        assert isinstance(message, str), (
            "MR5 Then - 'message' field in response is not a string."
        )
        # Accept any not-found style message; if you want strict equality, keep this:
        # assert message == "User not found", f"Expected 'User not found' message, got {message!r}"

    # Additionally ensure that the follow-up output differs from the seed output
    seed_response = getattr(context, "seed_response", None)
    if seed_response is not None:
        try:
            seed_serialized = json.dumps(seed_response, sort_keys=True)
        except (TypeError, ValueError):
            seed_serialized = str(seed_response)

        try:
            followup_serialized = (
                json.dumps(body, sort_keys=True)
                if isinstance(body, (dict, list))
                else str(body)
            )
        except (TypeError, ValueError):
            followup_serialized = str(body)

        assert seed_serialized != followup_serialized, (
            "MR5 Then - Seed response and follow-up response should differ after deletion."
        )

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')




@given("a seed input that retrieves a pet by ID, producing a seed output with the pet's current name for MR7.")
def _mr_MR7_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }

    # Create pet using POST /pet
    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_no_500(response, "MR7 Given - create pet")

    try:
        body = response.json()
    except ValueError as exc:
        raise AssertionError(f"MR7 Given - create pet: Response is not valid JSON: {exc}; text={response.text}") from exc

    if response.status_code != 200:
        raise AssertionError(f"MR7 Given - create pet failed: {response.status_code}, body={body}")

    # Safely extract pet id
    pet_id = body.get("id")
    if pet_id is None:
        raise AssertionError(f"MR7 Given - create pet: 'id' missing in response body: {body}")

    context.seed_created_pet = body

    # Retrieve the pet by ID using GET /pet/\{petId\}
    response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(response, "MR7 Given - get pet by id")

    try:
        body = response.json()
    except ValueError as exc:
        raise AssertionError(f"MR7 Given - get pet by id: Response is not valid JSON: {exc}; text={response.text}") from exc

    if response.status_code != 200:
        raise AssertionError(f"MR7 Given - get pet by id failed: {response.status_code}, body={body}")

    # Ensure required fields exist to avoid KeyError / TypeError later
    if "name" not in body:
        raise AssertionError(f"MR7 Given - get pet by id: 'name' missing in response body: {body}")
    if "photoUrls" not in body or not isinstance(body.get("photoUrls"), list):
        raise AssertionError(f"MR7 Given - get pet by id: 'photoUrls' missing or not a list in response body: {body}")

    context.seed_request = response
    context.seed_response = body
    context.seed_pet_id = pet_id
    context.seed_pet_name = body.get("name")


@when("a follow-up input is created by updating the pet's representation so that its name is changed while keeping the same identifier, and the pet is retrieved again by the same ID, yielding a follow-up output for MR7.")
def _mr_MR7_followup_input(context):
    # Ensure seed data is present
    if not hasattr(context, "seed_response") or not hasattr(context, "seed_pet_id"):
        raise AssertionError("MR7 When - missing seed_response or seed_pet_id from Given step")

    seed_body = context.seed_response
    pet_id = context.seed_pet_id

    # Build updated pet payload safely
    updated_name = "doggie_updated"
    updated_pet_data = {
        "id": pet_id,
        "name": updated_name,
        "photoUrls": seed_body.get("photoUrls") or [],
        "status": seed_body.get("status", "available")
    }

    # Update pet using PUT /pet
    response = requests.put(f"{BASE_URL}/pet", json=updated_pet_data, timeout=10)
    _check_response_no_500(response, "MR7 When - update pet")

    try:
        body = response.json()
    except ValueError as exc:
        raise AssertionError(f"MR7 When - update pet: Response is not valid JSON: {exc}; text={response.text}") from exc

    if response.status_code != 200:
        raise AssertionError(f"MR7 When - update pet failed: {response.status_code}, body={body}")

    # Optionally validate updated response structure
    if body.get("id") != pet_id:
        raise AssertionError(
            f"MR7 When - update pet: expected id {pet_id} in response, got {body.get('id')}, body={body}"
        )

    # Retrieve the pet again by ID using GET /pet/\{petId\}
    response_get = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(response_get, "MR7 When - get updated pet by id")

    try:
        body_get = response_get.json()
    except ValueError as exc:
        raise AssertionError(
            f"MR7 When - get updated pet by id: Response is not valid JSON: {exc}; text={response_get.text}"
        ) from exc

    if response_get.status_code != 200:
        raise AssertionError(
            f"MR7 When - get updated pet by id failed: {response_get.status_code}, body={body_get}"
        )

    if "name" not in body_get:
        raise AssertionError(f"MR7 When - get updated pet by id: 'name' missing in response body: {body_get}")

    context.followup_request = response_get
    context.followup_response = body_get
    context.updated_name = updated_name


@then("the follow-up output should have the updated name in its representation, differing from the seed output for MR7.")
def _mr_MR7_followup_output(context):
    if not hasattr(context, "followup_response") or not hasattr(context, "seed_response"):
        raise AssertionError("MR7 Then - missing followup_response or seed_response from previous steps")

    follow_body = context.followup_response
    seed_body = context.seed_response

    follow_name = follow_body.get("name")
    seed_name = seed_body.get("name")

    if follow_name is None:
        raise AssertionError(f"MR7 Then - follow-up response missing 'name': {follow_body}")
    if seed_name is None:
        raise AssertionError(f"MR7 Then - seed response missing 'name': {seed_body}")

    expected_updated_name = getattr(context, "updated_name", "doggie_updated")

    assert follow_name == expected_updated_name, (
        f"Expected updated name to be '{expected_updated_name}', but got '{follow_name}'"
    )
    assert seed_name != follow_name, (
        f"Seed output name '{seed_name}' should differ from follow-up output name '{follow_name}'."
    )

# ----






@given(
    "a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR8."
)
def _mr_MR8_seed_input(context):
    # Safely create a pet and then retrieve it by ID (getPetById)
    pet_data = {
        "id": 1,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available",
    }

    # Create/overwrite the pet using POST /pet (addPet)
    create_response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_no_500(create_response, "Given MR8 - create pet")

    try:
        create_body = create_response.json()
    except ValueError:
        raise AssertionError(
            f"Given MR8 - create pet: Response is not valid JSON. Status: {create_response.status_code}, "
            f"Body: {create_response.text}"
        )

    if create_response.status_code != 200:
        raise AssertionError(
            f"Given MR8 - create pet: Expected 200, got {create_response.status_code}. "
            f"Body: {json.dumps(create_body, ensure_ascii=False)}"
        )

    # Retrieve the pet via GET /pet/\{petId\} (getPetById) to produce the seed output
    pet_id = create_body.get("id")
    if pet_id is None:
        raise AssertionError(
            f"Given MR8 - create pet: Response JSON missing 'id'. Body: {json.dumps(create_body, ensure_ascii=False)}"
        )

    get_response = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(get_response, "Given MR8 - get pet by id")

    try:
        seed_body = get_response.json()
    except ValueError:
        raise AssertionError(
            f"Given MR8 - get pet by id: Response is not valid JSON. "
            f"Status: {get_response.status_code}, Body: {get_response.text}"
        )

    if get_response.status_code != 200:
        raise AssertionError(
            f"Given MR8 - get pet by id: Expected 200, got {get_response.status_code}. "
            f"Body: {json.dumps(seed_body, ensure_ascii=False)}"
        )

    # Store both request/response data on context safely
    context.seed_create_response = create_response
    context.seed_response = seed_body


@when(
    "a follow-up input is created by uploading an image for the same pet, and the pet is retrieved again by the same ID, yielding a follow-up output for MR8."
)
def _mr_MR8_followup_input(context):
    # Upload image for the same pet using POST /pet/\{petId\}/uploadImage
    seed_body = getattr(context, "seed_response", None)
    if not isinstance(seed_body, dict):
        raise AssertionError(
            "When MR8 - upload image: 'seed_response' is not available or not a dict."
        )

    pet_id = seed_body.get("id")
    if pet_id is None:
        raise AssertionError(
            "When MR8 - upload image: 'seed_response' JSON missing 'id'. "
            f"Body: {json.dumps(seed_body, ensure_ascii=False)}"
        )

    # Use a small dummy binary payload instead of relying on a real file path to avoid FileNotFoundError
    dummy_image_bytes = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR"

    upload_files = {
        "file": ("dummy.png", dummy_image_bytes, "application/octet-stream"),
    }

    upload_response = requests.post(
        f"{BASE_URL}/pet/{pet_id}/uploadImage", files=upload_files, timeout=10
    )
    _check_response_no_500(upload_response, "When MR8 - upload image")

    try:
        upload_body = upload_response.json()
    except ValueError:
        upload_body = {"raw": upload_response.text}

    if upload_response.status_code != 200:
        raise AssertionError(
            f"When MR8 - upload image: Expected 200, got {upload_response.status_code}. "
            f"Body: {json.dumps(upload_body, ensure_ascii=False)}"
        )

    # Retrieve the pet again via GET /pet/\{petId\}
    followup_request = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(followup_request, "When MR8 - get pet after upload")

    try:
        followup_body = followup_request.json()
    except ValueError:
        raise AssertionError(
            f"When MR8 - get pet after upload: Response is not valid JSON. "
            f"Status: {followup_request.status_code}, Body: {followup_request.text}"
        )

    if followup_request.status_code != 200:
        raise AssertionError(
            f"When MR8 - get pet after upload: Expected 200, got {followup_request.status_code}. "
            f"Body: {json.dumps(followup_body, ensure_ascii=False)}"
        )

    context.upload_response = upload_response
    context.followup_request = followup_request
    context.followup_response = followup_body


@then(
    "the follow-up output should have the same pet details as the seed output for MR8, since uploading an image does not modify the stored pet representation."
)
def _mr_MR8_followup_output(context):
    seed_body = getattr(context, "seed_response", None)
    followup_body = getattr(context, "followup_response", None)

    if not isinstance(seed_body, dict):
        raise AssertionError(
            "Then MR8: 'seed_response' is not available or not a dict."
        )
    if not isinstance(followup_body, dict):
        raise AssertionError(
            "Then MR8: 'followup_response' is not available or not a dict."
        )

    def _safe_get(obj: dict, key: str):
        return obj.get(key, None)

    seed_id = _safe_get(seed_body, "id")
    follow_id = _safe_get(followup_body, "id")
    if seed_id != follow_id:
        raise AssertionError(
            f"Then MR8: Pet ID does not match. Seed: {seed_id}, Follow-up: {follow_id}"
        )

    seed_name = _safe_get(seed_body, "name")
    follow_name = _safe_get(followup_body, "name")
    if seed_name != follow_name:
        raise AssertionError(
            f"Then MR8: Pet name does not match. Seed: {seed_name}, Follow-up: {follow_name}"
        )

    seed_photos = _safe_get(seed_body, "photoUrls")
    follow_photos = _safe_get(followup_body, "photoUrls")
    if seed_photos != follow_photos:
        raise AssertionError(
            f"Then MR8: Pet photoUrls do not match. Seed: {seed_photos}, Follow-up: {follow_photos}"
        )

    seed_status = _safe_get(seed_body, "status")
    follow_status = _safe_get(followup_body, "status")
    if seed_status != follow_status:
        raise AssertionError(
            f"Then MR8: Pet status does not match. Seed: {seed_status}, Follow-up: {follow_status}"
        )

# ----




def _check_http_500(response, step_name: str) -> None:
    """
    Helper to ensure no 500-level error responses pass silently.
    Raises an AssertionError if a 5xx status code is returned.
    """
    if 500 <= response.status_code <= 599:
        raise AssertionError(
            f"MR9 {step_name}: Server error {response.status_code} received from "
            f"{response.request.method} {response.request.url} with body: {response.text}"
        )


@given(
    'a seed input that logs in a user with valid credentials, producing a seed output that includes a response body and login-related headers such as rate limit and expiration time for MR9.'
)
def _mr_MR9_seed_login(context):
    username = "testuser"
    password = "testpassword"

    # Seed request parameters for /user/login (GET)
    context.seed_request = {
        "username": username,
        "password": password,
    }

    response = requests.get(
        f"{BASE_URL}/user/login",
        params=context.seed_request,
        timeout=10,
    )

    _check_http_500(response, "Given")

    # Raise for all non-2xx/non-3xx errors explicitly
    try:
        response.raise_for_status()
    except requests.HTTPError as exc:
        raise AssertionError(
            f"MR9 Given: Login request failed with status {response.status_code}: {response.text}"
        ) from exc

    # Response body is declared as string in OpenAPI; keep it as text
    context.seed_response_body = response.text

    # Store headers related to login info
    context.seed_rate_limit = response.headers.get("X-Rate-Limit")
    context.seed_expires_after = response.headers.get("X-Expires-After")

    # Ensure headers exist to avoid TypeError/AttributeError later
    assert context.seed_rate_limit is not None, "MR9 Given: X-Rate-Limit header is missing in seed response"
    assert context.seed_expires_after is not None, "MR9 Given: X-Expires-After header is missing in seed response"


@when(
    'a follow-up input is created by logging in the same user again with the same credentials, yielding a follow-up output for MR9.'
)
def _mr_MR9_followup_login(context):
    # Reuse the same seed_request params
    if not hasattr(context, "seed_request"):
        raise AssertionError("MR9 When: seed_request not found in context; Given step may have failed or not run")

    response = requests.get(
        f"{BASE_URL}/user/login",
        params=context.seed_request,
        timeout=10,
    )

    _check_http_500(response, "When")

    try:
        response.raise_for_status()
    except requests.HTTPError as exc:
        raise AssertionError(
            f"MR9 When: Login request failed with status {response.status_code}: {response.text}"
        ) from exc

    context.followup_response_body = response.text
    context.followup_rate_limit = response.headers.get("X-Rate-Limit")
    context.followup_expires_after = response.headers.get("X-Expires-After")

    assert context.followup_rate_limit is not None, "MR9 When: X-Rate-Limit header is missing in follow-up response"
    assert context.followup_expires_after is not None, "MR9 When: X-Expires-After header is missing in follow-up response"


@then(
    'both the seed and follow-up outputs should indicate successful login and include headers conveying rate limit and expiration time information, and the follow-up output may differ from the seed output in the specific header or body values while still conforming to the same structure.'
)
def _mr_MR9_assert_login_responses(context):
    # Ensure attributes exist to avoid AttributeError
    for attr in [
        "seed_response_body",
        "followup_response_body",
        "seed_rate_limit",
        "followup_rate_limit",
        "seed_expires_after",
        "followup_expires_after",
    ]:
        assert hasattr(context, attr), f"MR9 Then: Missing context attribute '{attr}'. Prior steps may have failed."

    # Successful login already enforced via raise_for_status in previous steps.
    # Now check structure-related properties:
    assert isinstance(context.seed_response_body, str), "MR9 Then: Seed response body must be a string"
    assert isinstance(context.followup_response_body, str), "MR9 Then: Follow-up response body must be a string"

    # Headers must be present and string-like
    assert isinstance(context.seed_rate_limit, str), "MR9 Then: Seed X-Rate-Limit header must be a string"
    assert isinstance(context.followup_rate_limit, str), "MR9 Then: Follow-up X-Rate-Limit header must be a string"
    assert isinstance(context.seed_expires_after, str), "MR9 Then: Seed X-Expires-After header must be a string"
    assert isinstance(context.followup_expires_after, str), "MR9 Then: Follow-up X-Expires-After header must be a string"

    # Both calls should provide rate limit and expiration info; they may differ in value
    # but must both be non-empty strings.
    assert context.seed_rate_limit.strip(), "MR9 Then: Seed X-Rate-Limit header is empty"
    assert context.followup_rate_limit.strip(), "MR9 Then: Follow-up X-Rate-Limit header is empty"
    assert context.seed_expires_after.strip(), "MR9 Then: Seed X-Expires-After header is empty"
    assert context.followup_expires_after.strip(), "MR9 Then: Follow-up X-Expires-After header is empty"

    # The MR allows bodies/headers to differ, but they must be of the same type/structure.
    # Since the body is defined as string, structure equality is just type equality (already checked).
