Feature: Iteration 1 MRs

  Scenario: MR5 Deleting a user should result in the user no longer being retrievable
    Given a seed input that retrieves a user by username, producing a seed output with the user's details for MR5.
    When a follow-up input is created by deleting the user with the same username, and an attempt is made to retrieve the user again, yielding a follow-up output for MR5.
    Then the follow-up output should indicate that the user is not found (for example, via a corresponding error status or message), differing from the seed output for MR5.

  Scenario: MR7 Updating a pet's name should reflect in subsequent retrieval by ID
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's current name for MR7.
    When a follow-up input is created by updating the pet's representation so that its name is changed while keeping the same identifier, and the pet is retrieved again by the same ID, yielding a follow-up output for MR7.
    Then the follow-up output should have the updated name in its representation, differing from the seed output for MR7.

  Scenario: MR8 Uploading an image for a pet should not alter the pet's existing details
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR8.
    When a follow-up input is created by uploading an image for the same pet, and the pet is retrieved again by the same ID, yielding a follow-up output for MR8.
    Then the follow-up output should have the same pet details as the seed output for MR8, since uploading an image does not modify the stored pet representation.

  Scenario: MR9 Repeated logins should consistently provide login response data with expiration information
    Given a seed input that logs in a user with valid credentials, producing a seed output that includes a response body and login-related headers such as rate limit and expiration time for MR9.
    When a follow-up input is created by logging in the same user again with the same credentials, yielding a follow-up output for MR9.
    Then both the seed and follow-up outputs should indicate successful login and include headers conveying rate limit and expiration time information, and the follow-up output may differ from the seed output in the specific header or body values while still conforming to the same structure.
