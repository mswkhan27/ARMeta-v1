from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_response_for_server_error(response, step_name: str) -> None:
    """
    Helper to ensure no 5xx errors pass silently.
    Raises AssertionError if a 5xx status code is returned.
    """
    status = getattr(response, "status_code", None)
    if isinstance(status, int) and 500 <= status <= 599:
        body = None
        try:
            body = response.json()
        except Exception:
            body = response.text
        raise AssertionError(
            f"{step_name}: Server error {status} received from API. Response body: {body}"
        )


@given(
    "a seed input that retrieves an existing order by a valid identifier, producing a seed output with the order's details for MR22."
)
def _mr_MR22_seed_input(context):
    # Create a new order to ensure we have a valid identifier
    order_data = {
        "petId": 198772,
        "quantity": 1,
        "status": "placed",
        "complete": True,
    }

    response = requests.post(f"{BASE_URL}/store/order", json=order_data, timeout=10)
    _check_response_for_server_error(response, "Given MR22 create order")

    context.seed_request = response

    try:
        context.seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Given MR22: Response is not valid JSON: {e}. Body: {response.text}")

    if response.status_code != 200:
        raise AssertionError(
            f"Given MR22: Failed to create order. "
            f"Status: {response.status_code}, Body: {context.seed_response}"
        )

    order_id = context.seed_response.get("id")
    if order_id is None:
        raise AssertionError(
            f"Given MR22: Created order response does not contain 'id'. "
            f"Response: {json.dumps(context.seed_response, ensure_ascii=False)}"
        )

    context.order_id = order_id

    # Retrieve the same order to produce the actual seed output
    get_response = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    _check_response_for_server_error(get_response, "Given MR22 get order by id")

    context.seed_get_request = get_response

    try:
        context.seed_get_response = get_response.json()
    except ValueError as e:
        raise AssertionError(f"Given MR22: GET /store/order/{{orderId}} response is not valid JSON: {e}. "
                             f"Body: {get_response.text}")

    if get_response.status_code != 200:
        raise AssertionError(
            f"Given MR22: Failed to retrieve order by id. "
            f"Status: {get_response.status_code}, Body: {context.seed_get_response}"
        )


@when(
    "a follow-up input is created by retrieving the same order using the same valid identifier again, yielding a follow-up output for MR22."
)
def _mr_MR22_followup_input(context):
    if not hasattr(context, "order_id"):
        raise AssertionError("When MR22: context.order_id is missing from Given step.")

    order_id = context.order_id
    if order_id is None:
        raise AssertionError("When MR22: order_id is None.")

    response = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    _check_response_for_server_error(response, "When MR22 get order by id again")

    context.followup_request = response

    try:
        context.followup_response = response.json()
    except ValueError as e:
        raise AssertionError(f"When MR22: Response is not valid JSON: {e}. Body: {response.text}")

    if response.status_code != 200:
        raise AssertionError(
            f"When MR22: Failed to retrieve order by id. "
            f"Status: {response.status_code}, Body: {context.followup_response}"
        )


@then(
    "the follow-up output should be identical to the seed output for MR22, assuming no operations modified or deleted that order between the two retrievals."
)
def _mr_MR22_followup_output(context):
    if not hasattr(context, "seed_get_response"):
        raise AssertionError("Then MR22: context.seed_get_response is missing from Given step.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Then MR22: context.followup_response is missing from When step.")

    seed_output = context.seed_get_response
    followup_output = context.followup_response

    if seed_output != followup_output:
        raise AssertionError(
            "Then MR22: Follow-up output does not match seed output.\n"
            f"Seed output: {json.dumps(seed_output, ensure_ascii=False, sort_keys=True)}\n"
            f"Follow-up output: {json.dumps(followup_output, ensure_ascii=False, sort_keys=True)}"
        )

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


def _check_500(response, step_name: str) -> None:
    """Fail fast on HTTP 500 to avoid hiding server errors."""
    if response is not None and response.status_code == 500:
        raise AssertionError(f"HTTP 500 detected in {step_name}: {response.text}")


@given(
    "a seed input that retrieves an existing pet by its identifier, producing a seed output with the pet's current details for MR24."
)
def _mr_MR24_seed_input(context):
    # Create a pet to ensure it exists (POST /pet).
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available",
    }

    response = requests.post(
        f"{BASE_URL}/pet", json=pet_data, timeout=10
    )
    _check_500(response, "Given MR24 - create pet")
    response.raise_for_status()

    # Be defensive about JSON decoding.
    try:
        seed_response = response.json()
    except ValueError as exc:
        raise AssertionError(f"Invalid JSON in seed response: {exc}") from exc

    if not isinstance(seed_response, dict):
        raise AssertionError(
            f"Seed response must be an object, got {type(seed_response).__name__}"
        )

    pet_id = seed_response.get("id")
    if pet_id is None:
        raise AssertionError("Seed pet response does not contain an 'id' field")

    # Retrieve the pet by ID (GET /pet/\{petId\}) to conform strictly with the MR wording.
    get_response = requests.get(
        f"{BASE_URL}/pet/{pet_id}", timeout=10
    )
    _check_500(get_response, "Given MR24 - get pet by id")
    get_response.raise_for_status()

    try:
        get_pet = get_response.json()
    except ValueError as exc:
        raise AssertionError(f"Invalid JSON in get-by-id response: {exc}") from exc

    if not isinstance(get_pet, dict):
        raise AssertionError(
            f"Get-by-id response must be an object, got {type(get_pet).__name__}"
        )

    context.seed_request = pet_data
    context.seed_response = get_pet
    context.seed_pet_id = pet_id


@when(
    "a follow-up input is created by updating that pet's details using form data (such as its name and/or status), and the pet is retrieved again by the same identifier, yielding a follow-up output for MR24."
)
def _mr_MR24_followup_input(context):
    if not hasattr(context, "seed_pet_id"):
        raise AssertionError("seed_pet_id is missing from context in MR24 When step")

    pet_id = context.seed_pet_id

    # Update the pet's details using form data semantics via query parameters
    # on POST /pet/\{petId\} (updatePetWithForm in the OpenAPI spec).
    updated_params = {
        "name": "doggie_updated",
        "status": "pending",
    }

    update_response = requests.post(
        f"{BASE_URL}/pet/{pet_id}",
        params=updated_params,
        timeout=10,
    )
    _check_500(update_response, "When MR24 - update pet with form")
    update_response.raise_for_status()

    # Retrieve the updated pet (GET /pet/\{petId\}).
    followup_response = requests.get(
        f"{BASE_URL}/pet/{pet_id}", timeout=10
    )
    _check_500(followup_response, "When MR24 - get updated pet by id")
    followup_response.raise_for_status()

    try:
        followup_pet = followup_response.json()
    except ValueError as exc:
        raise AssertionError(f"Invalid JSON in follow-up response: {exc}") from exc

    if not isinstance(followup_pet, dict):
        raise AssertionError(
            f"Follow-up response must be an object, got {type(followup_pet).__name__}"
        )

    context.followup_response = followup_pet
    context.updated_params = updated_params


@then(
    "the follow-up output should reflect the updated form data fields for the pet (for example, the new name and/or status), while other fields remain unchanged compared to the seed output for MR24, except for any fields that the system may legitimately modify automatically."
)
def _mr_MR24_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response is missing from context in MR24 Then step")
    if not hasattr(context, "followup_response"):
        raise AssertionError(
            "followup_response is missing from context in MR24 Then step"
        )
    if not hasattr(context, "updated_params"):
        raise AssertionError("updated_params is missing from context in MR24 Then step")

    seed = context.seed_response
    followup = context.followup_response
    updated_params = context.updated_params

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise AssertionError(
            "Seed and follow-up responses must both be JSON objects (dicts)"
        )

    # Check that updated fields reflect the form data.
    expected_name = updated_params.get("name")
    expected_status = updated_params.get("status")

    if expected_name is not None:
        assert (
            followup.get("name") == expected_name
        ), f"Name was not updated correctly: expected {expected_name}, got {followup.get('name')}"
    if expected_status is not None:
        assert (
            followup.get("status") == expected_status
        ), f"Status was not updated correctly: expected {expected_status}, got {followup.get('status')}"

    # Fields that may legitimately change can be excluded here if needed.
    auto_fields = set()

    # Check that other fields remain unchanged (shallow comparison).
    for key, seed_value in seed.items():
        if key in {"name", "status"} or key in auto_fields:
            continue
        follow_value = followup.get(key)
        assert (
            follow_value == seed_value
        ), f"Field '{key}' changed between seed and follow-up: seed={seed_value!r}, follow-up={follow_value!r}"
