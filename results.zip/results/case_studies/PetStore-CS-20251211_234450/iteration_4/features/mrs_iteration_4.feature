Feature: Iteration 4 MRs

  Scenario: MR22 Retrieving an order by ID should return consistent details
    Given a seed input that retrieves an existing order by a valid identifier, producing a seed output with the order's details for MR22.
    When a follow-up input is created by retrieving the same order using the same valid identifier again, yielding a follow-up output for MR22.
    Then the follow-up output should be identical to the seed output for MR22, assuming no operations modified or deleted that order between the two retrievals.

  Scenario: MR24 Updating a pet with form data should reflect in subsequent retrieval by ID
    Given a seed input that retrieves an existing pet by its identifier, producing a seed output with the pet's current details for MR24.
    When a follow-up input is created by updating that pet's details using form data (such as its name and/or status), and the pet is retrieved again by the same identifier, yielding a follow-up output for MR24.
    Then the follow-up output should reflect the updated form data fields for the pet (for example, the new name and/or status), while other fields remain unchanged compared to the seed output for MR24, except for any fields that the system may legitimately modify automatically.
