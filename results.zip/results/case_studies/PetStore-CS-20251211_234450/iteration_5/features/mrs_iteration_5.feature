Feature: Iteration 5 MRs

  Scenario: MR25 Deleting an order should result in the order no longer being retrievable
    Given a seed input that retrieves an existing purchase order by a valid order ID (for which a successful response is returned), producing a seed output with that order's details for MR25.
    When a follow-up input is created by deleting the purchase order with the same valid order ID, and an attempt is then made to retrieve the order again using that ID, yielding a follow-up output for MR25.
    Then the follow-up output should indicate that the order is not found (for example, via a corresponding error status or message), differing from the successful seed output for MR25.

  Scenario: MR26 Creating multiple users with a list should result in all those users being individually retrievable
    Given a seed input that retrieves details for a set of existing users by their usernames, producing a seed output that conceptually represents the current list of those users for MR26.
    When a follow-up input is created by adding a list of new users using the list-based user-creation operation, and then details are retrieved individually for these newly created users by their usernames, yielding a follow-up output for MR26.
    Then the follow-up output, when considered together with the seed output, should include user details for all users from the seed output plus the newly added users, meaning that the combined set of retrieved users after creation is a superset of the seed set for MR26.
