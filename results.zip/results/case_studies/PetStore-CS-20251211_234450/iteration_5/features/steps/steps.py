from behave import given, when, then
import os
import json
import requests
import time

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


def _check_500(response, step_name: str) -> None:
    """Raise AssertionError if a 500-level error is returned."""
    status = getattr(response, "status_code", None)
    if status is None:
        raise AssertionError(f"{step_name}: Response has no status_code")
    if 500 <= status <= 599:
        body = None
        try:
            body = response.json()
        except Exception:
            body = response.text
        raise AssertionError(
            f"{step_name}: Server error {status} received. Body: {body}"
        )


@given(
    "a seed input that retrieves an existing purchase order by a valid order ID "
    "(for which a successful response is returned), producing a seed output with "
    "that order's details for MR25."
)
def _mr_MR25_seed_input(context):
    # Create a new order to ensure we have a valid order ID, then retrieve it
    order_data = {
        "petId": 198772,
        "quantity": 1,
        "status": "placed",
        "complete": True,
    }

    # Place order
    place_resp = requests.post(f"{BASE_URL}/store/order", json=order_data, timeout=10)
    _check_500(place_resp, "MR25 GIVEN - placeOrder")

    if place_resp.status_code != 200:
        raise AssertionError(
            f"MR25 GIVEN - Failed to create order: "
            f"status={place_resp.status_code}, body={place_resp.text}"
        )

    try:
        seed_order = place_resp.json() if place_resp.content else {}
    except ValueError as e:
        raise AssertionError(f"MR25 GIVEN - Invalid JSON in create order response: {e}")

    order_id = seed_order.get("id")
    if not isinstance(order_id, int):
        raise AssertionError(
            f"MR25 GIVEN - Created order has invalid or missing 'id': {seed_order}"
        )

    # Retrieve the order by ID to produce the official seed output (getOrderById)
    get_resp = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    _check_500(get_resp, "MR25 GIVEN - getOrderById")

    if get_resp.status_code != 200:
        raise AssertionError(
            f"MR25 GIVEN - Expected to retrieve order successfully: "
            f"status={get_resp.status_code}, body={get_resp.text}"
        )

    try:
        context.seed_response = get_resp.json() if get_resp.content else {}
    except ValueError as e:
        raise AssertionError(f"MR25 GIVEN - Invalid JSON in get order response: {e}")

    context.seed_order_id = order_id
    context.seed_request = get_resp


@when(
    "a follow-up input is created by deleting the purchase order with the same valid "
    "order ID, and an attempt is then made to retrieve the order again using that ID, "
    "yielding a follow-up output for MR25."
)
def _mr_MR25_followup_input(context):
    if not hasattr(context, "seed_order_id"):
        raise AssertionError("MR25 WHEN - Missing seed_order_id from GIVEN step")

    order_id = context.seed_order_id

    # Delete the order (deleteOrder)
    delete_resp = requests.delete(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    _check_500(delete_resp, "MR25 WHEN - deleteOrder")

    if delete_resp.status_code != 200:
        raise AssertionError(
            f"MR25 WHEN - Failed to delete order: "
            f"status={delete_resp.status_code}, body={delete_resp.text}"
        )

    # Attempt to retrieve the deleted order (getOrderById)
    followup_req = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
    _check_500(followup_req, "MR25 WHEN - getOrderById after delete")

    context.followup_request = followup_req
    try:
        context.followup_response = followup_req.json() if followup_req.content else {}
    except ValueError:
        # If response is not JSON, store raw text to keep assertions safe
        context.followup_response = {"raw": followup_req.text}


@then(
    "the follow-up output should indicate that the order is not found (for example, "
    "via a corresponding error status or message), differing from the successful "
    "seed output for MR25."
)
def _mr_MR25_followup_output(context):
    if not hasattr(context, "followup_request"):
        raise AssertionError("MR25 THEN - Missing followup_request from WHEN step")

    resp = context.followup_request
    _check_500(resp, "MR25 THEN - final assertion")

    # According to the specification for /store/order/\{orderId\} GET,
    # a not-found order should yield 404.
    if resp.status_code != 404:
        raise AssertionError(
            f"MR25 THEN - Expected 404 Not Found after deleting order, "
            f"got {resp.status_code}. Body: {getattr(context, 'followup_response', None)}"
        )

    # Ensure the follow-up output differs from the successful seed output
    seed_body = getattr(context, "seed_response", None)
    followup_body = getattr(context, "followup_response", None)
    if seed_body == followup_body:
        raise AssertionError(
            "MR25 THEN - Follow-up response body should differ from the successful seed response body."
        )

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')




@given('a seed input that retrieves details for a set of existing users by their usernames, producing a seed output that conceptually represents the current list of those users for MR26.')
def _mr_MR26_seed_input(context):
    # Create a list of users to ensure they exist
    users_to_create = [
        {
            "username": "user1",
            "firstName": "John",
            "lastName": "Doe",
            "email": "john@example.com",
            "password": "password",
            "phone": "1234567890",
            "userStatus": 1,
        },
        {
            "username": "user2",
            "firstName": "Jane",
            "lastName": "Doe",
            "email": "jane@example.com",
            "password": "password",
            "phone": "0987654321",
            "userStatus": 1,
        },
    ]

    context.seed_request = users_to_create

    response = requests.post(
        f"{BASE_URL}/user/createWithList",
        json=users_to_create,
        timeout=10,
    )
    _check_500(response, "Given MR26 - createWithList")
    response.raise_for_status()

    # Retrieve the users to confirm they were created
    context.seed_response = []
    for user in users_to_create:
        username = user.get("username")
        if not isinstance(username, str):
            raise AssertionError("Given MR26: username must be a string in users_to_create.")

        user_response = requests.get(
            f"{BASE_URL}/user/{username}",
            timeout=10,
        )
        _check_500(user_response, f"Given MR26 - getUserByName ({username})")
        user_response.raise_for_status()

        try:
            user_json = user_response.json()
        except json.JSONDecodeError as exc:
            raise AssertionError(
                f"Given MR26: Failed to decode JSON for user '{username}'. "
                f"Response text: {user_response.text}"
            ) from exc

        context.seed_response.append(user_json)


@when('a follow-up input is created by adding a list of new users using the list-based user-creation operation, and then details are retrieved individually for these newly created users by their usernames, yielding a follow-up output for MR26.')
def _mr_MR26_followup_input(context):
    # Create new users
    new_users = [
        {
            "username": "user3",
            "firstName": "Alice",
            "lastName": "Smith",
            "email": "alice@example.com",
            "password": "password",
            "phone": "1231231234",
            "userStatus": 1,
        },
        {
            "username": "user4",
            "firstName": "Bob",
            "lastName": "Brown",
            "email": "bob@example.com",
            "password": "password",
            "phone": "3213214321",
            "userStatus": 1,
        },
    ]

    context.followup_request = new_users

    response = requests.post(
        f"{BASE_URL}/user/createWithList",
        json=new_users,
        timeout=10,
    )
    _check_500(response, "When MR26 - createWithList")
    response.raise_for_status()

    # Retrieve the newly created users
    context.followup_response = []
    for user in new_users:
        username = user.get("username")
        if not isinstance(username, str):
            raise AssertionError("When MR26: username must be a string in new_users.")

        user_response = requests.get(
            f"{BASE_URL}/user/{username}",
            timeout=10,
        )
        _check_500(user_response, f"When MR26 - getUserByName ({username})")
        user_response.raise_for_status()

        try:
            user_json = user_response.json()
        except json.JSONDecodeError as exc:
            raise AssertionError(
                f"When MR26: Failed to decode JSON for user '{username}'. "
                f"Response text: {user_response.text}"
            ) from exc

        context.followup_response.append(user_json)


@then('the follow-up output, when considered together with the seed output, should include user details for all users from the seed output plus the newly added users, meaning that the combined set of retrieved users after creation is a superset of the seed set for MR26.')
def _mr_MR26_assert_followup_output(context):
    seed_response = getattr(context, "seed_response", None)
    followup_response = getattr(context, "followup_response", None)

    if not isinstance(seed_response, list):
        raise AssertionError("Then MR26: context.seed_response must be a list.")
    if not isinstance(followup_response, list):
        raise AssertionError("Then MR26: context.followup_response must be a list.")

    combined_users = seed_response + followup_response

    try:
        usernames_combined = {user.get("username") for user in combined_users if isinstance(user, dict)}
        usernames_seed = {user.get("username") for user in seed_response if isinstance(user, dict)}
        usernames_followup = {user.get("username") for user in followup_response if isinstance(user, dict)}
    except Exception as exc:
        raise AssertionError(f"Then MR26: Error while extracting usernames: {exc}") from exc

    if None in usernames_combined:
        raise AssertionError("Then MR26: One or more users in combined set do not have a 'username' field.")

    assert usernames_seed.issubset(
        usernames_combined
    ), "Seed users are not a subset of combined users."
    assert usernames_followup.issubset(
        usernames_combined
    ), "Follow-up users are not included in combined users."
