Feature: Iteration 2 MRs

  Scenario: MR12 Logging out should not affect the inventory data
    Given a seed input that retrieves the inventory of pets by status, producing a seed output with the count of pets in each status for MR12.
    When a follow-up input is created by logging out the current user, and the inventory is retrieved again without performing any other operations that change inventory counts, yielding a follow-up output for MR12.
    Then the follow-up output should be identical to the seed output for MR12, as logging out does not modify inventory data.

  Scenario: MR14 Updating a user's details should reflect in subsequent retrieval by username
    Given a seed input that retrieves a user by username, producing a seed output with the user's current details for MR14.
    When a follow-up input is created by updating the user's details for the same username, and the user is retrieved again by that username, yielding a follow-up output for MR14.
    Then the follow-up output should show the updated fields for that username, while fields not modified by the update should match the seed output for MR14.
