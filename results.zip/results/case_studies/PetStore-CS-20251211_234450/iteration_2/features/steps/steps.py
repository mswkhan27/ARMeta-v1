from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_response_for_server_error(response, step_name: str) -> None:
    """
    Ensure no 5xx responses pass silently.
    Raises an AssertionError with detailed information if a server error occurs.
    """
    if 500 <= response.status_code <= 599:
        body = None
        try:
            body = response.json()
        except ValueError:
            body = response.text
        raise AssertionError(
            f"{step_name}: Server error {response.status_code} for URL {response.url}. "
            f"Response body: {body}"
        )


@given('a seed input that retrieves the inventory of pets by status, producing a seed output with the count of pets in each status for MR12.')
def _mr_MR12_seed_input(context):
    url = f"{BASE_URL}/store/inventory"
    try:
        response = requests.get(url, timeout=10)
        _check_response_for_server_error(response, "Given MR12")
        response.raise_for_status()
        # Inventory endpoint returns a JSON object (map of status -> quantity)
        data = response.json()
        if not isinstance(data, dict):
            raise AssertionError(
                f"Given MR12: Expected inventory response to be an object, got {type(data).__name__}"
            )
        context.seed_response = data
        context.seed_request = {"method": "GET", "url": url}
    except (requests.RequestException, ValueError, TypeError) as e:
        raise AssertionError(f"Given MR12: Error while retrieving inventory: {e}") from e


@when('a follow-up input is created by logging out the current user, and the inventory is retrieved again without performing any other operations that change inventory counts, yielding a follow-up output for MR12.')
def _mr_MR12_followup_input(context):
    logout_url = f"{BASE_URL}/user/logout"
    inventory_url = f"{BASE_URL}/store/inventory"
    try:
        # Log out the current user
        logout_response = requests.get(logout_url, timeout=10)
        _check_response_for_server_error(logout_response, "When MR12 - logout")
        logout_response.raise_for_status()

        # Retrieve inventory again
        followup_response = requests.get(inventory_url, timeout=10)
        _check_response_for_server_error(followup_response, "When MR12 - inventory")
        followup_response.raise_for_status()
        data = followup_response.json()
        if not isinstance(data, dict):
            raise AssertionError(
                f"When MR12: Expected follow-up inventory response to be an object, got {type(data).__name__}"
            )
        context.followup_response = data
        context.followup_request = {"method": "GET", "url": inventory_url}
    except (requests.RequestException, ValueError, TypeError) as e:
        raise AssertionError(f"When MR12: Error during logout or inventory retrieval: {e}") from e


@then('the follow-up output should be identical to the seed output for MR12, as logging out does not modify inventory data.')
def _mr_MR12_assert_followup(context):
    try:
        seed = getattr(context, "seed_response", None)
        followup = getattr(context, "followup_response", None)
        if seed is None or followup is None:
            raise AssertionError(
                "Then MR12: Missing seed_response or followup_response on context."
            )

        # Deep equality comparison of the inventory maps
        if seed != followup:
            seed_str = json.dumps(seed, sort_keys=True)
            followup_str = json.dumps(followup, sort_keys=True)
            raise AssertionError(
                "Then MR12: Follow-up output does not match seed output.\n"
                f"Seed: {seed_str}\nFollow-up: {followup_str}"
            )
    except (TypeError, ValueError) as e:
        raise AssertionError(f"Then MR12: Error while comparing responses: {e}") from e

# ----




def _check_500(response, step_name: str) -> None:
    """Raise an AssertionError if the response status code is 500."""
    if response is not None and response.status_code == 500:
        raise AssertionError(
            f"MR14 - 500 Internal Server Error encountered during {step_name} step: "
            f"status_code=500, url={response.url}, body={response.text}"
        )


@given("a seed input that retrieves a user by username, producing a seed output with the user's current details for MR14.")
def _mr_MR14_seed_input(context):
    username = "theUser"
    context.seed_request = {
        "username": username
    }

    response = None
    try:
        url = f"{BASE_URL}/user/{username}"
        response = requests.get(url, timeout=10)
        _check_500(response, "GIVEN (getUserByName)")
        response.raise_for_status()

        # Ensure JSON decoding is safe
        try:
            data = response.json()
        except ValueError as e:
            raise AssertionError(f"MR14 - Failed to decode JSON in GIVEN step: {e}")

        if not isinstance(data, dict):
            raise AssertionError(
                f"MR14 - Expected JSON object for user in GIVEN step, got {type(data).__name__}"
            )

        context.seed_response = data
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"MR14 - HTTP error in GIVEN step for MR14: {e}") from e


@when("a follow-up input is created by updating the user's details for the same username, and the user is retrieved again by that username, yielding a follow-up output for MR14.")
def _mr_MR14_followup_input(context):
    if not hasattr(context, "seed_request") or not isinstance(context.seed_request, dict):
        raise AssertionError("MR14 - seed_request is missing or invalid in WHEN step")

    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("MR14 - seed_response is missing or invalid in WHEN step")

    username = context.seed_request.get("username")
    if not isinstance(username, str):
        raise AssertionError("MR14 - username in seed_request must be a string in WHEN step")

    seed = context.seed_response

    updated_user_data = {
        "id": seed.get("id"),
        "username": username,
        "firstName": "UpdatedFirstName",
        "firstName": "UpdatedFirstName",
        "lastName": seed.get("lastName"),
        "email": seed.get("email"),
        "password": seed.get("password"),
        "phone": seed.get("phone"),
        "userStatus": seed.get("userStatus"),
    }

    update_response = None
    followup_response = None
    try:
        # Update user (PUT /user/\{username\} - updateUser)
        update_url = f"{BASE_URL}/user/{username}"
        update_response = requests.put(update_url, json=updated_user_data, timeout=10)
        _check_500(update_response, "WHEN (updateUser)")
        update_response.raise_for_status()

        context.followup_request = {
            "username": username
        }

        # Retrieve user again (GET /user/\{username\} - getUserByName)
        followup_url = f"{BASE_URL}/user/{username}"
        followup_response = requests.get(followup_url, timeout=10)
        _check_500(followup_response, "WHEN (getUserByName follow-up)")
        followup_response.raise_for_status()

        try:
            data = followup_response.json()
        except ValueError as e:
            raise AssertionError(f"MR14 - Failed to decode JSON in WHEN follow-up step: {e}")

        if not isinstance(data, dict):
            raise AssertionError(
                f"MR14 - Expected JSON object for user in WHEN follow-up step, got {type(data).__name__}"
            )

        context.followup_response = data
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"MR14 - HTTP error in WHEN step for MR14: {e}") from e


@then("the follow-up output should show the updated fields for that username, while fields not modified by the update should match the seed output for MR14.")
def _mr_MR14_followup_output(context):
    if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
        raise AssertionError("MR14 - seed_response is missing or invalid in THEN step")

    if not hasattr(context, "followup_response") or not isinstance(context.followup_response, dict):
        raise AssertionError("MR14 - followup_response is missing or invalid in THEN step")

    seed = context.seed_response
    followup = context.followup_response

    # Defensive access using dict.get to avoid KeyError/TypeError
    assert followup.get("firstName") == "UpdatedFirstName", (
        f"MR14 - First name was not updated correctly. "
        f"Expected 'UpdatedFirstName', got {followup.get('firstName')!r}"
    )

    assert followup.get("lastName") == seed.get("lastName"), (
        f"MR14 - Last name should remain unchanged. "
        f"Seed: {seed.get('lastName')!r}, Follow-up: {followup.get('lastName')!r}"
    )
    assert followup.get("email") == seed.get("email"), (
        f"MR14 - Email should remain unchanged. "
        f"Seed: {seed.get('email')!r}, Follow-up: {followup.get('email')!r}"
    )
    assert followup.get("password") == seed.get("password"), (
        f"MR14 - Password should remain unchanged. "
        f"Seed: {seed.get('password')!r}, Follow-up: {followup.get('password')!r}"
    )
    assert followup.get("phone") == seed.get("phone"), (
        f"MR14 - Phone should remain unchanged. "
        f"Seed: {seed.get('phone')!r}, Follow-up: {followup.get('phone')!r}"
    )
    assert followup.get("userStatus") == seed.get("userStatus"), (
        f"MR14 - User status should remain unchanged. "
        f"Seed: {seed.get('userStatus')!r}, Follow-up: {followup.get('userStatus')!r}"
    )
