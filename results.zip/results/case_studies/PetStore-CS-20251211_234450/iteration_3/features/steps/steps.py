from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, step_name: str) -> None:
    """
    Utility to ensure no 500-level error responses pass silently.
    Raises an AssertionError that will fail the Behave step.
    """
    if 500 <= response.status_code <= 599:
        try:
            body = response.json()
        except ValueError:
            body = response.text
        raise AssertionError(
            f"Server error in {step_name}: status {response.status_code}, body: {body}"
        )


@given('a seed input that retrieves the inventory of pets by status, producing a seed output with the quantities of pets for each status for MR17.')
def _mr_MR17_seed_input(context):
    response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    _check_500(response, "Given MR17 /store/inventory")
    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        # Propagate as test failure with clear message
        raise AssertionError(f"HTTP error in Given step for MR17: {e}") from e

    try:
        context.seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in Given step for MR17: {e}") from e

    context.seed_request = None  # Explicit placeholder, kept for consistency


@when('a follow-up input is created by logging out the current user, and the inventory is retrieved again without performing any other operations that change inventory quantities, yielding a follow-up output for MR17.')
def _mr_MR17_followup_input(context):
    # Log out the user
    logout_response = requests.get(f"{BASE_URL}/user/logout", timeout=10)
    _check_500(logout_response, "When MR17 /user/logout")
    try:
        logout_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"HTTP error while logging out in When step for MR17: {e}") from e

    # Retrieve inventory again
    followup_response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
    _check_500(followup_response, "When MR17 /store/inventory follow-up")
    try:
        followup_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"HTTP error fetching follow-up inventory in When step for MR17: {e}") from e

    try:
        context.followup_response = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in When step for MR17 (follow-up inventory): {e}") from e

    context.followup_request = None  # Explicit placeholder, kept for consistency


@then('the follow-up output should be identical to the seed output for MR17, as logging out does not modify inventory data.')
def _mr_MR17_assert_followup(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("Seed response is missing in Then step for MR17.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response is missing in Then step for MR17.")

    try:
        seed_serialized = json.dumps(context.seed_response, sort_keys=True)
        followup_serialized = json.dumps(context.followup_response, sort_keys=True)
    except (TypeError, ValueError) as e:
        raise AssertionError(f"Error serializing responses for comparison in Then step for MR17: {e}") from e

    assert seed_serialized == followup_serialized, (
        "Follow-up output does not match seed output for MR17."
    )

# ----






@given("a seed input that retrieves a user by username, producing a seed output with that user's current details for MR19.")
def _mr_MR19_seed_input(context):
    username = "theUser"
    context.seed_request = {
        "username": username
    }
    try:
        response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
        _check_500(response, "GIVEN MR19")
        # For non-2xx that are not 5xx, raise for status to surface clear failure
        response.raise_for_status()
        # Safely parse JSON; if empty body, use empty dict
        try:
            context.seed_response = response.json()
        except ValueError:
            context.seed_response = {}
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in GIVEN step for MR19: {e}") from e


@when("a follow-up input is created by updating the user's details for the same username, and the user is retrieved again by that username, yielding a follow-up output for MR19.")
def _mr_MR19_followup_input(context):
    if not hasattr(context, "seed_request"):
        raise AssertionError("Seed request not found in context for MR19.")
    username = context.seed_request.get("username")
    if not isinstance(username, str) or not username:
        raise AssertionError("Username in seed_request is missing or not a valid string for MR19.")

    seed_response = getattr(context, "seed_response", {})
    if not isinstance(seed_response, dict):
        seed_response = {}

    updated_user = {
        "id": seed_response.get("id"),
        "username": username,
        "firstName": "UpdatedFirstName",
        "lastName": "UpdatedLastName",
        "email": "updated@example.com",
        "password": "newpassword",
        "phone": "1234567890",
        "userStatus": 1
    }

    try:
        update_response = requests.put(f"{BASE_URL}/user/{username}", json=updated_user, timeout=10)
        _check_500(update_response, "WHEN MR19 - updateUser")
        update_response.raise_for_status()

        followup_response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
        _check_500(followup_response, "WHEN MR19 - getUserByName (follow-up)")
        followup_response.raise_for_status()
        try:
            context.followup_response = followup_response.json()
        except ValueError:
            context.followup_response = {}
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in WHEN step for MR19: {e}") from e


@then("the follow-up output should show the user details matching the data provided in the update operation for that username.")
def _mr_MR19_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AssertionError("Follow-up response not found in context for MR19.")
    followup = context.followup_response
    if not isinstance(followup, dict):
        raise AssertionError(f"Follow-up response is not a JSON object: {followup!r}")

    expected = {
        "firstName": "UpdatedFirstName",
        "lastName": "UpdatedLastName",
        "email": "updated@example.com",
        "phone": "1234567890",
        "userStatus": 1,
    }

    for field, expected_value in expected.items():
        if field not in followup:
            raise AssertionError(f"Field '{field}' missing in follow-up response for MR19.")
        actual_value = followup[field]
        if actual_value != expected_value:
            raise AssertionError(
                f"Field '{field}' did not match for MR19: expected {expected_value!r}, got {actual_value!r}"
            )
