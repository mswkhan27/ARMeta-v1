Feature: Iteration 3 MRs

  Scenario: MR17 Retrieving inventory should remain consistent after logout
    Given a seed input that retrieves the inventory of pets by status, producing a seed output with the quantities of pets for each status for MR17.
    When a follow-up input is created by logging out the current user, and the inventory is retrieved again without performing any other operations that change inventory quantities, yielding a follow-up output for MR17.
    Then the follow-up output should be identical to the seed output for MR17, as logging out does not modify inventory data.

  Scenario: MR19 Updating a user's details should reflect in subsequent retrieval by username
    Given a seed input that retrieves a user by username, producing a seed output with that user's current details for MR19.
    When a follow-up input is created by updating the user's details for the same username, and the user is retrieved again by that username, yielding a follow-up output for MR19.
    Then the follow-up output should show the user details matching the data provided in the update operation for that username.
