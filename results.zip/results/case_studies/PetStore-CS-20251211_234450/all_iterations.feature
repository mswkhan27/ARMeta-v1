
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet with a given status should increase the count for that status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of pets in status 'available' for MR1.
    When a follow-up input is created by adding a new pet whose status is set to 'available', and the list of pets is retrieved again using status 'available', yielding a follow-up output for MR1.
    Then the follow-up output should have a count of pets in status 'available' that is one more than the seed output for MR1, assuming no other operations modified pets with status 'available' in between.

  Scenario: MR2 Updating a pet's status should reflect in subsequent status-based retrieval
    Given a seed input that retrieves the list of pets filtered by status 'pending', producing a seed output with a list of pets in status 'pending' for MR2.
    When a follow-up input is created by updating one of these pet's status from 'pending' to 'sold', and the list of pets is retrieved again using status 'pending', yielding a follow-up output for MR2.
    Then the follow-up output should no longer include the updated pet in the list of pets with status 'pending', differing from the seed output for MR2.

  Scenario: MR3 Deleting a pet should decrease the count of pets for that pet’s status
    Given a seed input that retrieves the list of pets filtered by a specific status (for example, 'available') that includes a particular pet, producing a seed output with a count of pets for that status for MR3.
    When a follow-up input is created by deleting that specific pet, and the list of pets is retrieved again using the same status filter, yielding a follow-up output for MR3.
    Then the follow-up output should have a count of pets for that status that is one less than the seed output for MR3, assuming no other operations modified pets with that status in between.

  Scenario: MR4 Finding pets by multiple tags should include all pets found by a subset of those tags
    Given a seed input that retrieves pets filtered by the tag 'tag1', producing a seed output with a list of pets for MR4.
    When a follow-up input is created by retrieving pets filtered by both 'tag1' and an additional tag 'tag2', yielding a follow-up output for MR4.
    Then the follow-up output should include all pets that appeared in the seed output (those matching 'tag1'), plus any additional pets that match either 'tag1' or 'tag2' for MR4.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR5 Deleting a user should result in the user no longer being retrievable
    Given a seed input that retrieves a user by username, producing a seed output with the user's details for MR5.
    When a follow-up input is created by deleting the user with the same username, and an attempt is made to retrieve the user again, yielding a follow-up output for MR5.
    Then the follow-up output should indicate that the user is not found (for example, via a corresponding error status or message), differing from the seed output for MR5.

  Scenario: MR7 Updating a pet's name should reflect in subsequent retrieval by ID
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's current name for MR7.
    When a follow-up input is created by updating the pet's representation so that its name is changed while keeping the same identifier, and the pet is retrieved again by the same ID, yielding a follow-up output for MR7.
    Then the follow-up output should have the updated name in its representation, differing from the seed output for MR7.

  Scenario: MR8 Uploading an image for a pet should not alter the pet's existing details
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR8.
    When a follow-up input is created by uploading an image for the same pet, and the pet is retrieved again by the same ID, yielding a follow-up output for MR8.
    Then the follow-up output should have the same pet details as the seed output for MR8, since uploading an image does not modify the stored pet representation.

  Scenario: MR9 Repeated logins should consistently provide login response data with expiration information
    Given a seed input that logs in a user with valid credentials, producing a seed output that includes a response body and login-related headers such as rate limit and expiration time for MR9.
    When a follow-up input is created by logging in the same user again with the same credentials, yielding a follow-up output for MR9.
    Then both the seed and follow-up outputs should indicate successful login and include headers conveying rate limit and expiration time information, and the follow-up output may differ from the seed output in the specific header or body values while still conforming to the same structure.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR12 Logging out should not affect the inventory data
    Given a seed input that retrieves the inventory of pets by status, producing a seed output with the count of pets in each status for MR12.
    When a follow-up input is created by logging out the current user, and the inventory is retrieved again without performing any other operations that change inventory counts, yielding a follow-up output for MR12.
    Then the follow-up output should be identical to the seed output for MR12, as logging out does not modify inventory data.

  Scenario: MR14 Updating a user's details should reflect in subsequent retrieval by username
    Given a seed input that retrieves a user by username, producing a seed output with the user's current details for MR14.
    When a follow-up input is created by updating the user's details for the same username, and the user is retrieved again by that username, yielding a follow-up output for MR14.
    Then the follow-up output should show the updated fields for that username, while fields not modified by the update should match the seed output for MR14.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR17 Retrieving inventory should remain consistent after logout
    Given a seed input that retrieves the inventory of pets by status, producing a seed output with the quantities of pets for each status for MR17.
    When a follow-up input is created by logging out the current user, and the inventory is retrieved again without performing any other operations that change inventory quantities, yielding a follow-up output for MR17.
    Then the follow-up output should be identical to the seed output for MR17, as logging out does not modify inventory data.

  Scenario: MR19 Updating a user's details should reflect in subsequent retrieval by username
    Given a seed input that retrieves a user by username, producing a seed output with that user's current details for MR19.
    When a follow-up input is created by updating the user's details for the same username, and the user is retrieved again by that username, yielding a follow-up output for MR19.
    Then the follow-up output should show the user details matching the data provided in the update operation for that username.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR22 Retrieving an order by ID should return consistent details
    Given a seed input that retrieves an existing order by a valid identifier, producing a seed output with the order's details for MR22.
    When a follow-up input is created by retrieving the same order using the same valid identifier again, yielding a follow-up output for MR22.
    Then the follow-up output should be identical to the seed output for MR22, assuming no operations modified or deleted that order between the two retrievals.

  Scenario: MR24 Updating a pet with form data should reflect in subsequent retrieval by ID
    Given a seed input that retrieves an existing pet by its identifier, producing a seed output with the pet's current details for MR24.
    When a follow-up input is created by updating that pet's details using form data (such as its name and/or status), and the pet is retrieved again by the same identifier, yielding a follow-up output for MR24.
    Then the follow-up output should reflect the updated form data fields for the pet (for example, the new name and/or status), while other fields remain unchanged compared to the seed output for MR24, except for any fields that the system may legitimately modify automatically.


# --- From iteration_5\features\mrs_iteration_5.feature ---

Feature: Iteration 5 MRs

  Scenario: MR25 Deleting an order should result in the order no longer being retrievable
    Given a seed input that retrieves an existing purchase order by a valid order ID (for which a successful response is returned), producing a seed output with that order's details for MR25.
    When a follow-up input is created by deleting the purchase order with the same valid order ID, and an attempt is then made to retrieve the order again using that ID, yielding a follow-up output for MR25.
    Then the follow-up output should indicate that the order is not found (for example, via a corresponding error status or message), differing from the successful seed output for MR25.

  Scenario: MR26 Creating multiple users with a list should result in all those users being individually retrievable
    Given a seed input that retrieves details for a set of existing users by their usernames, producing a seed output that conceptually represents the current list of those users for MR26.
    When a follow-up input is created by adding a list of new users using the list-based user-creation operation, and then details are retrieved individually for these newly created users by their usernames, yielding a follow-up output for MR26.
    Then the follow-up output, when considered together with the seed output, should include user details for all users from the seed output plus the newly added users, meaning that the combined set of retrieved users after creation is a superset of the seed set for MR26.

