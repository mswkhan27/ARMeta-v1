from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given("a seed input that retrieves a permission's details by its key, producing a seed output with that permission's information for MR20.")
def step_mr_MR20_seed_input(context):
    permission_key = "example_permission_key"  # Replace with actual key if needed
    url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"

    response = requests.get(url, timeout=10)
    context.seed_status_code = response.status_code

    # Only attempt to parse JSON and save if status is 200
    context.seed_response = None
    if response.status_code == 200:
        try:
            context.seed_response = response.json()
        except ValueError:
            context.seed_response = None

    assert context.seed_status_code == 200, (
        f"Failed to retrieve permission: {response.status_code} {response.text}"
    )


@when("a follow-up input is created by first deleting the permission using the DELETE operation on the permission key and then retrieving the list of permissions using a read operation, yielding a follow-up output for MR20.")
def step_mr_MR20_followup_input(context):
    permission_key = "example_permission_key"  # Replace with actual key if needed

    # Delete the permission by key
    delete_url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"
    delete_response = requests.delete(delete_url, timeout=10)
    context.delete_status_code = delete_response.status_code

    assert delete_response.status_code in (200, 204), (
        f"Failed to delete permission: {delete_response.status_code} {delete_response.text}"
    )

    # Retrieve the list of permissions
    list_url = f"{BASE_URL}/users/rbac/permissions"
    list_response = requests.get(list_url, timeout=10)
    context.followup_status_code = list_response.status_code

    # Safely parse JSON; if parsing fails, use empty list to avoid TypeError
    try:
        parsed = list_response.json()
    except ValueError:
        parsed = []

    # The spec defines the response as an array of PermissionDTO
    context.followup_response = parsed if isinstance(parsed, list) else []

    assert context.followup_status_code == 200, (
        f"Failed to retrieve permissions list: {list_response.status_code} {list_response.text}"
    )


@then("the follow-up output should not contain the deleted permission in the retrieved permission list, indicating it has been removed compared to the seed output for MR20.")
def step_mr_MR20_followup_output(context):
    # Ensure seed_response is a dict to avoid AttributeError/TypeError
    seed = context.seed_response if isinstance(context.seed_response, dict) else {}

    deleted_permission = seed.get("permission")
    # If we couldn't determine the permission key from the seed, we cannot assert removal
    assert deleted_permission is not None, "Seed permission does not contain a 'permission' field."

    # Build a list of permission identifiers safely
    permission_values = []
    for perm in context.followup_response:
        if isinstance(perm, dict) and "permission" in perm:
            permission_values.append(perm.get("permission"))

    assert deleted_permission not in permission_values, (
        "Deleted permission is still present in the list."
    )

# ----




@given("a seed input that retrieves a role's details by its ID, producing a seed output with the role's information for MR21.")
def step_mr_MR21_seed_input(context):
    # Create a role to ensure it exists before retrieval
    role_data = {"role": "TestRole"}
    response = requests.post(f"{BASE_URL}/users/rbac/roles", json=role_data, timeout=10)

    # Ensure we created the role successfully and got JSON back
    if response.status_code not in (200, 201):
        raise AssertionError(f"Failed to create role, status={response.status_code}, body={response.text}")

    try:
        seed_json = response.json()
    except ValueError as e:
        raise AssertionError(f"Create role response is not valid JSON: {e}, body={response.text}")

    role_id = seed_json.get("id")
    if role_id is None:
        raise AssertionError(f"'id' field missing in create role response JSON: {json.dumps(seed_json, ensure_ascii=False)}")

    context.role_id = role_id

    # Retrieve the created role as the seed output
    get_response = requests.get(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)

    if get_response.status_code != 200:
        raise AssertionError(
            f"Failed to retrieve role after creation, status={get_response.status_code}, body={get_response.text}"
        )

    try:
        context.seed_response = get_response.json()
    except ValueError as e:
        raise AssertionError(f"Get role response is not valid JSON: {e}, body={get_response.text}")


@when("a follow-up input is created by deleting the role using the DELETE operation on the role ID and then attempting to retrieve the same role again using a read operation, yielding a follow-up output for MR21.")
def step_mr_MR21_followup_input(context):
    if not hasattr(context, "role_id"):
        raise AssertionError("role_id is not set in context; Given step may have failed or not run.")

    # Delete the role
    delete_response = requests.delete(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
    if delete_response.status_code not in (200, 204):
        raise AssertionError(
            f"Failed to delete role, status={delete_response.status_code}, body={delete_response.text}"
        )

    context.delete_response_status = delete_response.status_code

    # Attempt to retrieve the deleted role
    get_after_delete = requests.get(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
    context.followup_status = get_after_delete.status_code
    context.followup_body = get_after_delete.text


@then("the delete operation should return a success status (such as 'OK' or 'No Content'), and the subsequent retrieval should not return the deleted role (for example, by resulting in a not-found response or by its absence), indicating the role has been successfully removed compared to the seed output for MR21.")
def step_mr_MR21_assertion(context):
    if not hasattr(context, "delete_response_status"):
        raise AssertionError("Delete response status not found in context; When step may have failed or not run.")

    if not hasattr(context, "followup_status"):
        raise AssertionError("Follow-up status not found in context; When step may have failed or not run.")

    # Confirm delete operation succeeded as per OpenAPI (200 or 204)
    assert context.delete_response_status in (200, 204), (
        f"Delete operation did not succeed, status={context.delete_response_status}"
    )

    # OpenAPI specifies 404 for not found; ensure the role is no longer retrievable
    assert context.followup_status == 404, (
        f"Role was not deleted successfully; expected 404 on retrieval, got "
        f"{context.followup_status} with body: {context.followup_body}"
    )

# ----




@given('a seed input that requests a salt generation, producing a seed output with a salt value for MR22.')
def step_mr_MR22_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/salt", timeout=10)
    response.raise_for_status()
    # Response schema: type=string, so use text safely
    context.seed_response = response.text
    context.seed_request = response.request


@when('a follow-up input is created by requesting another salt generation, yielding a follow-up output for MR22.')
def step_mr_MR22_followup_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/salt", timeout=10)
    response.raise_for_status()
    context.followup_response = response.text
    context.followup_request = response.request


@then('the follow-up output should contain a salt value that is different from the seed output for MR22, reflecting that salts are generated as distinct values across calls.')
def step_mr_MR22_assert_different_salts(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    # Basic safety checks to avoid TypeError
    if seed is None or followup is None:
        raise AssertionError("Seed or follow-up response is missing from context.")

    if not isinstance(seed, str) or not isinstance(followup, str):
        raise AssertionError("Salt responses must be string values.")

    assert seed != followup, "The follow-up salt is not different from the seed salt."

# ----




@given('a seed input that retrieves error information using the GET method, producing a seed output with the response status code and headers for MR23.')
def step_mr_MR23_seed_input(context):
    response = requests.get(f"{BASE_URL}/error", timeout=10)
    context.seed_response = response
    assert response is not None, "Seed response is None"
    assert isinstance(response.status_code, int), "Status code is not an integer"
    assert response.status_code in [200, 401, 403, 404], "Unexpected status code for GET /error"


@when('a follow-up input is created by retrieving error information using the HEAD method, yielding a follow-up output for MR23.')
def step_mr_MR23_followup_input(context):
    response = requests.head(f"{BASE_URL}/error", timeout=10)
    context.followup_response = response
    assert response is not None, "Follow-up response is None"
    assert isinstance(response.status_code, int), "Status code is not an integer"
    assert response.status_code in [200, 204, 401, 403], "Unexpected status code for HEAD /error"


@then('the follow-up output should have the same response status code and compatible headers as the seed output for MR23, with the HEAD response not including a message body.')
def step_mr_MR23_followup_output(context):
    assert hasattr(context, "seed_response"), "seed_response not found in context"
    assert hasattr(context, "followup_response"), "followup_response not found in context"

    seed_status = context.seed_response.status_code
    follow_status = context.followup_response.status_code

    assert isinstance(seed_status, int) and isinstance(follow_status, int), "Status codes must be integers"
    assert follow_status == seed_status or (seed_status == 200 and follow_status == 204), \
        "Status codes are not consistent between GET and HEAD for /error"

    seed_headers = getattr(context.seed_response, "headers", {}) or {}
    follow_headers = getattr(context.followup_response, "headers", {}) or {}

    assert isinstance(seed_headers, dict), "Seed headers are not a dictionary-like object"
    assert isinstance(follow_headers, dict), "Follow-up headers are not a dictionary-like object"

    for header, seed_value in seed_headers.items():
        header_l = str(header).lower()
        if header_l in ["content-length", "transfer-encoding"]:
            continue
        follow_value = follow_headers.get(header)
        assert follow_value == seed_value, f"Header '{header}' does not match between GET and HEAD for /error"

    follow_body = getattr(context.followup_response, "content", b"")
    assert not follow_body, "HEAD response should not include a message body"
