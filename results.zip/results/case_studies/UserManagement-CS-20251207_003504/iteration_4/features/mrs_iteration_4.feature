Feature: Iteration 4 MRs

  Scenario: MR20 Deleting a permission by key should remove it from the permission list
    Given a seed input that retrieves a permission's details by its key, producing a seed output with that permission's information for MR20.
    When a follow-up input is created by first deleting the permission using the DELETE operation on the permission key and then retrieving the list of permissions using a read operation, yielding a follow-up output for MR20.
    Then the follow-up output should not contain the deleted permission in the retrieved permission list, indicating it has been removed compared to the seed output for MR20.

  Scenario: MR21 Deleting a role by ID should remove it from subsequent retrievals
    Given a seed input that retrieves a role's details by its ID, producing a seed output with the role's information for MR21.
    When a follow-up input is created by deleting the role using the DELETE operation on the role ID and then attempting to retrieve the same role again using a read operation, yielding a follow-up output for MR21.
    Then the delete operation should return a success status (such as 'OK' or 'No Content'), and the subsequent retrieval should not return the deleted role (for example, by resulting in a not-found response or by its absence), indicating the role has been successfully removed compared to the seed output for MR21.

  Scenario: MR22 Generating a salt should produce a different value on subsequent calls
    Given a seed input that requests a salt generation, producing a seed output with a salt value for MR22.
    When a follow-up input is created by requesting another salt generation, yielding a follow-up output for MR22.
    Then the follow-up output should contain a salt value that is different from the seed output for MR22, reflecting that salts are generated as distinct values across calls.

  Scenario: MR23 Retrieving error status via different methods should yield consistent metadata
    Given a seed input that retrieves error information using the GET method, producing a seed output with the response status code and headers for MR23.
    When a follow-up input is created by retrieving error information using the HEAD method, yielding a follow-up output for MR23.
    Then the follow-up output should have the same response status code and compatible headers as the seed output for MR23, with the HEAD response not including a message body.
