
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new user should increase the user list size by one
    Given a seed input that retrieves the list of users, producing a seed output with a count of users for MR1.
    When a follow-up input is created by first adding a new user using the user-creation operation and then retrieving the list of users again, yielding a follow-up output for MR1.
    Then the follow-up output should have a user list size that is one greater than the seed output for MR1, assuming the newly created user was not already present in the seed output.

  Scenario: MR2 Deleting a user should decrease the user list size by one
    Given a seed input that retrieves the list of users, producing a seed output with a count of users for MR2.
    When a follow-up input is created by first deleting an existing user using the user-deletion operation and then retrieving the list of users again, yielding a follow-up output for MR2.
    Then the follow-up output should have a user list size that is one less than the seed output for MR2, assuming the deleted user was present in the seed output.

  Scenario: MR3 Updating a user's information should change the returned data for the updated fields
    Given a seed input that retrieves a user's details by ID, producing a seed output with user information for MR3.
    When a follow-up input is created by updating the user's information using the user-update operation, yielding a follow-up output for MR3.
    Then the follow-up output should reflect the new values for all fields provided in the update request for MR3, while still representing the same user as in the seed output.

  Scenario: MR4 Adding a permission to a role should increase the role's permission list size by one
    Given a seed input that retrieves a role's details by its ID, producing a seed output that includes the role's list of permissions for MR4.
    When a follow-up input is created by adding a permission to the role using the role-permission-assignment operation, yielding a follow-up output for MR4 that includes the updated role data.
    Then the follow-up output should have a permission list size that is one greater than the seed output for MR4, assuming the added permission was not already present in the role.

  Scenario: MR5 Removing a permission from a role should decrease the role's permission list size by one
    Given a seed input that retrieves a role's details by its ID, producing a seed output that includes the role's list of permissions for MR5.
    When a follow-up input is created by removing a permission from the role using the role-permission-removal operation, yielding a follow-up output for MR5 that includes the updated role data.
    Then the follow-up output should have a permission list size that is one less than the seed output for MR5, assuming the removed permission was present in the role in the seed output.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR6 Logging in with valid credentials should consistently identify the same user
    Given a seed input with valid login credentials, producing a seed output with a UserDTO object that contains the authenticated user details for MR6.
    When a follow-up input is created by using the same valid login credentials, yielding a follow-up output for MR6.
    Then the follow-up output should correspond to the same user as in the seed output for MR6 (for example, same user id and username), although dynamic fields such as login timestamps may legitimately differ.

  Scenario: MR7 Registering a new user should increase the total number of users
    Given a seed input that retrieves the list of users, producing a seed output with a count of users from the returned UserListDTO for MR7.
    When a follow-up input is created by registering a new user using the user registration operation and then retrieving the list of users again, yielding a follow-up output for MR7.
    Then the follow-up output should have a user list size that is one greater than the seed output for MR7, assuming the registration succeeds and the newly registered user was not already present in the seed output.

  Scenario: MR8 Deleting a role should remove it from the role list
    Given a seed input that retrieves the list of roles, producing a seed output with a count of roles for MR8.
    When a follow-up input is created by deleting an existing role using the role-deletion operation and then retrieving the list of roles again, yielding a follow-up output for MR8.
    Then the follow-up output should have a role list size that is one less than the seed output for MR8, assuming the deleted role existed and was present in the seed output.

  Scenario: MR9 Adding a role to a user should increase the user's role list size by one
    Given a seed input that retrieves a user's details by ID, producing a seed output that includes the user's list of roles in the UserDTO for MR9.
    When a follow-up input is created by adding a role to the user using the user-role-assignment operation, yielding a follow-up output for MR9 that includes the updated user data.
    Then the follow-up output should have a role list size that is one greater than the seed output for MR9, assuming the added role was not already present in the user's roles.

  Scenario: MR10 Removing a role from a user should decrease the user's role list size by one
    Given a seed input that retrieves a user's details by ID, producing a seed output that includes the user's list of roles in the UserDTO for MR10.
    When a follow-up input is created by removing a role from the user using the user-role-removal operation, yielding a follow-up output for MR10 that includes the updated user data.
    Then the follow-up output should have a role list size that is one less than the seed output for MR10, assuming the removed role was present in the user's roles in the seed output.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR11 Deleting a permission should remove it from the permission list
    Given a seed input that retrieves the list of permissions, producing a seed output with a count of permissions for MR11.
    When a follow-up input is created by deleting an existing permission using the permission-deletion operation and then retrieving the list of permissions again, yielding a follow-up output for MR11.
    Then the follow-up output should have a permission list size that is one less than the seed output for MR11, assuming the deleted permission existed and no other permissions were added or removed between the two retrievals.

  Scenario: MR12 Generating a salt should produce a different value on subsequent calls
    Given a seed input that requests a salt generation, producing a seed output with a salt value for MR12.
    When a follow-up input is created by requesting another salt generation, yielding a follow-up output for MR12.
    Then the follow-up output should contain a salt value that is different from the seed output for MR12, reflecting that salts are generated as distinct values across calls.

  Scenario: MR13 Retrieving error status via different methods should yield consistent metadata
    Given a seed input that retrieves error information using the GET method, producing a seed output with the response status code and headers for MR13.
    When a follow-up input is created by retrieving error information using the HEAD method, yielding a follow-up output for MR13.
    Then the follow-up output should have the same response status code and compatible headers as the seed output for MR13, with the HEAD response not including a message body.

  Scenario: MR14 Updating a permission should reflect the changes in the permission details
    Given a seed input that retrieves a permission's details by its key, producing a seed output with that permission's information, including its current field values, for MR14.
    When a follow-up input is created by updating that permission's details using the permission-update operation for the same permission identifier (for example, key or id) and then retrieving the permission details again, yielding a follow-up output for MR14.
    Then the follow-up output should reflect the new values for all fields provided in the update request for MR14, while preserving the permission identifier so that it still represents the same permission as in the seed output.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR15 Deleting an error should result in no content
    Given a seed input that retrieves error information using the GET method, producing a seed output with the error details for MR15.
    When a follow-up input is created by deleting the error using the DELETE operation, yielding a follow-up output for MR15.
    Then the follow-up output should return a status of 'No Content', indicating the error has been successfully deleted, and the error details should no longer be present compared to the seed output for MR15.

  Scenario: MR16 Deleting a permission by key should remove it from the permission list
    Given a seed input that retrieves a permission's details by its key, producing a seed output with that permission's information for MR16.
    When a follow-up input is created by first deleting the permission using the DELETE operation on the permission key and then retrieving the list of permissions using a read operation, yielding a follow-up output for MR16.
    Then the follow-up output should not contain the deleted permission in the retrieved permission list, indicating it has been removed compared to the seed output for MR16.

  Scenario: MR17 Deleting a role by ID should remove it from subsequent retrievals
    Given a seed input that retrieves a role's details by its ID, producing a seed output with the role's information for MR17.
    When a follow-up input is created by deleting the role using the DELETE operation on the role ID and then attempting to retrieve the same role again using a read operation, yielding a follow-up output for MR17.
    Then the delete operation should return a success status (such as 'OK' or 'No Content'), and the subsequent retrieval should not return the deleted role (for example, by resulting in a not-found response or by its absence), indicating the role has been successfully removed compared to the seed output for MR17.

  Scenario: MR18 Retrieving a permission by key should yield consistent details
    Given a seed input that retrieves a permission's details by its key, producing a seed output with that permission's information for MR18.
    When a follow-up input is created by retrieving the same permission's details again using the GET operation on the same permission key, yielding a follow-up output for MR18.
    Then the follow-up output should contain the same permission details as the seed output for MR18, ensuring consistency in retrieval as long as the permission has not been modified or deleted between the two requests.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR20 Deleting a permission by key should remove it from the permission list
    Given a seed input that retrieves a permission's details by its key, producing a seed output with that permission's information for MR20.
    When a follow-up input is created by first deleting the permission using the DELETE operation on the permission key and then retrieving the list of permissions using a read operation, yielding a follow-up output for MR20.
    Then the follow-up output should not contain the deleted permission in the retrieved permission list, indicating it has been removed compared to the seed output for MR20.

  Scenario: MR21 Deleting a role by ID should remove it from subsequent retrievals
    Given a seed input that retrieves a role's details by its ID, producing a seed output with the role's information for MR21.
    When a follow-up input is created by deleting the role using the DELETE operation on the role ID and then attempting to retrieve the same role again using a read operation, yielding a follow-up output for MR21.
    Then the delete operation should return a success status (such as 'OK' or 'No Content'), and the subsequent retrieval should not return the deleted role (for example, by resulting in a not-found response or by its absence), indicating the role has been successfully removed compared to the seed output for MR21.

  Scenario: MR22 Generating a salt should produce a different value on subsequent calls
    Given a seed input that requests a salt generation, producing a seed output with a salt value for MR22.
    When a follow-up input is created by requesting another salt generation, yielding a follow-up output for MR22.
    Then the follow-up output should contain a salt value that is different from the seed output for MR22, reflecting that salts are generated as distinct values across calls.

  Scenario: MR23 Retrieving error status via different methods should yield consistent metadata
    Given a seed input that retrieves error information using the GET method, producing a seed output with the response status code and headers for MR23.
    When a follow-up input is created by retrieving error information using the HEAD method, yielding a follow-up output for MR23.
    Then the follow-up output should have the same response status code and compatible headers as the seed output for MR23, with the HEAD response not including a message body.

