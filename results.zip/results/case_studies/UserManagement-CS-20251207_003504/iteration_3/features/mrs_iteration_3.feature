Feature: Iteration 3 MRs

  Scenario: MR15 Deleting an error should result in no content
    Given a seed input that retrieves error information using the GET method, producing a seed output with the error details for MR15.
    When a follow-up input is created by deleting the error using the DELETE operation, yielding a follow-up output for MR15.
    Then the follow-up output should return a status of 'No Content', indicating the error has been successfully deleted, and the error details should no longer be present compared to the seed output for MR15.

  Scenario: MR16 Deleting a permission by key should remove it from the permission list
    Given a seed input that retrieves a permission's details by its key, producing a seed output with that permission's information for MR16.
    When a follow-up input is created by first deleting the permission using the DELETE operation on the permission key and then retrieving the list of permissions using a read operation, yielding a follow-up output for MR16.
    Then the follow-up output should not contain the deleted permission in the retrieved permission list, indicating it has been removed compared to the seed output for MR16.

  Scenario: MR17 Deleting a role by ID should remove it from subsequent retrievals
    Given a seed input that retrieves a role's details by its ID, producing a seed output with the role's information for MR17.
    When a follow-up input is created by deleting the role using the DELETE operation on the role ID and then attempting to retrieve the same role again using a read operation, yielding a follow-up output for MR17.
    Then the delete operation should return a success status (such as 'OK' or 'No Content'), and the subsequent retrieval should not return the deleted role (for example, by resulting in a not-found response or by its absence), indicating the role has been successfully removed compared to the seed output for MR17.

  Scenario: MR18 Retrieving a permission by key should yield consistent details
    Given a seed input that retrieves a permission's details by its key, producing a seed output with that permission's information for MR18.
    When a follow-up input is created by retrieving the same permission's details again using the GET operation on the same permission key, yielding a follow-up output for MR18.
    Then the follow-up output should contain the same permission details as the seed output for MR18, ensuring consistency in retrieval as long as the permission has not been modified or deleted between the two requests.
