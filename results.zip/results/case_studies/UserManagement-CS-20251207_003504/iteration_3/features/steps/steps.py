from behave import given, when, then
import os
import requests

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


@given("a seed input that retrieves error information using the GET method, producing a seed output with the error details for MR15.")
def step_mr_MR15_seed_input(context):
    url = f"{BASE_URL}/error"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        try:
            context.seed_response = response.json()
        except ValueError:
            context.seed_response = response.text
        context.seed_request = response.request
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in Given step for MR15 (GET {url}): {e}") from e


@when("a follow-up input is created by deleting the error using the DELETE operation, yielding a follow-up output for MR15.")
def step_mr_MR15_followup_input(context):
    url = f"{BASE_URL}/error"
    try:
        response = requests.delete(url, timeout=10)
        context.followup_response = response
        context.followup_request = response.request
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in When step for MR15 (DELETE {url}): {e}") from e


@then("the follow-up output should return a status of 'No Content', indicating the error has been successfully deleted, and the error details should no longer be present compared to the seed output for MR15.")
def step_mr_MR15_followup_output(context):
    followup_response = getattr(context, "followup_response", None)
    assert followup_response is not None, "followup_response is not set in context"
    assert followup_response.status_code == 204, (
        f"Expected status code 204 for No Content, got {followup_response.status_code}"
    )

    url = f"{BASE_URL}/error"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        try:
            followup_output = response.json()
        except ValueError:
            followup_output = response.text
    except requests.exceptions.RequestException as e:
        raise AssertionError(f"Error in Then step for MR15 (GET {url}): {e}") from e

    seed_response = getattr(context, "seed_response", None)
    assert seed_response is not None, "seed_response is not set in context"
    assert followup_output != seed_response, (
        "Error details should no longer be present; follow-up output matches seed output"
    )

# ----

import json



@given("a seed input that retrieves a permission's details by its key, producing a seed output with that permission's information for MR16.")
def step_mr_MR16_seed_input(context):
    permission_key = "example_permission_key"  # Replace with a real key if needed
    url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"

    response = requests.get(url, timeout=10)
    context.seed_status_code = response.status_code

    # Safely parse JSON; fall back to empty dict
    try:
        context.seed_response = response.json()
    except ValueError:
        context.seed_response = {}

    assert context.seed_status_code == 200, (
        f"Failed to retrieve permission: {context.seed_status_code} {response.text}"
    )

    # Store the key used so that When/Then use the same one safely
    context.permission_key = permission_key


@when("a follow-up input is created by first deleting the permission using the DELETE operation on the permission key and then retrieving the list of permissions using a read operation, yielding a follow-up output for MR16.")
def step_mr_MR16_followup_input(context):
    permission_key = getattr(context, "permission_key", "example_permission_key")

    delete_url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"
    delete_response = requests.delete(delete_url, timeout=10)
    context.delete_status_code = delete_response.status_code

    assert context.delete_status_code in (200, 204), (
        f"Failed to delete permission: {context.delete_status_code} {delete_response.text}"
    )

    list_url = f"{BASE_URL}/users/rbac/permissions"
    list_response = requests.get(list_url, timeout=10)
    context.followup_status_code = list_response.status_code

    # Safely parse JSON; fall back to empty list
    try:
        data = list_response.json()
    except ValueError:
        data = []

    # According to OpenAPI, this should be an array of PermissionDTO
    if isinstance(data, list):
        context.followup_response = data
    else:
        # If the API returns an unexpected shape, normalize to a list to avoid TypeError
        context.followup_response = []

    assert context.followup_status_code == 200, (
        f"Failed to retrieve permissions list: {context.followup_status_code} {list_response.text}"
    )


@then("the follow-up output should not contain the deleted permission in the retrieved permission list, indicating it has been removed compared to the seed output for MR16.")
def step_mr_MR16_followup_output(context):
    deleted_permission_key = getattr(context, "permission_key", "example_permission_key")

    permissions_list = getattr(context, "followup_response", [])
    if not isinstance(permissions_list, list):
        permissions_list = []

    # Safely check entries; tolerate missing keys or non-dict items
    for item in permissions_list:
        if isinstance(item, dict) and item.get("permission") == deleted_permission_key:
            raise AssertionError(
                "Deleted permission is still present in the follow-up output."
            )

# ----




@given("a seed input that retrieves a role's details by its ID, producing a seed output with the role's information for MR17.")
def _mr_MR17_seed_input(context):
    # Create a role to ensure it exists
    role_data = "TestRole"
    create_resp = requests.post(
        f"{BASE_URL}/users/rbac/roles",
        json=role_data,
        timeout=10,
    )

    # Safely get created role id from JSON body
    role_json = {}
    try:
        role_json = create_resp.json()
    except ValueError:
        pass

    role_id = role_json.get("id")
    if role_id is None:
        raise AssertionError(f"Role creation did not return an id. Status: {create_resp.status_code}, Body: {create_resp.text}")

    context.role_id = role_id
    context.create_role_response = create_resp

    # Retrieve the role details by ID
    seed_resp = requests.get(
        f"{BASE_URL}/users/rbac/roles/{context.role_id}",
        timeout=10,
    )
    context.seed_get_response = seed_resp


@when("a follow-up input is created by deleting the role using the DELETE operation on the role ID and then attempting to retrieve the same role again using a read operation, yielding a follow-up output for MR17.")
def _mr_MR17_followup_input(context):
    # Delete the role by ID
    delete_resp = requests.delete(
        f"{BASE_URL}/users/rbac/roles/{context.role_id}",
        timeout=10,
    )
    context.delete_role_response = delete_resp

    # Attempt to retrieve the deleted role
    followup_get_resp = requests.get(
        f"{BASE_URL}/users/rbac/roles/{context.role_id}",
        timeout=10,
    )
    context.followup_get_response = followup_get_resp


@then("the delete operation should return a success status (such as 'OK' or 'No Content'), and the subsequent retrieval should not return the deleted role (for example, by resulting in a not-found response or by its absence), indicating the role has been successfully removed compared to the seed output for MR17.")
def _mr_MR17_assertion(context):
    delete_status = getattr(context.delete_role_response, "status_code", None)
    followup_status = getattr(context.followup_get_response, "status_code", None)

    if delete_status is None or followup_status is None:
        raise AssertionError("Missing HTTP responses for delete or follow-up get operation.")

    assert delete_status in (200, 204), (
        f"Delete operation did not return success status. "
        f"Got {delete_status} with body: {context.delete_role_response.text}"
    )

    assert followup_status == 404, (
        f"The role was not deleted successfully; expected 404 on retrieval, "
        f"got {followup_status} with body: {context.followup_get_response.text}"
    )

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given("a seed input that retrieves a permission's details by its key, producing a seed output with that permission's information for MR18.")
def _mr_MR18_seed_input(context):
    # Create a permission to ensure it exists before retrieval
    permission_data = {
        "enabled": True,
        "note": "Test permission",
        "permission": "test_permission"
    }

    response = requests.post(
        f"{BASE_URL}/users/rbac/permissions",
        json=permission_data,
        timeout=10
    )
    # Fail fast if status is not successful
    response.raise_for_status()

    # Safely parse JSON
    try:
        seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Response from POST /users/rbac/permissions is not valid JSON: {e}")

    if not isinstance(seed_response, dict):
        raise AssertionError("Seed response is not a JSON object as expected for PermissionDTO")

    # Safely extract fields with explicit checks to avoid KeyError/TypeError
    permission_key = seed_response.get('permission')
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError("Seed response does not contain a valid 'permission' field")

    context.seed_response = seed_response
    context.permission_key = permission_key


@when("a follow-up input is created by retrieving the same permission's details again using the GET operation on the same permission key, yielding a follow-up output for MR18.")
def _mr_MR18_followup_input(context):
    if not hasattr(context, 'permission_key'):
        raise AssertionError("permission_key is not available in context from the Given step")

    permission_key = context.permission_key
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError("permission_key in context is not a valid non-empty string")

    response = requests.get(
        f"{BASE_URL}/users/rbac/permissions/{permission_key}",
        timeout=10
    )
    response.raise_for_status()

    try:
        followup_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Response from GET /users/rbac/permissions/{{permissionKey}} is not valid JSON: {e}")

    if not isinstance(followup_response, dict):
        raise AssertionError("Follow-up response is not a JSON object as expected for PermissionDTO")

    context.followup_response = followup_response


@then("the follow-up output should contain the same permission details as the seed output for MR18, ensuring consistency in retrieval as long as the permission has not been modified or deleted between the two requests.")
def _mr_MR18_assert_consistency(context):
    if not hasattr(context, 'seed_response'):
        raise AssertionError("seed_response is not available in context from the Given step")
    if not hasattr(context, 'followup_response'):
        raise AssertionError("followup_response is not available in context from the When step")

    seed = context.seed_response
    followup = context.followup_response

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise AssertionError("Seed and follow-up responses must both be JSON objects")

    # Safely get keys with default None to avoid KeyError and compare
    seed_enabled = seed.get('enabled')
    follow_enabled = followup.get('enabled')
    seed_note = seed.get('note')
    follow_note = followup.get('note')
    seed_permission = seed.get('permission')
    follow_permission = followup.get('permission')

    # Optional: type checks to avoid unintended comparison issues
    if not isinstance(seed_enabled, bool) or not isinstance(follow_enabled, bool):
        raise AssertionError("Both seed and follow-up 'enabled' fields must be boolean")
    if seed_note is not None and not isinstance(seed_note, str):
        raise AssertionError("Seed 'note' field must be a string or null")
    if follow_note is not None and not isinstance(follow_note, str):
        raise AssertionError("Follow-up 'note' field must be a string or null")
    if not isinstance(seed_permission, str) or not isinstance(follow_permission, str):
        raise AssertionError("Both seed and follow-up 'permission' fields must be strings")

    assert follow_enabled == seed_enabled, "Enabled status does not match between seed and follow-up responses"
    assert follow_note == seed_note, "Note does not match between seed and follow-up responses"
    assert follow_permission == seed_permission, "Permission key does not match between seed and follow-up responses"
