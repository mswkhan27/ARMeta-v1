from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input with valid login credentials, producing a seed output with a UserDTO object that contains the authenticated user details for MR6.')
def step_mr_MR6_seed_input(context):
    login_request = {
        "username": "valid_user",
        "password": "valid_password"
    }
    context.seed_request = login_request

    response = requests.post(f"{BASE_URL}/login", json=login_request, timeout=10)
    response.raise_for_status()

    try:
        seed_response = response.json()
    except ValueError:
        raise AssertionError("Seed response is not valid JSON")

    if not isinstance(seed_response, dict):
        raise AssertionError("Seed response JSON is not an object as expected for UserDTO")

    context.seed_response = seed_response

    # Validate required fields exist to avoid KeyError in Then
    for key in ("id", "username"):
        if key not in context.seed_response:
            raise AssertionError(f"Seed response is missing expected field '{key}'")


@when('a follow-up input is created by using the same valid login credentials, yielding a follow-up output for MR6.')
def step_mr_MR6_followup_input(context):
    followup_request = getattr(context, "seed_request", None)
    if not isinstance(followup_request, dict):
        raise AssertionError("Seed request is not available or has invalid type")

    context.followup_request = followup_request

    response = requests.post(f"{BASE_URL}/login", json=followup_request, timeout=10)
    response.raise_for_status()

    try:
        followup_response = response.json()
    except ValueError:
        raise AssertionError("Follow-up response is not valid JSON")

    if not isinstance(followup_response, dict):
        raise AssertionError("Follow-up response JSON is not an object as expected for UserDTO")

    context.followup_response = followup_response

    # Validate required fields exist to avoid KeyError in Then
    for key in ("id", "username"):
        if key not in context.followup_response:
            raise AssertionError(f"Follow-up response is missing expected field '{key}'")


@then('the follow-up output should correspond to the same user as in the seed output for MR6 (for example, same user id and username), although dynamic fields such as login timestamps may legitimately differ.')
def step_mr_MR6_followup_output(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    if not isinstance(seed, dict) or not isinstance(followup, dict):
        raise AssertionError("Seed or follow-up response is missing or has invalid type")

    # Safely extract fields, guarding against None
    seed_id = seed.get("id")
    followup_id = followup.get("id")
    seed_username = seed.get("username")
    followup_username = followup.get("username")

    if seed_id is None or followup_id is None:
        raise AssertionError("User 'id' is missing in seed or follow-up response")
    if seed_username is None or followup_username is None:
        raise AssertionError("User 'username' is missing in seed or follow-up response")

    assert seed_id == followup_id, "User IDs do not match between seed and follow-up responses"
    assert seed_username == followup_username, "Usernames do not match between seed and follow-up responses"

    # Dynamic fields such as loginDt may differ; if present, they are allowed to be equal or different.
    # No strict assertion here to avoid false negatives or TypeErrors if they are missing or null.

# ----




@given('a seed input that retrieves the list of users, producing a seed output with a count of users from the returned UserListDTO for MR7.')
def _mr_MR7_seed_input(context):
    try:
        response = requests.get(f"{BASE_URL}/users", timeout=10)
        response.raise_for_status()

        try:
            data = response.json()
        except ValueError:
            raise AssertionError("Seed /users response is not valid JSON")

        if not isinstance(data, dict):
            raise AssertionError(f"Seed /users response JSON is not an object, got: {type(data)}")

        user_list = data.get('userList', [])
        if user_list is None:
            user_list = []
        if not isinstance(user_list, list):
            raise AssertionError(f"'userList' is not a list in seed response, got: {type(user_list)}")

        context.seed_response = data
        context.seed_request = response.request
        context.seed_user_count = len(user_list)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in Given step for MR7: {e}") from e


@when('a follow-up input is created by registering a new user using the user registration operation and then retrieving the list of users again, yielding a follow-up output for MR7.')
def _mr_MR7_followup_input(context):
    new_user_data = {
        "username": "newuser_mr7",
        "password": "password123",
        "name": "New",
        "surname": "User",
        "email": "newuser_mr7@example.com",
        "gender": "other"
    }
    try:
        register_response = requests.post(
            f"{BASE_URL}/users/register",
            json=new_user_data,
            timeout=10
        )
        register_response.raise_for_status()

        followup_response = requests.get(f"{BASE_URL}/users", timeout=10)
        followup_response.raise_for_status()

        try:
            data = followup_response.json()
        except ValueError:
            raise AssertionError("Follow-up /users response is not valid JSON")

        if not isinstance(data, dict):
            raise AssertionError(f"Follow-up /users response JSON is not an object, got: {type(data)}")

        user_list = data.get('userList', [])
        if user_list is None:
            user_list = []
        if not isinstance(user_list, list):
            raise AssertionError(f"'userList' is not a list in follow-up response, got: {type(user_list)}")

        context.followup_response = data
        context.followup_request = followup_response.request
        context.followup_user_count = len(user_list)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in When step for MR7: {e}") from e


@then('the follow-up output should have a user list size that is one greater than the seed output for MR7, assuming the registration succeeds and the newly registered user was not already present in the seed output.')
def _mr_MR7_followup_output(context):
    if not hasattr(context, 'seed_user_count'):
        raise AssertionError("seed_user_count is missing on context")
    if not hasattr(context, 'followup_user_count'):
        raise AssertionError("followup_user_count is missing on context")

    try:
        seed_count = int(context.seed_user_count)
        followup_count = int(context.followup_user_count)
    except (TypeError, ValueError) as e:
        raise AssertionError(f"User counts are not integers: seed={context.seed_user_count}, "
                             f"followup={context.followup_user_count}") from e

    expected = seed_count + 1
    assert followup_count == expected, (
        f"Expected user count to be {expected}, but got {followup_count}."
    )

# ----




@given('a seed input that retrieves the list of roles, producing a seed output with a count of roles for MR8.')
def step_mr_MR8_seed_input(context):
    response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    response.raise_for_status()

    data = response.json()
    # According to OpenAPI, /users/rbac/roles GET returns an array of RoleDTO
    if not isinstance(data, list):
        raise TypeError(f"Expected list for roles, got {type(data).__name__}")

    context.seed_response = data
    context.seed_request = response.request
    context.seed_role_count = len(data)


@when('a follow-up input is created by deleting an existing role using the role-deletion operation and then retrieving the list of roles again, yielding a follow-up output for MR8.')
def step_mr_MR8_followup_input(context):
    if not hasattr(context, "seed_response"):
        raise AttributeError("seed_response is not set in context. The Given step may have failed.")

    if not isinstance(context.seed_response, list):
        raise TypeError(f"seed_response must be a list, got {type(context.seed_response).__name__}")

    if not context.seed_response:
        raise AssertionError("No roles available to delete for MR8.")

    first_role = context.seed_response[0]
    if not isinstance(first_role, dict):
        raise TypeError(f"Expected role object to be dict, got {type(first_role).__name__}")

    role_id = first_role.get("id")
    if role_id is None:
        raise ValueError("Role object does not contain 'id' field.")

    # OpenAPI: /users/rbac/roles/{roleId} with roleId as int64 for deleteRoleById
    delete_url = f"{BASE_URL}/users/rbac/roles/{role_id}"
    delete_response = requests.delete(delete_url, timeout=10)
    delete_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/users/rbac/roles", timeout=10)
    followup_response.raise_for_status()

    followup_data = followup_response.json()
    if not isinstance(followup_data, list):
        raise TypeError(f"Expected list for follow-up roles, got {type(followup_data).__name__}")

    context.followup_response = followup_data
    context.followup_request = followup_response.request
    context.followup_role_count = len(followup_data)


@then('the follow-up output should have a role list size that is one less than the seed output for MR8, assuming the deleted role existed and was present in the seed output.')
def step_mr_MR8_followup_output(context):
    if not hasattr(context, "seed_role_count") or not hasattr(context, "followup_role_count"):
        raise AttributeError("Role counts are not available in context for MR8 assertion.")

    expected_count = context.seed_role_count - 1
    actual_count = context.followup_role_count

    assert actual_count == expected_count, (
        f"Expected role count to be {expected_count}, but got {actual_count}."
    )

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


def _safe_get_json(response):
    try:
        return response.json()
    except ValueError:
        raise AssertionError(f"Response is not valid JSON. Status: {response.status_code}, Body: {response.text}")


@given("a seed input that retrieves a user's details by ID, producing a seed output that includes the user's list of roles in the UserDTO for MR9.")
def step_mr_MR9_seed_input(context):
    # Create a user to ensure we have a valid user to retrieve
    user_data = {
        "username": "testuser_mr9",
        "password": "password",
        "email": "testuser_mr9@example.com",
        "name": "Test",
        "surname": "User"
    }

    create_resp = requests.post(f"{BASE_URL}/users", json=user_data, timeout=10)
    assert create_resp.status_code == 200, f"Failed to create user: {create_resp.status_code} {create_resp.text}"
    created_user = _safe_get_json(create_resp)

    user_id = created_user.get("id")
    assert isinstance(user_id, int), f"User id is missing or not an integer in response: {created_user}"

    get_resp = requests.get(f"{BASE_URL}/users/{user_id}", timeout=10)
    assert get_resp.status_code == 200, f"Failed to retrieve user: {get_resp.status_code} {get_resp.text}"
    user_details = _safe_get_json(get_resp)

    roles = user_details.get("roles") or []
    if not isinstance(roles, list):
        raise AssertionError(f"'roles' field is not a list: {roles}")

    context.seed_response = user_details
    context.seed_roles_count = len(roles)
    context.user_id = user_id


@when("a follow-up input is created by adding a role to the user using the user-role-assignment operation, yielding a follow-up output for MR9 that includes the updated user data.")
def step_mr_MR9_followup_input(context):
    # Create a role first, as required by the API
    role_body = "role_mr9"
    create_role_resp = requests.post(f"{BASE_URL}/users/rbac/roles", json=role_body, timeout=10)
    assert create_role_resp.status_code == 200, f"Failed to create role: {create_role_resp.status_code} {create_role_resp.text}"
    role = _safe_get_json(create_role_resp)

    role_id = role.get("id")
    assert isinstance(role_id, int), f"Role id is missing or not an integer in response: {role}"

    user_id = context.user_id

    # Call the user-role-assignment operation: POST /users/{id}/roles/{roleId}
    add_role_resp = requests.post(f"{BASE_URL}/users/{user_id}/roles/{role_id}", timeout=10)
    assert add_role_resp.status_code == 200, f"Failed to add role to user: {add_role_resp.status_code} {add_role_resp.text}"
    updated_user = _safe_get_json(add_role_resp)

    roles = updated_user.get("roles") or []
    if not isinstance(roles, list):
        raise AssertionError(f"'roles' field is not a list after assignment: {roles}")

    context.followup_response = updated_user
    context.followup_roles_count = len(roles)


@then("the follow-up output should have a role list size that is one greater than the seed output for MR9, assuming the added role was not already present in the user's roles.")
def step_mr_MR9_followup_output(context):
    seed_count = getattr(context, "seed_roles_count", None)
    followup_count = getattr(context, "followup_roles_count", None)

    assert isinstance(seed_count, int), f"Seed roles count is not set correctly: {seed_count}"
    assert isinstance(followup_count, int), f"Follow-up roles count is not set correctly: {followup_count}"

    expected = seed_count + 1
    assert followup_count == expected, (
        f"Expected role count to be {expected}, but got {followup_count}. "
        f"Seed response roles: {context.seed_response.get('roles')}, "
        f"Follow-up response roles: {context.followup_response.get('roles')}"
    )

# ----






@given("a seed input that retrieves a user's details by ID, producing a seed output that includes the user's list of roles in the UserDTO for MR10.")
def _mr_MR10_seed_input(context):
    # Create a user to ensure we have a valid user to retrieve
    user_data = {
        "username": "testuser_mr10",
        "password": "password",
        "name": "Test",
        "surname": "User",
        "email": "testuser_mr10@example.com"
    }

    create_resp = requests.post(f"{BASE_URL}/users", json=user_data, timeout=10)
    create_body = _safe_get_json(create_resp)
    assert create_resp.status_code == 200, f"Failed to create user: {create_body}"

    user_id = create_body.get("id")
    assert isinstance(user_id, int), f"User id missing or not int in create response: {create_body}"

    # Retrieve the user by ID to get the roles
    get_resp = requests.get(f"{BASE_URL}/users/{user_id}", timeout=10)
    get_body = _safe_get_json(get_resp)
    assert get_resp.status_code == 200, f"Failed to retrieve user: {get_body}"

    # Ensure roles key is always present for later len() calls
    if "roles" not in get_body or get_body["roles"] is None:
        get_body["roles"] = []

    context.user_id = user_id
    context.seed_request = get_resp
    context.seed_response = get_body


@when("a follow-up input is created by removing a role from the user using the user-role-removal operation, yielding a follow-up output for MR10 that includes the updated user data.")
def _mr_MR10_followup_input(context):
    user_id = getattr(context, "user_id", None)
    assert isinstance(user_id, int), f"user_id not set correctly on context: {user_id}"

    # First, create a role so we have a valid roleId
    role_body_req = "mr10_testrole"
    role_create_resp = requests.post(f"{BASE_URL}/users/rbac/roles", json=role_body_req, timeout=10)
    role_create_json = _safe_get_json(role_create_resp)
    assert role_create_resp.status_code == 200, f"Failed to create role: {role_create_json}"

    role_id = role_create_json.get("id")
    assert isinstance(role_id, int), f"role id missing or not int in role create response: {role_create_json}"

    # Add this role to the user: POST /users/{id}/roles/{roleId}
    add_role_resp = requests.post(f"{BASE_URL}/users/{user_id}/roles/{role_id}", timeout=10)
    add_role_json = _safe_get_json(add_role_resp)
    assert add_role_resp.status_code == 200, f"Failed to add role to user: {add_role_json}"

    # Retrieve user after adding role to compute seed role count for comparison
    seed_get_resp = requests.get(f"{BASE_URL}/users/{user_id}", timeout=10)
    seed_get_json = _safe_get_json(seed_get_resp)
    assert seed_get_resp.status_code == 200, f"Failed to retrieve user after adding role: {seed_get_json}"
    if "roles" not in seed_get_json or seed_get_json["roles"] is None:
        seed_get_json["roles"] = []
    context.seed_response = seed_get_json

    # Now remove the role: DELETE /users/{id}/roles/{roleId}
    remove_resp = requests.delete(f"{BASE_URL}/users/{user_id}/roles/{role_id}", timeout=10)
    # Body might be empty (204), so don't assume JSON
    assert remove_resp.status_code in (200, 204), f"Failed to remove role from user: status={remove_resp.status_code}"

    # Retrieve the updated user data
    follow_get_resp = requests.get(f"{BASE_URL}/users/{user_id}", timeout=10)
    follow_get_json = _safe_get_json(follow_get_resp)
    assert follow_get_resp.status_code == 200, f"Failed to retrieve updated user: {follow_get_json}"
    if "roles" not in follow_get_json or follow_get_json["roles"] is None:
        follow_get_json["roles"] = []

    context.followup_request = follow_get_resp
    context.followup_response = follow_get_json


@then("the follow-up output should have a role list size that is one less than the seed output for MR10, assuming the removed role was present in the user's roles in the seed output.")
def _mr_MR10_followup_output(context):
    seed_roles = context.seed_response.get("roles") or []
    follow_roles = context.followup_response.get("roles") or []

    assert isinstance(seed_roles, list), f"Seed roles is not a list: {seed_roles}"
    assert isinstance(follow_roles, list), f"Follow-up roles is not a list: {follow_roles}"

    seed_roles_count = len(seed_roles)
    followup_roles_count = len(follow_roles)

    # We explicitly added exactly one role and then removed it,
    # so we expect the role count to decrease by one.
    assert followup_roles_count == seed_roles_count - 1, (
        f"Expected role count to be {seed_roles_count - 1}, but got {followup_roles_count}"
    )
