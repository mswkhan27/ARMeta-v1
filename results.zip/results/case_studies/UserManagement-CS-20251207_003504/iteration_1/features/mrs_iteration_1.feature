Feature: Iteration 1 MRs

  Scenario: MR6 Logging in with valid credentials should consistently identify the same user
    Given a seed input with valid login credentials, producing a seed output with a UserDTO object that contains the authenticated user details for MR6.
    When a follow-up input is created by using the same valid login credentials, yielding a follow-up output for MR6.
    Then the follow-up output should correspond to the same user as in the seed output for MR6 (for example, same user id and username), although dynamic fields such as login timestamps may legitimately differ.

  Scenario: MR7 Registering a new user should increase the total number of users
    Given a seed input that retrieves the list of users, producing a seed output with a count of users from the returned UserListDTO for MR7.
    When a follow-up input is created by registering a new user using the user registration operation and then retrieving the list of users again, yielding a follow-up output for MR7.
    Then the follow-up output should have a user list size that is one greater than the seed output for MR7, assuming the registration succeeds and the newly registered user was not already present in the seed output.

  Scenario: MR8 Deleting a role should remove it from the role list
    Given a seed input that retrieves the list of roles, producing a seed output with a count of roles for MR8.
    When a follow-up input is created by deleting an existing role using the role-deletion operation and then retrieving the list of roles again, yielding a follow-up output for MR8.
    Then the follow-up output should have a role list size that is one less than the seed output for MR8, assuming the deleted role existed and was present in the seed output.

  Scenario: MR9 Adding a role to a user should increase the user's role list size by one
    Given a seed input that retrieves a user's details by ID, producing a seed output that includes the user's list of roles in the UserDTO for MR9.
    When a follow-up input is created by adding a role to the user using the user-role-assignment operation, yielding a follow-up output for MR9 that includes the updated user data.
    Then the follow-up output should have a role list size that is one greater than the seed output for MR9, assuming the added role was not already present in the user's roles.

  Scenario: MR10 Removing a role from a user should decrease the user's role list size by one
    Given a seed input that retrieves a user's details by ID, producing a seed output that includes the user's list of roles in the UserDTO for MR10.
    When a follow-up input is created by removing a role from the user using the user-role-removal operation, yielding a follow-up output for MR10 that includes the updated user data.
    Then the follow-up output should have a role list size that is one less than the seed output for MR10, assuming the removed role was present in the user's roles in the seed output.
