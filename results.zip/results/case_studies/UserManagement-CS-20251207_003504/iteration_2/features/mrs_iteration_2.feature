Feature: Iteration 2 MRs

  Scenario: MR11 Deleting a permission should remove it from the permission list
    Given a seed input that retrieves the list of permissions, producing a seed output with a count of permissions for MR11.
    When a follow-up input is created by deleting an existing permission using the permission-deletion operation and then retrieving the list of permissions again, yielding a follow-up output for MR11.
    Then the follow-up output should have a permission list size that is one less than the seed output for MR11, assuming the deleted permission existed and no other permissions were added or removed between the two retrievals.

  Scenario: MR12 Generating a salt should produce a different value on subsequent calls
    Given a seed input that requests a salt generation, producing a seed output with a salt value for MR12.
    When a follow-up input is created by requesting another salt generation, yielding a follow-up output for MR12.
    Then the follow-up output should contain a salt value that is different from the seed output for MR12, reflecting that salts are generated as distinct values across calls.

  Scenario: MR13 Retrieving error status via different methods should yield consistent metadata
    Given a seed input that retrieves error information using the GET method, producing a seed output with the response status code and headers for MR13.
    When a follow-up input is created by retrieving error information using the HEAD method, yielding a follow-up output for MR13.
    Then the follow-up output should have the same response status code and compatible headers as the seed output for MR13, with the HEAD response not including a message body.

  Scenario: MR14 Updating a permission should reflect the changes in the permission details
    Given a seed input that retrieves a permission's details by its key, producing a seed output with that permission's information, including its current field values, for MR14.
    When a follow-up input is created by updating that permission's details using the permission-update operation for the same permission identifier (for example, key or id) and then retrieving the permission details again, yielding a follow-up output for MR14.
    Then the follow-up output should reflect the new values for all fields provided in the update request for MR14, while preserving the permission identifier so that it still represents the same permission as in the seed output.
