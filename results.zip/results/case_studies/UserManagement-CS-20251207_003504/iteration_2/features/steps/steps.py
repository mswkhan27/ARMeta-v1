from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the list of permissions, producing a seed output with a count of permissions for MR11.')
def step_mr_MR11_seed_input(context):
    try:
        response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
        response.raise_for_status()

        data = response.json()
        if not isinstance(data, list):
            raise AssertionError(f"Expected a list of permissions, but got: {type(data).__name__}")

        context.seed_response = data
        context.seed_request = response.request
        context.seed_count = len(context.seed_response)
    except (requests.RequestException, ValueError, json.JSONDecodeError) as e:
        print(f"Error in Given step for MR11: {e}")
        raise
    except Exception as e:
        print(f"Unexpected error in Given step for MR11: {e}")
        raise


@when('a follow-up input is created by deleting an existing permission using the permission-deletion operation and then retrieving the list of permissions again, yielding a follow-up output for MR11.')
def step_mr_MR11_followup_input(context):
    try:
        seed_permissions = getattr(context, "seed_response", None)
        if not isinstance(seed_permissions, list) or len(seed_permissions) == 0:
            raise AssertionError("No permissions found in seed response; cannot perform delete operation for MR11.")

        first_permission = seed_permissions[0]
        if not isinstance(first_permission, dict):
            raise AssertionError(f"Expected first permission to be an object, but got: {type(first_permission).__name__}")

        permission_key = first_permission.get("permission")
        if not isinstance(permission_key, str) or not permission_key:
            raise AssertionError(f"Permission object does not contain a valid 'permission' key: {first_permission}")

        delete_url = f"{BASE_URL}/users/rbac/permissions/{permission_key}"
        delete_response = requests.delete(delete_url, timeout=10)
        delete_response.raise_for_status()

        followup_response = requests.get(f"{BASE_URL}/users/rbac/permissions", timeout=10)
        followup_response.raise_for_status()

        followup_data = followup_response.json()
        if not isinstance(followup_data, list):
            raise AssertionError(f"Expected a list of permissions in follow-up, but got: {type(followup_data).__name__}")

        context.followup_response = followup_data
        context.followup_request = followup_response.request
    except (requests.RequestException, ValueError, json.JSONDecodeError) as e:
        print(f"Error in When step for MR11: {e}")
        raise
    except Exception as e:
        print(f"Unexpected error in When step for MR11: {e}")
        raise


@then('the follow-up output should have a permission list size that is one less than the seed output for MR11, assuming the deleted permission existed and no other permissions were added or removed between the two retrievals.')
def step_mr_MR11_followup_output(context):
    try:
        followup_permissions = getattr(context, "followup_response", None)
        if not isinstance(followup_permissions, list):
            raise AssertionError(f"Expected follow-up response to be a list, but got: {type(followup_permissions).__name__}")

        seed_count = getattr(context, "seed_count", None)
        if not isinstance(seed_count, int):
            raise AssertionError(f"Seed count is not an integer: {seed_count!r}")

        followup_count = len(followup_permissions)
        expected_count = seed_count - 1

        assert followup_count == expected_count, (
            f"Expected {expected_count} permissions after deletion, but got {followup_count}."
        )
    except Exception as e:
        print(f"Error in Then step for MR11: {e}")
        raise

# ----




@given('a seed input that requests a salt generation, producing a seed output with a salt value for MR12.')
def step_mr_MR12_seed_input(context):
    url = f"{BASE_URL}/users/rbac/salt"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except Exception as e:
        raise AssertionError(f"Error in Given step for MR12 while calling {url}: {e}") from e

    # Ensure we always have a string and avoid attribute errors
    context.seed_response = response.text if hasattr(response, "text") else str(response.content or "")


@when('a follow-up input is created by requesting another salt generation, yielding a follow-up output for MR12.')
def step_mr_MR12_followup_input(context):
    url = f"{BASE_URL}/users/rbac/salt"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except Exception as e:
        raise AssertionError(f"Error in When step for MR12 while calling {url}: {e}") from e

    context.followup_response = response.text if hasattr(response, "text") else str(response.content or "")


@then('the follow-up output should contain a salt value that is different from the seed output for MR12, reflecting that salts are generated as distinct values across calls.')
def step_mr_MR12_assert_different_salts(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    if seed is None or followup is None:
        raise AssertionError(
            "Seed and follow-up responses must both be present on the context "
            "before asserting different salts."
        )

    if not isinstance(seed, str):
        seed = str(seed)
    if not isinstance(followup, str):
        followup = str(followup)

    try:
        assert seed != followup, "The follow-up salt should be different from the seed salt."
    except AssertionError as e:
        raise AssertionError(f"Assertion error in Then step for MR12: {e}") from e

# ----




@given('a seed input that retrieves error information using the GET method, producing a seed output with the response status code and headers for MR13.')
def step_mr_MR13_seed_input(context):
    response = requests.get(f"{BASE_URL}/error", timeout=10)

    context.seed_request = response
    context.seed_status_code = response.status_code
    context.seed_headers = response.headers

    # Only parse JSON if content is present and content-type is JSON
    context.seed_response = None
    content_type = response.headers.get('Content-Type', '')
    if response.content and 'application/json' in content_type.lower():
        try:
            context.seed_response = response.json()
        except ValueError:
            context.seed_response = None

    assert response.status_code in [200, 401, 403, 404], "Unexpected status code from GET /error"


@when('a follow-up input is created by retrieving error information using the HEAD method, yielding a follow-up output for MR13.')
def step_mr_MR13_followup_input(context):
    response = requests.head(f"{BASE_URL}/error", timeout=10)

    context.followup_request = response
    context.followup_status_code = response.status_code
    context.followup_headers = response.headers

    assert response.status_code in [200, 204, 401, 403], "Unexpected status code from HEAD /error"


@then('the follow-up output should have the same response status code and compatible headers as the seed output for MR13, with the HEAD response not including a message body.')
def step_mr_MR13_followup_output(context):
    # Allow 200 <-> 204 equivalence for HEAD vs GET, otherwise require exact match
    if context.seed_status_code in (200, 204) and context.followup_status_code in (200, 204):
        pass
    else:
        assert context.followup_status_code == context.seed_status_code, "Status codes do not match"

    # Compare common headers, excluding headers that can legitimately differ
    skip_headers = {'content-length', 'date', 'server'}
    for key, value in context.seed_headers.items():
        if key.lower() in skip_headers:
            continue
        follow_value = context.followup_headers.get(key)
        assert follow_value == value, f"Header '{key}' does not match"

    # For HEAD, body should be empty (or equivalent to empty)
    body = context.followup_request.content or b''
    assert body == b'', "HEAD response should not include a message body"
