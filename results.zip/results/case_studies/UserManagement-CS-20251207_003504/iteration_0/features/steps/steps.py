from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8090')


@given('a seed input that retrieves the list of users, producing a seed output with a count of users for MR1.')
def step_mr_MR1_seed_input(context):
    response = requests.get(f"{BASE_URL}/users", timeout=10)
    response.raise_for_status()

    try:
        seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Seed response is not valid JSON: {e}")

    if not isinstance(seed_response, dict):
        raise AssertionError(f"Seed response JSON must be an object, got {type(seed_response).__name__}")

    user_list = seed_response.get('userList', [])
    if user_list is None:
        user_list = []

    if not isinstance(user_list, list):
        raise AssertionError(f"'userList' must be a list, got {type(user_list).__name__}")

    context.seed_response = seed_response
    context.seed_request = response.request
    context.user_count = len(user_list)


@when('a follow-up input is created by first adding a new user using the user-creation operation and then retrieving the list of users again, yielding a follow-up output for MR1.')
def step_mr_MR1_followup_input(context):
    new_user = {
        "address": "123 Test St",
        "address2": "Suite 1",
        "birthDate": "2000-01-01",
        "city": "Testville",
        "contactNote": "Test contact",
        "country": "Testland",
        "email": "newuser@example.com",
        "enabled": True,
        "facebook": "newuser_fb",
        "gender": "other",
        "linkedin": "newuser_li",
        "name": "New",
        "note": "Created by MR1 test",
        "password": "password123",
        "phone": "1234567890",
        "secured": False,
        "skype": "newuser_skype",
        "surname": "User",
        "username": "new_user_mr1",
        "website": "https://example.com",
        "zipCode": "12345"
    }

    create_response = requests.post(
        f"{BASE_URL}/users",
        json=new_user,
        headers={"Content-Type": "application/json"},
        timeout=10
    )
    create_response.raise_for_status()

    followup_response = requests.get(f"{BASE_URL}/users", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_json = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response is not valid JSON: {e}")

    if not isinstance(followup_json, dict):
        raise AssertionError(f"Follow-up response JSON must be an object, got {type(followup_json).__name__}")

    followup_user_list = followup_json.get('userList', [])
    if followup_user_list is None:
        followup_user_list = []

    if not isinstance(followup_user_list, list):
        raise AssertionError(f"'userList' in follow-up response must be a list, got {type(followup_user_list).__name__}")

    context.followup_response = followup_json
    context.followup_request = followup_response.request
    context.followup_user_count = len(followup_user_list)


@then('the follow-up output should have a user list size that is one greater than the seed output for MR1, assuming the newly created user was not already present in the seed output.')
def step_mr_MR1_followup_output(context):
    expected_count = getattr(context, "user_count", None)
    actual_count = getattr(context, "followup_user_count", None)

    if expected_count is None or actual_count is None:
        raise AssertionError(
            f"Missing counts on context: user_count={expected_count}, followup_user_count={actual_count}"
        )

    if not isinstance(expected_count, int) or not isinstance(actual_count, int):
        raise AssertionError(
            f"Counts must be integers, got user_count={type(expected_count).__name__}, "
            f"followup_user_count={type(actual_count).__name__}"
        )

    assert actual_count == expected_count + 1, (
        f"Expected user count to be {expected_count + 1}, but got {actual_count}."
    )

# ----




@given('a seed input that retrieves the list of users, producing a seed output with a count of users for MR2.')
def step_mr_MR2_seed_input(context):
    response = requests.get(f"{BASE_URL}/users", timeout=10)
    response.raise_for_status()

    try:
        seed_json = response.json()
    except ValueError as e:
        raise AssertionError(f"Response from /users is not valid JSON: {e}")

    if not isinstance(seed_json, dict):
        raise AssertionError(f"Expected JSON object from /users, got {type(seed_json).__name__}")

    user_list = seed_json.get('userList', [])
    if user_list is None:
        user_list = []
    if not isinstance(user_list, list):
        raise AssertionError(f"Expected 'userList' to be a list, got {type(user_list).__name__}")

    context.seed_response = seed_json
    context.seed_request = response.request
    context.user_count = len(user_list)

    # Try to remember an existing user id (if any) for later deletion
    context.existing_user_id = None
    for user in user_list:
        if isinstance(user, dict) and 'id' in user:
            context.existing_user_id = user['id']
            break


@when('a follow-up input is created by first deleting an existing user using the user-deletion operation and then retrieving the list of users again, yielding a follow-up output for MR2.')
def step_mr_MR2_followup_input(context):
    # Determine which user to delete or create one if none exist
    user_id_to_delete = getattr(context, 'existing_user_id', None)

    if user_id_to_delete is None:
        # No existing user with id found; create one to delete
        new_user = {
            "username": "testuser_mr2",
            "password": "password",
            "name": "Test",
            "surname": "User",
            "email": "testuser_mr2@example.com"
        }
        create_response = requests.post(f"{BASE_URL}/users", json=new_user, timeout=10)
        create_response.raise_for_status()

        try:
            created_json = create_response.json()
        except ValueError as e:
            raise AssertionError(f"Response from POST /users is not valid JSON: {e}")

        if not isinstance(created_json, dict):
            raise AssertionError(f"Expected JSON object from POST /users, got {type(created_json).__name__}")

        created_user_id = created_json.get('id')
        if created_user_id is None:
            raise AssertionError("Created user response does not contain 'id' field")

        context.created_user_id = created_user_id
        user_id_to_delete = created_user_id

    # Delete the chosen user using the correct delete operation /users/{id}
    delete_response = requests.delete(f"{BASE_URL}/users/{user_id_to_delete}", timeout=10)
    delete_response.raise_for_status()

    # Retrieve the user list again
    followup_response = requests.get(f"{BASE_URL}/users", timeout=10)
    followup_response.raise_for_status()

    try:
        followup_json = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up response from /users is not valid JSON: {e}")

    if not isinstance(followup_json, dict):
        raise AssertionError(f"Expected JSON object from follow-up /users, got {type(followup_json).__name__}")

    context.followup_response = followup_json


@then('the follow-up output should have a user list size that is one less than the seed output for MR2, assuming the deleted user was present in the seed output.')
def step_mr_MR2_followup_output(context):
    followup = getattr(context, 'followup_response', None)
    if followup is None:
        raise AssertionError("followup_response is not set in context")

    user_list = followup.get('userList', [])
    if user_list is None:
        user_list = []
    if not isinstance(user_list, list):
        raise AssertionError(f"Expected 'userList' in follow-up response to be a list, got {type(user_list).__name__}")

    followup_user_count = len(user_list)

    # If we deleted a pre-existing user, user_count should decrease by 1.
    # If we created a user only to delete it (seed had no deletable id),
    # then the total may remain the same; in that special case we assert equality.
    deleted_existing = getattr(context, 'existing_user_id', None) is not None

    expected_count = context.user_count - 1 if deleted_existing else context.user_count
    assert followup_user_count == expected_count, (
        f"Expected user count to be {expected_count}, but got {followup_user_count}."
    )

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8090")


def _safe_get(d, key, default=None):
    if isinstance(d, dict):
        return d.get(key, default)
    return default


@given("a seed input that retrieves a user's details by ID, producing a seed output with user information for MR3.")
def step_mr_MR3_seed_input(context):
    # Create a user to ensure we have a valid ID to retrieve
    user_data = {
        "username": "testuser",
        "password": "password123",
        "name": "Test",
        "surname": "User",
        "email": "testuser@example.com",
        "gender": "male",
        "enabled": True,
    }

    response = requests.post(f"{BASE_URL}/users", json=user_data, timeout=10)
    response.raise_for_status()

    try:
        created_user = response.json()
    except ValueError as e:
        raise AssertionError(f"Create user response is not valid JSON: {e}")

    if not isinstance(created_user, dict):
        raise AssertionError("Create user response JSON is not an object as expected.")

    user_id = _safe_get(created_user, "id")
    if user_id is None:
        raise AssertionError("Created user response does not contain 'id' field.")

    context.user_id = user_id

    # Retrieve the user details to set the seed output
    get_response = requests.get(f"{BASE_URL}/users/{context.user_id}", timeout=10)
    get_response.raise_for_status()

    try:
        seed_user = get_response.json()
    except ValueError as e:
        raise AssertionError(f"Get user-by-id response is not valid JSON: {e}")

    if not isinstance(seed_user, dict):
        raise AssertionError("Get user-by-id response JSON is not an object as expected.")

    context.seed_response = seed_user


@when("a follow-up input is created by updating the user's information using the user-update operation, yielding a follow-up output for MR3.")
def step_mr_MR3_followup_input(context):
    if not hasattr(context, "user_id"):
        raise AssertionError("context.user_id is not set in Given step.")

    # Prepare update payload according to CreateOrUpdateUserDTO schema
    # Only change username and email; other fields left out to avoid accidental overwrites
    update_data = {
        "username": "updateduser",
        "email": "updateduser@example.com",
    }

    response = requests.put(f"{BASE_URL}/users/{context.user_id}", json=update_data, timeout=10)
    response.raise_for_status()

    try:
        updated_user = response.json()
    except ValueError as e:
        raise AssertionError(f"Update user response is not valid JSON: {e}")

    if not isinstance(updated_user, dict):
        raise AssertionError("Update user response JSON is not an object as expected.")

    context.followup_response = updated_user
    context.update_data = update_data


@then("the follow-up output should reflect the new values for all fields provided in the update request for MR3, while still representing the same user as in the seed output.")
def step_mr_MR3_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AssertionError("context.followup_response is not set in When step.")
    if not hasattr(context, "seed_response"):
        raise AssertionError("context.seed_response is not set in Given step.")
    if not hasattr(context, "update_data"):
        raise AssertionError("context.update_data is not set in When step.")

    followup = context.followup_response
    seed = context.seed_response
    update_data = context.update_data

    if not isinstance(followup, dict):
        raise AssertionError("followup_response is not a JSON object.")
    if not isinstance(seed, dict):
        raise AssertionError("seed_response is not a JSON object.")

    # Check that the user ID remains the same
    followup_id = _safe_get(followup, "id")
    seed_id = _safe_get(seed, "id")
    assert followup_id == seed_id, f"User ID should remain the same. Seed: {seed_id}, Follow-up: {followup_id}"

    # For each field we updated, verify the follow-up contains the new value
    for field, new_value in update_data.items():
        actual_value = _safe_get(followup, field)
        assert (
            actual_value == new_value
        ), f"Field '{field}' did not update correctly. Expected: {new_value}, Actual: {actual_value}"

    # Verify that some unchanged fields from the seed still match (if present in both)
    for field in ["name", "surname", "gender", "enabled"]:
        seed_val = _safe_get(seed, field, object())
        followup_val = _safe_get(followup, field, object())
        if seed_val is not object() and followup_val is not object():
            assert (
                followup_val == seed_val
            ), f"Field '{field}' should remain unchanged. Seed: {seed_val}, Follow-up: {followup_val}"

# ----




@given("a seed input that retrieves a role's details by its ID, producing a seed output that includes the role's list of permissions for MR4.")
def step_mr_MR4_seed_input(context):
    # Create a role to ensure it exists
    role_data = {"role": "test_role_MR4"}
    role_response = requests.post(f"{BASE_URL}/users/rbac/roles", json=role_data, timeout=10)
    role_response.raise_for_status()

    try:
        role_json = role_response.json()
    except ValueError as e:
        raise AssertionError(f"Role creation did not return valid JSON: {e}") from e

    role_id = role_json.get('id')
    if role_id is None:
        raise AssertionError(f"Role creation response JSON has no 'id': {json.dumps(role_json, indent=2)}")

    context.role_id = role_id

    # Retrieve the role's details
    seed_request = requests.get(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
    seed_request.raise_for_status()

    try:
        seed_response_json = seed_request.json()
    except ValueError as e:
        raise AssertionError(f"Seed role retrieval did not return valid JSON: {e}") from e

    if not isinstance(seed_response_json, dict):
        raise AssertionError(f"Seed role retrieval JSON is not an object: {json.dumps(seed_response_json, indent=2)}")

    # Ensure permissions is a list (or absent)
    permissions = seed_response_json.get('permissions', [])
    if permissions is None:
        permissions = []
    if not isinstance(permissions, list):
        raise AssertionError(f"'permissions' field is not a list: {json.dumps(seed_response_json, indent=2)}")

    context.seed_response = seed_response_json


@when("a follow-up input is created by adding a permission to the role using the role-permission-assignment operation, yielding a follow-up output for MR4 that includes the updated role data.")
def step_mr_MR4_followup_input(context):
    # Create a permission to add to the role
    permission_data = {"permission": "test_permission_MR4"}
    permission_response = requests.post(f"{BASE_URL}/users/rbac/permissions", json=permission_data, timeout=10)
    permission_response.raise_for_status()

    try:
        permission_json = permission_response.json()
    except ValueError as e:
        raise AssertionError(f"Permission creation did not return valid JSON: {e}") from e

    permission_key = permission_json.get('permission')
    if not isinstance(permission_key, str) or not permission_key:
        raise AssertionError(f"Permission creation response JSON has invalid 'permission' key: {json.dumps(permission_json, indent=2)}")

    context.permission_key = permission_key

    # Add the permission to the role using the role-permission-assignment operation
    followup_request = requests.post(
        f"{BASE_URL}/users/rbac/roles/{context.role_id}/permissions/{context.permission_key}",
        timeout=10
    )
    followup_request.raise_for_status()

    try:
        followup_response_json = followup_request.json()
    except ValueError as e:
        raise AssertionError(f"Follow-up role update did not return valid JSON: {e}") from e

    if not isinstance(followup_response_json, dict):
        raise AssertionError(f"Follow-up role retrieval JSON is not an object: {json.dumps(followup_response_json, indent=2)}")

    permissions = followup_response_json.get('permissions', [])
    if permissions is None:
        permissions = []
    if not isinstance(permissions, list):
        raise AssertionError(f"'permissions' field in follow-up response is not a list: {json.dumps(followup_response_json, indent=2)}")

    context.followup_response = followup_response_json


@then("the follow-up output should have a permission list size that is one greater than the seed output for MR4, assuming the added permission was not already present in the role.")
def step_mr_MR4_followup_output(context):
    seed_permissions = context.seed_response.get('permissions', [])
    if seed_permissions is None:
        seed_permissions = []
    if not isinstance(seed_permissions, list):
        raise AssertionError(f"'permissions' in seed response is not a list: {json.dumps(context.seed_response, indent=2)}")

    followup_permissions = context.followup_response.get('permissions', [])
    if followup_permissions is None:
        followup_permissions = []
    if not isinstance(followup_permissions, list):
        raise AssertionError(f"'permissions' in follow-up response is not a list: {json.dumps(context.followup_response, indent=2)}")

    seed_permissions_count = len(seed_permissions)
    followup_permissions_count = len(followup_permissions)

    if followup_permissions_count != seed_permissions_count + 1:
        raise AssertionError(
            f"Expected permission list size to be {seed_permissions_count + 1}, "
            f"but got {followup_permissions_count}. "
            f"Seed response: {json.dumps(context.seed_response, indent=2)} "
            f"Follow-up response: {json.dumps(context.followup_response, indent=2)}"
        )

# ----




@given("a seed input that retrieves a role's details by its ID, producing a seed output that includes the role's list of permissions for MR5.")
def step_mr_MR5_seed_input(context):
    # Create a role first to ensure it exists
    role_data = "TestRole"
    response = requests.post(f"{BASE_URL}/users/rbac/roles", json=role_data, timeout=10)
    response.raise_for_status()

    data = response.json() if response.content else {}
    role_id = data.get('id')
    if role_id is None:
        raise AssertionError("Role creation response does not contain 'id'")

    context.role_id = role_id

    # Retrieve the role's details
    seed_request = requests.get(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
    seed_request.raise_for_status()
    seed_response = seed_request.json() if seed_request.content else {}

    permissions = seed_response.get('permissions')
    if permissions is None:
        # Ensure we always have a list to avoid TypeError in len()
        permissions = []
    if not isinstance(permissions, list):
        raise AssertionError(f"'permissions' field is not a list: {type(permissions)}")

    context.seed_response = seed_response
    context.initial_permissions_count = len(permissions)


@when("a follow-up input is created by removing a permission from the role using the role-permission-removal operation, yielding a follow-up output for MR5 that includes the updated role data.")
def step_mr_MR5_followup_input(context):
    # Ensure seed_response and role_id exist
    if not hasattr(context, "seed_response") or not hasattr(context, "role_id"):
        raise AssertionError("Seed data or role_id not found in context")

    permissions = context.seed_response.get('permissions') or []
    if not isinstance(permissions, list):
        raise AssertionError(f"'permissions' field is not a list: {type(permissions)}")

    # We must have at least one permission to remove
    if len(permissions) == 0:
        raise AssertionError("No permissions available to remove for MR5.")

    first_permission = permissions[0]
    if not isinstance(first_permission, dict):
        raise AssertionError(f"Permission item is not an object: {type(first_permission)}")

    permission_key = first_permission.get('permission')
    if not permission_key:
        raise AssertionError("First permission does not contain a 'permission' key or it is empty")

    # Remove permission from role using the correct operation
    followup_request = requests.delete(
        f"{BASE_URL}/users/rbac/roles/{context.role_id}/permissions/{permission_key}",
        timeout=10
    )
    followup_request.raise_for_status()
    context.followup_response = followup_request.json() if followup_request.content else {}


@then("the follow-up output should have a permission list size that is one less than the seed output for MR5, assuming the removed permission was present in the role in the seed output.")
def step_mr_MR5_followup_output(context):
    if not hasattr(context, "role_id"):
        raise AssertionError("role_id not found in context")
    if not hasattr(context, "initial_permissions_count"):
        raise AssertionError("initial_permissions_count not found in context")

    # Retrieve the updated role details
    updated_role_request = requests.get(f"{BASE_URL}/users/rbac/roles/{context.role_id}", timeout=10)
    updated_role_request.raise_for_status()
    updated_role_response = updated_role_request.json() if updated_role_request.content else {}

    updated_permissions = updated_role_response.get('permissions') or []
    if not isinstance(updated_permissions, list):
        raise AssertionError(f"'permissions' field is not a list: {type(updated_permissions)}")

    updated_permissions_count = len(updated_permissions)
    expected_count = context.initial_permissions_count - 1

    if context.initial_permissions_count <= 0:
        raise AssertionError(
            f"Initial permissions count must be greater than 0 for MR5, got {context.initial_permissions_count}"
        )

    assert updated_permissions_count == expected_count, (
        f"Expected permission count to be {expected_count}, "
        f"but got {updated_permissions_count}."
    )
