Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new user should increase the user list size by one
    Given a seed input that retrieves the list of users, producing a seed output with a count of users for MR1.
    When a follow-up input is created by first adding a new user using the user-creation operation and then retrieving the list of users again, yielding a follow-up output for MR1.
    Then the follow-up output should have a user list size that is one greater than the seed output for MR1, assuming the newly created user was not already present in the seed output.

  Scenario: MR2 Deleting a user should decrease the user list size by one
    Given a seed input that retrieves the list of users, producing a seed output with a count of users for MR2.
    When a follow-up input is created by first deleting an existing user using the user-deletion operation and then retrieving the list of users again, yielding a follow-up output for MR2.
    Then the follow-up output should have a user list size that is one less than the seed output for MR2, assuming the deleted user was present in the seed output.

  Scenario: MR3 Updating a user's information should change the returned data for the updated fields
    Given a seed input that retrieves a user's details by ID, producing a seed output with user information for MR3.
    When a follow-up input is created by updating the user's information using the user-update operation, yielding a follow-up output for MR3.
    Then the follow-up output should reflect the new values for all fields provided in the update request for MR3, while still representing the same user as in the seed output.

  Scenario: MR4 Adding a permission to a role should increase the role's permission list size by one
    Given a seed input that retrieves a role's details by its ID, producing a seed output that includes the role's list of permissions for MR4.
    When a follow-up input is created by adding a permission to the role using the role-permission-assignment operation, yielding a follow-up output for MR4 that includes the updated role data.
    Then the follow-up output should have a permission list size that is one greater than the seed output for MR4, assuming the added permission was not already present in the role.

  Scenario: MR5 Removing a permission from a role should decrease the role's permission list size by one
    Given a seed input that retrieves a role's details by its ID, producing a seed output that includes the role's list of permissions for MR5.
    When a follow-up input is created by removing a permission from the role using the role-permission-removal operation, yielding a follow-up output for MR5 that includes the updated role data.
    Then the follow-up output should have a permission list size that is one less than the seed output for MR5, assuming the removed permission was present in the role in the seed output.
