Feature: Iteration 4 MRs

  Scenario: MR19 Finding pets by tags should return a consistent set of pets when the underlying data does not change
    Given a seed input that retrieves a list of pets filtered by a specific set of tags, producing a seed output with the list of pets for MR19, and assuming no pets or their tags are modified between calls.
    When a follow-up input is created by retrieving the list of pets again using the same set of tags under the same data conditions, yielding a follow-up output for MR19.
    Then the follow-up output should be identical to the seed output, ensuring that the same set of tags consistently returns the same list of pets for MR19 when the store data remains unchanged.

  Scenario: MR20 Logging in and then logging out should both complete successfully
    Given a seed input that logs a user into the system, producing a seed output with a successful login response for MR20.
    When a follow-up input is created by logging out the user using the same client context, yielding a follow-up output for MR20.
    Then the follow-up output should indicate a successful logout operation, confirming that a user who has logged in can subsequently log out without error for MR20.
