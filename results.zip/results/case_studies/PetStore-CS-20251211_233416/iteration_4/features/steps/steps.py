from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_response_no_500(response, step_name: str) -> None:
    """
    Common helper to ensure no 500-class error is silently ignored.
    Raises AssertionError so Behave marks the step as failed.
    """
    if response is None:
        raise AssertionError(f"{step_name}: No response object available")
    status_code = getattr(response, "status_code", None)
    if status_code is None:
        raise AssertionError(f"{step_name}: Response has no status_code")
    if 500 <= status_code <= 599:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unavailable>"
        raise AssertionError(
            f"{step_name}: Server error {status_code} received. "
            f"Response body: {body}"
        )


@given(
    'a seed input that retrieves a list of pets filtered by a specific set of tags, '
    'producing a seed output with the list of pets for MR19, and assuming no pets or '
    'their tags are modified between calls.'
)
def _mr_MR19_seed_input(context):
    tags = ['tag1', 'tag2']  # Example tags for filtering
    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params={'tags': tags},
            timeout=10
        )
    except requests.RequestException as e:
        raise AssertionError(f"Given (MR19): HTTP request to /pet/findByTags failed: {e}")

    context.seed_request = response
    _check_response_no_500(response, "Given (MR19)")

    # Safely parse JSON; prevent ValueError
    try:
        seed_response = response.json()
    except ValueError as e:
        raise AssertionError(f"Given (MR19): Failed to decode JSON response: {e}")

    context.seed_response = seed_response
    assert response.status_code == 200, (
        f"Given (MR19): Expected status 200, got {response.status_code}. "
        f"Body: {response.text}"
    )


@when(
    'a follow-up input is created by retrieving the list of pets again using the same set '
    'of tags under the same data conditions, yielding a follow-up output for MR19.'
)
def _mr_MR19_followup_input(context):
    tags = ['tag1', 'tag2']  # Same tags used for follow-up
    try:
        response = requests.get(
            f"{BASE_URL}/pet/findByTags",
            params={'tags': tags},
            timeout=10
        )
    except requests.RequestException as e:
        raise AssertionError(f"When (MR19): HTTP request to /pet/findByTags failed: {e}")

    context.followup_request = response
    _check_response_no_500(response, "When (MR19)")

    # Safely parse JSON; prevent ValueError
    try:
        followup_response = response.json()
    except ValueError as e:
        raise AssertionError(f"When (MR19): Failed to decode JSON response: {e}")

    context.followup_response = followup_response
    assert response.status_code == 200, (
        f"When (MR19): Expected status 200, got {response.status_code}. "
        f"Body: {response.text}"
    )


@then(
    'the follow-up output should be identical to the seed output, ensuring that the same '
    'set of tags consistently returns the same list of pets for MR19 when the store data '
    'remains unchanged.'
)
def _mr_MR19_assert_output(context):
    # Defensive checks to avoid AttributeError/TypeError
    if not hasattr(context, "seed_response"):
        raise AssertionError("Then (MR19): seed_response is missing from context")
    if not hasattr(context, "followup_response"):
        raise AssertionError("Then (MR19): followup_response is missing from context")

    try:
        assert context.seed_response == context.followup_response, (
            "Then (MR19): Follow-up output does not match seed output."
        )
    except TypeError as e:
        raise AssertionError(f"Then (MR19): Type error during comparison: {e}")

# ----




def _check_response_no_5xx(response, step_name: str) -> None:
    """
    Helper to ensure no 5xx is silently ignored.
    Raises AssertionError if a 5xx status code is returned.
    """
    if response is None:
        raise AssertionError(f"{step_name}: No response object available.")
    status = getattr(response, "status_code", None)
    if status is None:
        raise AssertionError(f"{step_name}: Response has no status_code.")
    if 500 <= int(status) <= 599:
        raise AssertionError(
            f"{step_name}: Server error {status} received. Body: {response.text}"
        )


@given('a seed input that logs a user into the system, producing a seed output with a successful login response for MR20.')
def step_mr_MR20_seed_input(context):
    context.seed_request = {
        "username": "testuser",
        "password": "testpassword",
    }

    try:
        response = requests.get(
            f"{BASE_URL}/user/login",
            params=context.seed_request,
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"Given step MR20: HTTP error during login: {e}")

    _check_response_no_5xx(response, "Given step MR20 (login)")
    context.seed_response = response

    if response.status_code != 200:
        raise AssertionError(
            f"Given step MR20: Login failed with status {response.status_code}. "
            f"Body: {response.text}"
        )


@when('a follow-up input is created by logging out the user using the same client context, yielding a follow-up output for MR20.')
def step_mr_MR20_followup_input(context):
    try:
        response = requests.get(
            f"{BASE_URL}/user/logout",
            timeout=10,
        )
    except requests.RequestException as e:
        raise AssertionError(f"When step MR20: HTTP error during logout: {e}")

    _check_response_no_5xx(response, "When step MR20 (logout)")
    context.followup_response = response

    if response.status_code != 200:
        raise AssertionError(
            f"When step MR20: Logout failed with status {response.status_code}. "
            f"Body: {response.text}"
        )


@then('the follow-up output should indicate a successful logout operation, confirming that a user who has logged in can subsequently log out without error for MR20.')
def step_mr_MR20_followup_output(context):
    response = getattr(context, "followup_response", None)
    _check_response_no_5xx(response, "Then step MR20 (logout verification)")

    if response.status_code != 200:
        raise AssertionError(
            f"Then step MR20: Logout was not successful. "
            f"Status: {response.status_code}, Body: {response.text}"
        )
