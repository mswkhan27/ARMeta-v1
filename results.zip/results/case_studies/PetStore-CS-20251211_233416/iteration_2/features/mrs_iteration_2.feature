Feature: Iteration 2 MRs

  Scenario: MR12 Deleting an order should make it unavailable for subsequent retrieval
    Given a seed input that retrieves a specific order by its identifier, producing a seed output that includes the details of this order for MR12.
    When a follow-up input is created by deleting this specific order using its identifier, followed by another attempt to retrieve the same order by the same identifier, yielding a follow-up output for MR12.
    Then the follow-up output should indicate that the order can no longer be found when retrieved by its identifier (for example, resulting in a not-found response), ensuring the order is unavailable for MR12.

  Scenario: MR13 Repeated logins with the same credentials should yield successful responses of the same type
    Given a seed input that attempts to log in with valid credentials, producing a seed output that includes a successful login response (such as a 200 status code and a string body) for MR13.
    When a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR13.
    Then the follow-up output should also represent a successful login response with the same general structure and type as the seed output (for example, the same status code class and a string body) for MR13.
