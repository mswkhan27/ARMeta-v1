from behave import given, when, then
import os, json, requests, time

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')

@given('a seed input that retrieves a specific order by its identifier, producing a seed output that includes the details of this order for MR12.')
def step_mr_MR12_seed_input(context):
    try:
        # Create an order to ensure it exists
        order_data = {
            "petId": 198772,
            "quantity": 1,
            "status": "placed",
            "complete": False
        }
        context.seed_request = requests.post(f"{BASE_URL}/store/order", json=order_data, timeout=10)
        context.seed_response = context.seed_request.json()
        assert context.seed_request.status_code == 200, f"Failed to create order: {context.seed_response}"
    except Exception as e:
        print(f"Error in Given step for MR12: {str(e)}")
        raise

@when('a follow-up input is created by deleting this specific order using its identifier, followed by another attempt to retrieve the same order by the same identifier, yielding a follow-up output for MR12.')
def step_mr_MR12_followup_input(context):
    try:
        order_id = context.seed_response['id']
        # Delete the order
        delete_response = requests.delete(f"{BASE_URL}/store/order/{order_id}", timeout=10)
        assert delete_response.status_code == 200, f"Failed to delete order: {delete_response.json()}"
        
        # Attempt to retrieve the same order
        context.followup_request = requests.get(f"{BASE_URL}/store/order/{order_id}", timeout=10)
        context.followup_response = context.followup_request.json()
    except Exception as e:
        print(f"Error in When step for MR12: {str(e)}")
        raise

@then('the follow-up output should indicate that the order can no longer be found when retrieved by its identifier (for example, resulting in a not-found response), ensuring the order is unavailable for MR12.')
def step_mr_MR12_followup_output(context):
    try:
        assert context.followup_request.status_code == 404, f"Expected 404 but got {context.followup_request.status_code}: {context.followup_response}"
    except Exception as e:
        print(f"Error in Then step for MR12: {str(e)}")
        raise

# ----

import os
import requests

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


def _check_500(response, step_name: str) -> None:
    """
    Fail fast on server errors and ensure we don't continue
    with invalid context state.
    """
    if response is None:
        raise AssertionError(f"{step_name}: No response object (response is None).")
    status = getattr(response, "status_code", None)
    if status is None:
        raise AssertionError(f"{step_name}: Response object has no status_code.")
    if 500 <= status <= 599:
        raise AssertionError(
            f"{step_name}: Server error {status} received from API. "
            f"Response text: {response.text}"
        )


@given(
    "a seed input that attempts to log in with valid credentials, producing a seed output that includes a successful login response (such as a 200 status code and a string body) for MR13."
)
def _mr_MR13_seed_login(context):
    context.username = "validUser"   # Replace with actual valid username if needed
    context.password = "validPassword"  # Replace with actual valid password if needed

    context.seed_request = {
        "username": context.username,
        "password": context.password,
    }

    response = requests.get(
        f"{BASE_URL}/user/login",
        params=context.seed_request,
        timeout=10,
    )
    _check_500(response, "MR13 Given (seed login)")

    context.seed_response = response

    status_code = context.seed_response.status_code
    if status_code != 200:
        raise AssertionError(f"Expected 200 but got {status_code}")

    # The OpenAPI spec says the 200 response body is a string; be defensive
    try:
        seed_body = context.seed_response.json()
    except ValueError:
        # If not JSON, fall back to text and still treat as a string body
        seed_body = context.seed_response.text

    if not isinstance(seed_body, str):
        raise AssertionError(
            f"Expected seed response body to be a string, got {type(seed_body).__name__}"
        )

    context.seed_body = seed_body


@when(
    "a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR13."
)
def _mr_MR13_followup_login(context):
    if not hasattr(context, "seed_request"):
        raise AssertionError(
            "MR13 When step: seed_request is missing from context. "
            "Given step may have failed or not run."
        )

    response = requests.get(
        f"{BASE_URL}/user/login",
        params=context.seed_request,
        timeout=10,
    )
    _check_500(response, "MR13 When (follow-up login)")

    context.followup_response = response

    status_code = context.followup_response.status_code
    if status_code != 200:
        raise AssertionError(f"Expected 200 but got {status_code}")


@then(
    "the follow-up output should also represent a successful login response with the same general structure and type as the seed output (for example, the same status code class and a string body) for MR13."
)
def _mr_MR13_verify_followup(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError(
            "MR13 Then step: seed_response is missing from context. "
            "Given step may have failed or not run."
        )
    if not hasattr(context, "followup_response"):
        raise AssertionError(
            "MR13 Then step: followup_response is missing from context. "
            "When step may have failed or not run."
        )

    _check_500(context.seed_response, "MR13 Then (seed re-check)")
    _check_500(context.followup_response, "MR13 Then (follow-up re-check)")

    seed_status = context.seed_response.status_code
    followup_status = context.followup_response.status_code

    if seed_status != followup_status:
        raise AssertionError(
            f"Status codes do not match between seed and follow-up: "
            f"{seed_status} != {followup_status}"
        )

    # Ensure both responses have string bodies (same general structure/type)
    try:
        followup_body = context.followup_response.json()
    except ValueError:
        followup_body = context.followup_response.text

    if not isinstance(followup_body, str):
        raise AssertionError(
            f"Expected follow-up response body to be a string, "
            f"got {type(followup_body).__name__}"
        )

    # Store for potential further checks or debugging
    context.followup_body = followup_body
