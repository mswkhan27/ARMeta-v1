Feature: Iteration 3 MRs

  Scenario: MR15 Retrieving pet inventory should reflect changes in pet status
    Given a seed input that retrieves the pet inventory by status, producing a seed output with a map of status values to quantities for MR15.
    When a follow-up input is created by updating the status of at least one existing pet to a different valid status and then retrieving the pet inventory again, yielding a follow-up output for MR15.
    Then the follow-up output should reflect the updated quantities for the affected status values, showing a non-increasing quantity for the original status of the updated pet and a non-decreasing quantity for its new status for MR15.

  Scenario: MR17 Creating users with a list should result in more retrievable users
    Given a seed input that identifies a set of existing users by their usernames and retrieves each of them individually, producing a seed output with the details of these users for MR17.
    When a follow-up input is created by submitting a list of new users with distinct usernames and then retrieving each of these new users individually by their usernames, yielding a follow-up output for MR17.
    Then the follow-up output should include all users from the seed output plus the newly created users, such that every username from both the original and newly created sets can be retrieved with corresponding user details for MR17.

  Scenario: MR18 Updating a pet with form data should only change specified fields
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR18.
    When a follow-up input is created by updating the pet's name and status using form data, and then retrieving the pet again by the same ID, yielding a follow-up output for MR18.
    Then the follow-up output should reflect the updated name and status while all other pet details (such as category, photoUrls, and tags) remain unchanged compared to the seed output for MR18.
