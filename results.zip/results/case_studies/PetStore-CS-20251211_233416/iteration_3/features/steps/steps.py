from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, step_name: str) -> None:
    if response is not None and response.status_code == 500:
        raise AssertionError(f"500 Internal Server Error in {step_name} for URL {response.url}")


@given('a seed input that retrieves the pet inventory by status, producing a seed output with a map of status values to quantities for MR15.')
def step_mr_MR15_seed_input(context):
    response = None
    try:
        response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
        _check_500(response, "MR15 Given - get inventory")
        response.raise_for_status()

        # Ensure we always have a dict to avoid TypeError
        data = response.json()
        if not isinstance(data, dict):
            raise AssertionError("Inventory response is not a JSON object (expected map of status to quantities).")

        context.seed_response = data
        context.seed_request = {
            "method": "GET",
            "url": f"{BASE_URL}/store/inventory"
        }
    except Exception as e:
        # Ensure error is visible in Behave report
        raise AssertionError(f"Error in MR15 Given step: {e}") from e


@when('a follow-up input is created by updating the status of at least one existing pet to a different valid status and then retrieving the pet inventory again, yielding a follow-up output for MR15.')
def step_mr_MR15_followup_input(context):
    add_response = None
    update_response = None
    followup_response = None

    try:
        # Create a new pet with a known initial status
        new_pet = {
            "name": "TestPet-MR15",
            "photoUrls": ["http://example.com/photo.jpg"],
            "status": "available"
        }

        add_response = requests.post(f"{BASE_URL}/pet", json=new_pet, timeout=10)
        _check_500(add_response, "MR15 When - add pet")
        add_response.raise_for_status()

        add_data = add_response.json()
        if not isinstance(add_data, dict):
            raise AssertionError("Add pet response is not a JSON object.")
        pet_id = add_data.get('id')
        if pet_id is None:
            raise AssertionError("Add pet response does not contain 'id' field.")

        # Safely convert pet_id to int if possible (spec says int64)
        try:
            pet_id_int = int(pet_id)
        except (TypeError, ValueError) as conv_err:
            raise AssertionError(f"Pet id is not a valid integer: {pet_id}") from conv_err

        # Update the pet's status using POST /pet/{petId} with query parameters name/status
        update_params = {
            "status": "sold"
        }
        update_response = requests.post(
            f"{BASE_URL}/pet/{pet_id_int}",
            params=update_params,
            timeout=10
        )
        _check_500(update_response, "MR15 When - update pet status")
        update_response.raise_for_status()

        # Retrieve the pet inventory again
        followup_response = requests.get(f"{BASE_URL}/store/inventory", timeout=10)
        _check_500(followup_response, "MR15 When - get inventory follow-up")
        followup_response.raise_for_status()

        followup_data = followup_response.json()
        if not isinstance(followup_data, dict):
            raise AssertionError("Follow-up inventory response is not a JSON object (expected map of status to quantities).")

        context.followup_response = followup_data
        context.followup_request = {
            "created_pet_id": pet_id_int,
            "update_params": update_params,
            "inventory_url": f"{BASE_URL}/store/inventory"
        }
        context.updated_from_status = "available"
        context.updated_to_status = "sold"
    except Exception as e:
        raise AssertionError(f"Error in MR15 When step: {e}") from e


@then('the follow-up output should reflect the updated quantities for the affected status values, showing a non-increasing quantity for the original status of the updated pet and a non-decreasing quantity for its new status for MR15.')
def step_mr_MR15_followup_output(context):
    try:
        if not hasattr(context, "seed_response") or not isinstance(context.seed_response, dict):
            raise AssertionError("Seed inventory response is missing or invalid.")
        if not hasattr(context, "followup_response") or not isinstance(context.followup_response, dict):
            raise AssertionError("Follow-up inventory response is missing or invalid.")

        from_status = getattr(context, "updated_from_status", "available")
        to_status = getattr(context, "updated_to_status", "sold")

        # Use 0 as default if the key is missing; ensure values are ints
        def _safe_int(value):
            try:
                return int(value)
            except (TypeError, ValueError):
                return 0

        original_from_qty = _safe_int(context.seed_response.get(from_status, 0))
        followup_from_qty = _safe_int(context.followup_response.get(from_status, 0))

        original_to_qty = _safe_int(context.seed_response.get(to_status, 0))
        followup_to_qty = _safe_int(context.followup_response.get(to_status, 0))

        # Non-increasing for original status
        if followup_from_qty > original_from_qty:
            raise AssertionError(
                f"Quantity for status '{from_status}' increased from {original_from_qty} to {followup_from_qty}, "
                f"expected non-increasing."
            )

        # Non-decreasing for new status
        if followup_to_qty < original_to_qty:
            raise AssertionError(
                f"Quantity for status '{to_status}' decreased from {original_to_qty} to {followup_to_qty}, "
                f"expected non-decreasing."
            )

    except Exception as e:
        raise AssertionError(f"Error in MR15 Then step: {e}") from e

# ----




def _check_server_error(response, step_name: str, action: str) -> None:
    """
    Ensure no 5xx errors are silently ignored.
    Raises AssertionError if a 5xx status code is returned.
    """
    status = response.status_code
    if 500 <= status <= 599:
        # Include body for debugging but keep it safe
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"[{step_name}] Server error during {action}: "
            f"HTTP {status} - {body}"
        )


@given('a seed input that identifies a set of existing users by their usernames and retrieves each of them individually, producing a seed output with the details of these users for MR17.')
def _mr_MR17_seed_users(context):
    # Initialize containers defensively
    context.usernames = ['user1', 'user2', 'user3']
    context.seed_response = []

    for index, username in enumerate(context.usernames, start=1):
        user_data = {
            "id": index,
            "username": username,
            "firstName": f"First{index}",
            "lastName": f"Last{index}",
            "email": f"{username}@example.com",
            "password": "password",
            "phone": "1234567890",
            "userStatus": 1
        }

        # Create or overwrite the user via POST /user
        response = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
        _check_server_error(response, "Given", f"creating user '{username}'")

        if response.status_code != 200:
            raise AssertionError(
                f"[Given] Failed to create user '{username}': "
                f"HTTP {response.status_code} - {response.text}"
            )

        # Retrieve the user details via GET /user/\{username\}
        get_response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
        _check_server_error(get_response, "Given", f"retrieving user '{username}'")

        if get_response.status_code != 200:
            raise AssertionError(
                f"[Given] Failed to retrieve user '{username}' after creation: "
                f"HTTP {get_response.status_code} - {get_response.text}"
            )

        try:
            user_details = get_response.json()
        except ValueError as exc:
            raise AssertionError(
                f"[Given] Response for user '{username}' is not valid JSON: {exc}"
            ) from exc

        if not isinstance(user_details, dict):
            raise AssertionError(
                f"[Given] Expected JSON object for user '{username}', "
                f"got {type(user_details).__name__}"
            )

        context.seed_response.append(user_details)


@when('a follow-up input is created by submitting a list of new users with distinct usernames and then retrieving each of these new users individually by their usernames, yielding a follow-up output for MR17.')
def _mr_MR17_followup_users(context):
    context.new_usernames = ['user4', 'user5']
    context.followup_created_users = []
    context.followup_retrieved_users = []

    # According to MR: create users *with a list* using POST /user/createWithList
    new_users_payload = []
    start_index = len(getattr(context, "seed_response", [])) + 1

    for offset, username in enumerate(context.new_usernames, start=0):
        user_data = {
            "id": start_index + offset,
            "username": username,
            "firstName": f"FirstNew{offset + 1}",
            "lastName": f"LastNew{offset + 1}",
            "email": f"{username}@example.com",
            "password": "password",
            "phone": "1234567890",
            "userStatus": 1
        }
        new_users_payload.append(user_data)

    # Create list of users via POST /user/createWithList (matches MR + OpenAPI summary)
    create_list_response = requests.post(
        f"{BASE_URL}/user/createWithList",
        json=new_users_payload,
        timeout=10
    )
    _check_server_error(create_list_response, "When", "creating list of new users")

    if create_list_response.status_code != 200:
        raise AssertionError(
            "[When] Failed to create users with list: "
            f"HTTP {create_list_response.status_code} - {create_list_response.text}"
        )

    # Store the payload as the created set (we rely on server echo/contract behavior)
    context.followup_created_users.extend(new_users_payload)

    # Retrieve each newly created user individually using GET /user/\{username\}
    for username in context.new_usernames:
        get_response = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
        _check_server_error(get_response, "When", f"retrieving new user '{username}'")

        if get_response.status_code != 200:
            raise AssertionError(
                f"[When] Failed to retrieve new user '{username}': "
                f"HTTP {get_response.status_code} - {get_response.text}"
            )

        try:
            user_details = get_response.json()
        except ValueError as exc:
            raise AssertionError(
                f"[When] Response for new user '{username}' is not valid JSON: {exc}"
            ) from exc

        if not isinstance(user_details, dict):
            raise AssertionError(
                f"[When] Expected JSON object for new user '{username}', "
                f"got {type(user_details).__name__}"
            )

        context.followup_retrieved_users.append(user_details)


@then('the follow-up output should include all users from the seed output plus the newly created users, such that every username from both the original and newly created sets can be retrieved with corresponding user details for MR17.')
def _mr_MR17_assert_users(context):
    # Defensive defaults
    seed_users = getattr(context, "seed_response", [])
    retrieved_new_users = getattr(context, "followup_retrieved_users", [])
    original_usernames = getattr(context, "usernames", [])
    new_usernames = getattr(context, "new_usernames", [])

    if not isinstance(seed_users, list) or not isinstance(retrieved_new_users, list):
        raise AssertionError(
            "[Then] Internal test state invalid: user collections are not lists."
        )

    expected_usernames = set(original_usernames + new_usernames)
    all_users = seed_users + retrieved_new_users

    # Ensure that for every expected username, we have at least one user detail entry
    found_usernames = set()
    for user in all_users:
        if not isinstance(user, dict):
            raise AssertionError(
                f"[Then] Expected each user to be a dict, got {type(user).__name__}"
            )

        username = user.get("username")
        if not isinstance(username, str):
            raise AssertionError(
                "[Then] Each user must contain a string 'username' field."
            )

        if username in expected_usernames:
            found_usernames.add(username)

    missing_usernames = expected_usernames - found_usernames
    if missing_usernames:
        raise AssertionError(
            "[Then] Some expected usernames were not present in the follow-up output: "
            f"{sorted(missing_usernames)}"
        )

# ----


BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")




@given(
    "a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR18."
)
def _mr_MR18_seed_input(context):
    # Create a pet to ensure it exists, then retrieve it by ID to form the seed output.
    pet_data = {
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available",
    }

    create_response = None
    get_response = None
    try:
        create_response = requests.post(
            f"{BASE_URL}/pet",
            json=pet_data,
            timeout=10,
        )
        _check_500(create_response, "Given MR18 - create pet")
        create_response.raise_for_status()

        created_pet = create_response.json() if create_response.content else {}
        pet_id = created_pet.get("id")
        if pet_id is None:
            raise AssertionError("Created pet has no 'id' field in response.")

        # Now retrieve the pet by ID as the seed output
        get_response = requests.get(
            f"{BASE_URL}/pet/{pet_id}",
            timeout=10,
        )
        _check_500(get_response, "Given MR18 - get pet by id")
        get_response.raise_for_status()

        seed_pet = get_response.json() if get_response.content else {}
        # Store both request and response safely
        context.seed_request = json.loads(json.dumps(pet_data))
        context.seed_response = json.loads(json.dumps(seed_pet))
        context.pet_id = pet_id
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in Given step for MR18: {e}") from e
    except (TypeError, ValueError) as e:
        raise AssertionError(f"Parsing/Type error in Given step for MR18: {e}") from e


@when(
    "a follow-up input is created by updating the pet's name and status using form data, and then retrieving the pet again by the same ID, yielding a follow-up output for MR18."
)
def _mr_MR18_followup_input(context):
    if not hasattr(context, "pet_id"):
        raise AssertionError("pet_id not found in context; Given step may have failed.")

    pet_id = context.pet_id
    updated_name = "doggie_updated"
    updated_status = "sold"

    update_response = None
    followup_response = None
    try:
        # According to OpenAPI: POST /pet/\{petId\} with query params name and status
        update_response = requests.post(
            f"{BASE_URL}/pet/{pet_id}",
            params={"name": updated_name, "status": updated_status},
            timeout=10,
        )
        _check_500(update_response, "When MR18 - updatePetWithForm")
        update_response.raise_for_status()

        # Retrieve the pet again to get the follow-up output
        followup_response = requests.get(
            f"{BASE_URL}/pet/{pet_id}",
            timeout=10,
        )
        _check_500(followup_response, "When MR18 - getPetById after update")
        followup_response.raise_for_status()

        context.updated_name = updated_name
        context.updated_status = updated_status
        context.followup_response = (
            followup_response.json() if followup_response.content else {}
        )
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in When step for MR18: {e}") from e
    except (TypeError, ValueError) as e:
        raise AssertionError(f"Parsing/Type error in When step for MR18: {e}") from e


@then(
    "the follow-up output should reflect the updated name and status while all other pet details (such as category, photoUrls, and tags) remain unchanged compared to the seed output for MR18."
)
def _mr_MR18_followup_assertion(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("seed_response not found in context; Given step may have failed.")
    if not hasattr(context, "followup_response"):
        raise AssertionError("followup_response not found in context; When step may have failed.")

    seed = context.seed_response or {}
    followup = context.followup_response or {}

    try:
        # Check updated fields
        expected_name = getattr(context, "updated_name", "doggie_updated")
        expected_status = getattr(context, "updated_status", "sold")

        if followup.get("name") != expected_name:
            raise AssertionError(
                f"Name was not updated correctly. Expected '{expected_name}', got '{followup.get('name')}'."
            )

        if followup.get("status") != expected_status:
            raise AssertionError(
                f"Status was not updated correctly. Expected '{expected_status}', got '{followup.get('status')}'."
            )

        # Helper to normalize possibly-missing fields to allow safe comparison
        def _field(obj, key, default):
            val = obj.get(key, default)
            # Ensure types are JSON-serializable and comparable
            try:
                json.dumps(val)
            except (TypeError, ValueError):
                raise AssertionError(f"Non-serializable value for field '{key}'.")
            return val

        # Compare other fields: category, photoUrls, tags should remain unchanged
        seed_category = _field(seed, "category", None)
        followup_category = _field(followup, "category", None)
        if seed_category != followup_category:
            raise AssertionError(
                f"Category has changed. Seed: {seed_category}, Follow-up: {followup_category}"
            )

        seed_photos = _field(seed, "photoUrls", [])
        followup_photos = _field(followup, "photoUrls", [])
        if seed_photos != followup_photos:
            raise AssertionError(
                f"Photo URLs have changed. Seed: {seed_photos}, Follow-up: {followup_photos}"
            )

        seed_tags = _field(seed, "tags", [])
        followup_tags = _field(followup, "tags", [])
        if seed_tags != followup_tags:
            raise AssertionError(
                f"Tags have changed. Seed: {seed_tags}, Follow-up: {followup_tags}"
            )
    except (TypeError, ValueError) as e:
        raise AssertionError(f"Type/Value error in Then step for MR18: {e}") from e
