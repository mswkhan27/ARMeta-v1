
# --- From iteration_0\features\mrs_iteration_0.feature ---

Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet with a given status should increase the count of pets with that status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of available pets for MR1.
    When a follow-up input is created by adding a new pet whose status is set to 'available', and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR1.
    Then the follow-up output should include the newly added pet in the list of available pets and have a count of available pets that is greater than or equal to the seed output, and exactly one more than the seed output if no other changes have occurred in between for MR1.

  Scenario: MR2 Updating a pet's status should reflect in the pet's retrieved details
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's current status for MR2.
    When a follow-up input is created by updating the same pet so that only its status is changed to 'sold' while all other fields are kept the same in the request, and then retrieving the pet again by the same ID, yielding a follow-up output for MR2.
    Then the follow-up output should reflect the updated status 'sold', and all other pet details (such as name, category, photoUrls, and tags) should remain identical to the seed output for MR2.

  Scenario: MR3 Deleting a pet should make it unavailable for subsequent retrieval
    Given a seed input that retrieves a specific pet by its identifier (and optionally confirms its presence in a filtered list, such as by status), producing a seed output that includes this pet for MR3.
    When a follow-up input is created by deleting this specific pet using its identifier, followed by another attempt to retrieve the same pet (and, if applicable, retrieve the filtered list again), yielding a follow-up output for MR3.
    Then the follow-up output should no longer return the deleted pet when retrieved by its identifier (for example, resulting in a not-found response) and should not include the deleted pet in any relevant filtered list, with the count of pets in that list reduced accordingly if no other changes have occurred for MR3.

  Scenario: MR5 Updating user details should only change the specified fields
    Given a seed input that retrieves a user by username, producing a seed output with the user's full set of details for MR5.
    When a follow-up input is created by updating the same user so that only the email field is changed while all other fields are kept the same in the request, and then retrieving the user again by the same username, yielding a follow-up output for MR5.
    Then the follow-up output should reflect the updated email value while all other user details (such as id, username, firstName, lastName, phone, and userStatus) remain identical to the seed output for MR5.


# --- From iteration_1\features\mrs_iteration_1.feature ---

Feature: Iteration 1 MRs

  Scenario: MR6 Deleting a user should make the user unavailable for subsequent retrieval
    Given a seed input that retrieves a specific user by their username, producing a seed output that includes this user's details for MR6.
    When a follow-up input is created by deleting this specific user using their username, followed by another attempt to retrieve the same user, yielding a follow-up output for MR6.
    Then the follow-up output should indicate that the user can no longer be found when retrieved by their username (for example, resulting in a not-found response), ensuring the user is unavailable for MR6.

  Scenario: MR10 Uploading an image for a pet should not alter other pet details
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR10.
    When a follow-up input is created by uploading an image for the same pet, and then retrieving the pet again by the same ID, yielding a follow-up output for MR10.
    Then the follow-up output should reflect the same pet details as the seed output, ensuring that uploading an image does not alter the stored pet information for MR10.


# --- From iteration_2\features\mrs_iteration_2.feature ---

Feature: Iteration 2 MRs

  Scenario: MR12 Deleting an order should make it unavailable for subsequent retrieval
    Given a seed input that retrieves a specific order by its identifier, producing a seed output that includes the details of this order for MR12.
    When a follow-up input is created by deleting this specific order using its identifier, followed by another attempt to retrieve the same order by the same identifier, yielding a follow-up output for MR12.
    Then the follow-up output should indicate that the order can no longer be found when retrieved by its identifier (for example, resulting in a not-found response), ensuring the order is unavailable for MR12.

  Scenario: MR13 Repeated logins with the same credentials should yield successful responses of the same type
    Given a seed input that attempts to log in with valid credentials, producing a seed output that includes a successful login response (such as a 200 status code and a string body) for MR13.
    When a follow-up input is created by logging in again with the same credentials, yielding a follow-up output for MR13.
    Then the follow-up output should also represent a successful login response with the same general structure and type as the seed output (for example, the same status code class and a string body) for MR13.


# --- From iteration_3\features\mrs_iteration_3.feature ---

Feature: Iteration 3 MRs

  Scenario: MR15 Retrieving pet inventory should reflect changes in pet status
    Given a seed input that retrieves the pet inventory by status, producing a seed output with a map of status values to quantities for MR15.
    When a follow-up input is created by updating the status of at least one existing pet to a different valid status and then retrieving the pet inventory again, yielding a follow-up output for MR15.
    Then the follow-up output should reflect the updated quantities for the affected status values, showing a non-increasing quantity for the original status of the updated pet and a non-decreasing quantity for its new status for MR15.

  Scenario: MR17 Creating users with a list should result in more retrievable users
    Given a seed input that identifies a set of existing users by their usernames and retrieves each of them individually, producing a seed output with the details of these users for MR17.
    When a follow-up input is created by submitting a list of new users with distinct usernames and then retrieving each of these new users individually by their usernames, yielding a follow-up output for MR17.
    Then the follow-up output should include all users from the seed output plus the newly created users, such that every username from both the original and newly created sets can be retrieved with corresponding user details for MR17.

  Scenario: MR18 Updating a pet with form data should only change specified fields
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR18.
    When a follow-up input is created by updating the pet's name and status using form data, and then retrieving the pet again by the same ID, yielding a follow-up output for MR18.
    Then the follow-up output should reflect the updated name and status while all other pet details (such as category, photoUrls, and tags) remain unchanged compared to the seed output for MR18.


# --- From iteration_4\features\mrs_iteration_4.feature ---

Feature: Iteration 4 MRs

  Scenario: MR19 Finding pets by tags should return a consistent set of pets when the underlying data does not change
    Given a seed input that retrieves a list of pets filtered by a specific set of tags, producing a seed output with the list of pets for MR19, and assuming no pets or their tags are modified between calls.
    When a follow-up input is created by retrieving the list of pets again using the same set of tags under the same data conditions, yielding a follow-up output for MR19.
    Then the follow-up output should be identical to the seed output, ensuring that the same set of tags consistently returns the same list of pets for MR19 when the store data remains unchanged.

  Scenario: MR20 Logging in and then logging out should both complete successfully
    Given a seed input that logs a user into the system, producing a seed output with a successful login response for MR20.
    When a follow-up input is created by logging out the user using the same client context, yielding a follow-up output for MR20.
    Then the follow-up output should indicate a successful logout operation, confirming that a user who has logged in can subsequently log out without error for MR20.

