from behave import given, when, then
import os
import json
import requests

BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')


def _check_500(response, step_name: str) -> None:
    """Raise AssertionError if a 500-class error is returned."""
    status = response.status_code
    if 500 <= status <= 599:
        body = None
        try:
            body = response.json()
        except ValueError:
            body = response.text
        raise AssertionError(f"{step_name}: Server error {status} received. Response body: {body}")


@given("a seed input that retrieves a specific user by their username, producing a seed output that includes this user's details for MR6.")
def _mr_MR6_seed_input(context):
    # Use unique-ish username per run to avoid collisions
    username = "testuser_mr6"
    user_data = {
        "id": 10,
        "username": username,
        "firstName": "Test",
        "lastName": "User",
        "email": "testuser@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1,
    }

    # Create user (POST /user)
    response = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    _check_500(response, "Given MR6 - createUser")
    context.seed_request = response

    # Safely parse response JSON (may be non-JSON on error)
    try:
        context.seed_response = response.json()
    except ValueError:
        context.seed_response = {}

    assert response.status_code == 200, (
        f"Failed to create user, status={response.status_code}, body={response.text}"
    )

    # Retrieve the same user to satisfy 'seed input that retrieves a specific user'
    get_resp = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    _check_500(get_resp, "Given MR6 - getUserByName (seed retrieval)")

    try:
        context.seed_get_response = get_resp.json()
    except ValueError:
        context.seed_get_response = {}

    assert get_resp.status_code == 200, (
        f"Seed retrieval failed, expected 200, got {get_resp.status_code}, body={get_resp.text}"
    )

    # Ensure we have user details stored for later steps
    context.username = username


@when("a follow-up input is created by deleting this specific user using their username, followed by another attempt to retrieve the same user, yielding a follow-up output for MR6.")
def _mr_MR6_followup_input(context):
    # Ensure username is available
    username = getattr(context, "username", None)
    if not isinstance(username, str) or not username:
        # Fallback to seed_response if needed, but guard against missing keys
        seed_username = None
        seed_resp = getattr(context, "seed_response", {}) or {}
        if isinstance(seed_resp, dict):
            seed_username = seed_resp.get("username")
        if not isinstance(seed_username, str) or not seed_username:
            raise AssertionError("Username for MR6 not available in context.")
        username = seed_username
        context.username = username

    # Delete the user (DELETE /user/\{username\})
    delete_response = requests.delete(f"{BASE_URL}/user/{username}", timeout=10)
    _check_500(delete_response, "When MR6 - deleteUser")
    context.delete_response = delete_response

    assert delete_response.status_code == 200, (
        f"Failed to delete user, status={delete_response.status_code}, body={delete_response.text}"
    )

    # Attempt to retrieve the same user (GET /user/\{username\})
    followup_request = requests.get(f"{BASE_URL}/user/{username}", timeout=10)
    _check_500(followup_request, "When MR6 - getUserByName (follow-up retrieval)")
    context.followup_request = followup_request

    try:
        context.followup_response = followup_request.json()
    except ValueError:
        context.followup_response = None


@then("the follow-up output should indicate that the user can no longer be found when retrieved by their username (for example, resulting in a not-found response), ensuring the user is unavailable for MR6.")
def _mr_MR6_followup_output(context):
    followup_request = getattr(context, "followup_request", None)
    assert followup_request is not None, "Follow-up request not found in context."

    # 500s already checked in When, but double-check defensively
    _check_500(followup_request, "Then MR6 - getUserByName (assertion)")

    status = followup_request.status_code
    assert status == 404, (
        f"User should not be found after deletion, expected 404, got {status}, "
        f"body={followup_request.text}"
    )

# ----


PET_ID_FOR_MR10 = 10
IMAGE_PATH_FOR_MR10 = os.environ.get('MR10_IMAGE_PATH', 'path_to_image.jpg')


def _check_response_no_500(response, step_name: str) -> None:
    """
    Ensure no 5xx error is returned.
    Raise AssertionError so Behave marks the step as failed.
    """
    status = getattr(response, "status_code", None)
    if status is None:
        raise AssertionError(f"{step_name}: Response has no status_code attribute")
    if 500 <= status <= 599:
        body = None
        try:
            body = response.json()
        except Exception:
            body = response.text
        raise AssertionError(f"{step_name}: Server error {status}: {body}")


def _safe_get_json(response):
    """
    Safely parse JSON; always return a dict (or list) to avoid TypeError.
    """
    try:
        return response.json()
    except ValueError:
        return {}


@given("a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR10.")
def _mr_MR10_seed_input(context):
    # Create or update a pet to ensure it exists using POST /pet
    pet_data = {
        "id": PET_ID_FOR_MR10,
        "name": "doggie",
        "photoUrls": ["url1", "url2"],
        "status": "available"
    }
    response = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_no_500(response, "MR10 Given - create pet")
    seed_body = _safe_get_json(response)

    if response.status_code != 200:
        raise AssertionError(f"MR10 Given - Failed to create pet: status={response.status_code}, body={seed_body}")

    # Now retrieve the pet by ID using GET /pet/\{petId\}
    get_response = requests.get(f"{BASE_URL}/pet/{PET_ID_FOR_MR10}", timeout=10)
    _check_response_no_500(get_response, "MR10 Given - get pet by id")
    get_body = _safe_get_json(get_response)

    if get_response.status_code != 200:
        raise AssertionError(f"MR10 Given - Failed to retrieve pet by id: status={get_response.status_code}, body={get_body}")

    # Store responses safely on context
    context.seed_request = get_response
    context.seed_response = get_body


@when("a follow-up input is created by uploading an image for the same pet, and then retrieving the pet again by the same ID, yielding a follow-up output for MR10.")
def _mr_MR10_followup_input(context):
    # Upload an image for the pet via POST /pet/\{petId\}/uploadImage
    # API spec: consumes application/octet-stream with binary body
    if not os.path.isfile(IMAGE_PATH_FOR_MR10):
        raise AssertionError(f"MR10 When - Image file not found at path: {IMAGE_PATH_FOR_MR10}")

    with open(IMAGE_PATH_FOR_MR10, "rb") as image_file:
        upload_response = requests.post(
            f"{BASE_URL}/pet/{PET_ID_FOR_MR10}/uploadImage",
            data=image_file,
            headers={"Content-Type": "application/octet-stream"},
            timeout=20,
        )

    _check_response_no_500(upload_response, "MR10 When - upload image")

    # 200 is successful per spec; other statuses (400/404/default) should fail the MR
    upload_body = _safe_get_json(upload_response)
    if upload_response.status_code != 200:
        raise AssertionError(
            f"MR10 When - Failed to upload image: status={upload_response.status_code}, body={upload_body}"
        )

    # Retrieve the pet again using GET /pet/\{petId\}
    followup_request = requests.get(f"{BASE_URL}/pet/{PET_ID_FOR_MR10}", timeout=10)
    _check_response_no_500(followup_request, "MR10 When - get pet after upload")
    followup_body = _safe_get_json(followup_request)

    if followup_request.status_code != 200:
        raise AssertionError(
            f"MR10 When - Failed to retrieve pet after upload: status={followup_request.status_code}, body={followup_body}"
        )

    context.followup_request = followup_request
    context.followup_response = followup_body


@then("the follow-up output should reflect the same pet details as the seed output, ensuring that uploading an image does not alter the stored pet information for MR10.")
def _mr_MR10_followup_output(context):
    seed = getattr(context, "seed_response", None)
    followup = getattr(context, "followup_response", None)

    if not isinstance(seed, dict):
        raise AssertionError(f"MR10 Then - Seed response is not a JSON object: {seed!r}")
    if not isinstance(followup, dict):
        raise AssertionError(f"MR10 Then - Follow-up response is not a JSON object: {followup!r}")

    # Extract fields safely with .get to avoid KeyError / TypeError
    seed_id = seed.get("id")
    follow_id = followup.get("id")
    seed_name = seed.get("name")
    follow_name = followup.get("name")
    seed_status = seed.get("status")
    follow_status = followup.get("status")
    seed_photos = seed.get("photoUrls")
    follow_photos = followup.get("photoUrls")

    # Basic type checks to avoid confusing assertion messages
    if seed_id is None or follow_id is None:
        raise AssertionError(f"MR10 Then - Missing 'id' in responses: seed_id={seed_id}, follow_id={follow_id}")

    if not isinstance(seed_photos, list) or not isinstance(follow_photos, list):
        raise AssertionError(
            f"MR10 Then - 'photoUrls' should be lists: seed_photoUrls={seed_photos!r}, follow_photoUrls={follow_photos!r}"
        )

    assert follow_id == seed_id, f"MR10 Then - Pet ID does not match: seed={seed_id}, followup={follow_id}"
    assert follow_name == seed_name, f"MR10 Then - Pet name has changed: seed={seed_name!r}, followup={follow_name!r}"
    assert (
        follow_status == seed_status
    ), f"MR10 Then - Pet status has changed: seed={seed_status!r}, followup={follow_status!r}"
    assert (
        follow_photos == seed_photos
    ), f"MR10 Then - Pet photoUrls have changed: seed={seed_photos!r}, followup={follow_photos!r}"
