Feature: Iteration 1 MRs

  Scenario: MR6 Deleting a user should make the user unavailable for subsequent retrieval
    Given a seed input that retrieves a specific user by their username, producing a seed output that includes this user's details for MR6.
    When a follow-up input is created by deleting this specific user using their username, followed by another attempt to retrieve the same user, yielding a follow-up output for MR6.
    Then the follow-up output should indicate that the user can no longer be found when retrieved by their username (for example, resulting in a not-found response), ensuring the user is unavailable for MR6.

  Scenario: MR10 Uploading an image for a pet should not alter other pet details
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's details for MR10.
    When a follow-up input is created by uploading an image for the same pet, and then retrieving the pet again by the same ID, yielding a follow-up output for MR10.
    Then the follow-up output should reflect the same pet details as the seed output, ensuring that uploading an image does not alter the stored pet information for MR10.
