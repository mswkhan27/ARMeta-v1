from behave import given, when, then
import os
import json
import requests
from behave import step

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080/api/v3")


def _check_500(response, step_name: str) -> None:
    """
    Utility to ensure no 500-level error slips through silently.
    Raises an AssertionError with details if a 500 error is encountered.
    """
    if 500 <= response.status_code <= 599:
        try:
            body = response.json()
        except ValueError:
            body = response.text
        raise AssertionError(
            f"Server error in {step_name}: status={response.status_code}, body={body}"
        )


@given(
    "a seed input that retrieves the list of pets filtered by status 'available', "
    "producing a seed output with a count of available pets for MR1."
)
def _mr_MR1_seed_input(context):
    # Retrieve the list of available pets using GET /pet/findByStatus with query param `status`
    url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}

    try:
        response = requests.get(url, params=params, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error in GIVEN step for MR1: {e}") from e

    _check_500(response, "GIVEN MR1")
    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(f"Non-success status in GIVEN MR1: {response.status_code}") from e

    try:
        data = response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in GIVEN MR1 response: {e}") from e

    if not isinstance(data, list):
        raise AssertionError(f"GIVEN MR1 expected a list of pets, got: {type(data)}")

    context.seed_response = data
    context.seed_request = {"status": "available"}
    context.misc = {"available_count": len(data)}


@when(
    "a follow-up input is created by adding a new pet whose status is set to 'available', "
    "and then retrieving again the list of pets filtered by status 'available', "
    "yielding a follow-up output for MR1."
)
def _mr_MR1_followup_input(context):
    # Create a new pet using POST /pet with status 'available'
    new_pet = {
        "name": "New Available Pet",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available",
    }
    create_url = f"{BASE_URL}/pet"

    try:
        add_response = requests.post(create_url, json=new_pet, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error when creating pet in WHEN MR1: {e}") from e

    _check_500(add_response, "WHEN MR1 create pet")
    try:
        add_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"Non-success status when creating pet in WHEN MR1: {add_response.status_code}"
        ) from e

    # We can safely attempt to parse; errors will be surfaced clearly
    try:
        created_pet = add_response.json()
    except ValueError:
        created_pet = None

    # Store created_pet safely; it may be None if server returned no/invalid JSON
    context.created_pet = created_pet

    # Retrieve the list of available pets again using GET /pet/findByStatus
    list_url = f"{BASE_URL}/pet/findByStatus"
    params = {"status": "available"}

    try:
        followup_response = requests.get(list_url, params=params, timeout=10)
    except requests.RequestException as e:
        raise AssertionError(f"HTTP error when listing pets in WHEN MR1: {e}") from e

    _check_500(followup_response, "WHEN MR1 list pets")
    try:
        followup_response.raise_for_status()
    except requests.HTTPError as e:
        raise AssertionError(
            f"Non-success status when listing pets in WHEN MR1: {followup_response.status_code}"
        ) from e

    try:
        followup_data = followup_response.json()
    except ValueError as e:
        raise AssertionError(f"Invalid JSON in WHEN MR1 list response: {e}") from e

    if not isinstance(followup_data, list):
        raise AssertionError(f"WHEN MR1 expected a list of pets, got: {type(followup_data)}")

    context.followup_response = followup_data
    context.followup_request = {"status": "available"}


@then(
    "the follow-up output should include the newly added pet in the list of available pets "
    "and have a count of available pets that is greater than or equal to the seed output, "
    "and exactly one more than the seed output if no other changes have occurred in between for MR1."
)
def _mr_MR1_followup_output(context):
    if not hasattr(context, "followup_response"):
        raise AssertionError("THEN MR1: followup_response is missing from context.")
    if not hasattr(context, "misc") or "available_count" not in context.misc:
        raise AssertionError("THEN MR1: seed available_count is missing from context.")

    seed_count = context.misc["available_count"]
    followup_data = context.followup_response

    if not isinstance(followup_data, list):
        raise AssertionError(f"THEN MR1 expected followup_response to be a list, got: {type(followup_data)}")

    followup_count = len(followup_data)

    # Count relationships
    if followup_count < seed_count:
        raise AssertionError(
            f"THEN MR1: Follow-up count {followup_count} is less than seed count {seed_count}."
        )

    if followup_count != seed_count + 1:
        raise AssertionError(
            f"THEN MR1: Follow-up count {followup_count} is not exactly one more than seed count {seed_count}."
        )

    # Verify that the newly added pet is present by name (robust against missing keys)
    new_pet_name = "New Available Pet"
    found = False
    for pet in followup_data:
        if not isinstance(pet, dict):
            continue
        name = pet.get("name")
        if isinstance(name, str) and name == new_pet_name:
            found = True
            break

    if not found:
        raise AssertionError("THEN MR1: Newly added pet is not in the follow-up output.")

# ----




def _check_response_no_500(response, step_name: str) -> None:
    """
    Ensure no 5xx error is returned. Raise AssertionError to fail Behave step.
    """
    status_code = getattr(response, "status_code", None)
    if status_code is None:
        raise AssertionError(f"{step_name}: Response object has no status_code")

    if 500 <= status_code <= 599:
        body = None
        try:
            body = response.text
        except Exception:
            body = "<unreadable body>"
        raise AssertionError(
            f"{step_name}: Server error {status_code} received. Response body: {body}"
        )


def _safe_json(response, step_name: str):
    """
    Safely parse JSON without raising TypeError/ValueError.
    """
    if response is None:
        raise AssertionError(f"{step_name}: Response is None")
    try:
        return response.json()
    except ValueError:
        text = None
        try:
            text = response.text
        except Exception:
            text = "<unreadable body>"
        raise AssertionError(
            f"{step_name}: Response body is not valid JSON. Status: {response.status_code}, Body: {text}"
        )


@given(
    "a seed input that retrieves a pet by ID, producing a seed output with the pet's current status for MR2."
)
def _mr_MR2_seed_input(context):
    # Create a pet to ensure it exists (POST /pet)
    pet_data = {
        "id": 1,
        "name": "doggie",
        "category": {
            "id": 1,
            "name": "Dogs",
        },
        "photoUrls": ["url1", "url2"],
        "tags": [],
        "status": "available",
    }

    response_create = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_response_no_500(response_create, "MR2 Given - create pet")

    # Even if non-200, try to parse JSON to provide clearer error, but guarded
    created_body = _safe_json(response_create, "MR2 Given - create pet")
    pet_id = created_body.get("id", pet_data["id"])

    # Retrieve the pet to get the seed output (GET /pet/\{petId\})
    response_get = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(response_get, "MR2 Given - get pet by id")

    seed_body = _safe_json(response_get, "MR2 Given - get pet by id")

    # Store on context safely
    context.seed_pet_id = seed_body.get("id", pet_id)
    context.seed_response = seed_body


@when(
    "a follow-up input is created by updating the same pet so that only its status is changed to 'sold' while all other fields are kept the same in the request, and then retrieving the pet again by the same ID, yielding a follow-up output for MR2."
)
def _mr_MR2_followup_input(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("MR2 When - seed_response is missing from context")

    seed = context.seed_response

    # Build update payload, guarding missing keys with defaults
    update_data = {
        "id": seed.get("id", getattr(context, "seed_pet_id", 1)),
        "name": seed.get("name", "doggie"),
        "category": seed.get("category"),
        "photoUrls": seed.get("photoUrls", []),
        "tags": seed.get("tags", []),
        "status": "sold",
    }

    # Update pet (PUT /pet)
    response_update = requests.put(f"{BASE_URL}/pet", json=update_data, timeout=10)
    _check_response_no_500(response_update, "MR2 When - update pet")

    update_body = _safe_json(response_update, "MR2 When - update pet")
    pet_id = update_body.get("id", update_data["id"])

    # Retrieve updated pet (GET /pet/\{petId\})
    response_get = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_response_no_500(response_get, "MR2 When - get updated pet by id")

    followup_body = _safe_json(response_get, "MR2 When - get updated pet by id")

    context.followup_response = followup_body


@then(
    "the follow-up output should reflect the updated status 'sold', and all other pet details (such as name, category, photoUrls, and tags) should remain identical to the seed output for MR2."
)
def _mr_MR2_followup_output(context):
    if not hasattr(context, "seed_response"):
        raise AssertionError("MR2 Then - seed_response is missing from context")
    if not hasattr(context, "followup_response"):
        raise AssertionError("MR2 Then - followup_response is missing from context")

    seed = context.seed_response
    followup = context.followup_response

    # Compare with safe .get to avoid KeyError/TypeError
    assert followup.get("status") == "sold", (
        f"Status did not update to 'sold'. Actual: {followup.get('status')}"
    )
    assert followup.get("name") == seed.get("name"), "Name has changed"
    assert followup.get("category") == seed.get("category"), "Category has changed"
    assert followup.get("photoUrls", []) == seed.get("photoUrls", []), "Photo URLs have changed"
    assert followup.get("tags", []) == seed.get("tags", []), "Tags have changed"

# ----


BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8080/api/v3')






@given('a seed input that retrieves a specific pet by its identifier (and optionally confirms its presence in a filtered list, such as by status), producing a seed output that includes this pet for MR3.')
def step_mr_MR3_seed_input(context):
    # Create a pet to ensure it exists
    pet_data = {
        "id": 123,
        "name": "Fido",
        "photoUrls": ["http://example.com/photo.jpg"],
        "status": "available"
    }

    response_create = requests.post(f"{BASE_URL}/pet", json=pet_data, timeout=10)
    _check_500(response_create, "MR3 Given - create pet")
    context.seed_request = response_create

    seed_body = _safe_json(response_create)
    assert response_create.status_code == 200, f"Failed to create pet: {seed_body if seed_body is not None else response_create.text}"
    assert isinstance(seed_body, dict), "Create pet response body is not a JSON object."

    pet_id = seed_body.get("id")
    assert pet_id is not None, "Create pet response does not contain 'id'."
    context.seed_response = seed_body

    # Retrieve the pet to confirm its presence
    response_get = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_500(response_get, "MR3 Given - get pet by id")
    context.initial_get_request = response_get

    get_body = _safe_json(response_get)
    assert response_get.status_code == 200, f"Failed to retrieve pet: {get_body if get_body is not None else response_get.text}"
    assert isinstance(get_body, dict), "Get pet response body is not a JSON object."
    assert get_body.get("id") == pet_id, "Retrieved pet ID does not match seed pet ID."

    # Optionally confirm its presence in a filtered list by status=available
    response_filtered = requests.get(f"{BASE_URL}/pet/findByStatus", params={"status": "available"}, timeout=10)
    _check_500(response_filtered, "MR3 Given - find pets by status")
    context.initial_filtered_request = response_filtered

    filtered_body = _safe_json(response_filtered)
    assert response_filtered.status_code == 200, f"Failed to retrieve pets by status: {filtered_body if filtered_body is not None else response_filtered.text}"
    assert isinstance(filtered_body, list), "Filtered pets response is not a JSON array."

    # Store initial count and ensure our pet is present in the list
    context.initial_filtered_pets = filtered_body
    context.initial_filtered_count = len(filtered_body)

    found = any(isinstance(p, dict) and p.get("id") == pet_id for p in filtered_body)
    # If not found, we still can test the direct GET behavior, but record presence flag
    context.seed_pet_in_filtered_list = found


@when('a follow-up input is created by deleting this specific pet using its identifier, followed by another attempt to retrieve the same pet (and, if applicable, retrieve the filtered list again), yielding a follow-up output for MR3.')
def step_mr_MR3_followup_input(context):
    assert hasattr(context, "seed_response"), "Seed response is not available in context."
    seed_body = context.seed_response
    pet_id = seed_body.get("id")
    assert pet_id is not None, "Seed pet id is missing in context."

    # Delete the pet
    response_delete = requests.delete(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_500(response_delete, "MR3 When - delete pet")
    context.delete_request = response_delete

    delete_body = _safe_json(response_delete)
    # According to spec, 200 is expected for successful delete
    assert response_delete.status_code == 200, f"Failed to delete pet: {delete_body if delete_body is not None else response_delete.text}"

    # Attempt to retrieve the deleted pet
    response_get_after_delete = requests.get(f"{BASE_URL}/pet/{pet_id}", timeout=10)
    _check_500(response_get_after_delete, "MR3 When - get deleted pet")
    context.followup_request = response_get_after_delete
    context.followup_response = _safe_json(response_get_after_delete)

    # Retrieve the filtered list again by status=available
    response_filtered_after = requests.get(f"{BASE_URL}/pet/findByStatus", params={"status": "available"}, timeout=10)
    _check_500(response_filtered_after, "MR3 When - find pets by status after delete")
    context.followup_filtered_request = response_filtered_after
    context.followup_filtered_pets = _safe_json(response_filtered_after)


@then('the follow-up output should no longer return the deleted pet when retrieved by its identifier (for example, resulting in a not-found response) and should not include the deleted pet in any relevant filtered list, with the count of pets in that list reduced accordingly if no other changes have occurred for MR3.')
def step_mr_MR3_followup_output(context):
    assert hasattr(context, "followup_request"), "Follow-up request is not available in context."

    # For GET /pet/{petId} after delete: expect not-found (404) or at least not a successful retrieval of the pet
    resp = context.followup_request
    body = context.followup_response

    if resp.status_code == 200:
        # If server returns 200, ensure that it is not returning the deleted pet
        assert isinstance(body, dict), "Follow-up get response body is not a JSON object."
        assert body.get("id") != context.seed_response.get("id"), "Deleted pet was still returned with 200 OK."
    else:
        # Stronger expectation based on MR description: 404 not found
        assert resp.status_code == 404, f"Expected 404 after deleting pet, got {resp.status_code}."

    # Check filtered list: deleted pet should not be present and count should be reduced if it was present before
    assert hasattr(context, "followup_filtered_pets"), "Follow-up filtered pets are not available in context."
    filtered_after = context.followup_filtered_pets
    assert isinstance(filtered_after, list), "Follow-up filtered pets response is not a JSON array."

    pet_id = context.seed_response.get("id")
    # Ensure the deleted pet is not in the filtered list
    for pet in filtered_after:
        if isinstance(pet, dict):
            assert pet.get("id") != pet_id, "Deleted pet found in filtered list after deletion."

    # If the pet was present in the initial filtered list, the count should be reduced by at least one,
    # assuming no other changes occurred.
    if getattr(context, "seed_pet_in_filtered_list", False):
        initial_count = getattr(context, "initial_filtered_count", None)
        if isinstance(initial_count, int):
            assert len(filtered_after) <= initial_count - 1, (
                "Filtered list count was not reduced after deleting a pet that was previously present."
            )

# ----








@given("a seed input that retrieves a user by username, producing a seed output with the user's full set of details for MR5.")
def step_mr_MR5_seed_input(context):
    # Create a user to ensure it exists (POST /user)
    user_data = {
        "id": 10,
        "username": "testuser",
        "firstName": "John",
        "lastName": "Doe",
        "email": "john.doe@example.com",
        "password": "password",
        "phone": "1234567890",
        "userStatus": 1,
    }

    create_resp = requests.post(f"{BASE_URL}/user", json=user_data, timeout=10)
    _check_response_no_500(create_resp, "MR5 Given - create user")
    assert create_resp.status_code == 200, (
        f"MR5 Given - Failed to create user: {create_resp.status_code} {create_resp.text}"
    )

    # Retrieve the user to get the seed output (GET /user/\{username\})
    get_resp = requests.get(f"{BASE_URL}/user/testuser", timeout=10)
    context.seed_request = get_resp
    context.seed_response = _safe_json(get_resp, "MR5 Given - retrieve user")
    assert get_resp.status_code == 200, (
        f"MR5 Given - Failed to retrieve user: {get_resp.status_code} {get_resp.text}"
    )

    # Ensure required fields exist to avoid KeyError/TypeError later
    required_fields = ["id", "username", "firstName", "lastName", "email", "password", "phone", "userStatus"]
    for field in required_fields:
        assert field in context.seed_response, f"MR5 Given - Missing expected field '{field}' in seed response"


@when("a follow-up input is created by updating the same user so that only the email field is changed while all other fields are kept the same in the request, and then retrieving the user again by the same username, yielding a follow-up output for MR5.")
def step_mr_MR5_followup_input(context):
    seed = context.seed_response

    # Build updated user body for PUT /user/\{username\}
    updated_user_data = {
        "id": seed.get("id"),
        "username": seed.get("username"),
        "firstName": seed.get("firstName"),
        "lastName": seed.get("lastName"),
        "email": "new.email@example.com",  # Change email
        "password": seed.get("password"),
        "phone": seed.get("phone"),
        "userStatus": seed.get("userStatus"),
    }

    put_resp = requests.put(
        f"{BASE_URL}/user/{seed.get('username')}",
        json=updated_user_data,
        timeout=10,
    )
    _check_response_no_500(put_resp, "MR5 When - update user")
    assert put_resp.status_code == 200, (
        f"MR5 When - Failed to update user: {put_resp.status_code} {put_resp.text}"
    )

    # Retrieve the user again to get the follow-up output (GET /user/\{username\})
    get_resp = requests.get(f"{BASE_URL}/user/testuser", timeout=10)
    context.followup_request = get_resp
    context.followup_response = _safe_json(get_resp, "MR5 When - retrieve updated user")
    assert get_resp.status_code == 200, (
        f"MR5 When - Failed to retrieve updated user: {get_resp.status_code} {get_resp.text}"
    )


@then("the follow-up output should reflect the updated email value while all other user details (such as id, username, firstName, lastName, phone, and userStatus) remain identical to the seed output for MR5.")
def step_mr_MR5_followup_output(context):
    follow = context.followup_response
    seed = context.seed_response

    assert follow.get("email") == "new.email@example.com", "MR5 Then - Email was not updated correctly."

    # Check that all other fields remain the same
    assert follow.get("id") == seed.get("id"), "MR5 Then - ID has changed."
    assert follow.get("username") == seed.get("username"), "MR5 Then - Username has changed."
    assert follow.get("firstName") == seed.get("firstName"), "MR5 Then - First name has changed."
    assert follow.get("lastName") == seed.get("lastName"), "MR5 Then - Last name has changed."
    assert follow.get("phone") == seed.get("phone"), "MR5 Then - Phone has changed."
    assert follow.get("userStatus") == seed.get("userStatus"), "MR5 Then - User status has changed."
