Feature: Iteration 0 MRs

  Scenario: MR1 Adding a new pet with a given status should increase the count of pets with that status
    Given a seed input that retrieves the list of pets filtered by status 'available', producing a seed output with a count of available pets for MR1.
    When a follow-up input is created by adding a new pet whose status is set to 'available', and then retrieving again the list of pets filtered by status 'available', yielding a follow-up output for MR1.
    Then the follow-up output should include the newly added pet in the list of available pets and have a count of available pets that is greater than or equal to the seed output, and exactly one more than the seed output if no other changes have occurred in between for MR1.

  Scenario: MR2 Updating a pet's status should reflect in the pet's retrieved details
    Given a seed input that retrieves a pet by ID, producing a seed output with the pet's current status for MR2.
    When a follow-up input is created by updating the same pet so that only its status is changed to 'sold' while all other fields are kept the same in the request, and then retrieving the pet again by the same ID, yielding a follow-up output for MR2.
    Then the follow-up output should reflect the updated status 'sold', and all other pet details (such as name, category, photoUrls, and tags) should remain identical to the seed output for MR2.

  Scenario: MR3 Deleting a pet should make it unavailable for subsequent retrieval
    Given a seed input that retrieves a specific pet by its identifier (and optionally confirms its presence in a filtered list, such as by status), producing a seed output that includes this pet for MR3.
    When a follow-up input is created by deleting this specific pet using its identifier, followed by another attempt to retrieve the same pet (and, if applicable, retrieve the filtered list again), yielding a follow-up output for MR3.
    Then the follow-up output should no longer return the deleted pet when retrieved by its identifier (for example, resulting in a not-found response) and should not include the deleted pet in any relevant filtered list, with the count of pets in that list reduced accordingly if no other changes have occurred for MR3.

  Scenario: MR5 Updating user details should only change the specified fields
    Given a seed input that retrieves a user by username, producing a seed output with the user's full set of details for MR5.
    When a follow-up input is created by updating the same user so that only the email field is changed while all other fields are kept the same in the request, and then retrieving the user again by the same username, yielding a follow-up output for MR5.
    Then the follow-up output should reflect the updated email value while all other user details (such as id, username, firstName, lastName, phone, and userStatus) remain identical to the seed output for MR5.
